﻿Public Class Form1

    Private virtualui As New Cybele.Thinfinity.VirtualUI()

    Private Sub btnupload_Click(sender As Object, e As EventArgs) Handles Button1.Click
        virtualui.UploadFile("C:\temp")

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'virtualui.Start()

    End Sub
End Class
