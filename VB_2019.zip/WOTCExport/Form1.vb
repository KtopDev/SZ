﻿Imports System.Security.Principal
Imports System.DirectoryServices.AccountManagement
Imports Excel = Microsoft.Office.Interop.Excel

Public Class FrmWOTCMain
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        '1) authenticate against AD
        '2) registry authenticate bypass
        '3) load statelist
        '4) default to first (alabama)
        '5) load branches in that state, default to 'checked'
        '6) retrieve defauly exportpath, dispaly
        '7) retrieve default filename and type.
        '8) append currentdate to filename


        Debug = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\Software\Reportdriver", "Debug", Nothing)
        DomainName = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\Software\Reportdriver", "DomainName", Nothing)
        DomainConnector = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\Software\Reportdriver", "DomainConnector", Nothing)
        '2 database connector information
        DatabaseIP = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\Software\Reportdriver", "DatabaseIP", Nothing)
        DatabaseName = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\Software\Reportdriver", "Database", Nothing)

        DatabaseIP = "192.168.100.163"

        ' TextBox2.Text = Date.Now


        Dim T As New PrincipalContext(ContextType.Domain, DomainName, DomainConnector)

        If GroupPrincipal.FindByIdentity(T, "Report_Personnel") IsNot Nothing Then
            If UserPrincipal.Current.IsMemberOf(GroupPrincipal.FindByIdentity(T, "Report_Personnel")) = True Then
                'user is authorized
                CONNECTIONSTRING2 = "Server=" & DatabaseIP & ";Database=SZEmpAppConsolidated;User Id=report;Password=report123;"
                CN2 = New SqlClient.SqlConnection
                CN2.ConnectionString = CONNECTIONSTRING2
                CN3 = New SqlClient.SqlConnection
                CN3.ConnectionString = CONNECTIONSTRING2
                CN4 = New SqlClient.SqlConnection
                CN4.ConnectionString = CONNECTIONSTRING2

                CN5 = New SqlClient.SqlConnection
                CN5.ConnectionString = CONNECTIONSTRING2
                CN6 = New SqlClient.SqlConnection
                CN6.ConnectionString = CONNECTIONSTRING2


                Dim cmd As New SqlClient.SqlCommand

                cmd.Connection = CN2

                If CN2.State <> ConnectionState.Open Then
                    CN2.Open()
                End If

                Me.Text = "  WOTC Export Version 2019-5    Username: " & My.User.Name

                ComboBox1.Items.Clear()

                ' Dim cmd As New SqlClient.SqlCommand
                cmd.Connection = CN2
                cmd.CommandType = CommandType.Text
                cmd.CommandText = "select name from szempappconsolidated.dbo.states order by name"


                ' Dim i As Integer = 0
                Dim RS As SqlClient.SqlDataReader
                RS = cmd.ExecuteReader
                While RS.Read
                    ' i = i + 1
                    ' RS.Read()
                    ComboBox1.Items.Add(RS.Item(0).ToString)


                End While
                RS.Close()
                RS.Dispose()

                CN2.Close()
                ToolStripStatusLabel1.Text = "Ready"
            Else
                MsgBox("You are not authorized to access this system, or a domain controller cannot verify your credentials.")
                End

            End If
        Else
            MsgBox("Please notify the system administrator that the Active Directory security group 'Report_Personnel' does not exist in this domain or a domain controller cannot be contacted.")
            End

        End If




    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged


        ToolStripStatusLabel1.Text = "Ready"

        Dim cmd As New SqlClient.SqlCommand

        cmd.Connection = CN2

        If CN2.State <> ConnectionState.Open Then
            CN2.Open()
        End If



        'Dim cmd As New SqlClient.SqlCommand
        cmd.Connection = CN2
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select abbreviation from szempappconsolidated.dbo.states where name = @name"
        cmd.Parameters.AddWithValue("@Name", ComboBox1.Text)

        Dim retval
        retval = cmd.ExecuteScalar



        cmd.Parameters.Clear()
        ' Dim i As Integer = 0
        cmd.CommandText = "Select CommonName from szempappconsolidated.dbo.BranchData where BranchState=@State order by commonname"
        cmd.Parameters.AddWithValue("@state", retval)

        CheckedListBox1.Items.Clear()

        Dim RS As SqlClient.SqlDataReader
        RS = cmd.ExecuteReader
        While RS.Read
            CheckedListBox1.Items.Add(RS.Item(0).ToString, True)
        End While
        RS.Close()
        RS.Dispose()
        cmd.Parameters.Clear()
        cmd.CommandText = "select ExportFilePath from szempappconsolidated.dbo.states where name = @name"
        cmd.Parameters.AddWithValue("@Name", ComboBox1.Text)
        retval = cmd.ExecuteScalar
        TextBox3.Text = retval.ToString

        cmd.Parameters.Clear()
        cmd.CommandText = "select ExportFileName from szempappconsolidated.dbo.states where name = @name"
        cmd.Parameters.AddWithValue("@Name", ComboBox1.Text)
        retval = cmd.ExecuteScalar
        TextBox4.Text = retval.ToString & "_" & FormatDateTime(DateAndTime.Now, DateFormat.ShortDate)

        cmd.Parameters.Clear()
        cmd.CommandText = "select FileExtention from szempappconsolidated.dbo.states where name = @name"
        cmd.Parameters.AddWithValue("@Name", ComboBox1.Text)
        retval = cmd.ExecuteScalar
        CurrentFileExtention = retval.ToString




        CN2.Close()


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Button1.Enabled = False
        Me.Cursor = Cursors.WaitCursor

        ToolStripStatusLabel1.Text = "Please Wait, Loading."

        'need to drop ##Tennessee_export if exists.




        Select Case Trim(ComboBox1.Text)


            Case "Alabama"
                'Call Export_Alabama()
                Call Export_Tennessee()
            Case "Arizona"
                Call Export_Tennessee()
              ' MsgBox("This state does not have an upload system.")
            Case "Colorado"
                Call Export_Tennessee()
               ' MsgBox("This state does not have an upload system.")
            Case "Florida"
                'Call Export_Florida()
                Call Export_Tennessee()
            Case "Georgia"
                Call Export_Tennessee()
                'MsgBox("This state does not have an upload system.")
            Case "Nevada"
                Call Export_Tennessee()
                'MsgBox("This state does not have an upload system.")
            Case "North Carolina"
                Call Export_Tennessee()
                'Call Export_NorthCarolina()
            Case "South Carolina"
                Call Export_Tennessee()
                'MsgBox("This state does not have an upload system.")
            Case "Tennessee"
                Call Export_Tennessee()
            Case "Texas"
                'Call Export_Tennessee()
                Call Export_Texas()
            Case "Virginia"
                Call Export_Tennessee()
                'MsgBox("This state does not have an upload system.")
        End Select

        ToolStripStatusLabel1.Text = "Ready"
        Button1.Enabled = True
        Me.Cursor = Cursors.Default

    End Sub
    Private Function ToLen(text As String, length As Integer)
        If text.Length > length Then
            Return text.Substring(0, length)
        Else
            Return text.PadRight(length)
        End If
    End Function


    Private Sub Export_Alabama()
        Dim cmd As New SqlClient.SqlCommand

        cmd.Connection = CN2
        Dim retval
        If CN2.State <> ConnectionState.Open Then
            CN2.Open()
        End If


        Dim branchstring As String = ""
        'Dim i As Integer
        For Each DR As String In CheckedListBox1.CheckedItems
            cmd.Connection = CN2
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "Select branchid from szempappconsolidated.dbo.BranchData where commonname=@name"
            cmd.Parameters.AddWithValue("@name", DR.ToString)
            retval = cmd.ExecuteScalar
            cmd.Parameters.Clear()

            branchstring = branchstring + "'" + Trim(retval.ToString) + "',"

        Next
        'trim off the last comma
        branchstring = Mid(branchstring, 1, Len(branchstring) - 1)



        cmd.CommandText = "Select distinct SSN, branchID into ##Alabama_Export from szempappconsolidated.dbo.personstatus where Status='U' and WOTC=1 and date>='" + Trim(TextBox1.Text) + "' and date<='" + Trim(TextBox2.Text) + "' and BranchID In (" + branchstring + ") order by BranchID"
        'MsgBox(branchstring)
        ' MsgBox(cmd.CommandText)
        cmd.Parameters.AddWithValue("@Sdate", TextBox1.Text)
        cmd.Parameters.AddWithValue("@Edate", TextBox2.Text)
        cmd.Parameters.AddWithValue("@Str", branchstring)

        cmd.ExecuteNonQuery()
        cmd.Parameters.Clear()






        'cmd.CommandText = "Select distinct SSN, branchID into ##Alabama_Export from szempappconsolidated.dbo.personstatus where Status='U' and WOTC=1 and date >= @Sdate and date <= @EDate and BranchID In ( @Str ) order by BranchID"
        'cmd.Parameters.AddWithValue("@Sdate", TextBox1.Text)
        'cmd.Parameters.AddWithValue("@Edate", TextBox2.Text)
        'cmd.Parameters.AddWithValue("@Str", branchstring)
        'cmd.ExecuteNonQuery()
        'cmd.Parameters.Clear()

        ' bulk upload needs to in excel xslx file with header record.
        ' should be located in my documents\Tennessee_WOTC_Export, then saved as Tennessee_WOTC_Export_MM_DD_YYYY.xslx


        Call Export_Alabama_TXT()

        If CN2.State <> ConnectionState.Closed Then
            CN2.Close()
        End If

    End Sub

    Private Sub Export_Alabama_TXT()
        Dim cmd As New SqlClient.SqlCommand
        Dim cmd2 As New SqlClient.SqlCommand
        Dim cmd3 As New SqlClient.SqlCommand
        Dim cmd4 As New SqlClient.SqlCommand
        Dim cmd5 As New SqlClient.SqlCommand
        Dim cmd6 As New SqlClient.SqlCommand


        cmd.Connection = CN2

        cmd3.Connection = CN4



        cmd.CommandType = CommandType.Text
        Dim retval
        If CN2.State <> ConnectionState.Open Then
            CN2.Open()
        End If
        If CN3.State <> ConnectionState.Open Then
            CN3.Open()
        End If
        If CN4.State <> ConnectionState.Open Then
            CN4.Open()
        End If
        If CN5.State <> ConnectionState.Open Then
            CN5.Open()
        End If
        If CN6.State <> ConnectionState.Open Then
            CN6.Open()
        End If
        cmd2.Connection = CN3
        cmd2.CommandType = CommandType.Text
        Dim rs2 As SqlClient.SqlDataReader
        Dim rs3 As SqlClient.SqlDataReader
        Dim rs4 As SqlClient.SqlDataReader
        Dim rs5 As SqlClient.SqlDataReader

        Dim fedein As String = "582633827"
        Dim wstring As String = ""
        Dim linectr As Integer = 1
        cmd.CommandText = "Select count(ssn) from ##Alabama_Export"
        ' Dim retval
        retval = cmd.ExecuteScalar
        'If IsDBNull(retval) = False And retval > 0 Then
        Dim file As System.IO.StreamWriter
        file = My.Computer.FileSystem.OpenTextFileWriter(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\AlabamaExport.txt", False)

        file.WriteLine(ToLen("ver4", 6) + ToLen(fedein, 10) + ToLen("AlabamaExport.txt", 64) + ToLen(retval.ToString, 10) + Chr(13) + Chr(10))

        cmd.CommandText = "select * from ##Alabama_Export"
            Dim rs As SqlClient.SqlDataReader
            rs = cmd.ExecuteReader

        wstring = ""

        While rs.Read

            cmd2.Parameters.Clear()
            cmd3.Parameters.Clear()
            cmd4.Parameters.Clear()
            cmd5.Parameters.Clear()

            cmd2.CommandText = "Select * from szempappconsolidated.dbo.apppage1 where branchid=@branchid and SSN=@ssn"
            cmd2.Parameters.AddWithValue("@BranchID", rs.Item("Branchid").ToString)
            cmd2.Parameters.AddWithValue("@ssn", rs.Item("ssn").ToString)
            rs2 = cmd2.ExecuteReader

            If rs2.HasRows = True Then
                rs2.Read()
            Else
                GoTo BailOut
            End If

            cmd3.Connection = CN4
            cmd3.CommandText = "Select * from szempappconsolidated.dbo.apppage8850 where branchid=@branchid and SSN=@ssn"
            cmd3.Parameters.AddWithValue("@BranchID", rs.Item("Branchid").ToString)
            cmd3.Parameters.AddWithValue("@ssn", rs.Item("ssn").ToString)
            rs3 = cmd3.ExecuteReader
            If rs3.HasRows = True Then
                rs3.Read()
            Else
                GoTo BailOut
            End If

            cmd4.Connection = CN5
            cmd4.CommandText = "Select * from szempappconsolidated.dbo.apppage90612015 where branchid=@branchid and SSN=@ssn"
            cmd4.Parameters.AddWithValue("@BranchID", rs.Item("Branchid").ToString)
            cmd4.Parameters.AddWithValue("@ssn", rs.Item("ssn").ToString)
            rs5 = cmd4.ExecuteReader
            If rs5.HasRows = True Then
                rs5.Read()
            Else
                GoTo BailOut
            End If

            cmd5.Connection = CN6
            cmd5.CommandText = "Select * from szempappconsolidated.dbo.applicationstatusaudit where branchid=@branchid and SSN=@ssn"
            cmd5.Parameters.AddWithValue("@BranchID", rs.Item("Branchid").ToString)
            cmd5.Parameters.AddWithValue("@ssn", rs.Item("ssn").ToString)
            rs4 = cmd5.ExecuteReader

            If rs4.HasRows = True Then
                rs4.Read()
            Else
                GoTo BailOut
            End If


            wstring = ToLen("582633827", 12)
            wstring = wstring + ToLen("582633827", 0)
            wstring = wstring + ToLen(rs2.Item("SSN").ToString, 9)
            wstring = wstring + ToLen(rs2.Item("FirstName").ToString, 10)
            wstring = wstring + ToLen(rs2.Item("MiddleInitial").ToString, 1)
            wstring = wstring + ToLen(rs2.Item("LastName").ToString, 19)
            wstring = wstring + ToLen(rs2.Item("Address").ToString + " " + rs2.Item("AptNumber").ToString, 30)
            wstring = wstring + ToLen(rs2.Item("City").ToString, 20)
            wstring = wstring + ToLen(rs2.Item("State").ToString, 20)
            wstring = wstring + ToLen(rs2.Item("Zipcode").ToString, 5) + Space(119)
            wstring = wstring + "Y"
            wstring = wstring + ToLen(ALDateFormat(rs3.Item("AckDate").ToString), 8)
            Dim zval As String = ""
            If rs3.Item("chk4").ToString = True Then
                zval = "4"
            ElseIf rs3.Item("chk6").ToString = True Then
                zval = "6"
            Else
                zval = " "
            End If '280
            wstring = wstring + zval
            wstring = wstring + ToLen(ALDateFormat(rs3.Item("AckDate").ToString), 8)
            wstring = wstring + ToLen(ALDateFormat(rs4.Item("completionDate").ToString), 8)
            wstring = wstring + ToLen(ALDateFormat(rs4.Item("completionDate").ToString), 8)
            wstring = wstring + ToLen(ALDateFormat(rs4.Item("completionDate").ToString), 8)
            wstring = wstring + Space(22)
            wstring = wstring + ToLen(ALDateFormat(rs3.Item("AckDate").ToString), 8)
            wstring = wstring + "072547N"
            wstring = wstring + YN(rs5.Item("V9061Q13B").ToString)
            wstring = wstring + YN(rs5.Item("V9061Q13C").ToString)
            wstring = wstring + YN(rs5.Item("V9061Q14A").ToString)
            wstring = wstring + YN(rs5.Item("V9061Q14B").ToString)
            wstring = wstring + YN(rs5.Item("V9061Q15A").ToString)
            wstring = wstring + YN(rs5.Item("V9061Q15B").ToString)
            wstring = wstring + YN(rs5.Item("V9061Q15C").ToString)
            wstring = wstring + YN(rs5.Item("V9061Q16A").ToString)
            wstring = wstring + YN(rs5.Item("V9061Q16B").ToString)
            wstring = wstring + YN(rs5.Item("V9061Q16C").ToString)
            wstring = wstring + YN(rs5.Item("V9061Q16D").ToString)
            wstring = wstring + ToLen(rs5.Item("V9061Q16Recipient").ToString, 30)
            wstring = wstring + ToLen(GetCity(rs5.Item("V9061Q16CityState").ToString), 20)
            wstring = wstring + ToLen(getstate(rs5.Item("V9061Q16CityState").ToString), 2)
            wstring = wstring + ToLen(GetCity(rs5.Item("V9061Q16CityState").ToString), 20)
            wstring = wstring + YN(rs5.Item("V9061Q17F").ToString)
            wstring = wstring + ToLen(ALDateFormat(rs5.Item("V9061Q17DOC").ToString), 8)
            wstring = wstring + ToLen(ALDateFormat(rs5.Item("V9061Q17DOR").ToString), 8)
            wstring = wstring + YN(rs5.Item("V9061Q18A").ToString) + Space(21)
            wstring = wstring + YN(rs5.Item("V9061Q20A").ToString) + Space(319) + "A"
            wstring = wstring + ToLen(ALDateFormat(rs5.Item("AckDate").ToString), 8) + Space(22)
            wstring = wstring + ToLen("E. Williams", 12) + Space(3)

            wstring = wstring + "16" + "16" + "N"

            'rs3
            wstring = wstring + YN(rs3.Item("chk2").ToString)
            wstring = wstring + YN(rs3.Item("chk3").ToString)
            wstring = wstring + YN(rs3.Item("chk4").ToString)
            wstring = wstring + YN(rs3.Item("chk5").ToString)
            wstring = wstring + YN(rs3.Item("chk6").ToString)



            If rs5.Item("V9061Q17F").ToString = True Then
                wstring = wstring + "F"
            Else
                wstring = wstring + " "
            End If

            If rs5.Item("V9061Q17S").ToString = True Then
                wstring = wstring + "F"
            Else
                wstring = wstring + " "
            End If

            wstring = wstring + YN(rs5.Item("V9061Q21A").ToString)
            wstring = wstring + YN(rs5.Item("V9061Q22A").ToString) + "N" + Space(8)
            wstring = wstring + YN(rs5.Item("V9061Q23A").ToString) + Space(1)
            wstring = wstring + YN(rs3.Item("chk5").ToString) + Space(235)


            file.WriteLine(wstring)
                wstring = ""
            linectr = linectr + 1
BailOut:

            rs2.Close()
            rs3.Close()
            rs4.Close()
            rs5.Close()




        End While


            'need to write header record.


            file.Close()

        MsgBox("Your file is named 'AlabamaExport.txt' and is located in your 'my documents' folder. Please rename the file and upload it to the Alabama WOTC site.")

        'Else
        '    MsgBox("Input table has no rows or does not exist.")

        'End If

        If CN2.State <> ConnectionState.Closed Then
            CN2.Close()
        End If
        If CN2.State <> ConnectionState.Closed Then
            CN2.Close()
        End If
        If CN3.State <> ConnectionState.Closed Then
            CN3.Close()
        End If
        If CN4.State <> ConnectionState.Closed Then
            CN4.Close()
        End If
        If CN5.State <> ConnectionState.Closed Then
            CN5.Close()
        End If
        If CN6.State <> ConnectionState.Open Then
            CN6.Open()
        End If



    End Sub






    Private Sub Export_NorthCarolina()
        Dim cmd As New SqlClient.SqlCommand

        cmd.Connection = CN2
        Dim retval
        If CN2.State <> ConnectionState.Open Then
            CN2.Open()
        End If


        Dim branchstring As String = ""
        'Dim i As Integer
        For Each DR As String In CheckedListBox1.CheckedItems
            cmd.Connection = CN2
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "Select branchid from szempappconsolidated.dbo.BranchData where commonname=@name"
            cmd.Parameters.AddWithValue("@name", DR.ToString)
            retval = cmd.ExecuteScalar
            cmd.Parameters.Clear()

            branchstring = branchstring + "'" + retval.ToString + "',"

        Next
        'trim off the last comma
        branchstring = Mid(branchstring, 1, Len(branchstring) - 1)



        cmd.CommandText = "Select distinct SSN, branchID into ##NorthCarolina_Export from szempappconsolidated.dbo.personstatus where Status='U' and WOTC=1 and date>='" + Trim(TextBox1.Text) + "' and date<='" + Trim(TextBox2.Text) + "' and BranchID In (" + branchstring + ") order by BranchID"

        'cmd.CommandText = "Select distinct SSN, branchID into ##NorthCarolina_Export from szempappconsolidated.dbo.personstatus where Status='U' and WOTC=1 and date >= @Sdate and date <= @EDate and BranchID In ( @Str ) order by BranchID"
        cmd.Parameters.AddWithValue("@Sdate", TextBox1.Text)
        cmd.Parameters.AddWithValue("@Edate", TextBox2.Text)
        cmd.Parameters.AddWithValue("@Str", branchstring)
        cmd.ExecuteNonQuery()
        cmd.Parameters.Clear()


        'need to delete those without a 8850 or 9061
        cmd.CommandText = "Delete from ##NorthCarolina_export where not exists(select SSN from szempappconsolidated.dbo.apppage90612015 where ssn=##northCarolina_Export.ssn and branchid=##northCarolina_Export.BranchID)"
        cmd.ExecuteNonQuery()

        cmd.CommandText = "Delete from ##NorthCarolina_export where not exists(select SSN from szempappconsolidated.dbo.apppage8850 where ssn=##northCarolina_Export.ssn and branchid=##northCarolina_Export.BranchID)"
        cmd.ExecuteNonQuery()

        ' bulk upload needs to in excel xslx file with header record.
        ' should be located in my documents\Tennessee_WOTC_Export, then saved as Tennessee_WOTC_Export_MM_DD_YYYY.xslx


        Export_North_Carolina_TXT()



        If CN2.State <> ConnectionState.Closed Then
            CN2.Close()
        End If




    End Sub
    Private Sub Export_North_Carolina_TXT()

        Dim cmd As New SqlClient.SqlCommand
        Dim cmd2 As New SqlClient.SqlCommand
        Dim cmd3 As New SqlClient.SqlCommand
        Dim cmd4 As New SqlClient.SqlCommand
        Dim cmd5 As New SqlClient.SqlCommand
        Dim cmd6 As New SqlClient.SqlCommand
        Dim cmd7 As New SqlClient.SqlCommand
        cmd.Connection = CN2
        cmd.CommandType = CommandType.Text
        Dim retval

        If CN.State <> ConnectionState.Open Then
            CN.Open()
        End If

        If CN2.State <> ConnectionState.Open Then
            CN2.Open()
        End If
        If CN3.State <> ConnectionState.Open Then
            CN3.Open()
        End If
        If CN4.State <> ConnectionState.Open Then
            CN4.Open()
        End If
        If CN5.State <> ConnectionState.Open Then
            CN5.Open()
        End If
        If CN6.State <> ConnectionState.Open Then
            CN6.Open()
        End If
        cmd2.Connection = CN3
        cmd2.CommandType = CommandType.Text
        Dim rs2 As SqlClient.SqlDataReader
        Dim rs3 As SqlClient.SqlDataReader
        Dim rs4 As SqlClient.SqlDataReader
        Dim rs5 As SqlClient.SqlDataReader
        Dim rs6 As SqlClient.SqlDataReader
        Dim rs7 As SqlClient.SqlDataReader
        Dim County As String
        Dim fedein As String = "58-2633827"
        Dim wstring As String = ""
        Dim linectr As Integer = 1
        cmd.CommandText = "Select count(ssn) from ##NorthCarolina_Export"
        'Dim retval
        retval = cmd.ExecuteScalar
        If IsDBNull(retval) = False And retval > 0 Then
            Dim file As System.IO.StreamWriter
            file = My.Computer.FileSystem.OpenTextFileWriter(My.Computer.FileSystem.SpecialDirectories.MyDocuments + "\NorthCarolinaExport.txt", False)

            file.WriteLine(ToLen("ver4", 6) + ToLen(fedein, 10) + ToLen("NorthCarolinaExport.txt", 64) + ToLen(retval.ToString, 10) + Chr(13) + Chr(10))

            cmd.CommandText = "select * from ##NorthCarolina_Export"
            Dim rs As SqlClient.SqlDataReader
            rs = cmd.ExecuteReader



            While rs.Read




                cmd2.Parameters.Clear()
                cmd2.CommandText = "Select * from szempappconsolidated.dbo.apppage1 where branchid=@branchid and SSN=@ssn"
                cmd2.Parameters.AddWithValue("@BranchID", rs.Item("Branchid").ToString)
                cmd2.Parameters.AddWithValue("@ssn", rs.Item("ssn").ToString)
                rs2 = cmd2.ExecuteReader


                cmd4.CommandType = CommandType.Text
                cmd4.Connection = CN4
                cmd4.CommandText = "Select * from szempappconsolidated.dbo.apppage8850 where branchid=@branchid and SSN=@ssn"
                cmd4.Parameters.AddWithValue("@BranchID", rs.Item("Branchid").ToString)
                cmd4.Parameters.AddWithValue("@ssn", rs.Item("ssn").ToString)
                rs3 = cmd4.ExecuteReader


                cmd5.CommandType = CommandType.Text
                cmd5.Connection = CN5
                cmd5.CommandText = "Select * from szempappconsolidated.dbo.apppage90612015 where branchid=@branchid and SSN=@ssn"
                cmd5.Parameters.AddWithValue("@BranchID", rs.Item("Branchid").ToString)
                cmd5.Parameters.AddWithValue("@ssn", rs.Item("ssn").ToString)
                rs5 = cmd5.ExecuteReader


                cmd3.CommandType = CommandType.Text
                cmd3.Connection = CN6
                cmd3.CommandText = "Select * from szempappconsolidated.dbo.applicationstatusaudit where branchid=@branchid and SSN=@ssn"
                cmd3.Parameters.AddWithValue("@BranchID", rs.Item("Branchid").ToString)
                cmd3.Parameters.AddWithValue("@ssn", rs.Item("ssn").ToString)
                rs6 = cmd3.ExecuteReader

                cmd7.CommandType = CommandType.Text
                cmd7.Connection = CN
                cmd7.CommandText = "Select County from szempappconsolidated.dbo.branchdata where branchid=@Branchid"
                cmd7.Parameters.AddWithValue("@Branchid", rs.Item("Branchid").ToString)
                County = cmd.ExecuteScalar


                If rs6.HasRows = False Or rs5.HasRows = False Or rs3.HasRows = False Then
                    GoTo SkipOut

                End If



                rs2.Read()
                rs3.Read()
                rs6.Read()
                rs5.Read()


                wstring = wstring + ToLen(rs2.Item("LastName").ToString, 64)
                wstring = wstring + ToLen(rs2.Item("FirstName").ToString, 64)
                wstring = wstring + ToLen(rs2.Item("MiddleInitial").ToString, 64)
                wstring = wstring + ToLen(rs2.Item("SSN").ToString, 9)
                wstring = wstring + ToLen(NCDateFormat(rs2.Item("Birthdate").ToString), 8)
                wstring = wstring + ToLen(rs2.Item("Address").ToString + rs2.Item("Aptnumber").ToString, 128)
                wstring = wstring + ToLen(rs2.Item("City").ToString, 32)
                wstring = wstring + ToLen(rs2.Item("State").ToString, 9)
                wstring = wstring + ToLen(rs2.Item("ZIPCode").ToString, 5)
                wstring = wstring + ToLen(NCPhoneFormat(rs2.Item("Cellphone").ToString), 12)
                wstring = wstring + Space(10)
                'need to put in county here.
                wstring = wstring + ToLen(County, 32)
                '
                wstring = wstring + ToLen(NCDateFormat(rs6.Item("StartDate").ToString), 8)
                wstring = wstring + ToLen(NCDateFormat(rs6.Item("CompletionDate").ToString), 8)
                wstring = wstring + ToLen(NCDateFormat(rs6.Item("CompletionDate").ToString), 8)
                wstring = wstring + ToLen(NCDateFormat(rs6.Item("CompletionDate").ToString), 8)
                wstring = wstring + "N" + Space(8)
                wstring = wstring + ToLen(rs2.Item("ZIPCode").ToString, 5)
                wstring = wstring + "  7.25"
                wstring = wstring + ToLen("General Labor", 32)
                wstring = wstring + "47"
                wstring = wstring + ToLen("Harris Ventures DBA Staff Zone", 64)
                wstring = wstring + ToLen("58-2633827", 10)
                wstring = wstring + ToLen("863 Holcomb Bridge Road", 128)
                wstring = wstring + ToLen("Roswell", 32)
                wstring = wstring + "GA"
                wstring = wstring + "30076"
                wstring = wstring + "770-645-6134"
                wstring = wstring + Space(54)

                '8850
                wstring = wstring + YN(rs3.Item("chk1").ToString)
                wstring = wstring + YN(rs3.Item("chk2").ToString)
                wstring = wstring + YN(rs3.Item("chk3").ToString)
                wstring = wstring + YN(rs3.Item("chk4").ToString)
                wstring = wstring + YN(rs3.Item("chk5").ToString)
                wstring = wstring + YN(rs3.Item("chk6").ToString)
                wstring = wstring + YN(rs3.Item("chk7").ToString)
                wstring = wstring + ToLen(NCDateFormat(rs3.Item("AckDate").ToString), 8)
                wstring = wstring + "N"
                '9061
                wstring = wstring + YN(rs5.Item("V9061Q13A").ToString)
                wstring = wstring + YN(rs5.Item("V9061Q13B").ToString)
                wstring = wstring + ToLen(rs5.Item("V9061Q13Recipient").ToString, 64)
                wstring = wstring + Mid(getstate(rs5.Item("V9061Q13citystate").ToString), 1, 2)
                wstring = wstring + ToLen(GetCity(rs5.Item("V9061Q13citystate").ToString), 32)
                wstring = wstring + YN(rs5.Item("V9061Q13B").ToString)
                wstring = wstring + YN(rs5.Item("V9061Q13C").ToString)
                wstring = wstring + YN(rs5.Item("V9061Q13D").ToString)
                wstring = wstring + YN(rs5.Item("V9061Q13E").ToString)
                wstring = wstring + YN(rs5.Item("V9061Q14A").ToString)
                wstring = wstring + YN(rs5.Item("V9061Q14B").ToString)
                wstring = wstring + ToLen(rs5.Item("V9061Q14Recipient").ToString, 64)
                wstring = wstring + Mid(getstate(rs5.Item("V9061Q14citystate").ToString), 1, 2)
                wstring = wstring + ToLen(GetCity(rs5.Item("V9061Q14citystate").ToString), 32)

                wstring = wstring + YN(rs5.Item("V9061Q15A").ToString)
                wstring = wstring + YN(rs5.Item("V9061Q15B").ToString)
                wstring = wstring + YN(rs5.Item("V9061Q15C").ToString)

                wstring = wstring + YN(rs5.Item("V9061Q16A").ToString)
                wstring = wstring + YN(rs5.Item("V9061Q15B").ToString)
                wstring = wstring + YN(rs5.Item("V9061Q15C").ToString)

                wstring = wstring + YN(rs5.Item("V9061Q16A").ToString)
                wstring = wstring + YN(rs5.Item("V9061Q16B").ToString)
                wstring = wstring + YN(rs5.Item("V9061Q16C").ToString)
                wstring = wstring + YN(rs5.Item("V9061Q16D").ToString)
                wstring = wstring + ToLen(rs5.Item("V9061Q16Recipient").ToString, 64)
                wstring = wstring + Mid(getstate(rs5.Item("V9061Q16citystate").ToString), 1, 2)
                wstring = wstring + ToLen(GetCity(rs5.Item("V9061Q16citystate").ToString), 32)

                wstring = wstring + YN(rs5.Item("V9061Q17A").ToString)
                wstring = wstring + ToLen(NCDateFormat(rs5.Item("V9061Q17DOC").ToString), 8)
                wstring = wstring + ToLen(NCDateFormat(rs5.Item("V9061Q17DOR").ToString), 8)
                wstring = wstring + YN(rs5.Item("V9061Q17F").ToString)
                wstring = wstring + YN(rs5.Item("V9061Q17S").ToString)

                wstring = wstring + YN(rs5.Item("V9061Q18A").ToString)
                wstring = wstring + YN(rs5.Item("V9061Q19A").ToString)
                wstring = wstring + YN(rs5.Item("V9061Q20A").ToString)
                wstring = wstring + YN(rs5.Item("V9061Q21A").ToString)
                wstring = wstring + YN(rs5.Item("V9061Q22A").ToString)
                wstring = wstring + YN(rs5.Item("V9061Q23A").ToString)
                wstring = wstring + ToLen(rs5.Item("V9061Q23State").ToString, 2)
                wstring = wstring + Space(128)
                wstring = wstring + ToLen("Applicant", 32)
                wstring = wstring + ToLen(NCDateFormat(rs5.Item("AckDate").ToString), 8)

                file.WriteLine(wstring)
                wstring = ""
                linectr = linectr + 1


SkipOut:

                cmd2.Parameters.Clear()
                cmd3.Parameters.Clear()
                cmd4.Parameters.Clear()
                cmd5.Parameters.Clear()
                cmd6.Parameters.Clear()
                cmd7.Parameters.Clear()
                rs2.Close()
                rs3.Close()
                rs6.Close()
                rs5.Close()
                rs7.Close()

            End While


            'need to write header record.


            file.Close()

            MsgBox("Your file is named 'NorthCarolinaExport.txt' and is located in your 'my documents' folder. Please rename the file and upload it to the North Carolina WOTC site.")

        Else
            MsgBox("Input table has no rows or does not exist.")

        End If

        If CN.State <> ConnectionState.Closed Then
            CN.Close()
        End If
        If CN2.State <> ConnectionState.Closed Then
            CN2.Close()
        End If
        If CN2.State <> ConnectionState.Closed Then
            CN2.Close()
        End If
        If CN3.State <> ConnectionState.Closed Then
            CN3.Close()
        End If
        If CN4.State <> ConnectionState.Closed Then
            CN4.Close()
        End If
        If CN5.State <> ConnectionState.Closed Then
            CN5.Close()
        End If
        If CN6.State <> ConnectionState.Open Then
            CN6.Open()
        End If


    End Sub

    Private Function ALDateFormat(ByVal indate As DateTime) As String
        If IsDBNull(indate) = False Then
            Return CDate(indate).ToString("MMddyyyy")
        Else
            Return ""
        End If
    End Function
    Private Function TNDateFormat(ByVal indate As DateTime) As String
        If IsDBNull(indate) = False Then
            Return CDate(indate).ToString("MM/dd/yyyy")
        Else
            Return ""
        End If
    End Function

    Private Function TXDateFormat(ByVal indate As DateTime) As String

        If IsDBNull(indate) = False Then
            Return CDate(indate).ToString("yyyyMMdd")
        Else
            Return ""
        End If





    End Function

    Private Function NCPhoneFormat(ByVal phoneno As String) As String

        Return Mid(phoneno, 1, 3) & "-" & Mid(phoneno, 4, 3) & "-" & Mid(phoneno, 7, 4)

    End Function

    Private Function NCDateFormat(ByVal indate As DateTime) As String

        'YYYYMMDD
        If IsDBNull(indate) = False Then
            Return CDate(indate).ToString("yyyyMMdd")
        Else
            Return ""
        End If

    End Function
    Private Function FLDateFormat(ByVal indate) As String
        If IsDBNull(indate) = False Then
            Return CDate(indate).ToString("MM/dd/yyyy").ToString
        Else
            Return ""
        End If


    End Function
    Private Function GetCity(ByVal inValue As String) As String
        'fall river MA

        If inValue <> "" Then

            If InStr(inValue, ",") >= 1 Then

                Return Mid(inValue, 1, InStr(inValue, ",") - 1)
            Else
                Return inValue
            End If

        Else
                Return ""
        End If


    End Function
    Private Function getstate(ByVal invalue As String) As String
        If invalue <> "" Then
            Return Mid(invalue, InStr(invalue, ",") + 1)
        Else
            Return ""
        End If

    End Function


    Private Function YN(ByVal InVal) As String
        If InVal = True Then
            Return "Y"
        Else
            Return "N"
        End If


    End Function



    Private Sub Export_Texas()

        Dim cmd As New SqlClient.SqlCommand

        cmd.Connection = CN2
        Dim retval
        If CN2.State <> ConnectionState.Open Then
            CN2.Open()
        End If


        Dim branchstring As String = ""
        'Dim i As Integer
        For Each DR As String In CheckedListBox1.CheckedItems
            cmd.Connection = CN2
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "Select branchid from szempappconsolidated.dbo.BranchData where commonname=@name"
            cmd.Parameters.AddWithValue("@name", DR.ToString)
            retval = cmd.ExecuteScalar
            cmd.Parameters.Clear()

            branchstring = branchstring + "'" + Trim(retval.ToString) + "',"

        Next
        'trim off the last comma
        branchstring = Mid(branchstring, 1, Len(branchstring) - 1)

        cmd.CommandText = "Select distinct SSN, branchID into ##Texas_Export from szempappconsolidated.dbo.personstatus where Status='U' and WOTC=1 and date >= @Sdate and date <= @EDate and BranchID In (" + branchstring + ") order by BranchID"
        cmd.Parameters.AddWithValue("@Sdate", TextBox1.Text)
        cmd.Parameters.AddWithValue("@Edate", TextBox2.Text)
        cmd.Parameters.AddWithValue("@Str", branchstring)
        cmd.ExecuteNonQuery()
        cmd.Parameters.Clear()

        ' bulk upload needs to in excel xslx file with header record.
        ' should be located in my documents\Tennessee_WOTC_Export, then saved as Tennessee_WOTC_Export_MM_DD_YYYY.xslx



        Dim REsults As Int16
        cmd.CommandText = "select count(ssn) from ##Texas_export"
        REsults = cmd.ExecuteScalar

        ' MsgBox(REsults)

        'If CN2.State <> ConnectionState.Closed Then
        '    CN2.Close()
        'End If

        If REsults >= 1 Then
            '  MsgBox(REsults.ToString + "  results found.")
            Call Export_Texas_XLS()
            'Call exceltest()

        Else
            MsgBox("No Results Found")
        End If





        Call Export_Texas_XLS()

        If CN2.State <> ConnectionState.Closed Then
            CN2.Close()
        End If
    End Sub


    Private Sub Export_Texas_XLS()

        'Dim dat As Date = Date.Now
        'Dim P As String = Format(dat, "Mdyyyy")
        'Dim misValue As Object = System.Reflection.Missing.Value
        'Dim xlApp = New Microsoft.Office.Interop.Excel.Application()
        'Dim xlWorkBook As Microsoft.Office.Interop.Excel.Workbook
        'Dim xlWorkSheet As Microsoft.Office.Interop.Excel.Worksheet
        'xlWorkBook = xlApp.Workbooks.Open(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\Texas_WOTC_Export.XSLX")
        'xlWorkSheet = xlWorkBook.Sheets("Sheet1")


        'new
        Dim dat As Date = Date.Now
        Dim P As String = Format(dat, "Mdyyyy")
        Dim misValue As Object = System.Reflection.Missing.Value
        Dim xlApp As Excel.Application = New Microsoft.Office.Interop.Excel.Application()

        If xlApp Is Nothing Then
            MessageBox.Show("Excel is not properly installed!!")
            Return
        End If
        xlApp.DisplayAlerts = False
        Dim filePath As String = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\Texas_WOTC_Export.xlsx"
        Dim xlWorkBook As Excel.Workbook = xlApp.Workbooks.Open(filePath, 0, False, 5, "", "",
             False, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", True, False, 0,
             True, False, False)
        Dim worksheets As Excel.Sheets = xlWorkBook.Worksheets
        '  worksheets(1).Delete()

        'xlApp.Visible = False

        '   Dim xlNewSheet = DirectCast(worksheets.Add(worksheets(1),
        '  Type.Missing, Type.Missing, Type.Missing), Excel.Worksheet)
        '  xlNewSheet.Name = "Sheet1"

        '   xlWorkBook.Save()

        '   Dim src As Excel._Worksheet
        '   Dim dest As Excel.Worksheet
        '   Dim header As Excel.Range
        '   Dim destination As Excel.Range
        '   src = xlWorkBook.Sheets("Sheet2")
        '   dest = xlWorkBook.Sheets("Sheet1")

        '   With src
        ''   header = .Range(.Cells(1, 1), .Cells(1, src.Columns.Count).End(Excel.XlDirection.xlToLeft))

        '   End With
        '  destination = dest.Cells(1, dest.Columns.Count).end(Excel.XlDirection.xlToLeft).offset(0, 0)
        '   header.Copy(destination)
        '   xlWorkBook.Save()
        'end new


        Dim xlworksheet As Excel.Worksheet
        xlworksheet = xlWorkBook.Sheets("Sheet1")




        If CN5.State <> ConnectionState.Open Then
            CN5.Open()
        End If
        If CN6.State <> ConnectionState.Open Then
            CN6.Open()
        End If




        Dim cmd As New SqlClient.SqlCommand
        Dim cmd2 As New SqlClient.SqlCommand
        cmd2.Connection = CN2
        cmd.Connection = CN2
        Dim retval
        Dim LineCtr As Integer = 1

        cmd.CommandType = CommandType.Text
        cmd.CommandText = "Select BranchID, SSN from ##Texas_Export"
        Dim RS As SqlClient.SqlDataReader
        Dim RS3 As SqlClient.SqlDataReader
        Dim RS4 As SqlClient.SqlDataReader
        Dim RS5 As SqlClient.SqlDataReader
        LineCtr = 2
        RS = cmd.ExecuteReader
        While RS.Read

            cmd2.Parameters.AddWithValue("@BranchID", RS.Item("BranchID").ToString)
            cmd2.Parameters.AddWithValue("@SSN", RS.Item("SSN").ToString)
            cmd2.Connection = CN5
            cmd2.CommandText = "Select * from szempappconsolidated.dbo.apppage1 where branchid=@branchid and SSN = @ssn"
            RS4 = cmd2.ExecuteReader
            RS4.Read()

            cmd2.Connection = CN6
            cmd2.CommandText = "Select * from szempappconsolidated.dbo.applicationstatusaudit where branchid=@branchid and SSN = @ssn"
            RS5 = cmd2.ExecuteReader
            RS5.Read()
            cmd2.Parameters.Clear()


            If RS4.HasRows = True And RS5.HasRows = True Then


                xlworksheet.Cells(LineCtr, 1).value = "582633827"
                xlworksheet.Cells(LineCtr, 2).value = "582633827"
                xlworksheet.Cells(LineCtr, 3).value = "Harris Ventures DBA Staff Zone"
                xlworksheet.Cells(LineCtr, 4).value = "30076"
                xlworksheet.Cells(LineCtr, 5).value = RS4.Item("SSN").ToString
                xlworksheet.Cells(LineCtr, 6).value = TXDateFormat(RS4.Item("Birthdate")).ToString
                xlworksheet.Cells(LineCtr, 7).value = RS5.Item("completiondate").ToString
                xlworksheet.Cells(LineCtr, 8).value = RS5.Item("appcompletiondate").ToString
                xlworksheet.Cells(LineCtr, 9).value = RS4.Item("LastName").ToString
                xlworksheet.Cells(LineCtr, 10).value = RS4.Item("Firstname").ToString
                xlworksheet.Cells(LineCtr, 11).value = RS4.Item("Address").ToString
                xlworksheet.Cells(LineCtr, 12).value = RS4.Item("City").ToString
                xlworksheet.Cells(LineCtr, 13).value = "TX"
                xlworksheet.Cells(LineCtr, 14).value = RS4.Item("ZIPcode").ToString
                xlworksheet.Cells(LineCtr, 15).value = "General Labor"
                xlworksheet.Cells(LineCtr, 16).value = "47"
                xlworksheet.Cells(LineCtr, 17).value = "9"


                LineCtr = LineCtr + 1

                RS4.Close()
                RS5.Close()


            Else

            End If

        End While
        RS.Close()

        'xlWorkBook.SaveAs(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\Texas_WOTC_Export_" & P & ".XSLX")
        'xlWorkBook.Close()
        'xlApp = Nothing

        xlWorkBook.SaveAs(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\Texas_WOTC_Export_" & P & ".xls", Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue,
         Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue)
        xlWorkBook.Close(True, misValue, misValue)
        xlApp.Quit()


        releaseObject(xlworksheet)
        releaseObject(xlWorkBook)
        releaseObject(xlApp)

        If CN2.State <> ConnectionState.Closed Then
            CN2.Close()
        End If
        If CN5.State <> ConnectionState.Closed Then
            CN5.Close()
        End If
        If CN6.State <> ConnectionState.Closed Then
            CN6.Close()
        End If


        MsgBox("Your file is called Texas_WOTC_Export_" & P & ".xls and is in your documents folder.")


    End Sub





    Private Sub Export_Tennessee()
        Dim cmd As New SqlClient.SqlCommand

        cmd.Connection = CN2
        Dim retval
        If CN2.State <> ConnectionState.Open Then
            CN2.Open()
        End If


        cmd.Connection = CN2
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "Drop table if exists ##Tennessee_Export"
        cmd.ExecuteNonQuery()







        Dim branchstring As String = ""
        'Dim i As Integer
        For Each DR As String In CheckedListBox1.CheckedItems
            cmd.Connection = CN2
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "Select branchid from szempappconsolidated.dbo.BranchData where commonname=@name"
            cmd.Parameters.AddWithValue("@name", DR.ToString)
            retval = cmd.ExecuteScalar
            cmd.Parameters.Clear()

            branchstring = branchstring + "'" + Trim(retval.ToString) + "',"

        Next
        'trim off the last comma
        branchstring = Mid(branchstring, 1, Len(branchstring) - 1)

        cmd.CommandText = "Select distinct SSN, branchID,birthdate into ##Tennessee_Export from szempappconsolidated.dbo.personstatus where Status='U' and WOTC=1 and date >= @Sdate and date <= @EDate and BranchID In (" + branchstring + ") order by BranchID"
        ' MsgBox(cmd.CommandText)

        cmd.Parameters.AddWithValue("@Sdate", TextBox1.Text)
        cmd.Parameters.AddWithValue("@Edate", TextBox2.Text)
        cmd.Parameters.AddWithValue("@Str", branchstring)
        cmd.ExecuteNonQuery()
        cmd.Parameters.Clear()

        ' bulk upload needs to in excel xslx file with header record.
        ' should be located in my documents\Tennessee_WOTC_Export, then saved as Tennessee_WOTC_Export_MM_DD_YYYY.xslx

        cmd.CommandText = "Delete from ##Tennessee_export where not exists(select SSN from szempappconsolidated.dbo.apppage90612015 where ssn=##Tennessee_Export.ssn and branchid=##Tennessee_Export.BranchID)"
        cmd.ExecuteNonQuery()

        cmd.CommandText = "Delete from ##Tennessee_export where not exists(select SSN from szempappconsolidated.dbo.apppage8850 where ssn=##Tennessee_Export.ssn and branchid=##Tennessee_Export.BranchID)"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "Delete from ##Tennessee_Export where datediff(year,birthdate,getdate()) >=40"
        cmd.ExecuteNonQuery()


        Dim REsults As Int16
        cmd.CommandText = "select count(ssn) from ##Tennessee_export"
        REsults = cmd.ExecuteScalar

        ' MsgBox(REsults)

        'If CN2.State <> ConnectionState.Closed Then
        '    CN2.Close()
        'End If

        If REsults >= 1 Then
            ' MsgBox(REsults.ToString + "  results found.")
            Call Export_Tennessee_XLSX()
            'Call exceltest()

        Else
            MsgBox("No Results Found")
        End If

    End Sub

    Private Sub exceltest()





        Dim xlApp As Excel.Application = New Microsoft.Office.Interop.Excel.Application()

        If xlApp Is Nothing Then
            MessageBox.Show("Excel is not properly installed!!")
            Return
        End If


        xlApp.DisplayAlerts = False
        Dim filePath As String = "c:\docshare\tennessee_wotc_export.xlsx"
        Dim xlWorkBook As Excel.Workbook = xlApp.Workbooks.Open(filePath, 0, False, 5, "", "",
             False, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", True, False, 0,
             True, False, False)
        Dim worksheets As Excel.Sheets = xlWorkBook.Worksheets
        worksheets(1).Delete()

        xlApp.Visible = False

        Dim xlNewSheet = DirectCast(worksheets.Add(worksheets(1),
        Type.Missing, Type.Missing, Type.Missing), Excel.Worksheet)
        xlNewSheet.Name = "Sheet1"

        xlWorkBook.Save()

        Dim src As Excel._Worksheet
        Dim dest As Excel.Worksheet
        Dim header As Excel.Range
        Dim destination As Excel.Range
        src = xlWorkBook.Sheets("Sheet2")
        dest = xlWorkBook.Sheets("Sheet1")

        With src
            header = .Range(.Cells(1, 1), .Cells(1, src.Columns.Count).End(Excel.XlDirection.xlToLeft))

        End With
        destination = dest.Cells(1, dest.Columns.Count).end(Excel.XlDirection.xlToLeft).offset(0, 0)

        ' destination.Resize(1, UBound(header, 2)) = header

        header.Copy(destination)







        xlWorkBook.Save()
        xlWorkBook.Close()

        releaseObject(worksheets)
        releaseObject(xlWorkBook)
        releaseObject(xlApp)

        MessageBox.Show("Worksheet Deleted!")

    End Sub

    Private Function Validate_Phone(InPhone As String) As String
        If Len(InPhone) = 10 Then
            Return InPhone
        Else
            Return "1234567890"
        End If


    End Function
    Private Sub Export_Tennessee_XLSX()

        Dim dat As Date = Date.Now
        Dim P As String = Format(dat, "Mdyyyy")
        Dim misValue As Object = System.Reflection.Missing.Value
        Dim xlApp As Excel.Application = New Microsoft.Office.Interop.Excel.Application()

        If xlApp Is Nothing Then
            MessageBox.Show("Excel is not properly installed!!")
            Return
        End If
        xlApp.DisplayAlerts = False
        Dim filePath As String = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\Tennessee_WOTC_Export.xlsx"
        Dim xlWorkBook As Excel.Workbook = xlApp.Workbooks.Open(filePath, 0, False, 5, "", "",
             False, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "", True, False, 0,
             True, False, False)
        Dim worksheets As Excel.Sheets = xlWorkBook.Worksheets
        ' worksheets(1).Delete()

        xlApp.Visible = False

        '  Dim xlNewSheet = DirectCast(worksheets.Add(worksheets(1),
        '  Type.Missing, Type.Missing, Type.Missing), Excel.Worksheet)
        '  xlNewSheet.Name = "Sheet1"

        '  xlWorkBook.Save()

        '   Dim src As Excel._Worksheet
        '   Dim dest As Excel.Worksheet
        '   Dim header As Excel.Range
        '   Dim destination As Excel.Range
        '   src = xlWorkBook.Sheets("Sheet2")
        '   dest = xlWorkBook.Sheets("Sheet1")

        '   With src
        '   header = .Range(.Cells(1, 1), .Cells(1, src.Columns.Count).End(Excel.XlDirection.xlToLeft))

        '   End With
        '    destination = dest.Cells(1, dest.Columns.Count).end(Excel.XlDirection.xlToLeft).offset(0, 0)
        '    header.Copy(destination)
        '   xlWorkBook.Save()


        'need to read and populate cells at sheet1,row 2, cell 1
        Dim cmd As New SqlClient.SqlCommand
        Dim cmd2 As New SqlClient.SqlCommand
        cmd2.Connection = CN2
        cmd.Connection = CN2
        Dim retval
        Dim LineCtr As Integer = 2
        If CN2.State <> ConnectionState.Open Then
            CN2.Open()
        End If
        If CN3.State <> ConnectionState.Open Then
            CN3.Open()
        End If
        If CN4.State <> ConnectionState.Open Then
            CN4.Open()
        End If
        If CN5.State <> ConnectionState.Open Then
            CN5.Open()
        End If

        If CN6.State <> ConnectionState.Open Then
            CN6.Open()
        End If
        'need to index through ##_Tennessee_Export
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "Select BranchID, SSN from ##Tennessee_Export"  '##Tennessee_export
        Dim RS As SqlClient.SqlDataReader
        Dim RS2 As SqlClient.SqlDataReader
        ' RS2.Close()
        Dim RS3 As SqlClient.SqlDataReader
        Dim RS4 As SqlClient.SqlDataReader
        Dim RS5 As SqlClient.SqlDataReader
        RS = cmd.ExecuteReader

        Dim xlworksheet As Excel.Worksheet
        xlworksheet = xlWorkBook.Sheets("Sheet1")


        While RS.Read



            cmd2.Parameters.AddWithValue("@BranchID", RS.Item("Branchid").ToString)
            cmd2.Parameters.AddWithValue("@SSN", RS.Item("SSN").ToString)

            cmd2.Connection = CN3
            cmd2.CommandText = "Select * from szempappconsolidated.dbo.apppage8850 where branchid=@branchid and SSN = @ssn"

            RS2 = cmd2.ExecuteReader
            RS2.Read()

            cmd2.Connection = CN4
            cmd2.CommandText = "Select * from szempappconsolidated.dbo.apppage90612015 where branchid=@branchid and SSN = @ssn"
            RS3 = cmd2.ExecuteReader
            RS3.Read()

            cmd2.Connection = CN5
            cmd2.CommandText = "Select * from szempappconsolidated.dbo.apppage1 where branchid=@branchid and SSN = @ssn"
            RS4 = cmd2.ExecuteReader
            RS4.Read()

            cmd2.Connection = CN6
            cmd2.CommandText = "Select * from szempappconsolidated.dbo.applicationstatusaudit where branchid=@branchid and SSN = @ssn"
            RS5 = cmd2.ExecuteReader
            RS5.Read()

            cmd2.Parameters.Clear()
            'need to write the cells here
            '(row,column)
            If RS2.HasRows = False Or RS3.HasRows = False Or RS4.HasRows = False Or RS5.HasRows = False Then

                GoTo SkipIt

            End If




            xlworksheet.Cells(LineCtr, 1).value = LineCtr
            xlworksheet.Cells(LineCtr, 2).value = RS4.Item("LastName").ToString
            xlworksheet.Cells(LineCtr, 3).value = RS4.Item("Firstname").ToString
            xlworksheet.Cells(LineCtr, 4).value = RS4.Item("SSN").ToString
            xlworksheet.Cells(LineCtr, 5).value = TNDateFormat(RS4.Item("Birthdate"))
            xlworksheet.Cells(LineCtr, 6).value = RS4.Item("Address").ToString
            xlworksheet.Cells(LineCtr, 7).value = RS4.Item("aptnumber").ToString
            xlworksheet.Cells(LineCtr, 8).value = RS4.Item("City").ToString
            xlworksheet.Cells(LineCtr, 9).value = RS4.Item("State").ToString
            xlworksheet.Cells(LineCtr, 10).value = RS4.Item("ZIPCode").ToString
            xlworksheet.Cells(LineCtr, 11).value = Validate_Phone(RS4.Item("cellphone").ToString)


            'application status audit
            xlworksheet.Cells(LineCtr, 12).value = TNDateFormat(RS5.Item("appcompletiondate"))
            xlworksheet.Cells(LineCtr, 13).value = TNDateFormat(RS5.Item("completiondate"))
            xlworksheet.Cells(LineCtr, 14).value = TNDateFormat(RS5.Item("completiondate"))
            xlworksheet.Cells(LineCtr, 15).value = TNDateFormat(RS5.Item("completiondate"))
            xlworksheet.Cells(LineCtr, 16).value = "N"
            '17 is date of last employment..
            xlworksheet.Cells(LineCtr, 18).value = "2"
            xlworksheet.Cells(LineCtr, 19).value = "General Labor"
            xlworksheet.Cells(LineCtr, 20).value = "47"
            xlworksheet.Cells(LineCtr, 21).value = "582633827"   'FEIN
            '8850

            xlworksheet.Cells(LineCtr, 22).value = RS2.Item("chk1").ToString
            xlworksheet.Cells(LineCtr, 23).value = RS2.Item("chk2").ToString
            xlworksheet.Cells(LineCtr, 24).value = RS2.Item("chk3").ToString
            xlworksheet.Cells(LineCtr, 25).value = RS2.Item("chk4").ToString
            xlworksheet.Cells(LineCtr, 26).value = RS2.Item("chk5").ToString
            xlworksheet.Cells(LineCtr, 27).value = RS2.Item("chk6").ToString
            xlworksheet.Cells(LineCtr, 28).value = RS2.Item("chk7").ToString

            If RS2.Item("chk4").ToString = "1" Then
                xlworksheet.Cells(LineCtr, 29).value = "4"
            End If
            If RS2.Item("chk6").ToString = "1" Then
                xlworksheet.Cells(LineCtr, 29).value = "6"
            End If
            xlworksheet.Cells(LineCtr, 30).value = TNDateFormat(CDate(RS2.Item("Ackdate").toshortdatestring))
            xlworksheet.Cells(LineCtr, 31).value = "Erica Williams"   'employer name(sig)
            xlworksheet.Cells(LineCtr, 32).value = "HR Manager" 'employer title


            '9061
            'must compute under 40
            'xlWorkSheet.Cells(LineCtr, 33).value = RS3.Item()
            xlworksheet.Cells(LineCtr, 34).value = RS3.Item("V9061Q13A").ToString
            xlworksheet.Cells(LineCtr, 35).value = RS3.Item("V9061Q13B").ToString
            xlworksheet.Cells(LineCtr, 36).value = RS3.Item("V9061Q13Recipient").ToString
            xlworksheet.Cells(LineCtr, 37).value = RS3.Item("V9061Q13CityState").ToString
            xlworksheet.Cells(LineCtr, 38).value = RS3.Item("V9061Q13C").ToString
            xlworksheet.Cells(LineCtr, 39).value = RS3.Item("V9061Q13D").ToString
            xlworksheet.Cells(LineCtr, 40).value = RS3.Item("V9061Q13E").ToString

            xlworksheet.Cells(LineCtr, 41).value = RS3.Item("V9061Q14A").ToString
            xlworksheet.Cells(LineCtr, 42).value = RS3.Item("V9061Q14B").ToString
            xlworksheet.Cells(LineCtr, 43).value = RS3.Item("V9061Q14Recipient").ToString
            xlworksheet.Cells(LineCtr, 44).value = RS3.Item("V9061Q14CityState").ToString
            xlworksheet.Cells(LineCtr, 45).value = RS3.Item("V9061Q15A").ToString
            xlworksheet.Cells(LineCtr, 46).value = RS3.Item("V9061Q15B").ToString
            xlworksheet.Cells(LineCtr, 47).value = RS3.Item("V9061Q15C").ToString

            xlworksheet.Cells(LineCtr, 48).value = RS3.Item("V9061Q16A").ToString
            xlworksheet.Cells(LineCtr, 49).value = RS3.Item("V9061Q16B").ToString
            xlworksheet.Cells(LineCtr, 50).value = RS3.Item("V9061Q16C").ToString
            xlworksheet.Cells(LineCtr, 51).value = RS3.Item("V9061Q16D").ToString
            xlworksheet.Cells(LineCtr, 52).value = RS3.Item("V9061Q16RECIPIENT").ToString
            xlworksheet.Cells(LineCtr, 53).value = RS3.Item("V9061Q16CITYSTATE").ToString

            xlworksheet.Cells(LineCtr, 54).value = RS3.Item("V9061Q17A").ToString
            xlworksheet.Cells(LineCtr, 55).value = RS3.Item("V9061Q17DOC").ToString
            xlworksheet.Cells(LineCtr, 56).value = RS3.Item("V9061Q17DOR").ToString
            If RS3.Item("V9061Q17F").ToString = "1" Then
                xlworksheet.Cells(LineCtr, 57).value = "Federal"
            ElseIf RS3.Item("V9061Q17S").ToString = "1" Then
                xlworksheet.Cells(LineCtr, 57).value = "State"
            End If
            xlworksheet.Cells(LineCtr, 58).value = RS3.Item("V9061Q18A").ToString
            xlworksheet.Cells(LineCtr, 59).value = RS3.Item("V9061Q19A").ToString
            xlworksheet.Cells(LineCtr, 60).value = RS3.Item("V9061Q20A").ToString
            xlworksheet.Cells(LineCtr, 61).value = RS3.Item("V9061Q21A").ToString
            xlworksheet.Cells(LineCtr, 62).value = RS3.Item("V9061Q22A").ToString
            xlworksheet.Cells(LineCtr, 63).value = RS3.Item("V9061Q23State").ToString
            xlworksheet.Cells(LineCtr, 65).value = "5"
            xlworksheet.Cells(LineCtr, 66).value = TNDateFormat(RS3.Item("AckDate"))
            xlworksheet.Cells(LineCtr, 67).value = RS3.Item("V9061Q23A").ToString
            LineCtr = LineCtr + 1
SkipIt:

            RS2.Close()
            RS3.Close()
            RS4.Close()
            RS5.Close()

        End While

        RS.Close()
        RS.Dispose()
        cmd.CommandText = "Drop Table ##Tennessee_Export"
        cmd.ExecuteNonQuery()
        If CN2.State <> ConnectionState.Closed Then
            CN2.Close()
        End If




        'xlWorkBook.SaveAs(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\Tennessee_WOTC_Export_" & P & ".XSLX")
        'xlWorkBook.Close()
        'xlApp = Nothing

        xlWorkBook.SaveAs(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\Tennessee_WOTC_Export_" & P & ".xls", Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue,
         Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue)
        xlWorkBook.Close(True, misValue, misValue)
        xlApp.Quit()


        releaseObject(xlworksheet)
        releaseObject(xlWorkBook)
        releaseObject(xlApp)


        If CN3.State <> ConnectionState.Closed Then
            CN3.Close()
        End If
        If CN4.State <> ConnectionState.Closed Then
            CN4.Close()
        End If
        If CN5.State <> ConnectionState.Closed Then
            CN5.Close()
        End If
        If CN6.State <> ConnectionState.Closed Then
            CN6.Close()
        End If

        RS.Close()
        RS.Dispose()
        If CN2.State <> ConnectionState.Closed Then
            CN2.Close()
        End If



        MsgBox("Your file is called Tennessee_WOTC_Export_" & P & ".xls and is in your documents folder.")
        ToolStripStatusLabel1.Text = "Ready"
    End Sub

    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try
    End Sub

    Private Sub Export_Florida()
        'text file

        ToolStripStatusLabel1.Text = "Loading Data."

        Dim cmd As New SqlClient.SqlCommand

        cmd.Connection = CN2
        Dim retval
        If CN2.State <> ConnectionState.Open Then
            CN2.Open()
        End If
        Dim branchstring As String = ""
        'Dim i As Integer
        For Each DR As String In CheckedListBox1.CheckedItems
            cmd.Connection = CN2
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "Select branchid from szempappconsolidated.dbo.BranchData where commonname=@name"
            cmd.Parameters.AddWithValue("@name", DR.ToString)
            retval = cmd.ExecuteScalar
            cmd.Parameters.Clear()

            branchstring = branchstring + "'" + Trim(retval.ToString) + "',"

        Next
        'trim off the last comma
        branchstring = Mid(branchstring, 1, Len(branchstring) - 1)


        cmd.CommandText = "Select object_id from sys.objects where type='U' and name='##Florida_Export'"
        retval = cmd.ExecuteScalar
        If Not retval Is Nothing Then

            cmd.CommandText = "Drop table ##Florida_Export"
            cmd.ExecuteNonQuery()
        End If
        'MsgBox("1")

        'now need to retrieve ssn's from personstatus where WOTC=1 between the dates indicated.
        cmd.CommandText = "Select distinct SSN, branchID into ##Florida_Export from szempappconsolidated.dbo.personstatus where Status='U' and WOTC=1 and date>='" + Trim(TextBox1.Text) + "' and date<='" + Trim(TextBox2.Text) + "' and BranchID In (" + branchstring + ") order by BranchID"
        'MsgBox(branchstring)
        ' MsgBox(cmd.CommandText)
        cmd.Parameters.AddWithValue("@Sdate", TextBox1.Text)
        cmd.Parameters.AddWithValue("@Edate",TextBox2.Text)
        cmd.Parameters.AddWithValue("@Str", branchstring)

        cmd.ExecuteNonQuery()
        cmd.Parameters.Clear()


        cmd.CommandText = "select count(ssn) from ##Florida_Export"
        Dim zval
        zval = cmd.ExecuteScalar
        ToolStripStatusLabel1.Text = zval.ToString + " records found"
        'MsgBox(zval)

        ' MsgBox("2")
        cmd.CommandText = "Alter table ##Florida_Export Add  Lastname nvarchar(30),Firstname Nvarchar(30), MI nchar(1), PrimeRecL nvarchar(30),PrimeRecF nvarchar(30),Add1 nvarchar(44),Add2 nvarchar(44),,County nvarchar(25),State nvarchar(2),County nvarchar(25), City nvarchar(25),ZIP nvarchar(5),DOB date, PriorEmp nvarchar(1),HireDate date,appdate date,PushDate date, Position nvarchar(25),TgtGrp nvarchar(30),HrlyWage nchar(1),OccGrp nvarchar(3)"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "Alter table ##Florida_Export Add  VetSnapState nvarchar(70), SnapState nvarchar(70), Felondate date,FelonRelease date,V9061Q13CityStat nvarchar(50),V9061Q14CityStat nvarchar(50)"
        cmd.ExecuteNonQuery()
        ' MsgBox("3")

        'need to populate applicants data
        cmd.CommandText = "update ##Florida_Export set lastname=B.Lastname,firstname=B.firstname,MI=B.middleinitial,Add1=B.address,Add2=B.aptnumber,State=B.state,City=B.city,ZIP=B.zipcode,DOB=convert(date,B.Birthdate,101) from  szempappconsolidated.dbo.apppage1 B where B.ssn=##Florida_Export.ssn"
        cmd.ExecuteNonQuery()
        'need to populate date hired,date job start,dateapplied,datejob offer

        ' MsgBox("4")


        'need to populate 9061 data
        cmd.CommandText = "update ##Florida_Export set vetsnapstate=V9061Q13CityState,snapstate=V9061Q13CityState,felondate=convert(date,V9061Q17DOC,101),felonrelease=convert(date,V9061Q17DOR,101),V9061Q13CityStat=V9061Q13CityState,V9061Q14CityStat=V9061Q14CityState from szempappconsolidated.dbo.apppage90612015 where szempappconsolidated.dbo.apppage90612015.ssn= ##Florida_export.SSN and sequence=(select max(sequence) from szempappconsolidated.dbo.apppage90612015 where szempappconsolidated.dbo.apppage90612015.ssn=##florida_export.ssn) and szempappconsolidated.dbo.apppage90612015.BranchID in (@str)"
        cmd.Parameters.AddWithValue("@Str", branchstring)
        cmd.ExecuteNonQuery()

        cmd.Parameters.Clear()
        'MsgBox("5")
        cmd.CommandText = "alter table ##Florida_Export add  TargetGroups nvarchar(30),OccGroup nvarchar(3),WageCode nvarchar(1),Appstartdate date,appcompletiondate date"
        cmd.ExecuteNonQuery()
        ' MsgBox("6")
        cmd.CommandText = "Update ##Florida_export set occgroup='19',wagecode='C',targetgroups=''"
        cmd.ExecuteNonQuery()
        ' MsgBox("7")
        'for florida, occgroup=19, wagecode "C"
        'for speed we must move this to a cursor in a sproc
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "szempappconsolidated.dbo.Load_##Florida_Export_Target_Groups"
        cmd.Parameters.AddWithValue("@Branchlist", branchstring)
        cmd.ExecuteNonQuery()
        cmd.Parameters.Clear()

        cmd.CommandType = CommandType.Text
        cmd.CommandText = "update ##Florida_Export set pushdate=B.Completiondate ,appcompletiondate=B.appcompletiondate ,appstartdate=B.startdate  from szempappconsolidated.dbo.applicationstatusaudit B where B.ssn=##Florida_Export.ssn"
        cmd.ExecuteNonQuery()



        cmd.CommandText = "update ##Florida_Export set county = (select county from szempappconsolidated.dbo.branchdata where branchid= ##Florida_Export.Branchid)"
        cmd.ExecuteNonQuery()
        'need to update the pushdate field
        'appstart,appcompletion,pushdate

        'update ##Florida_Export set V9061Q13CityStat='FL' where charindex('FL',UPPER(ltrim(rtrim(V9061Q13CityStat)))) > 0

        'MsgBox("8")
        'need to determine the county from the zipcode
        'need to write the export,all fields must be enclosed in double quotes, no commas within fields.
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "update ##Florida_Export set V9061Q13CityStat='FL' where UPPER(ltrim(rtrim(V9061Q13CityStat)))= 'FL'"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q13CityStat='FL' where UPPER(ltrim(rtrim(V9061Q13CityStat)))= 'FLORIDA'"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q13CityStat='FL' where charindex('FLORIDA',UPPER(ltrim(rtrim(V9061Q13CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q13CityStat='FL' where charindex('FL', UPPER(ltrim(rtrim(V9061Q13CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q13CityStat='GA' where charindex('GA',UPPER(ltrim(rtrim(V9061Q13CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q13CityStat='GA' where charindex('GEORGIA',UPPER(ltrim(rtrim(V9061Q13CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q13CityStat='SC' where charindex('SC',UPPER(ltrim(rtrim(V9061Q13CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q13CityStat='SC' where charindex('SOUTH CAROLINA',UPPER(ltrim(rtrim(V9061Q13CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q13CityStat='NC' where charindex('NC',UPPER(ltrim(rtrim(V9061Q13CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q13CityStat='NC' where charindex('NORTH CAROLINA',UPPER(ltrim(rtrim(V9061Q13CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q13CityStat='AL' where charindex('AL',UPPER(ltrim(rtrim(V9061Q13CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q13CityStat='AL' where charindex('ALABAMA',UPPER(ltrim(rtrim(V9061Q13CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q13CityStat='TN' where charindex('TN',UPPER(ltrim(rtrim(V9061Q13CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q13CityStat='TN' where charindex('TENNESSEE',UPPER(ltrim(rtrim(V9061Q13CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q13CityStat='TX' where charindex('TX',UPPER(ltrim(rtrim(V9061Q13CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q13CityStat='TX' where charindex('TEXAS',UPPER(ltrim(rtrim(V9061Q13CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q13CityStat='AZ' where charindex('AZ',UPPER(ltrim(rtrim(V9061Q13CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q13CityStat='AZ' where charindex('ARIZONA',UPPER(ltrim(rtrim(V9061Q13CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q13CityStat='NV' where charindex('NV',UPPER(ltrim(rtrim(V9061Q13CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q13CityStat='NV' where charindex('NEVADA',UPPER(ltrim(rtrim(V9061Q13CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q13CityStat='VA' where charindex('VA',UPPER(ltrim(rtrim(V9061Q13CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q13CityStat='VA' where charindex('VIRGINIA',UPPER(ltrim(rtrim(V9061Q13CityStat)))) > 0"
        cmd.ExecuteNonQuery()


        'MsgBox("9")

        cmd.CommandText = "update ##Florida_Export set V9061Q14CityStat='FL' where UPPER(ltrim(rtrim(V9061Q14CityStat)))= 'FL'"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q14CityStat='FL' where UPPER(ltrim(rtrim(V9061Q14CityStat)))= 'FLORIDA'"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q14CityStat='FL' where charindex('FLORIDA',UPPER(ltrim(rtrim(V9061Q14CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q14CityStat='FL' where charindex('FL',UPPER(ltrim(rtrim(V9061Q14CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q14CityStat='GA' where charindex('GA',UPPER(ltrim(rtrim(V9061Q14CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q14CityStat='GA' where charindex('GEORGIA',UPPER(ltrim(rtrim(V9061Q14CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q14CityStat='SC' where charindex('SC',UPPER(ltrim(rtrim(V9061Q14CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q14CityStat='SC' where charindex('SOUTH CAROLINA',UPPER(ltrim(rtrim(V9061Q14CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q14CityStat='NC' where charindex('NC',UPPER(ltrim(rtrim(V9061Q14CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q14CityStat='NC' where charindex('NORTH CAROLINA',UPPER(ltrim(rtrim(V9061Q14CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q14CityStat='AL' where charindex('AL',UPPER(ltrim(rtrim(V9061Q14CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q14CityStat='AL' where charindex('ALABAMA',UPPER(ltrim(rtrim(V9061Q14CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q14CityStat='TN' where charindex('TN',UPPER(ltrim(rtrim(V9061Q14CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q14CityStat='TN' where charindex('TENNESSEE',UPPER(ltrim(rtrim(V9061Q14CityStat))) ) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q14CityStat='TX' where charindex('TX',UPPER(ltrim(rtrim(V9061Q14CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q14CityStat='TX' where charindex('TEXAS',UPPER(ltrim(rtrim(V9061Q14CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q14CityStat='AZ' where charindex('AZ',UPPER(ltrim(rtrim(V9061Q14CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q14CityStat='AZ' where charindex('ARIZONA',UPPER(ltrim(rtrim(V9061Q14CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q14CityStat='NV' where charindex('NV',UPPER(ltrim(rtrim(V9061Q14CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q14CityStat='NV' where charindex('NEVADA',UPPER(ltrim(rtrim(V9061Q14CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q14CityStat='VA' where charindex('VA',UPPER(ltrim(rtrim(V9061Q14CityStat)))) > 0"
        cmd.ExecuteNonQuery()
        cmd.CommandText = "update ##Florida_Export set V9061Q14CityStat='VA' where charindex('VIRGINIA',UPPER(ltrim(rtrim(V9061Q14CityStat)))) > 0"
        cmd.ExecuteNonQuery()


        'export goes here.
        'MsgBox("10")

        ToolStripStatusLabel1.Text = "Data Loaded, Formatting for export."

        Call Export_Florida_txt_File()



        'after t5he export''''
        '  cmd.CommandType = CommandType.Text
        '  cmd.CommandText = "Drop table ##Florida_Export"
        '  cmd.ExecuteNonQuery()


        If CN2.State <> ConnectionState.Closed Then
            CN2.Close()
        End If

        ToolStripStatusLabel1.Text = "Data exported."

    End Sub


    Private Sub Export_Florida_txt_File()

        Dim cmd As New SqlClient.SqlCommand

        cmd.Connection = CN2
        cmd.CommandType = CommandType.Text
        Dim retval
        If CN2.State <> ConnectionState.Open Then
            CN2.Open()
        End If
        cmd.CommandText = "select * from ##Florida_export"
        Dim rs As SqlClient.SqlDataReader
        rs = cmd.ExecuteReader
        Dim fedein As String = """582633827"
        Dim wstring As String = ""
        Dim file As System.IO.StreamWriter
        file = My.Computer.FileSystem.OpenTextFileWriter(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\FloridaExport.txt", False)
        While rs.Read
            wstring = wstring + fedein + """,""" + Mid(rs.Item("Branchid").ToString, 2) + """,""" + Mid(rs.Item("LastName").ToString, 1, 30) + ""","""
            wstring = wstring + Mid(rs.Item("FirstName").ToString, 1, 30) + """,""" + Mid(rs.Item("MI").ToString, 1, 1) + """,""" + Mid(rs.Item("PrimeRecL").ToString, 1, 30) + ""","""
            wstring = wstring + Mid(rs.Item("PrimeRecF").ToString, 1, 30) + """,""" + rs.Item("SSN").ToString + """,""" + Mid(rs.Item("Add1").ToString, 1, 44) + """,""" + Mid(rs.Item("Add2"), 1, 44) + ""","""
            wstring = wstring + Mid(rs.Item("State"), 1, 2) + """,""" + Mid(rs.Item("County").ToString, 1, 25) + """,""" + Mid(rs.Item("City"), 1, 25) + """,""" + Mid(rs.Item("ZIP").ToString, 1, 5) + ""","""
            wstring = wstring + FLDateFormat(rs.Item("DOB")).ToString + """,""" + rs.Item("PriorEmp").ToString + """,""" + FLDateFormat(rs.Item("Pushdate")).ToString + """,""" + FLDateFormat(rs.Item("Pushdate")).ToString + ""","""
            wstring = wstring + FLDateFormat(rs.Item("appstartdate").ToString).ToString + """,""" + FLDateFormat(rs.Item("Pushdate").ToString).ToString + """,""" + rs.Item("V9061Q13CityStat").ToString + """,""" + rs.Item("V9061Q14CityStat").ToString + ""","""
            wstring = wstring + ",,,,,," + "" + FLDateFormat(rs.Item("FelonDate")).ToString + """,,""" + FLDateFormat(rs.Item("FelonRelease")).ToString + ""","""


            file.WriteLine(wstring)
            wstring = ""

        End While


        file.Close()

        MsgBox("Your file Is named 'FloridaExport.txt' and is located in your 'my documents' folder. Please rename the file and upload it to the Florida WOTC site.")

        rs.Close()
        rs.Dispose()


    End Sub




End Class
