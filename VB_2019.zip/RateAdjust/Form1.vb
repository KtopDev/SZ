﻿Imports System.Data.SqlClient
Imports System.Security.Principal
Imports System.DirectoryServices.AccountManagement


Imports System.Data.OleDb
Imports Excel = Microsoft.Office.Interop.Excel

Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'need to populate branch information

        'need AD authentication here.
        Dim T As New PrincipalContext(ContextType.Domain, DomainName, DomainConnector)

        DomainName = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\Software\Reportdriver", "DomainName", Nothing)
        DomainConnector = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\Software\Reportdriver", "DomainConnector", Nothing)



        If GroupPrincipal.FindByIdentity(T, "Rate_Adjust") IsNot Nothing Then
            If UserPrincipal.Current.IsMemberOf(GroupPrincipal.FindByIdentity(T, "Rate_Adjust")) = True Then




                CONNECTIONSTRING2 = "Data Source=192.168.100.162;Network Library=DBMSSOCN;Initial Catalog=szreports;User ID=HVI;Password=tacticalnuke;"
                CN2.ConnectionString = CONNECTIONSTRING2
                If CN2.State <> ConnectionState.Open Then
                    CN2.Open()
                End If

                ComboBox1.Items.Clear()


                Dim CMD As New SqlCommand
                CMD.Connection = CN2
                CMD.CommandType = CommandType.Text

                CMD.CommandText = "select locationID,Branchname from szreports.dbo.branchmaster where centralized=1"
                Dim RS As SqlDataReader
                RS = CMD.ExecuteReader
                While RS.Read
                    ComboBox1.Items.Add(RS.Item("LocationID").ToString & " - " & RS.Item("branchname").ToString)
                End While
                RS.Close()
                RS.Dispose()

                If CN2.State <> ConnectionState.Closed Then
                    CN2.Close()
                End If

                DataGridView1.EditMode = DataGridViewEditMode.EditOnEnter

            End If
        Else

            MsgBox("You are not a memeber of an Active Directory User Group with access to use this application")
        End If



    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub DataGridView1_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellEndEdit


        If CN2.State <> ConnectionState.Open Then
            CN2.Open()
        End If
        Dim cmd As New SqlClient.SqlCommand
        cmd.CommandType = CommandType.Text
        cmd.Connection = CN2



        Dim IDValue As Integer = 0
        If e.ColumnIndex = 7 Then 'labor type
            IDValue = DataGridView1(0, e.RowIndex).Value
            If DataGridView1(e.ColumnIndex, e.RowIndex).Value Is Nothing Then
                cmd.CommandText = "Update TempsSZ1SQL.dbo.customerrates set labortype=NULL,LastChangeDate=cast(getdate() as date) where ID=@Bvalue"
            Else
                cmd.CommandText = "Update TempsSZ1SQL.dbo.customerrates set labortype=@value,LastChangeDate=cast(getdate() as date) where ID=@Bvalue"
                cmd.Parameters.AddWithValue("@value", DataGridView1(e.ColumnIndex, e.RowIndex).Value)
            End If

            ' cmd.CommandText = "Update TempsSZ1SQL.dbo.customerrates set labortype=@value,LastChangeDate=cast(getdate() as date) where ID=@Bvalue"
            ' cmd.Parameters.AddWithValue("@value", DataGridView1(e.ColumnIndex, e.RowIndex).Value)
            cmd.Parameters.AddWithValue("@bvalue", IDValue)
            cmd.ExecuteNonQuery()
            cmd.Parameters.Clear()
        End If
        If e.ColumnIndex = 8 Then 'reg bill
            IDValue = DataGridView1(0, e.RowIndex).Value
            cmd.CommandText = "Update TempsSZ1SQL.dbo.customerrates set regbill=@value,LastChangeDate=cast(getdate() as date) where ID=@Bvalue"
            cmd.Parameters.AddWithValue("@value", DataGridView1(e.ColumnIndex, e.RowIndex).Value)
            cmd.Parameters.AddWithValue("@bvalue", IDValue)
            cmd.ExecuteNonQuery()
            cmd.Parameters.Clear()
        End If
        If e.ColumnIndex = 9 Then 'reg pay
            IDValue = DataGridView1(0, e.RowIndex).Value
            cmd.CommandText = "Update TempsSZ1SQL.dbo.customerrates set regpay=@value,LastChangeDate=cast(getdate() as date) where ID=@Bvalue"
            cmd.Parameters.AddWithValue("@value", DataGridView1(e.ColumnIndex, e.RowIndex).Value)
            cmd.Parameters.AddWithValue("@bvalue", IDValue)
            cmd.ExecuteNonQuery()
            cmd.Parameters.Clear()
        End If
        If e.ColumnIndex = 10 Then 'ot bill
            IDValue = DataGridView1(0, e.RowIndex).Value
            cmd.CommandText = "Update TempsSZ1SQL.dbo.customerrates set OTBILL=@value,LastChangeDate=cast(getdate() as date) where ID=@Bvalue"
            cmd.Parameters.AddWithValue("@value", DataGridView1(e.ColumnIndex, e.RowIndex).Value)
            cmd.Parameters.AddWithValue("@bvalue", IDValue)
            cmd.ExecuteNonQuery()
            cmd.Parameters.Clear()
        End If

        If CN2.State <> ConnectionState.Closed Then

            CN2.Close()

        End If

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click


        DataGridView1.Rows.Clear()

        If ComboBox1.Text <> "" Then

            If CN2.State <> ConnectionState.Open Then
            CN2.Open()
        End If
        Dim cmd As New SqlClient.SqlCommand
        cmd.CommandType = CommandType.Text
        cmd.Connection = CN2

            '.need to populate last invoicedate correctly




            If CheckBox1.Checked = True Then
                If Len(Trim(ComboBox2.Text)) > 0 Then
                    cmd.CommandText = "Select ID, Customer, CustomerName, JobTitle, WorkCode,convert(varchar(10), lastinvoicedate,1) as lastinvoicedate, convert(varchar(10),lastchangedate,1) as lastchangedate ,Labortype, regbill, regpay, otbill, JobStatus, Comment,reference from TempsSZ1SQL.dbo.customerrates where substring(customer,1,2) ='" & Mid(ComboBox1.Text, 1, 2) & "' and labortype='" & ComboBox2.Text & "' order by lastinvoicedate desc"
                Else
                    cmd.CommandText = "Select ID, Customer, CustomerName, JobTitle, WorkCode,  convert(varchar(10), lastinvoicedate,1) as lastinvoicedate ,  convert(varchar(10),lastchangedate,1) as lastchangedate , Labortype, regbill, regpay, otbill, JobStatus, Comment,reference from TempsSZ1SQL.dbo.customerrates where substring(customer,1,2)  = '" & Mid(ComboBox1.Text, 1, 2) & "' and (labortype is Null or labortype='') order by lastinvoicedate desc"

                End If
            Else
                If Len(Trim(ComboBox2.Text)) > 0 Then
                    cmd.CommandText = "Select ID, Customer, CustomerName, JobTitle, WorkCode,convert(varchar(10), lastinvoicedate,1) as lastinvoicedate,convert(varchar(10),lastchangedate,1) as lastchangedate, Labortype, regbill, regpay, otbill, JobStatus, Comment,reference from TempsSZ1SQL.dbo.customerrates where substring (customer,1,2)= '" & Mid(ComboBox1.Text, 1, 2) & "' and labortype='" & ComboBox2.Text & "' and (Jobstatus=0 or jobstatus is null) order by lastinvoicedate desc"
                Else
                    '  cmd.CommandText = "Select ID, Customer, CustomerName, JobTitle, WorkCode,  convert(varchar(10), lastinvoicedate,1) as lastinvoicedate , convert(varchar(10),lastchangedate,1) as lastchangedate, Labortype, regbill, regpay, otbill, JobStatus, Comment,reference from TempsSZ1SQL.dbo.customerrates where substring(customer,1,2) =" & Mid(ComboBox1.Text, 1, 2) & " and labortype is Null and Jobstatus is null order by lastinvoicedate desc"

                    cmd.CommandText = "Select ID, Customer, CustomerName,JobTitle, WorkCode,  convert(varchar(10), lastinvoicedate,1) as lastinvoicedate , convert(varchar(10),lastchangedate,1) as lastchangedate, Labortype, regbill, regpay, otbill, JobStatus, Comment,reference from TempsSZ1SQL.dbo.customerrates where substring(customer,1,2) = '" & Mid(ComboBox1.Text, 1, 2) & "'  and (labortype is Null or labortype='')  order by lastinvoicedate desc"
                End If
            End If
            '  ID, Customer, CustomerName, JobTitle, WorkCode, Convert(Date, lastinvoicedate), Convert(Date, lastchangedate), Labortype, regbill, regpay, otbill, JobStatus, Comment
            'MsgBox(cmd.CommandText)
            Dim RS As SqlClient.SqlDataReader
            RS = cmd.ExecuteReader

            While RS.Read
                '  RS.get



                DataGridView1.Rows.Add(RS.Item("ID").ToString, RS.Item("Customer").ToString, RS.Item("Customername").ToString, RS.Item("Jobtitle").ToString, RS.Item("Workcode").ToString, RS.Item("LastinvoiceDate").ToString, RS.Item("LastChangeDate").ToString, Trim(RS.Item("LaborType").ToString), RS.Item("RegBill").ToString, RS.Item("RegPay").ToString, RS.Item("OTBILL").ToString, RS.Item("JobStatus").ToString, Trim(RS.Item("Comment").ToString), RS.Item("Reference").ToString)
            End While


            RS.Close()
            RS.Dispose()

            If CN2.State <> ConnectionState.Closed Then

                CN2.Close()

            End If



        End If

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        'needs top load the grid based upon selections made
        If IsDate(TextBox1.Text) = True And IsDate(TextBox2.Text) = True Then


            DataGridView1.Rows.Clear()


        If CN2.State <> ConnectionState.Open Then
                    CN2.Open()
                End If
                Dim cmd As New SqlClient.SqlCommand
                cmd.CommandType = CommandType.Text
                cmd.Connection = CN2

            If RadioButton1.Checked = True Then 'create date
                cmd.CommandText = "select * from custoemrrates where locationid=" & Mid(ComboBox1.Text, 1, 2) & " and cast(createdate as date) >= cast(@date as date) and cast(createdate as date) <= @2Date)"
                cmd.Parameters.AddWithValue("@date", TextBox1.Text)
                cmd.Parameters.AddWithValue("@2date", TextBox2.Text)



            ElseIf RadioButton2.Checked = True Then 'lastchangedate
                cmd.CommandText = "select * from custoemrrates where locationid=" & Mid(ComboBox1.Text, 1, 2) & " and cast(lastChangeddate as date) >= cast(@date as date) and cast(lastChangeddate as date) <= @2Date)"
                cmd.Parameters.AddWithValue("@date", TextBox1.Text)
                cmd.Parameters.AddWithValue("@2date", TextBox2.Text)

            End If


            Dim RS As SqlClient.SqlDataReader
            RS = cmd.ExecuteReader
            While RS.Read
                DataGridView1.Rows.Add(RS.Item("ID").ToString, RS.Item("Customer").ToString, RS.Item("Customername").ToString, RS.Item("Jobtitle").ToString, RS.Item("Workcode").ToString, RS.Item("LastinvoiceDate").ToString, RS.Item("LastChangeDate").ToString, RS.Item("LaborType").ToString, RS.Item("RegBill").ToString, RS.Item("RegPay").ToString, RS.Item("OTBILL").ToString, RS.Item("JobStatus").ToString, RS.Item("Comment").ToString)
            End While
            RS.Close()
            RS.Dispose()



            If CN2.State <> ConnectionState.Closed Then

            CN2.Close()

        End If
            Call ExportExcel()

        Else

            MsgBox("Please enter 2 dates")
        End If



    End Sub

    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try
    End Sub
    Private Sub ExportExcel()

        Dim xlApp As Microsoft.Office.Interop.Excel.Application
        Dim xlWorkBook As Microsoft.Office.Interop.Excel.Workbook
        Dim xlWorkSheet As Microsoft.Office.Interop.Excel.Worksheet
        Dim misValue As Object = System.Reflection.Missing.Value
        Dim i As Integer
        Dim j As Integer

        xlApp = New Microsoft.Office.Interop.Excel.ApplicationClass
        xlWorkBook = xlApp.Workbooks.Add(misValue)
        xlWorkSheet = xlWorkBook.Sheets("sheet1")


        For i = 0 To DataGridView1.RowCount - 2
            For j = 0 To DataGridView1.ColumnCount - 1
                For k As Integer = 1 To DataGridView1.Columns.Count
                    xlWorkSheet.Cells(1, k) = DataGridView1.Columns(k - 1).HeaderText
                    xlWorkSheet.Cells(i + 2, j + 1) = DataGridView1(j, i).Value.ToString()
                Next
            Next
        Next

        xlWorkSheet.SaveAs(System.IO.Path.Combine(My.Computer.FileSystem.SpecialDirectories.MyDocuments, "Rate_Export" & FormatDateTime(DateAndTime.Now, DateFormat.ShortDate) & ".xlsx"))
        xlWorkBook.Close()
        xlApp.Quit()

        releaseObject(xlApp)
        releaseObject(xlWorkBook)
        releaseObject(xlWorkSheet)

        MsgBox("Saved in your 'My Documents' folder. Rate_export(date).xlsx")
    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox2.SelectedIndexChanged

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

        Me.Cursor = Cursors.WaitCursor

        If CN2.State <> ConnectionState.Open Then
            CN2.Open()
        End If
        Dim cmd As New SqlClient.SqlCommand
        cmd.Connection = CN2
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "update tempssz1sql.dbo.customerrates set lastinvoicedate=(select max(invoicedate) from tempssz1sql.dbo.historydetail where historydetail.reference=customerrates.reference) where substring(customer,1,2)='" & Mid(ComboBox1.Text, 1, 2) & "'"
        cmd.ExecuteNonQuery()
        If CN2.State <> ConnectionState.Closed Then
            CN2.Close()
        End If

        Me.Cursor = Cursors.Default
    End Sub
End Class
