﻿Module Module1


    Friend DomainName As String
    Friend DomainConnector As String
    Friend CONNECTIONSTRING2 As String
    Friend CN2 As New SqlClient.SqlConnection(CONNECTIONSTRING2)

End Module
