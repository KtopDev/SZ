﻿Imports System.Security.Principal
Imports System.DirectoryServices
Imports System.DirectoryServices.AccountManagement
Imports System.IO.Compression

Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'NationalCustomersDataSet.ARCustomers' table. You can move, or remove it, as needed.
        '  Me.ARCustomersTableAdapter.Fill(Me.NationalCustomersDataSet.ARCustomers)


        Button2.Visible = False
        Label1.Visible = False
        Label2.Visible = False
        Label3.Visible = False
        Label2.Text = ""
        Label3.Text = ""


        Button3.Visible = False
        TextBox2.Visible = False


        ToolStripStatusLabel1.Text = "Ready"

        'need to check registry setting here to see if this is a domain attached machine or not.

        '1 domain information for security

        SalesViewAuthorized = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\Software\NCL", "SalesViewAuthorized", Nothing)

        Debug = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\Software\NCL", "Debug", Nothing)
        'MsgBox(Debug.ToString)

        'MsgBox(Debug)


        If SalesViewAuthorized = True Then

            DomainName = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\Software\NCL", "DomainName", Nothing)
            DomainConnector = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\Software\NCL", "DomainConnector", Nothing)
            '2 database connector information
            DatabaseIP = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\Software\NCL", "DatabaseIP", Nothing)
            DatabaseName = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\Software\NCL", "DatabaseName", Nothing)

            If Debug = "True" Then
                MsgBox(DomainName)
                MsgBox(DomainConnector)
                MsgBox(DatabaseIP)
                MsgBox(DatabaseName)
                MsgBox(Debug)
            End If



            'MsgBox(UserPrincipal.Current.UserPrincipalName)

            ' Dim Z As New PrincipalContext()
            ' MsgBox("start T")
            Dim T As New PrincipalContext(ContextType.Domain, DomainName, DomainConnector, ContextOptions.Negotiate, "thestaffzone\LDAP_ACCESS", "LDAPsucks")  ', UserPrincipal.Current.UserPrincipalName)   ', "Thestaffzone\Administrator", "1%hvi%@1"

            ' MsgBox(T.UserName.ToString)
            'MsgBox(T.ValidateCredentials("Thestaffzone\Administrator", "1%hvi%@1").ToString)
            'MsgBox("1")
            If GroupPrincipal.FindByIdentity(T, "National_Customers_Sales_Data") IsNot Nothing Then  ', IdentityType.Name
                'MsgBox("2")
                If UserPrincipal.Current.IsMemberOf(GroupPrincipal.FindByIdentity(T, "National_Customers_Sales_Data")) = True Then  '"National_Customers_Sales_Data"
                    'user is authorized
                    Button2.Visible = True
                    ' MsgBox("3")

                    CurrentUsername = UserPrincipal.Current.DisplayName
                    CONNECTIONSTRING2 = "Server=" & DatabaseIP & ";Database=" & DatabaseName & ";User Id=NatCusLookup;Password=LookinUp123;"

                    If Debug = "True" Then
                        MsgBox(CONNECTIONSTRING2)

                    End If
                    CN2 = New SqlClient.SqlConnection
                    CN2.ConnectionString = CONNECTIONSTRING2
                    If Debug = "True" Then
                        MsgBox("Authorized")
                    End If
                    Me.Text = Me.Text & "    Username: " & My.User.Name

                    Button2.Visible = True
                    Label1.Visible = True
                    Label2.Visible = True
                    Label3.Visible = True

                    Button3.Visible = True
                    TextBox2.Visible = True

                End If
                'Else


            End If
        End If


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Cursor = Cursors.WaitCursor
        If Len(Trim(TextBox1.Text)) >= 3 Then

            ToolStripStatusLabel1.Text = "Loading"
            ActiveForm.Refresh()
            TextBox1.Text = UCase(Trim(TextBox1.Text))
            NationalCustomersDataSetBindingSource.Filter = "CustomerName like '" & Trim(TextBox1.Text) & "%'"

            Me.ARCustomersTableAdapter.Fill(Me.NationalCustomersDataSet.ARCustomers)

        Else
            MsgBox("Please enter 3 or more characters to search")

        End If
        Me.Cursor = Cursors.Default
        ToolStripStatusLabel1.Text = "Ready"
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub


    Private Sub TextBox1_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox1.KeyDown
        If e.KeyCode = Keys.Enter Then

            Call Button1_Click(sender, e)
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        ' If this user Is group member of (new) security group and this server is flagged as (registry entry) allowed.
        'then this button is visible. otherwise it is not.
        Form2.Show()





    End Sub



    'Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
    '    If e.RowIndex >= 0 Then

    '        DataGridView1.CurrentCell = Me.DataGridView1(4, e.RowIndex)
    '        Label3.Text = DataGridView1.CurrentCell.Value.ToString

    '        DataGridView1.CurrentCell = Me.DataGridView1(5, e.RowIndex)
    '        Label2.Text = DataGridView1.CurrentCell.Value.ToString


    '    End If

    'End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        'save button
        Cursor.Current = Cursors.WaitCursor
        If Label2.Text <> "" And Label3.Text <> "" And TextBox2.Text <> "" Then

            If CN2.State <> ConnectionState.Open Then
                CN2.Open()
            End If

            Dim cmd As New SqlClient.SqlCommand
            cmd.CommandType = CommandType.Text
            cmd.Connection = CN2
            cmd.CommandText = "Update nationalcustomers.dbo.arcustomers set CorpAcctNumber=@CorpAcctNum where RefreshFromBranch=@BranchID and Customer=@Branchcustomer"
            cmd.Parameters.AddWithValue("@Branchcustomer", Label2.Text)
            cmd.Parameters.AddWithValue("@BranchID", Label3.Text)
            cmd.Parameters.AddWithValue("@CorpAcctNum", TextBox2.Text)
            cmd.ExecuteNonQuery()
            If CN2.State <> ConnectionState.Closed Then
                CN2.Close()
            End If

            Dim t As Integer
            t = Label4.Text
            DataGridView1.CurrentCell = Me.DataGridView1(6, t)
            DataGridView1.CurrentCell.Value = TextBox2.Text


            Cursor.Current = Cursors.Default
        End If



    End Sub



    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick

        Label4.Text = ""
        If e.RowIndex >= 0 Then

            DataGridView1.CurrentCell = Me.DataGridView1(4, e.RowIndex)
            Label3.Text = DataGridView1.CurrentCell.Value.ToString

            DataGridView1.CurrentCell = Me.DataGridView1(5, e.RowIndex)
            Label2.Text = DataGridView1.CurrentCell.Value.ToString

            DataGridView1.CurrentCell = Me.DataGridView1(6, e.RowIndex)
            TextBox2.Text = DataGridView1.CurrentCell.Value.ToString

            Label4.Text = e.RowIndex

        End If
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class
