﻿Public Class Form2
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        Label4.Text = ""

        DataGridView1.Rows.Clear()
        'needs to open up sql connection


        ' pass parameters to stored procedure.
        ' display results from table on to grid.
        ' summarize total $ at the bottom.

        'display sum total



        Dim cmd As New SqlClient.SqlCommand



        If CN2.State <> ConnectionState.Open Then
            CN2.Open()
        End If
        cmd.Connection = CN2
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Load_BranchInvoiceAmt_Table"
        cmd.Parameters.AddWithValue("@Username", CurrentUsername)
        cmd.Parameters.AddWithValue("@CorporateAcctNumber", TextBox1.Text)
        cmd.Parameters.AddWithValue("@Startdate", TextBox2.Text)
        cmd.Parameters.AddWithValue("@EndDate", TextBox3.Text)
        cmd.ExecuteNonQuery()
        cmd.Parameters.Clear()

        If CN2.State = ConnectionState.Open Then
            CN2.Close()
        End If


        If CN2.State <> ConnectionState.Open Then
            CN2.Open()
        End If
        Dim TotalAmount As Double = 0
        'need to read that data into the gridview.
        Dim Zindex As Integer = 0




        cmd.CommandType = CommandType.Text
        cmd.Connection = CN2
        cmd.CommandText = "Select * from Branchinvoiceamt where username=@Username order by BranchID"
        cmd.Parameters.AddWithValue("@Username", CurrentUsername)
        Dim RS As SqlClient.SqlDataReader
        RS = cmd.ExecuteReader
        If RS.HasRows = True Then
            While RS.Read
                DataGridView1.Rows.Add()
                DataGridView1.CurrentCell = Me.DataGridView1(0, Zindex)
                DataGridView1.CurrentCell.Value = RS.Item("BranchID").ToString
                DataGridView1.CurrentCell = Me.DataGridView1(1, Zindex)
                DataGridView1.CurrentCell.Value = RS.Item("BranchLocation").ToString
                DataGridView1.CurrentCell = Me.DataGridView1(2, Zindex)
                If Val(RS.Item("InvoiceTotal").ToString) >= 0 Then
                    DataGridView1.CurrentCell.Value = FormatCurrency(RS.Item("InvoiceTotal").ToString, 2)
                    TotalAmount = Val(TotalAmount) + Val(RS.Item("InvoiceTotal").ToString)
                Else
                    DataGridView1.CurrentCell.Value = "Mapping does not exist"

                End If


                Zindex = Zindex + 1


            End While

        End If
        RS.Close()
        RS.Dispose()

        'CONVERT(varchar(20),@money, 1)

        Label4.Text = FormatCurrency(TotalAmount.ToString, 2)


        ' DataGridView1.Rows.Add()













    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        If DataGridView1.RowCount > 0 Then

            ' Print Button.
            Dim RowLine As String = ""
            ' Throw To simple text file and print out

            Dim mydocpath As String = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)


            'delete any existing report
            If System.IO.File.Exists(mydocpath & Convert.ToString("\salesreport.txt")) = True Then
                System.IO.File.Delete(mydocpath & Convert.ToString("\salesreport.txt"))
            End If



            Using outputFile As New System.IO.StreamWriter(mydocpath & Convert.ToString("\salesreport.txt"), True)
                outputFile.WriteLine("C O N F I D E N T I A L: Staffzone")
                outputFile.WriteLine("For Internal Use Only")
                outputFile.WriteLine("Print Date " & System.DateTime.Now)
                outputFile.WriteLine("Printed By " & My.User.Name.ToString)
                outputFile.WriteLine("")
                outputFile.WriteLine("")
                outputFile.WriteLine("")
                outputFile.WriteLine("Customer " & TextBox1.Text & " (searched other branches using <branch number>" & Mid(TextBox1.Text, 3) & ")")
                outputFile.WriteLine("         " & Label6.Text)
                outputFile.WriteLine("         " & Label7.Text)
                outputFile.WriteLine("         " & Label8.Text)

                outputFile.WriteLine("")
                outputFile.WriteLine("Invoiced sales For the time period " & TextBox2.Text & " to " & TextBox3.Text)
                outputFile.WriteLine("")


                For x = 0 To DataGridView1.RowCount - 1
                    DataGridView1.CurrentCell = Me.DataGridView1(0, x)
                    RowLine = DataGridView1.CurrentCell.Value.ToString & "   "
                    DataGridView1.CurrentCell = Me.DataGridView1(1, x)


                    If Len(Trim(DataGridView1.CurrentCell.Value.ToString)) <= 7 Then
                        RowLine = RowLine & DataGridView1.CurrentCell.Value.ToString & "   " & vbTab & vbTab
                    Else
                        RowLine = RowLine & DataGridView1.CurrentCell.Value.ToString & "   " & vbTab
                    End If
                    DataGridView1.CurrentCell = Me.DataGridView1(2, x)

                    RowLine = RowLine & String.Format("{0,15}", DataGridView1.CurrentCell.Value.ToString)

                    outputFile.WriteLine(RowLine.ToString)


                    RowLine = ""
                Next x

                outputFile.WriteLine("")

                outputFile.WriteLine("Total Sales   " & Label4.Text.ToString)


            End Using


            'print dialog function goes here

            PrintFile(mydocpath & Convert.ToString("\salesreport.txt"))


            ''after printing, delete it
            'If System.IO.File.Exists(mydocpath & Convert.ToString("\salesreport.txt")) = True Then

            '    System.IO.File.Delete(mydocpath & Convert.ToString("\salesreport.txt"))
            'End If


        End If

    End Sub
    Sub PrintFile(ByVal fileName As String)
        Dim myFile As New ProcessStartInfo
        With myFile
            .UseShellExecute = True
            .WindowStyle = ProcessWindowStyle.Hidden
            .FileName = fileName
            .Verb = "Print"
        End With
        Process.Start(myFile)
    End Sub
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label4.Text = ""
        Me.DataGridView1.Columns("InvAmt").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
    End Sub

    Private Sub TextBox1_Leave(sender As Object, e As EventArgs) Handles TextBox1.Leave
        TextBox1.Text = UCase(TextBox1.Text)

        If CN2.State <> ConnectionState.Open Then
            CN2.Open()
        End If
        Dim cmd As New SqlClient.SqlCommand

        cmd.CommandType = CommandType.Text
        cmd.Connection = CN2
        cmd.CommandText = "Select top(1) CustomerName,Address,CityLine from arcustomers where CorpAcctNumber=@customer"
        cmd.Parameters.AddWithValue("@customer", TextBox1.Text)

        Dim RS As SqlClient.SqlDataReader
        RS = cmd.ExecuteReader
        If RS.HasRows = True Then
            RS.Read()
            Label6.Text = RS.Item(0).ToString
            Label7.Text = RS.Item(1).ToString
            Label8.Text = RS.Item(2).ToString
        End If
        RS.Close()
        RS.Dispose()



        If CN2.State <> ConnectionState.Closed Then
            CN2.Close()
        End If


    End Sub


End Class