﻿Module Module1


    Friend SalesViewAuthorized As Boolean = False
    Friend DomainName As String
    Friend DomainConnector As String
    Friend DatabaseIP As String
    Friend DatabaseName As String

    Friend Debug As String

    Friend CONNECTIONSTRING2 As String

    Friend CN2 As New SqlClient.SqlConnection(CONNECTIONSTRING2)

    Friend SSN As String
    Friend CurrentBranch As String
    Friend CurrentName As String

    Friend CurrentUsername As String = ""
End Module
