﻿Public Class Form2
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim cmd As New SqlClient.SqlCommand



        If CN2.State <> ConnectionState.Open Then
            CN2.Open()
        End If


        cmd.Connection = CN2

        cmd.CommandText = "Select ltrim(rtrim(Branchid)) + '-' + ltrim(rtrim(Branchname)) from EverifyAudit_SZ1.dbo.branchmaster where active=1 order by branchid"

        Dim RS As SqlClient.SqlDataReader
        RS = cmd.ExecuteReader
        If RS.HasRows = True Then

            ComboBox1.Items.Clear()
            While RS.Read
                ComboBox1.Items.Add(RS.Item(0).ToString)
            End While
        End If
        RS.Close()
        RS = Nothing



        'needs to get active branches into listbox.
        MonthCalendar1.MaxSelectionCount = 1
        ToolStripStatusLabel1.Text = ""

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If ComboBox1.Text <> "" Then
            Dim Y
            Dim Z As String
            Y = MonthCalendar1.SelectionRange.Start.ToShortDateString()


            Z = DatePart(DateInterval.Year, Y,).ToString & "-" & DatePart(DateInterval.Month, Y).ToString & "-" & DatePart(DateInterval.Day, Y)
            'need to build the exec sql string here.

            ' MsgBox(Z.ToString)


            Dim cmd As New SqlClient.SqlCommand

            cmd.Connection = CN2

            If CN2.State <> ConnectionState.Open Then
                CN2.Open()
            End If

            cmd.CommandText = "select ltrim(rtrim(BranchID)) from EverifyAudit_SZ1.dbo.branchmaster where BranchID='" & Mid(ComboBox1.Text, 1, 3) & "'"
            Dim Branchlink As String
            Branchlink = cmd.ExecuteScalar

            cmd.CommandText = "exec " & Branchlink & "LINK.wagehistory.dbo.DailyNewHireReporting_by_Date @enterdate='" & Z & "'"

            'MsgBox(cmd.CommandText)
            Try
                cmd.ExecuteNonQuery()


                ToolStripStatusLabel1.Text = "Email for " & ComboBox1.Text & " date=" & Z & " queued"

            Catch ex As Exception
                MsgBox("An error ocurred during the attempt to execute this procedure, The branch payout computer is likely offline. Please try again later.")


            End Try

        End If

    End Sub
End Class