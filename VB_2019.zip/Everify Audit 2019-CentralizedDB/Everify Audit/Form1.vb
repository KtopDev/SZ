﻿Imports System.Security.Principal
Imports System.DirectoryServices.AccountManagement
Imports System.IO.Compression
Imports System.Net.Mail

Public Class Form1
    Private loadX As Boolean = True
    Private CurrentSSN As String
    Private CurrentDate As String
    Private CurrentBranch As String


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label1.Text = ""
        Label2.Text = ""

        'persom must be memeber of report_everify to access this app


        '1 domain information for security
        Debug = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\Software\Reportdriver", "Debug", Nothing)
        DomainName = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\Software\Reportdriver", "DomainName", Nothing)
        DomainConnector = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\Software\Reportdriver", "DomainConnector", Nothing)
        '2 database connector information
        ' DatabaseIP = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\Software\Reportdriver", "DatabaseIP", Nothing)
        ' DatabaseName = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\Software\Reportdriver", "Database2", Nothing)
        DatabaseIP2 = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\Software\Reportdriver", "DatabaseIP2", Nothing)
        DatabaseName2 = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\Software\Reportdriver", "Database2", Nothing)

        'DatabaseIP2 = "192.168.100.162"
        'DatabaseName2 = "Everifyaudit_SZ1"
        Dim T As New PrincipalContext(ContextType.Domain, DomainName, DomainConnector)

        If GroupPrincipal.FindByIdentity(T, "Report_EVerify") IsNot Nothing Then
            If UserPrincipal.Current.IsMemberOf(GroupPrincipal.FindByIdentity(T, "Report_EVerify")) = True Then
                'user is authorized

                Label1.Text = " Username: " & My.User.Name

                'CONNECTIONSTRING2 = "Server=" & DatabaseIP & ";Database=EverifyAudit;User Id=EverifyAuditUser;Password=RainSuit200;"
                CONNECTIONSTRING2 = "Server=" & DatabaseIP2 & ";Database=" & DatabaseName2 & ";User Id=EverifyAuditUser;Password=RainSuit200;"

                CN2 = New SqlClient.SqlConnection
                CN2.ConnectionString = CONNECTIONSTRING2
                CN3 = New SqlClient.SqlConnection
                CN3.ConnectionString = CONNECTIONSTRING2
                CN4 = New SqlClient.SqlConnection
                CN4.ConnectionString = CONNECTIONSTRING2

                Dim cmd As New SqlClient.SqlCommand

                cmd.Connection = CN2

                If CN2.State <> ConnectionState.Open Then
                    CN2.Open()
                End If

            Else
                MsgBox("You are not authorized to access this system, or a domain controller cannot verify your credentials.")
                End

            End If
        Else
            MsgBox("Please notify the system administrator that the Active Directory security group 'Report_Everify' does not exist in this domain or a domain controller cannot be contacted.")
            End

        End If

        'need to load combobox here with entries without an ACK
        Call LoadcomboBoxes()
        Label2.Text = ""
        ComboBox2.Items.Clear()
        TextBox1.Text = ""
        loadX = False

    End Sub


    Private Sub LoadcomboBoxes()


        If CN2.State <> ConnectionState.Open Then
            CN2.Open()
        End If

        Dim cmd As New SqlClient.SqlCommand
        cmd.CommandType = CommandType.Text
        cmd.Connection = CN2
        cmd.CommandText = "select BranchID,cast([date] as date) as Zdate, ssn, lastnamefirst from EverifyAudit_SZ1.dbo.consolidatedaudittable where ackcode is null order by BranchID,LastNameFirst"
        Dim RS As SqlClient.SqlDataReader
        RS = cmd.ExecuteReader
        If RS.HasRows = True Then

            ComboBox1.Items.Clear()
            While RS.Read
                ComboBox1.Items.Add(RS.Item("BranchID").ToString & "    " & RS.Item("SSN").ToString & "  " & RS.Item("Zdate").ToshortdateString & "    " & RS.Item("LastNameFirst").ToString)
            End While
        End If
        RS.Close()
        RS = Nothing

    End Sub

    Private Sub LoadComboboxesByPartialSSN()


        Dim cmd As New SqlClient.SqlCommand
        cmd.CommandType = CommandType.Text
        cmd.Connection = CN2
        cmd.CommandText = "select BranchID,cast([date] as date) as Zdate, ssn, lastnamefirst from EverifyAudit_SZ1.dbo.consolidatedaudittable where ackcode is null and ssn like '" & Trim(TextBox2.Text) & "%' order by SSN"
        Dim RS As SqlClient.SqlDataReader
        RS = cmd.ExecuteReader
        If RS.HasRows = True Then

            ComboBox1.Items.Clear()
            While RS.Read
                ComboBox1.Items.Add(RS.Item("BranchID").ToString & "    " & RS.Item("SSN").ToString & "  " & RS.Item("Zdate").ToshortdateString & "    " & RS.Item("LastNameFirst").ToString)
            End While
        End If
        RS.Close()
        RS = Nothing

    End Sub
    Private Sub LoadComboboxesByPartialSSN2()


        Dim cmd As New SqlClient.SqlCommand
        cmd.CommandType = CommandType.Text
        cmd.Connection = CN2
        cmd.CommandText = "select BranchID,cast([date] as date) as Zdate, ssn, lastnamefirst from EverifyAudit_SZ1.dbo.consolidatedaudittable where ackcode is null and rtrim(ssn) like '%" & Trim(TextBox3.Text) & "' order by SSN"
        Dim RS As SqlClient.SqlDataReader
        RS = cmd.ExecuteReader
        If RS.HasRows = True Then

            ComboBox1.Items.Clear()
            While RS.Read
                ComboBox1.Items.Add(RS.Item("BranchID").ToString & "    " & RS.Item("SSN").ToString & "  " & RS.Item("Zdate").ToshortdateString & "    " & RS.Item("LastNameFirst").ToString)
            End While
        End If
        RS.Close()
        RS = Nothing

    End Sub


    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

        'need to pull the person details including branch number
        'and then allow entry of ackcode,ackstatus,ack user, and timestamp ackdate.
        Dim cmd As New SqlClient.SqlCommand
        cmd.Connection = CN2
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select BranchID,Lastnamefirst,[date],SSN from EverifyAudit_SZ1.dbo.consolidatedaudittable where ssn=@ssn and ackcode is null"
        cmd.Parameters.AddWithValue("@SSN", Mid(Trim(ComboBox1.Text), 8, 9))
        Dim rs As SqlClient.SqlDataReader
        rs = cmd.ExecuteReader
        If rs.HasRows = True Then
            rs.Read()
            CurrentSSN = rs.Item("SSN").ToString
            CurrentBranch = rs.Item("Branchid").ToString
            CurrentDate = rs.Item("Date").ToString


            Label2.Text = rs.Item("BranchID").ToString & "  " & Mid(Trim(ComboBox1.Text), 8, 9) & "    " & rs.Item("Lastnamefirst").ToString
            rs.Close()


            Call LoadAckReposnses()

        End If
        rs.Close()
        rs = Nothing

        cmd.Parameters.Clear()
        cmd.CommandText = "Select Ackcode from EverifyAudit_SZ1.dbo.CaseCrossReference where SSN=@CurrentSSN and BranchID=@CurrentBranch"
        cmd.Parameters.AddWithValue("@currentSSN", CurrentSSN)
        cmd.Parameters.AddWithValue("@CurrentBranch", CurrentBranch)
        Dim R
        R = cmd.ExecuteScalar
        If Not R = Nothing And IsDBNull(R) = False Then
            TextBox1.Text = R.ToString
        End If





    End Sub

    Private Sub LoadAckReposnses()
        ComboBox2.Items.Clear()

        Dim cmd As New SqlClient.SqlCommand
        cmd.CommandType = CommandType.Text
        cmd.Connection = CN2
        cmd.CommandText = "select responsetext from EverifyAudit_SZ1.dbo.responses order by responsecode asc"
        Dim RS As SqlClient.SqlDataReader
        RS = cmd.ExecuteReader
        If RS.HasRows = True Then
            While RS.Read
                ComboBox2.Items.Add(RS.Item("responsetext").ToString)
            End While
        End If
        RS.Close()
        RS = Nothing



    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim cmd As New SqlClient.SqlCommand
        cmd.CommandType = CommandType.Text
        cmd.Connection = CN2

        If Trim(Label2.Text) <> "" Then 'select ssn
            If Trim(TextBox1.Text) <> "" Then 'case number

                If ComboBox2.SelectedItem <> Nothing Then

                    If Trim(ComboBox2.SelectedItem.ToString) <> "" Then  'case response

                        If CN2.State <> ConnectionState.Open Then
                            CN2.Open()
                        End If


                        'saves the response code
                        'removes this SSN from the list
                        'resets variables
                        If CheckBox1.Checked = True Or CheckBox2.Checked = True Then
                            cmd.Parameters.Clear()
                            cmd.CommandText = "Insert Into EverifyAudit_SZ1.dbo.DataErrorLog(SSN,BranchID,LastNameFirst,AckDate,BadScan,BadData,AckUser) values (@SSN,@BranchID,@LNF,Getdate(),@BS,@BD,@Ackuser)"


                            cmd.Parameters.AddWithValue("@AckCode", Trim(TextBox1.Text))
                            cmd.Parameters.AddWithValue("@Ackuser", My.User.Name)
                            cmd.Parameters.AddWithValue("@ssn", CurrentSSN)
                            cmd.Parameters.AddWithValue("@lnf", Trim(Mid(Label2.Text, 17)))
                            cmd.Parameters.AddWithValue("@BranchID", CurrentBranch)
                            cmd.Parameters.AddWithValue("@BS", CheckBox1.Checked)
                            cmd.Parameters.AddWithValue("@BD", CheckBox2.Checked)

                            cmd.ExecuteNonQuery()
                            cmd.Parameters.Clear()
                        End If



                        cmd.CommandText = "update EverifyAudit_SZ1.dbo.consolidatedaudittable set Ackcode=@ackcode,AckStatus=@ackStatus,ackdate=getdate(),Ackuser=@ackuser where Branchid=@branchID and SSN=@ssn"

                        cmd.Parameters.AddWithValue("@AckCode", Trim(TextBox1.Text))
                        cmd.Parameters.AddWithValue("@ackstatus", ComboBox2.SelectedIndex.ToString)
                        cmd.Parameters.AddWithValue("@Ackuser", My.User.Name)
                        cmd.Parameters.AddWithValue("@ssn", CurrentSSN)
                        'cmd.Parameters.AddWithValue("@currentdate", CurrentDate)
                        cmd.Parameters.AddWithValue("@BranchID", CurrentBranch)


                        Try

                            cmd.ExecuteNonQuery()

                            ComboBox1.Text = ""
                            LoadcomboBoxes()
                            Label2.Text = ""
                            ComboBox2.Items.Clear()
                            ComboBox2.Text = ""
                            TextBox1.Text = ""

                        Catch ex As SqlClient.SqlException
                            MsgBox("An Error Ocurred saving this record")
                            MsgBox(ex.InnerException.ToString)
                        End Try







                    Else
                        MsgBox("You must select a response code")
                    End If
                Else

                    If CheckBox1.Checked = True Or CheckBox2.Checked = True Then
                        cmd.Parameters.Clear()
                        cmd.CommandText = "Insert Into EverifyAudit_SZ1.dbo.DataErrorLog(SSN,BranchID,LastNameFirst,AckDate,BadScan,BadData,AckUser) values (@SSN,@BranchID,@LNF,Getdate(),@BS,@BD,@Ackuser)"


                        cmd.Parameters.AddWithValue("@AckCode", Trim(TextBox1.Text))
                        cmd.Parameters.AddWithValue("@Ackuser", My.User.Name)
                        cmd.Parameters.AddWithValue("@ssn", CurrentSSN)
                        cmd.Parameters.AddWithValue("@lnf", Trim(Mid(Label2.Text, 17)))
                        cmd.Parameters.AddWithValue("@BranchID", CurrentBranch)
                        cmd.Parameters.AddWithValue("@BS", CheckBox1.Checked)
                        cmd.Parameters.AddWithValue("@BD", CheckBox2.Checked)

                        cmd.ExecuteNonQuery()
                    End If



                    If Trim(TextBox1.Text) <> "" Then
                        cmd.Parameters.Clear()
                        cmd.CommandText = "Select SSN from EverifyAudit_SZ1.dbo.casecrossReference where SSN=@ssn"
                        cmd.Parameters.AddWithValue("@ssn", CurrentSSN)
                        Dim R
                        R = cmd.ExecuteScalar
                        If IsNothing(R) = True Or IsDBNull(R) = True Then




                            cmd.Parameters.Clear()
                            cmd.CommandText = "insert into EverifyAudit_SZ1.dbo.casecrossReference(SSN,BranchID,Date,AckCode) Values(@SSN,@BranchID,Getdate(),@AckCode)"
                            cmd.Parameters.AddWithValue("@ssn", CurrentSSN)
                            cmd.Parameters.AddWithValue("@BranchID", CurrentBranch)
                            cmd.Parameters.AddWithValue("@AckCode", Trim(TextBox1.Text))
                            cmd.ExecuteNonQuery()
                        End If

                    End If



                End If

            Else

                If CheckBox1.Checked = True Or CheckBox2.Checked = True Then
                    cmd.Parameters.Clear()
                    cmd.CommandText = "Insert Into EverifyAudit_SZ1.dbo.DataErrorLog(SSN,BranchID,LastNameFirst,AckDate,BadScan,BadData,AckUser) values (@SSN,@BranchID,@LNF,Getdate(),@BS,@BD,@Ackuser)"


                    cmd.Parameters.AddWithValue("@AckCode", Trim(TextBox1.Text))
                    ' cmd.Parameters.AddWithValue("@ackstatus", ComboBox2.SelectedIndex.ToString)
                    cmd.Parameters.AddWithValue("@Ackuser", My.User.Name)
                    cmd.Parameters.AddWithValue("@ssn", CurrentSSN)
                    cmd.Parameters.AddWithValue("@lnf", Trim(Mid(Label2.Text, 17)))
                    cmd.Parameters.AddWithValue("@BranchID", CurrentBranch)
                    cmd.Parameters.AddWithValue("@BS", CheckBox1.Checked)
                    cmd.Parameters.AddWithValue("@BD", CheckBox2.Checked)

                    cmd.ExecuteNonQuery()





                    If Trim(TextBox1.Text) <> "" Then
                        cmd.Parameters.Clear()
                        cmd.CommandText = "Select SSN from EverifyAudit_SZ1.dbo.casecrossReference where SSN=@ssn"
                        cmd.Parameters.AddWithValue("@ssn", CurrentSSN)
                        Dim R
                        R = cmd.ExecuteScalar
                        If IsNothing(R) = True Or IsDBNull(R) = True Then




                            cmd.Parameters.Clear()
                            cmd.CommandText = "insert into EverifyAudit_SZ1.dbo.casecrossReference(SSN,BranchID,Date,AckCode) Values(@SSN,@BranchID,Getdate(),@AckCode)"
                            cmd.Parameters.AddWithValue("@ssn", CurrentSSN)
                            cmd.Parameters.AddWithValue("@BranchID", CurrentBranch)
                            cmd.Parameters.AddWithValue("@AckCode", Trim(TextBox1.Text))
                            cmd.ExecuteNonQuery()
                        End If

                    End If

                    ComboBox1.Text = ""
                    LoadcomboBoxes()
                    Label2.Text = ""
                    ComboBox2.Items.Clear()
                    ComboBox2.Text = ""
                    TextBox1.Text = ""
                    CheckBox1.Checked = False
                    CheckBox2.Checked = False

                Else
                    MsgBox("You must enter a case number")

                End If




            End If

            ComboBox1.Text = ""
            LoadcomboBoxes()
            Label2.Text = ""
            ComboBox2.Items.Clear()
            ComboBox2.Text = ""
            TextBox1.Text = ""
            CheckBox1.Checked = False
            CheckBox2.Checked = False
        Else
            MsgBox("You must select a SSN")
        End If


    End Sub



    Private Sub TextBox2_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox2.KeyDown
        If e.KeyCode = Keys.Enter Then
            If Len(Trim(TextBox2.Text)) >= 3 Then
                Call LoadComboboxesByPartialSSN()
            Else
                MsgBox("You must enter at least 3 digits")
            End If
        End If

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub TextBox2_GotFocus(sender As Object, e As EventArgs) Handles TextBox2.GotFocus
        RadioButton2.Checked = True
    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        If loadX = False Then
            If RadioButton1.Checked = True Then
                TextBox2.Text = ""
                Label2.Text = ""
                ComboBox1.Text = ""
                TextBox3.Text = ""
                LoadcomboBoxes()
            End If
        End If
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        If loadX = False Then
            If RadioButton2.Checked = True Then
                ComboBox1.Text = ""
                Label2.Text = ""
                TextBox3.Text = ""
            End If
        End If
    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged

        If loadX = False Then
            If RadioButton2.Checked = True Then
                TextBox2.Text = ""
                ComboBox1.Text = ""
                Label2.Text = ""
            End If
        End If





    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged

    End Sub

    Private Sub TextBox3_GotFocus(sender As Object, e As EventArgs) Handles TextBox3.GotFocus
        RadioButton3.Checked = True
    End Sub

    Private Sub TextBox3_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox3.KeyDown
        If e.KeyCode = Keys.Enter Then
            If Len(Trim(TextBox3.Text)) = 4 Then
                Call LoadComboboxesByPartialSSN2()
            Else
                MsgBox("You must enter the last 4 digits")
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form2.Show()
    End Sub
    'need to load ack code table

End Class
