﻿function getAntiForgeryToken() {
    return document.getElementsByName("__RequestVerificationToken")[0].value;
}

function postData(url, params) {
    var form = document.createElement("form");
    form.setAttribute("method", "POST");
    form.setAttribute("action", url);
    form.style.display = "none";

    var tokenField = document.createElement("input");
    tokenField.setAttribute("type", "hidden");
    tokenField.setAttribute("name", "__RequestVerificationToken");
    tokenField.setAttribute("value", getAntiForgeryToken());
    form.appendChild(tokenField);

    for (var key in params) {
        if (params.hasOwnProperty(key)) {
            var hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", key);
            hiddenField.setAttribute("value", params[key]);

            form.appendChild(hiddenField);
        }
    }
    
    document.body.appendChild(form);
    form.submit();
    document.body.removeChild(form);
}

$("#logout").click(function () {
    var actionLink = $(this).attr("data-action-link");
    postData(actionLink);
});

$(document).ready(function () {
    $("#lang-selector").on("change", function () {
        window.location.href = "/Home/ChangeCulture?culture=" + $(this).val();
    });

    //$(".rtf-viewer").on("load", function () {
    //    $(this).contents().find("body").attr("style", "padding: 1.5rem");
    //    $(this).contents().find("body div:last-child").remove();
    //});

    $(".rtf-viewer a[href*='sautinsoft']").remove();

    $(".pdf-viewer").on("load", function () {
        
    });

    $("input[type=text].autocomplete-none").on("keyup", function (event) {
        var value = $(this).val();
        if (value.toLowerCase() === "n" && event.key.toLowerCase() === "n") {
            $(this).val("None");
        }
    });

    $(".uncheckable-radio").on("click", function (e) {
        var radioElem = $("#" + $(this).attr("for"));

        if (radioElem.prop("checked")) {
            e.preventDefault();
            $(radioElem).prop("checked", false);

            if ($("#forms-ncwithholding-page").length > 0
                && radioElem.attr("name") === "Settings.FilingType") {
                $("#FilingType1Options").addClass("d-none");
                $("#FilingType2Options").addClass("d-none");
                $("#FilingType3Options").addClass("d-none");

                //$("input[name='SettingsModel.FilingIncomeRange']").prop("checked", false);
            }
        }
    });

    if ($("#start-page").length < 1) {
        /*
     *  User inactivity timer.
     */
        var inactivityDetectTimer,
            inactivityNoticeTimer,
            isDetectedInactivity = false;

        function startInactivityDetectTimer() {
            if (isDetectedInactivity)
                return;

            stopInactivityDetectTimer(inactivityDetectTimer);

            inactivityDetectTimer = setTimeout(function () {
                isDetectedInactivity = true;

                // Show modal.
                var inactivityNoticeModal = new bootstrap.Modal(document.getElementById('inactivity-notice-modal'));
                inactivityNoticeModal.show();

                startInactivityNoticeTimer();
            }, 180000);
        }

        function stopInactivityDetectTimer() {
            if (inactivityDetectTimer)
                clearTimeout(inactivityDetectTimer);
        }

        function startInactivityNoticeTimer() {
            stopInactivityNoticeTimer(inactivityNoticeTimer);

            inactivityNoticeTimer = setTimeout(function () {
                window.location.href = "/Home";
            }, 15000);
        }

        function stopInactivityNoticeTimer() {
            if (inactivityNoticeTimer)
                clearTimeout(inactivityNoticeTimer);

            startInactivityDetectTimer();
        }

        $("#inactivity-notice-modal .modal-footer button").on("click", function () {
            isDetectedInactivity = false;

            stopInactivityNoticeTimer();
        });

        var events = [
            'load',
            'mousedown',
            //'mousemove',
            'keydown',
            //'keyup',
            'input',
            'scroll',
            'touchstart',
            'touchend',
            'touchcancel',
            'touchmove',
        ];
        events.forEach(name => {
            document.addEventListener(name, startInactivityDetectTimer, true);
        });
    }
});

function ToNumber(value) {
    return (value || 0) * 1.0;
}

function changeAndTriggerChk(selector, checked) {
    $(selector).prop("checked", checked);
    $(selector).trigger("change");
}

function startLogoutTimer(timeoutInSec) {
    setTimeout(function () {
        window.location.href = "/Home";
    }, timeoutInSec * 1000);
}

function makeSpecialTextInputField(id, text) {
    $("#" + id).on("keydown", function (e) {
        var key = e.key.toLowerCase();

        if (key === "backspace" || key === "delete")
            $(e.target).val("");
        else
            $(e.target).val(text);

        e.preventDefault();
    });
}