﻿$(document).ready(function () {
    function doLoginFormSubmit(isNew) {
        $("#IsNew").val(isNew ? "True" : "False");
        $("#login-form").submit();
    }

    //$("#start").click(function () {
    //    doLoginFormSubmit(false);
    //});

    //$("#new-user").click(function () {
    //    doLoginFormSubmit(true);
    //});
});