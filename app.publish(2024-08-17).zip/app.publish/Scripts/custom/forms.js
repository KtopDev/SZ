﻿$(document).ready(function () {
    if ($("#forms-w42020form-form").length > 0) {
        var under17DependentUnitCost = ToNumber($("#Under17DependentUnitCost").val()),
            otherDependentUnitCost = ToNumber($("#OtherDependentUnitCost").val());

        $("#Under17Dependents").on("focusout", function () {
            var amount = ToNumber($(this).val()) * under17DependentUnitCost,
                otherDependentsAmount = ToNumber($("#OtherDependentsAmount").val());

            $("#Under17DependentsAmount").val(amount);
            $("#TotalDependentsAmount").val(amount + otherDependentsAmount);
        });

        $("#OtherDependents").on("focusout", function () {
            var amount = ToNumber($(this).val()) * otherDependentUnitCost,
                under17DependentsAmount = ToNumber($("#Under17DependentsAmount").val()) * 1.0;

            $("#OtherDependentsAmount").val(amount);
            $("#TotalDependentsAmount").val(amount + under17DependentsAmount);
        });
    }


    if ($("#forms-w42022form-form").length > 0) {
        var under17DependentUnitCost = ToNumber($("#Under17DependentUnitCost").val()),
            otherDependentUnitCost = ToNumber($("#OtherDependentUnitCost").val());

        $("#Under17Dependents").on("focusout", function () {
            var amount = ToNumber($(this).val()) * under17DependentUnitCost,
                otherDependentsAmount = ToNumber($("#OtherDependentsAmount").val());

            $("#Under17DependentsAmount").val(amount);
            $("#TotalDependentsAmount").val(amount + otherDependentsAmount);
        });

        $("#OtherDependents").on("focusout", function () {
            var amount = ToNumber($(this).val()) * otherDependentUnitCost,
                under17DependentsAmount = ToNumber($("#Under17DependentsAmount").val()) * 1.0;

            $("#OtherDependentsAmount").val(amount);
            $("#TotalDependentsAmount").val(amount + under17DependentsAmount);
        });
    }


    if ($("#forms-i9-page").length > 0) {
        $("#AlienExpirationDatePicker").datetimepicker({
            format: 'MM/DD/YYYY',
            ignoreReadonly: true
        });
    }

    if ($("#forms-i9form-page").length > 0) {
        $("#AlienExpirationDatePicker").datetimepicker({
            format: 'MM/DD/YYYY',
            ignoreReadonly: true
        });


        function showElementsByI9ApplicantType(applicantType) {
            if (applicantType === $("#ApplicantType_LPR").val()) {
                $("#USCISNumber1").removeClass("d-none");

                $("#AlienExpirationDatePicker").addClass("d-none");
                $("#USCISNumber2").addClass("d-none");
                $("#I94AdmissionNumber").addClass("d-none");
                $("#ForeignPassportNumber").addClass("d-none");
                $("#IssuedCountry").addClass("d-none");
            } else if (applicantType === $("#ApplicantType_Alien").val()) {
                $("#USCISNumber1").addClass("d-none");

                $("#AlienExpirationDatePicker").removeClass("d-none");
                $("#USCISNumber2").removeClass("d-none");
                $("#I94AdmissionNumber").removeClass("d-none");
                $("#ForeignPassportNumber").removeClass("d-none");
                $("#IssuedCountry").removeClass("d-none");
            } else {
                $("#USCISNumber1").addClass("d-none");

                $("#AlienExpirationDatePicker").addClass("d-none");
                $("#USCISNumber2").addClass("d-none");
                $("#I94AdmissionNumber").addClass("d-none");
                $("#ForeignPassportNumber").addClass("d-none");
                $("#IssuedCountry").addClass("d-none");
            }
        }

        showElementsByI9ApplicantType($("input[name=ApplicantType]:checked").val());

        $("input[name=ApplicantType]").on("change", function () {
            showElementsByI9ApplicantType($(this).val());
        });
    }


    if ($("#forms-9061a-page").length > 0) {
        // Click V9061Q13A
        function makeElementsDisableV9061Q13A(value) {
            if (!$("#F9061A_V9061Q13A").is(":checked")) {
                $("#F9061A_V9061Q13B").attr("disabled", true);
                $("#F9061A_V9061Q13C").attr("disabled", true);
                $("#F9061A_V9061Q13D").attr("disabled", true);
                $("#F9061A_V9061Q13E").attr("disabled", true);
            } else {
                $("#F9061A_V9061Q13B").removeAttr("disabled");
                $("#F9061A_V9061Q13C").removeAttr("disabled");
                $("#F9061A_V9061Q13D").removeAttr("disabled");
                $("#F9061A_V9061Q13E").removeAttr("disabled");
            }

            makeElementsDisableV9061Q13B();
        }
        makeElementsDisableV9061Q13A();

        $("#F9061A_V9061Q13A").on("change", function () {
            makeElementsDisableV9061Q13A();
        });


        // Click V9061Q13B
        function makeElementsDisableV9061Q13B(value) {
            if ($("#F9061A_V9061Q13B").is(":disabled") || !$("#F9061A_V9061Q13B").is(":checked")) {
                $("#F9061A_V9061Q13Recipient").attr("disabled", true);
                $("#F9061A_V9061Q13CityState").attr("disabled", true);
            } else {
                $("#F9061A_V9061Q13Recipient").removeAttr("disabled");
                $("#F9061A_V9061Q13CityState").removeAttr("disabled");
            }
        }
        makeElementsDisableV9061Q13B();

        $("#F9061A_V9061Q13B").on("change", function () {
            makeElementsDisableV9061Q13B();
        });

        // Click V9061Q14A
        function makeElementsDisableV9061Q14A(value) {
            if (!$("#F9061A_V9061Q14A").is(":checked")) {
                $("#F9061A_V9061Q14Recipient1").attr("disabled", true);
                $("#F9061A_V9061Q14CityState1").attr("disabled", true);
            } else {
                $("#F9061A_V9061Q14Recipient1").removeAttr("disabled");
                $("#F9061A_V9061Q14CityState1").removeAttr("disabled");
            }
        }
        makeElementsDisableV9061Q14A();

        $("#F9061A_V9061Q14A").on("change", function () {
            makeElementsDisableV9061Q14A();
        });

        // Click V9061Q14B
        function makeElementsDisableV9061Q14B() {
            if (!$("#F9061A_V9061Q14B").is(":checked")) {
                $("#F9061A_V9061Q14Recipient2").attr("disabled", true);
                $("#F9061A_V9061Q14CityState2").attr("disabled", true);
            } else {
                $("#F9061A_V9061Q14Recipient2").removeAttr("disabled");
                $("#F9061A_V9061Q14CityState2").removeAttr("disabled");
            }
        }
        makeElementsDisableV9061Q14B();

        $("#F9061A_V9061Q14B").on("change", function () {
            makeElementsDisableV9061Q14B();
        });
    }


    if ($("#forms-9061b-page").length > 0) {
        $("#V9061Q17DOCDatePicker").datetimepicker({
            format: 'MM/DD/YYYY',
            ignoreReadonly: true
        });

        $("#V9061Q17DORDatePicker").datetimepicker({
            format: 'MM/DD/YYYY',
            ignoreReadonly: true
        });

        // Click F9061B.V9061Q16x
        function makeElementsDisableV9061Q16x() {
            if (!$("input[id^=F9061B_V9061Q16]").is(":checked")) {
                $("#F9061B_V9061Q16Recipient").attr("disabled", true);
                $("#F9061B_V9061Q16CityState").attr("disabled", true);
            } else {
                $("#F9061B_V9061Q16Recipient").removeAttr("disabled");
                $("#F9061B_V9061Q16CityState").removeAttr("disabled");
            }
        }
        makeElementsDisableV9061Q16x();

        $("input[id^=F9061B_V9061Q16]").on("change", function () {
            makeElementsDisableV9061Q16x();
        });

        // Click F9061B_V9061Q17A
        function makeElementsDisableV9061Q17A() {
            if (!$("#F9061B_V9061Q17A").is(":checked")) {
                $("#F9061B_V9061Q17S").attr("disabled", true);
                $("#F9061B_V9061Q17F").attr("disabled", true);
                $("#F9061B_V9061Q17DOC").attr("disabled", true);
                $("#F9061B_V9061Q17DOR").attr("disabled", true);
            } else {
                $("#F9061B_V9061Q17S").removeAttr("disabled");
                $("#F9061B_V9061Q17F").removeAttr("disabled");
                $("#F9061B_V9061Q17DOC").removeAttr("disabled");
                $("#F9061B_V9061Q17DOR").removeAttr("disabled");
            }
        }
        makeElementsDisableV9061Q17A();

        $("#F9061B_V9061Q17A").on("change", function () {
            makeElementsDisableV9061Q17A();
        });

        // Click F9061B_V9061Q23A
        function makeElementsDisableV9061Q23A() {
            if (!$("#F9061B_V9061Q23A").is(":checked")) {
                $("#F9061B_V9061Q23State").attr("disabled", true);
            } else {
                $("#F9061B_V9061Q23State").removeAttr("disabled");
            }
        }
        makeElementsDisableV9061Q23A();

        $("#F9061B_V9061Q23A").on("change", function () {
            makeElementsDisableV9061Q23A();
        });
    };

    if ($("#forms-ncwithholding-page").length > 0) {
        function toggleFilingTypeOptionsBlock(isLoading = false) {
            $("#FilingType1Options").addClass("d-none");
            $("#FilingType2Options").addClass("d-none");
            $("#FilingType3Options").addClass("d-none");

            if (!isLoading)
                $("input[name='Settings.FilingIncomeRange']").prop("checked", false);

            var checkedElem = $("input[name='Settings.FilingType']:checked");
            if (checkedElem.length > 0) {
                $("#" + checkedElem.attr("id") + "Options").removeClass("d-none");
            }
        }

        toggleFilingTypeOptionsBlock(true);

        $("input[name='Settings.FilingType']").on("change", function (e) {
            toggleFilingTypeOptionsBlock();
        });
    }

    if ($("#forms-vawithholding-page").length > 0) {
        $("#C1, #C2, #C3").on("focusout", function () {
            if (ToNumber($(this).val()) < 0)
                $(this).val(0);

            if (ToNumber($(this).val()) > 1)
                $(this).val(1);

            var c4Total = ToNumber($("#C1").val())
                + ToNumber($("#C2").val())
                + ToNumber($("#C3").val());
            var c8Total = ToNumber($("#C7").val()) + c4Total;

            $("#C4").val(c4Total);
            $("#C8").val(c8Total);

            $("#C1ASub").val(c4Total);
            $("#C1CSub").val(c8Total);
        });

        $("#C5A, #C5B, #C6A, #C6B").on("focusout", function () {
            if (ToNumber($(this).val()) < 0)
                $(this).val(0);

            if (ToNumber($(this).val()) > 1)
                $(this).val(1);

            var c7Total = ToNumber($("#C5A").val())
                + ToNumber($("#C5B").val())
                + ToNumber($("#C6A").val())
                + ToNumber($("#C6B").val());
            var c8Total = ToNumber($("#C4").val()) + c7Total;

            $("#C7").val(c7Total);
            $("#C8").val(c8Total);

            $("#C1BSub").val(c7Total);
            $("#C1CSub").val(c8Total);
        });
    }

    if ($("#forms-gawithholding-page").length > 0) {
        function calcTotals() {
            //
            var stdDeductCount = $("#CHK65you:checked, #ChkBlindYou:checked, #CHK65Sp:checked, #ChkBlindSp:checked").length,
                stdDeductAmount = stdDeductCount * 1300;
            $("#StdDeductCount").text(stdDeductCount);
            $("#StdDeductAmount").text(stdDeductAmount);

            //
            var fedItDed = ToNumber($("#FedItDed").val()),
                gaStdDed = ToNumber($("#GaStdDed").val()),
                _5CValue = gaStdDed - fedItDed;
            $("#5C").text(_5CValue);

            //
            var allowableDeduction = ToNumber($("#AllowableDeduction").val()),
                _5EValue = stdDeductAmount + _5CValue + allowableDeduction;
            $("#5E").text(_5EValue);

            //
            var nonTxIncome = ToNumber($("#NonTxIncome").val()),
                _5GValue = nonTxIncome - _5EValue;
            $("#5G").text(_5GValue);

            //
            var _5HValue = "";
            if (_5GValue > 0)
                _5HValue = Math.round(_5GValue / 3000 * 100) / 100;

            $("#5H").text(_5HValue);
            $("#C5H").val(_5HValue);

            //
            var maritalStatus = "",
                exemptStatus = 0;
            $("input[id^=C3]").each(function (index, elem) {
                var exemptStatusVal = $(elem).val();
                if (exemptStatusVal !== "") {
                    maritalStatus = $(elem).attr("id").substring(2);
                    exemptStatus = ToNumber(exemptStatusVal);
                }
            });

            var totalAllowances = exemptStatus + ToNumber($("#C4").val()) + ToNumber($("#C5").val());

            $("#MaritalStatusLetter").text(maritalStatus);
            $("#TotalAllowances").text(totalAllowances);
            $("#C7TA").val(totalAllowances);
        }

        calcTotals();

        $("#CHK65you, #ChkBlindYou, #CHK65Sp, #ChkBlindSp").on("change", function () {
            calcTotals();
        });

        $(".form-viewer input[type=number]").on("focusout", function () {
            if ($(this).attr("id").startsWith("C3") && !$(this).attr("readonly")) {
                if ($(this).val() === "") {
                    $("input[id^=C3]").attr("readonly", false);
                } else {
                    $("input[id^=C3]").not("input[id='" + $(this).attr("id") + "']").attr("readonly", true);
                }
            }

            calcTotals();
        });

        $("input[id^=C3]").each(function (index, elem) {
            var exemptStatusVal = $(elem).val();
            if (exemptStatusVal !== "") {
                $(elem).attr("readonly", false);
                $("input[id^=C3]").not("input[id='" + $(elem).attr("id") + "']").attr("readonly", true);
            }
        });
    }

    if ($("#forms-alwithholding-page").length > 0) {
        $("#Q1").on("keypress", function (e) {
            if (e.key !== "0")
                return false;

            $("#Q2").val("");
            $("#Q3").val("");

            changeQ6("No");
        });
        $("#Q2").on("keypress", function (e) {
            var key = e.key.toLowerCase(),
                value = "";

            if (key === "s")
                value = "S";
            else if (key === "m")
                value = "MS";
            else
                return false;

            $("#Q1").val("");
            $("#Q2").val(value);
            $("#Q3").val("");

            changeQ6(value);

            e.preventDefault();
        });
        $("#Q3").on("keypress", function (e) {
            var key = e.key.toLowerCase(),
                value = "";

            if (key === "m")
                value = "M";
            else if (key === "h")
                value = "H";
            else
                return false;

            $("#Q1").val("");
            $("#Q2").val("");
            $("#Q3").val(value);

            changeQ6(value);

            e.preventDefault();
        });

        $("#Q1, #Q2, #Q3, #Q4").on("change", function () {
            var prefix = "";

            if ($("#Q1").val() === "0")
                prefix = "No";
            else if (!!$("#Q2").val())
                prefix = $("#Q2").val();
            else if (!!$("#Q3").val())
                prefix = $("#Q3").val();
            else
                prefix = "";

            changeQ6(prefix);
        });

        function changeQ6(prefix) {
            $("#Q6").text(prefix ? (prefix + "-" + $("#Q4").val()) : "");
        }
    }

    if ($("#forms-azwithholding-page").length > 0) {
        $("#Box1").on("change", function () {
            if ($(this).prop("checked")) {
                changeAndTriggerChk("#Box2", false);
            } else {
                changeAndTriggerChk("input[type=checkbox][class*='box1-sub']", false);
            }
        });

        $("input[type=checkbox][class*='box1-sub']").on("change", function () {
            if ($(this).prop("checked")) {
                changeAndTriggerChk("#Box1", true);

                if ($(this).hasClass("box1-sub1")) {
                    $(".box1-sub1").not("[id='" + $(this).attr("id") + "']").prop("checked", false);
                }
            }
        });

        $(".box1-sub2").on("change", function () {
            $("#AdditionalAmount").prop("disabled", !$(this).prop("checked"));
        });
        $("#Box1").trigger("change");

        $("#Box2").on("change", function () {
            if ($(this).prop("checked")) {
                changeAndTriggerChk("#Box1", false);
            }
        });
    }

    if ($("#forms-w42019form-page").length > 0) {
        $("#Form2019_A, #Form2019_B, #Form2019_C, #Form2019_D, #Form2019_E, #Form2019_F, #Form2019_G").on("change", function () {
            var aVal = ToNumber($("#Form2019_A").val()),
                bVal = ToNumber($("#Form2019_B").val()),
                cVal = ToNumber($("#Form2019_C").val()),
                dVal = ToNumber($("#Form2019_D").val()),
                eVal = ToNumber($("#Form2019_E").val()),
                fVal = ToNumber($("#Form2019_F").val()),
                gVal = ToNumber($("#Form2019_G").val());
            $("#Form2019_H").val(aVal + bVal + cVal + dVal + eVal + fVal + gVal);
        });

        $("input[type=checkbox][class*='filing-type']").on("change", function () {
            if ($(this).prop("checked")) {
                $(".filing-type").not("[id='" + $(this).attr("id") + "']").prop("checked", false);
            }
        });

        makeSpecialTextInputField("Form2019_ExemptText", TXT_EXEMPT);
    }

    if ($("#forms-88502016form-page").length > 0) {
        function changeStepCount() {
            var stepCount = ToNumber($(".section-progress #SectionProgressPane_StepCount").val());
            $(".section-progress .progress-text .progress-step-count").text(
                $("input[type=checkbox][id^=Option]:checked").length > 0
                    ? stepCount + 1
                    : stepCount
            );
        }

        changeStepCount();

        $("input[type=checkbox][id^=Option]").on("change", function () {
            changeStepCount();
        });
    }

    if ($("#forms-okwithholding-page").length > 0) {
        function setC5Val() {
            $("#C5").val(ToNumber($("#C1").val()) + ToNumber($("#C2").val()) + ToNumber($("#C3").val()) + ToNumber($("#C4").val()));
        }

        setC5Val();

        $("input[name='C2a']").on("change", function (e) {
            var c2a = $("input[name='C2a']:checked").val();

            if (c2a === BinaryAnswer.Yes)
                $("#C2").val("0").trigger("change");
            else if (c2a === BinaryAnswer.No)
                $("#C2").val("1").trigger("change");
        });

        $("#C1, #C2, #C3, #C4").on("change", function (e) {
            setC5Val();
        });

        makeSpecialTextInputField("C7", TXT_EXEMPT);
        makeSpecialTextInputField("C8", TXT_EXEMPT);
        makeSpecialTextInputField("C9", TXT_EXEMPT);
    }

    $(document).ready(function () {
        $(document).on("change", "#forms-kswithholding-form .total_num", function () {
            total_num = $(this).val();
            $("#forms-kswithholding-form .total_num").each(function () {
                $(this).val(total_num);
            })
        })

        check_allowance_rate();
    })

    function check_allowance_rate() {
        $("#forms-kswithholding-form .allowance_rate1:NOT(.org)").prop("checked", $("#forms-kswithholding-form .allowance_rate1.org").prop("checked"));
        $("#forms-kswithholding-form .allowance_rate2:NOT(.org)").prop("checked", $("#forms-kswithholding-form .allowance_rate2.org").prop("checked"));
    }

    $("#forms-kswithholding-form .org").on("change", function () {
        check_allowance_rate();
    })
});