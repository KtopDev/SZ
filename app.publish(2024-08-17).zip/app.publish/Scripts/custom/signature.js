﻿$(document).ready(function () {
    let windowWidth = $(window).width(),
        canvas = document.querySelector("#signature-pad");

    let signaturePad = new SignaturePad(
        canvas,
        {
            backgroundColor: "rgb(255, 255, 255)",
            minWidth: 2,
            maxWidth: 4
        }
    );


    function resizeCanvas() {
        // When zoomed out to less than 100%, for some very strange reason,
        // some browsers report devicePixelRatio as less than 1
        // and only part of the canvas is cleared then.
        let ratio = Math.max(window.devicePixelRatio || 1, 1);
        canvas.width = canvas.offsetWidth * ratio;
        canvas.height = canvas.offsetHeight * ratio;
        canvas.getContext("2d").scale(ratio, ratio);

        signaturePad.clear();
        //signaturePad.fromData(signaturePad.toData());
    }

    window.onresize = function () {
        let currentWindowWidth = $(window).width();
        if (windowWidth === currentWindowWidth)
            return;

        windowWidth = currentWindowWidth;
        resizeCanvas();
    };

    resizeCanvas();


    $("#signature-pad-clear").click(function () {
        signaturePad.clear();
    });

    $("#completed").click(function () {
        if (signaturePad.isEmpty()) {
            $("#error-message").removeClass("d-none");
            return false;
        }

        let actionLink = $(this).attr("data-action-link");
        let image = signaturePad.toDataURL("image/jpeg");
        image = image.replace('data:image/jpeg;base64,', '');

        postData(actionLink, {"signImage": image});
    });
});