﻿$(document).ready(function () {
    $("#BirthdatePicker").datetimepicker({
        format: 'MM/DD/YYYY',
        ignoreReadonly: true
    });

    //$("#ExpirationDatePicker").datetimepicker({
    //    format: 'MM/DD/YYYY',
    //    ignoreReadonly: true
    //});

    $("input[name=Convicted]").on("change", function () {
        if ($(this).val() === "False") {
            $("input[name=ConvictedFor]").attr("disabled", "1");
        } else {
            $("input[name=ConvictedFor]").removeAttr("disabled");
        }
    });
});