﻿$(document).ready(function () {
    function doSkillsDetailsFormSubmit(nextButtonClicked) {
        $("#NextButtonClicked").val(nextButtonClicked ? "True" : "False");
        $("#skills-details-form").submit();
    }

    $("#back").click(function () {
        doSkillsDetailsFormSubmit(false);
    });

    $("#next").click(function () {
        doSkillsDetailsFormSubmit(true);
    });
});