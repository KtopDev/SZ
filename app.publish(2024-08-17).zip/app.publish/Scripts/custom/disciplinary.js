﻿$(document).ready(function () {
    $("[id^='Consequence']:radio:not(:checked)").attr("disabled", true);
});