﻿$(document).ready(function () {
    startLogoutTimer(5);
});