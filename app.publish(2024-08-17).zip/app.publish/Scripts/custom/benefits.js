﻿$(document).ready(function () {
    if ($("#benefits-page05-page").length > 0) {
        $("#daily-home-pay, #weekly-work-days").on("change", function () {
            var dailyHomePay = ToNumber($("#daily-home-pay").val()),
                weeklyWorkDays = ToNumber($("#weekly-work-days").val()),
                plan1WeekText = $("#Plan1Week").val(),
                plan2WeekText = $("#Plan2Week").val(),
                plan3WeekText = $("#Plan3Week").val(),
                plan4WeekText = $("#Plan4Week").val(),
                plan1Week = ToNumber(plan1WeekText),
                plan2Week = ToNumber(plan2WeekText),
                plan3Week = ToNumber(plan3WeekText),
                plan4Week = ToNumber(plan4WeekText),
                plan1MonthText = $("#Plan1Month").val(),
                plan2MonthText = $("#Plan2Month").val(),
                plan3MonthText = $("#Plan3Month").val(),
                plan4MonthText = $("#Plan4Month").val(),
                plan1Month = ToNumber(plan1MonthText),
                plan2Month = ToNumber(plan2MonthText),
                plan3Month = ToNumber(plan3MonthText),
                plan4Month = ToNumber(plan4MonthText);

            if (dailyHomePay <= 0 || weeklyWorkDays <= 0)
                return;

            var weeklyHomePay = dailyHomePay * weeklyWorkDays,
                plan1WeekValue = weeklyHomePay - plan1Week,
                plan2WeekValue = weeklyHomePay - plan2Week,
                plan3WeekValue = weeklyHomePay - plan3Week,
                plan4WeekValue = weeklyHomePay - plan4Week;

            $("#computed-weekly-pay").val("$" + Math.max(0, weeklyHomePay).toFixed(2));
            $("#employee-only").val(plan1WeekText ? "$" + Math.max(0, plan1WeekValue).toFixed(2) : "");
            $("#employee-and-spouse").val(plan2WeekText ? "$" + Math.max(0, plan2WeekValue).toFixed(2) : "");
            $("#employee-and-children").val(plan3WeekText ? "$" + Math.max(0, plan3WeekValue).toFixed(2) : "");
            $("#employee-and-family").val(plan4WeekText ? "$" + Math.max(0, plan4WeekValue).toFixed(2) : "");
        });
    }
});