import {createApi} from '@/utils/createApi/createApi';
import {
  LoginMFAVerifyDto,
  LoginUserDto,
  SavePasswordDto,
  SetPasswordDto,
  TermsOfUsePayload,
} from '@/types/dto/LoginFormDto';
import {HttpMethod} from '@/utils/createApi/types';

const mutationApis = {
  sendEmail: {
    query: (data: SetPasswordDto) => ({
      url: '/api/v1/authentication/password/reset',
      method: HttpMethod.POST,
      data,
    }),
  },
  verifyToken: {
    query: (token: string) => ({
      url: `/api/v1/authentication/password/verify/${token}`,
      method: HttpMethod.PUT,
    }),
  },
  savePassword: {
    query: (data: SavePasswordDto) => ({
      url: `/api/v1/authentication/password/save/${data.token}`,
      method: HttpMethod.PUT,
      data,
    }),
  },
  createVerifyMFA: {
    query: (data: LoginUserDto) => ({
      url: '/api/v1/verify-otp',
      data,
    }),
  },
  acceptTerms: {
    query: (data: TermsOfUsePayload) => ({
      url: '/api/v1/client-app-terms/agree',
      method: HttpMethod.POST,
      data: {
        contactId: data.contactId,
        clientAppTerms: data.clientAppTerms,
      },
    }),
  }
};

const api = createApi({mutationApis});
export const {useSendEmail, useCreateVerifyMFA, useVerifyToken, useSavePassword, useAcceptTerms} = api as {
    useSendEmail: () => [login: (data: SetPasswordDto) => any, props: any];
    useVerifyToken: () => [verifyToken: (token: string) => any, props: any];
    useSavePassword: () => [savePassword: (data: SavePasswordDto) => any, props: any];
    useCreateVerifyMFA: () => [verifyMFA: (data: LoginMFAVerifyDto) => any, props: any];
    useAcceptTerms: () => [acceptTerms: (data: TermsOfUsePayload) => any, props: any];
};
