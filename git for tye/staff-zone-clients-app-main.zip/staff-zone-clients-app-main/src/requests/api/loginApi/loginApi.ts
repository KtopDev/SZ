import { createApi } from '@/utils/createApi/createApi';
import { LoginMFAVerifyDto, LoginUserDto } from '@/types/dto/LoginFormDto';

const queryApis = {};

const mutationApis = {
  createLogin: {
    query: (data: LoginUserDto) => ({
      url: '/api/v1/login',
      data,
    }),
  },
  createVerifyMFA: {
    query: (data: LoginUserDto) => ({
      url: '/api/v1/verify-otp',
      data,
    }),
  },
  verifyMfaPhoneCode: {
    query: (payload: { authProcessId: string; code: string }) => ({
      url: '/api/v1/login/mfa/verify-code',
      data: { ...payload, userType: 'CLIENT' },
      errorMessage: '',
    }),
  },
};

const api = createApi({ queryApis, mutationApis });
export const { useCreateLogin, useCreateVerifyMFA, useVerifyMfaPhoneCode } = api as {
  useCreateLogin: () => [login: (data: LoginUserDto) => any, props: any];
  useCreateVerifyMFA: () => [verifyMFA: (data: LoginMFAVerifyDto) => any, props: any];
  useVerifyMfaPhoneCode: () => [
    (payload: { authProcessId: string; code: string }, config?: { useSnackbarPopup?: boolean }) => any,
    { loading: false },
  ];
};
