import { createApi } from '@/utils/createApi/createApi';
import { Dropdown } from '@/types/Dropdown';

const queryApis = {
  getSkillDropdown: {
    query: () => ({
      url: '/api/v1/skills/dropdown',
    }),
  },

};

const api = createApi({ queryApis });
export const {
  useGetSkillDropdown,
} = api as {
  useGetSkillDropdown: () => { data: Dropdown; loading: false };
};
