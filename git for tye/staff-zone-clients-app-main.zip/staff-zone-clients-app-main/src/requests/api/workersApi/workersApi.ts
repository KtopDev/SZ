import { createApi } from '@/utils/createApi/createApi';
import { HttpMethod } from '@/utils/createApi/types';
import { IWorker } from './types';

const queryApis = {
  getWorkerData: {
    query: (workerId: string) => ({
      url: `/api/v1/workers/${workerId}`,
    }),
  },
};

const mutationApis = {
  updateWorker: {
    query: (data: any) => ({
      url: `/api/v1/workers/${data.workerId}`,
      data,
      method: HttpMethod.PUT,
    }),
  },
  createWorker: {
    query: (data: IWorker) => ({
      url: '/api/v1/workers',
      data,
      method: HttpMethod.POST,
    }),
  },
};

const api = createApi({ queryApis, mutationApis });

export const { useCreateWorker, useGetWorkerData, useUpdateWorker } = api as {
  useCreateWorker: () => [createWorker: (data: any) => any, props: { loading: boolean }];
  useGetWorkerData: (workerId: string) => { data: any; loading: boolean };
  useUpdateWorker: () => [updateWorker: (data: any) => any, props: { loading: boolean }];
};
