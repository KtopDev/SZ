export interface IWorker {
  id?: string;
  firstName: string;
  lastName: string;
  middleInitial: string;
  otherNames: string;
  ssnNumber: number;
  dateOfBirth: string;
  phone: number;
  email: string;
  address: string;
  city: string;
  state: string;
  postalCode: number;
  skills: string[];
  certifications: string[];
  branchId?: string;
  addressLine2: string;
  address_line_2: string;
}
