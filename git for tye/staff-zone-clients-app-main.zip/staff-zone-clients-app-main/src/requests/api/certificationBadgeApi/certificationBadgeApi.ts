import { createApi } from '@/utils/createApi/createApi';
import { Dropdown } from '@/types/Dropdown';

const queryApis = {
  getCertificationDropdown: {
    query: () => ({
      url: '/api/v1/certifications/dropdown',
    }),
  },
};


const api = createApi({ queryApis });

export const {

  useGetCertificationDropdown,
} = api as {
  useGetCertificationDropdown: () => { data: Dropdown; loading: false };
};

export interface GetCertListPayload {
  size: number;
  page: number;
  sort: string;
  startDate: string;
  endDate: string;
}
