import { createApi } from '@/utils/createApi/createApi';
import { buildUrl } from '@/utils/buildUrl/buildUrl';
import { TempDispatcher } from '@/types/dto/TempDispatcher';
import { HttpMethod } from '@/utils/createApi/types';

const queryApis = {
  getTempDispatcher: {
    query: (bucketId: string) => ({
      url: buildUrl(`/api/v1/dispatcher/${bucketId}/dispatch-details/temp`),
    }),
  },
};

const mutationApis = {
  incrementSlot: {
    query: (bucketId: string) => ({
      url: `/api/v1/dispatcher/bucket/details/${bucketId}/increment-slots`,
      method: HttpMethod.PUT,
    }),
  },
  reduceSlot: {
    query: (bucketId: string) => ({
      url: `/api/v1/dispatcher/bucket/details/${bucketId}/reduce-slots`,
      method: HttpMethod.PUT,
    }),
  },
};

const api = createApi({ queryApis, mutationApis });
export const { useGetTempDispatcher, useIncrementSlot, useReduceSlot } = api as {
  useGetTempDispatcher: (bucketId: string) => { data: TempDispatcher; loading: false; refetch: () => void };
  useIncrementSlot: () => [incrementSlot: (bucketId: string) => any, props: any];
  useReduceSlot: () => [incrementSlot: (bucketId: string) => any, props: any];
};

export const bucketDetailsId1 = '27cffd31-fab0-4bc0-9248-d1cff7407cb3';
export const bucketDetailsId2 = 'a481bef5-d90d-4767-90cb-5415aa0a527c';
export const bucketDetailsId3 = '29728e8d-d2c8-4259-9e9c-11af5b93e54d';
