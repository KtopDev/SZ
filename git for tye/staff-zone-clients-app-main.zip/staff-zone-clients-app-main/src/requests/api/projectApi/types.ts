export interface GetProjectListPayload {
  size: number;
  page: number;
  sort: string;
  name: string;
  branch: string;
  status: string;
  startDate: string;
  endDate: string;
  client: string;
}

interface IProjectDetails {
  projectWorkerBasedBillingId: string,
  numberOfWorkers: number;
  hoursNeeded: number;
}

export interface ICreateProjectOrder {
  projectId: string;
  payload: {
    orderStartTs: string,
    projectOrderDetails: IProjectDetails[]
  }
}
