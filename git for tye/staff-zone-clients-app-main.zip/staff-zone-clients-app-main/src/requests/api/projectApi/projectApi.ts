import {buildUrl} from '@/utils/buildUrl/buildUrl';
import {createApi} from '@/utils/createApi/createApi';
import {GetProjectListPayload, ICreateProjectOrder} from '@/requests/api/projectApi/types';
import {HttpMethod} from '@/utils/createApi/types';

const queryApis = {
  getProjectList: {
    query: (payload: GetProjectListPayload) => ({
      url: buildUrl('/api/v1/projects', payload),
    }),
  },
  getProjectsDropdown: {
    query: (clientId: any) => ({
      url: buildUrl(`/api/v1/projects-dropdown?clientId=${clientId}`),
    }),
  },
  getProjectWorkerBasedBillingList: {
    query: (data: any) => ({
      url: buildUrl(`/api/v1/projects/${data.projectId}/rates-wbb`, data.payload),
    }),
    errorMessage: 'Failed to fetch worker based billing list',
  },
};

const mutationApis = {
  requestProject: {
    query: (data: any) => ({
      url: '/api/v1/projects/request-project',
      method: HttpMethod.POST,
      data,
    }),
  },
  requestClientProjectOrder: {
    query: (data: ICreateProjectOrder) => ({
      url: `/api/v1/projects/${data.projectId}/order`,
      data: data.payload,
      method: HttpMethod.POST,
    })
  }
}

const api = createApi({queryApis, mutationApis});

export const {useGetProjectList, useRequestProject, useGetProjectsDropdown, useGetProjectWorkerBasedBillingList, useRequestClientProjectOrder,
} = api as {
    useGetProjectList: (filter: any) => { data: any; loading: boolean };
    useRequestProject: () => [(props: any) => Promise<void>, { loading: boolean }];
    useGetProjectsDropdown: (clientId: string) => { data: any; loading: boolean };
    useGetProjectWorkerBasedBillingList: (data: any) => { data: any; loading: boolean; refetch: any };
    useRequestClientProjectOrder: () => [requestClientProjectOrder: (data: ICreateProjectOrder) => any, props: any];
};
