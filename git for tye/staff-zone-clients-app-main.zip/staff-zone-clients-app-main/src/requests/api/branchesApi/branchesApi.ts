import { createApi } from '@/utils/createApi/createApi';
import { Dropdown } from '@/types/Dropdown';
import { BranchDTO } from '@/types/dto/Branch';

const queryApis = {
  getDropdownBranchList: {
    query: () => ({
      url: '/api/v1/branches-dropdown',
    }),
    errorMessage: 'Failed to fetch dropdown branch list',
  },
  getBranchDetails: {
    query: (branchId: string) => ({
      url: `/api/v1/branches/${branchId}`,
    }),
    defaultValue: {},
    errorMessage: 'Failed to fetch branch details',
  },
};

const api = createApi({ queryApis });
export const { useGetDropdownBranchList, useGetBranchDetails } = api as {
  useGetDropdownBranchList: () => { data: Dropdown; loading: boolean };
  useGetBranchDetails: (branchId: string) => { data: BranchDTO; loading: boolean };
};
