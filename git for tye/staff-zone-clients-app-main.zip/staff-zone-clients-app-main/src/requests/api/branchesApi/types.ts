export interface GetBranchListPayload {
  size: number;
  page: number;
  sort: string;
  nameCode: string;
  state: string;
  status: string;
  startDate: string;
  endDate: string;
}
