import { createApi } from '@/utils/createApi/createApi';

const queryApis = {
  getOrdersDropdownByProject: {
    query: (projectId: string) => ({
      url: `/api/v1/orders-dropdown?projectId=${projectId}`
    })
  },
};


const api = createApi({ queryApis });

export const {
  useLazyGetOrdersDropdownByProject,
} = api as {
  useLazyGetOrdersDropdownByProject: () => [(projectId: string) => any, {loading: boolean}];
};
