import { createApi } from '@/utils/createApi/createApi';
import { HttpMethod } from '@/utils/createApi/types';

interface CreateDisciplinaryForm {
  workerId: string,
  payload: {
    orderId: string,
    warningType: string,
    formDate: string,
    infraction: string,
    expectedBehavior: string,
  }
}


const mutationApis = {
  createDisciplinaryForm: {
    query: (data: CreateDisciplinaryForm) => ({
      url: `/api/v1/workers/${data.workerId}/disciplinary-forms`,
      data: data.payload,
      method: HttpMethod.POST,
    }),
  },
}

const api = createApi({ mutationApis})

export const {
  useCreateDisciplinaryForm,

} = api as {
  useCreateDisciplinaryForm: () => [createDisciplinaryForm: (data: CreateDisciplinaryForm) => any, props: any]
}
