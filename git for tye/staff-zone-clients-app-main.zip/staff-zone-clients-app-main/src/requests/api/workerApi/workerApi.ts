import { buildUrl } from '@/utils/buildUrl/buildUrl';
import { createApi } from '@/utils/createApi/createApi';

const queryApis = {
  getWorkersList: {
    query: (payload: any) => ({
      url: buildUrl('/api/v1/workers', payload),
      params: payload,
    }),
    errorMessage: 'Failed to fetch worker list',
  },
  getWorkerListForDispatch: {
    query: (payload: any) => ({
      url: buildUrl('/api/v1/workers/dispatch/search', payload),
      params: payload,
    }),
    errorMessage: 'Failed to fetch worker list',
  },
};

const api = createApi({ queryApis });

export const { useGetWorkersList, useGetWorkerListForDispatch } = api as {
  useGetWorkersList: (payload: any) => { data: any; loading: boolean; refetch: any };
  useGetWorkerListForDispatch: (payload: any) => { data: any; loading: boolean; refetch: any };
};

/* export const useGetWorkerList = (payload: any) => ({
  loading: false,
  refetch: null,
  payload,
  data: {
    'size': 500, 'totalSize': 32, 'page': 1, 'totalPages': 1, 'hasNext': false, 'sort': 'first_name,asc', 'content': [{
      'rating': 4.6,
      'skills': [{
        'skill_id': '01ff093d-ca54-4e51-91b1-ac75b338545e',
        'skill_name': 'Electrical Work',
        'skill_group': 'Warehouse',
      }, {
        'skill_id': '24b3d605-b2e6-4834-9158-9eb08c1c9825',
        'skill_name': 'Roofing',
        'skill_group': 'Warehouse',
      }, {
        'skill_id': '00604884-f8b3-46af-b5f6-04ab5bc9ecd2',
        'skill_name': 'Willingness to Learn',
        'skill_group': 'Recycling',
      }],
      'status': 'TERMINATED',
      'warnings': [{ 'type': 'WARNING', 'message': 'This is a dummy warning' }],
      'lastWorked': '12/12/22',
      'hourWorked': '24h',
      'lastName': 'Gonzalez',
      'workerId': '5e56abc8-4085-4f2b-b775-404c46ab9fe7',
      'checkinAt': null,
      'firstName': 'Andrew',
      'totalRows': '32',
      'otherNames': 'Miller',
      'paymentAvg': 18.0,
      'workerCode': '00100177',
      'lastPayDate': '2024-09-01',
      'certifications': [{
        'certification_id': '139d197c-f380-4169-ae04-acbb77dfbdc0',
        'certification_name': 'American Welding Society (AWS) Certifications',
        'certification_abreviation': 'AWS',
      }, {
        'certification_id': '49fd31a6-94aa-4ecf-8adc-ffe7521e9e8d',
        'certification_name': 'Certified Construction Manager',
        'certification_abreviation': '.',
      }, {
        'certification_id': '980cb5d0-7d2b-44c0-ab9c-f9093972dc06',
        'certification_name': 'carpentry Certifications',
        'certification_abreviation': 'NCCER',
      }],
      'middleInitial': 'Mad',
      'passengersCount': null,
    }],
  },
}); */
