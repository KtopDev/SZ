'use client';
import React, { Suspense, useEffect, useState } from 'react';
import { Box, Container, FormHelperText, Grid, IconButton, InputAdornment, TextField, Typography } from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { useSavePassword, useVerifyToken } from '@/requests/api/authApi/authApi';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import { useSearchParams } from 'next/navigation';
import { PasswordVerifyResponse, SavePasswordDto } from '@/types/dto/LoginFormDto';
import CircularProgress from '@mui/material/CircularProgress';
import { validatePassword } from './functions';

function SetPasswordPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [token, setToken] = useState('');
  const [verifyToken, { loading: verifyingToken }] = useVerifyToken();
  const [savePassword, { loading: savingPassword }] = useSavePassword();
  const [tokenVerification, setTokenVerification] = useState<PasswordVerifyResponse>({
    expired: true,
  } as PasswordVerifyResponse);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmationPassword, setShowConfirmationPassword] = useState(false);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [errors, setErrors] = useState({
    password: [] as string[],
    confirmPassword: [] as string[],
  });

  const handleClickShowPassword = () => {
    setShowPassword(!showPassword);
  };

  const handleClickShowConfirmationPassword = () => {
    setShowConfirmationPassword(!showConfirmationPassword);
  };

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newPass = e.target.value;
    setPassword(newPass);

    const validationMessages = validatePassword(newPass);
    setErrors((prev) => ({ ...prev, password: validationMessages }));
    if (confirmPassword && newPass !== confirmPassword) {
      setErrors((prev) => ({
        ...prev,
        confirmPassword: ['Passwords do not match.'],
      }));
    }
    if (newPass === confirmPassword) {
      setErrors((prev) => ({
        ...prev,
        confirmPassword: [],
      }));
    }
  };

  const handleConfirmPasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newConfirmPass = e.target.value;
    setConfirmPassword(newConfirmPass);

    const validationMessages = newConfirmPass !== password ? ['Passwords do not match.'] : [];
    setErrors((prev) => ({ ...prev, confirmPassword: validationMessages }));
  };

  const submit = async () => {
    const passwordError = validatePassword(password);
    if (passwordError.length === 0 && password === confirmPassword) {
      await savePassword({
        token,
        password,
        confirmPassword,
        userType: 'CLIENT',
        email: tokenVerification.email,
        id: tokenVerification.id,
      } as SavePasswordDto);
      router.push('/home');
    } else {
      setErrors({
        ...errors,
        password: passwordError || errors.password,
        confirmPassword: password !== confirmPassword ? ['Passwords do not match.'] : [],
      });
    }
  };

  useEffect(() => {
    const fetchVerifyToken = async () => {
      const loadedToken = searchParams.get('token');
      if (loadedToken) {
        setToken(loadedToken);
        const response = await verifyToken(loadedToken);
        if (response) {
          if (tokenVerification.expired && tokenVerification.expired === true) {
            setTokenVerification(response.data);
          }
        } else {
          router.push('/auth/token-expired');
        }
      }
    };
    fetchVerifyToken();
  }, [router, searchParams, token, tokenVerification.expired, verifyToken]);

  return (
    <Container
      maxWidth={false}
      sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '98vh',
        padding: '0 !important',
      }}>
      {verifyingToken && (
        <Box sx={{ display: 'flex' }}>
          <CircularProgress />
        </Box>
      )}
      {tokenVerification && !tokenVerification.expired && (
        <Grid item xs={6} lg={6} md={6} sm={12}>
          <Box>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                flexDirection: 'column',
              }}>
              <Image src="/img/sz-logo-small.png" alt="Picture of the author" width={80} height={80} />
              <Typography
                variant="subtitle1"
                align="center"
                gutterBottom
                sx={{ alignSelf: 'center', color: '#616161' }}>
                <b>CLIENT</b> APP
              </Typography>
            </div>
            <Typography variant="h4" component="h4" align="center" gutterBottom>
              Set up password
            </Typography>
            <Typography variant="caption" display="block" gutterBottom textAlign="center">
              Please enter your new password
            </Typography>
            <TextField
              size="small"
              type={showPassword ? 'text' : 'password'}
              label="Password"
              placeholder="Password"
              value={password}
              required={true}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton aria-label="toggle password visibility" onClick={handleClickShowPassword} edge="end">
                      {showPassword ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
              fullWidth
              error={errors.password.length > 0}
              onChange={handlePasswordChange}
              sx={{ marginTop: 3 }}
            />
            <FormHelperText error={errors.password.length > 0}>
              Your password must follow this rules:
              <ul>
                <li>Contain at least 8 characters</li>
                <li>Contain at least 1 upper case letter</li>
                <li>Contain at least 1 lower case letter</li>
                <li>Contain at least 1 number</li>
              </ul>
            </FormHelperText>
            <TextField
              size="small"
              type={showConfirmationPassword ? 'text' : 'password'}
              label="Confirm password"
              placeholder="Confirm password"
              value={confirmPassword}
              required={true}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      aria-label="toggle password visibility"
                      onClick={handleClickShowConfirmationPassword}
                      edge="end">
                      {showConfirmationPassword ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
              fullWidth
              error={errors.confirmPassword.length > 0}
              helperText={
                errors.confirmPassword.length > 0 && (
                  <ul>
                    {errors.confirmPassword.map((error, index) => (
                      <li key={index}>{error}</li>
                    ))}
                  </ul>
                )
              }
              onChange={handleConfirmPasswordChange}
              sx={{ marginTop: 1 }}
            />
            <LoadingButton
              disabled={
                errors.password.length > 0 || errors.confirmPassword.length > 0 || !password || !confirmPassword
              }
              loading={savingPassword}
              variant="contained"
              color="primary"
              fullWidth
              sx={{ marginTop: 3, marginBottom: 3 }}
              onClick={submit}>
              SAVE NEW PASSWORD
            </LoadingButton>
          </Box>
        </Grid>
      )}
    </Container>
  );
}

export default function RenderPage() {
  return (
    <Suspense>
      <SetPasswordPage />
    </Suspense>
  );
}
