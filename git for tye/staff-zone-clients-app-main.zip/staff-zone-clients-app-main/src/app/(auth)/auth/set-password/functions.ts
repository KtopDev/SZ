export const validatePassword = (pass: string) => {
  const validations = [
    { regex: /.{8,}/, message: 'Contain at least 8 characters' },
    { regex: /[A-Z]/, message: 'Contain at least 1 upper case letter' },
    { regex: /[a-z]/, message: 'Contain at least 1 lower case letter' },
    { regex: /[0-9]/, message: 'Contain at least 1 number' },
  ];

  return validations.filter((validation) => !validation.regex.test(pass)).map((validation) => validation.message);
};
