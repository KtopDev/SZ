'use client';
import React, {Suspense} from 'react';
import Image from 'next/image';
import {Box, Button, Container, Typography} from '@mui/material';
import {useRouter, useSearchParams} from 'next/navigation';

const ConfirmEmail: React.FC = () => {
  const router = useRouter();
  const searchParams = useSearchParams();

  const email = searchParams.get('email');

  return (
    <Container maxWidth="sm">
      <Box
        display="flex"
        flexDirection="column"
        alignItems="center"
        justifyContent="center"
        minHeight="100vh"
        textAlign="center"
        gap={2}>
        <Image src="/images/common/success.png" alt="Picture of the author" width={136} height={136}/>
        <Typography variant="h5" gutterBottom>
                    Check your inbox
        </Typography>
        <Typography variant="subtitle2" gutterBottom>
                    If the e-mail {email} is registered in our system, we&apos;ll send a link to your inbox so
                    you can
                    setup a new password
        </Typography>
        <Button
          fullWidth
          variant="contained"
          color="primary"
          onClick={() => {
            router.push('/login');
          }}>
                    RETURN TO LOGIN
        </Button>
      </Box>
    </Container>
  );
};

const ConfirmEmailWrapper: React.FC = () => {
  return (
    <Suspense fallback={null}>
      <ConfirmEmail/>
    </Suspense>
  );
};

export default ConfirmEmailWrapper;
