'use client';
import React, { useState } from 'react';
import { Box, Button, Container, Grid, TextField, Typography } from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { useSendEmail } from '@/requests/api/authApi/authApi';
import { validateEmail } from '@/utils/general/general';

const SendEmailPassword = ({ searchParams }: any) => {
  const router = useRouter();
  const [sendEmail, { loading }] = useSendEmail();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [email, setEmail] = useState('');

  const submit = async () => {
    if (email) {
      setIsSubmitting(true);
      await sendEmail({ email, userType: 'CLIENT' });
      router.push(`/auth/email-sent?email=${email}`);
    }
  };
  return (
    <Container
      maxWidth={false}
      sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '98vh',
        padding: '0 !important',
      }}>
      <Grid item xs={6} lg={6} md={6} sm={12}>
        <Box>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              flexDirection: 'column',
            }}>
            <Image src="/img/sz-logo-small.png" alt="Picture of the author" width={80} height={80} />
            <Typography variant="subtitle1" align="center" gutterBottom sx={{ alignSelf: 'center', color: '#616161' }}>
              <b>CLIENT</b> APP
            </Typography>
          </div>

          <Typography variant="h4" component="h4" align="center" gutterBottom>
            {searchParams?.origin === 'forgot' ? 'Forgot my' : 'Set up'} password
          </Typography>
          <Typography variant="caption" display="block" gutterBottom textAlign="center">
            Enter your email to proceed
          </Typography>

          <TextField
            id="outlined-basic"
            label="Email"
            variant="outlined"
            fullWidth
            onChange={(e) => {
              setEmail(e.target.value);
            }}
            sx={{ marginTop: 3 }}
          />
          <LoadingButton
            disabled={isSubmitting || loading || !validateEmail(email)}
            loading={loading}
            variant="contained"
            color="primary"
            fullWidth
            sx={{ marginTop: 3, marginBottom: 3 }}
            onClick={submit}>
            CONTINUE
          </LoadingButton>
          <Box textAlign="center">
            <Button variant="text" color="secondary" href="/login" sx={{ alignSelf: 'center' }}>
              I ALREADY HAVE AN ACCOUNT
            </Button>
          </Box>
        </Box>
      </Grid>
    </Container>
  );
};

export default SendEmailPassword;
