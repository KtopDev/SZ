'use client';
import React from 'react';
import Image from 'next/image';
import { Button, Typography, Box, Container } from '@mui/material';
import { useRouter } from 'next/navigation';

const TokenExpiredPage: React.FC = () => {
  const router = useRouter();

  return (
    <Container maxWidth="sm">
      <Box
        display="flex"
        flexDirection="column"
        alignItems="center"
        justifyContent="center"
        minHeight="100vh"
        textAlign="center"
        gap={2}>
        <Image src="/images/common/error.png" alt="Picture of the author" width={136} height={136} />
        <Typography variant="h5" gutterBottom>
          Expired link
        </Typography>
        <Typography variant="subtitle2" gutterBottom>
          Sorry, looks like this link has expired. Please try again.
        </Typography>
        <Button
          fullWidth
          variant="contained"
          color="primary"
          onClick={() => {
            router.push('/login');
          }}>
          GO TO LOGIN SCREEN
        </Button>
        <Button fullWidth variant="text" color="primary" href={'mailto:help@staffzone.com'} onClick={() => {}}>
          HELP@STAFFZONE.COM
        </Button>
      </Box>
    </Container>
  );
};

export default TokenExpiredPage;
