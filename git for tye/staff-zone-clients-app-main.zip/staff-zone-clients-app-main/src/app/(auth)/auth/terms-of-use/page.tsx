/* eslint-disable react/no-unescaped-entities */
'use client';
import React, {useState} from 'react';
import {Box, Checkbox, Container, Divider, FormControlLabel, Typography} from '@mui/material';
import {styled} from '@mui/material/styles';
import {useRouter} from 'next/navigation';
import UserClosure from '@/utils/UserClosure';
import {Term} from '@/utils/UserClosure/types';
import {useAcceptTerms} from '@/requests/api/authApi/authApi';
import LoadingButton from '@mui/lab/LoadingButton';

const TermText = styled('div')(({theme}) => ({
  height: '600px',
  overflow: 'auto',
  marginTop: theme.spacing(2),
  marginBottom: theme.spacing(1),
  padding: theme.spacing(2),
  border: `1px solid ${theme.palette.divider}`,
  borderRadius: theme.shape.borderRadius,
}));

const TermsOfUsePage: React.FC = () => {
  const router = useRouter();
  const [accepted, setAccepted] = useState(false);
  const [acceptTerms, {loading}] = useAcceptTerms();

  const handleAcceptChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setAccepted(event.target.checked);
  };

  const handleAcceptTerms = async () => {
    try {
      await acceptTerms({
        contactId: UserClosure.getUser()?.auth_user_details.user.contact_id || '',
        clientAppTerms: UserClosure.getUserTerms()?.map((term: Term) => term.client_app_term_id) || [],
        clientId: UserClosure.getUser()?.auth_user_details.user.client_id || ''
      })
      router.push('/home');
    } catch (e) {
      // handleError
    }
  }

  return (
    <Container
      maxWidth="sm"
      sx={{
        minHeight: '98vh',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
      }}>
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          flexDirection: 'column',
        }}>
        <Typography variant="h5" gutterBottom>
                    Terms and conditions of use
        </Typography>
        <Typography fontSize={16} fontWeight={400} variant="subtitle1" align="center" gutterBottom>
                    Please agree to these statements in order to complete your sign in process
        </Typography>
      </div>
      <Divider/>
      <TermText>
        {UserClosure.getUserTerms()?.map((term: Term, index: number) => (
          <iframe key={`${term.client_app_term_file_uri}-${index}`}
            style={{border: 'none', height: '100vh'}}
            src={term.client_app_term_file_uri} width="100%"
          ></iframe>
        ))}
      </TermText>
      <FormControlLabel
        control={<Checkbox checked={accepted} onChange={handleAcceptChange} name="acceptTerms"
          color="primary"/>}
        label="I have read and accept this terms and conditions"
      />
      <Box textAlign="center" mt={2}>
        <LoadingButton
          variant="contained"
          color="primary"
          disabled={!accepted}
          fullWidth
          loading={loading}
          onClick={handleAcceptTerms}>
                    CONTINUE
        </LoadingButton>
      </Box>
    </Container>
  );
};

export default TermsOfUsePage;
