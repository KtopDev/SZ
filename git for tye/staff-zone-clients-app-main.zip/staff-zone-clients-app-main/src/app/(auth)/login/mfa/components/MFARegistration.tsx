'use client';
import React from 'react';
import { Typography, Box, Button } from '@mui/material';
import Image from 'next/image';
import AppLinks from './AppLinks';
import { SubmitHandler, useForm } from 'react-hook-form';
import { useRouter } from 'next/navigation';
import { useCreateVerifyMFA } from '@/requests/api/loginApi/loginApi';
import { useLogin } from '@/context/LoginContext';
import { LoginMFAVerifyDto, LoginMFAVerifyResponseDto } from '@/types/dto/LoginFormDto';
import RHTextField from '@/components/shared/Form/RHTextField';

export default function MFARegistration() {
  const [verifyMFA] = useCreateVerifyMFA();
  const { mfaTokenDtoResponse, email, setFirstName } = useLogin();
  const router = useRouter();
  const {
    control,
    formState: { errors },
    handleSubmit,
  } = useForm<LoginMFAVerifyDto>({
    defaultValues: { email },
    mode: 'onBlur',
  });

  const onSubmit: SubmitHandler<LoginMFAVerifyDto> = async (data) => {
    const response = await verifyMFA(data);
    if (response && response.data) {
      const mfaResponseDto = response.data as LoginMFAVerifyResponseDto;
      setFirstName(mfaResponseDto.firstName);
      router.push('/home');
    }
  };

  return (
    <Box sx={styles.container}>
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          width: '90%',
        }}>
        <Typography variant="subtitle1" gutterBottom textAlign="left" fontWeight="bold">
          Setup authenticator app
        </Typography>
        <Typography variant="body1">
          <ol>
            <li>
              If you don’t have one already, download and install an authenticator app. <br />
              Below are our recommended authenticators:
            </li>
          </ol>
        </Typography>

        <AppLinks />

        <Typography variant="body1">
          <ol>
            <li value="2">Use your authenticator app to scan this QR code</li>
          </ol>
        </Typography>

        <Image src={mfaTokenDtoResponse.qrCode} alt="QR Code" width={200} height={200} />
        <Typography variant="body1">
          If you can’t scan this QR code, input the code below in your authenticator app setup setting
        </Typography>
        <Typography
          variant="body1"
          sx={{
            my: 1,
            fontWeight: 'bold',
            width: 500,
          }}>
          <span
            style={{
              fontWeight: 'bold',
              backgroundColor: '#DED7E5',
              borderRadius: 1,
              padding: 5,
              wordWrap: 'break-word',
            }}>
            {mfaTokenDtoResponse.mfaCode}
          </span>
        </Typography>
        <Typography variant="body1">
          3. Test if everything works. Insert the code you see in your app for Staff Zone System here:
        </Typography>

        <RHTextField<LoginMFAVerifyDto>
          label="6-digit verification code"
          fullWidth={false}
          propName="token"
          type="text"
          isInteger
          rhProps={{
            required: true,
            errors,
            control,
            minLength: 6,
            maxLength: 6,
          }}
        />

        <Typography variant="body1" sx={{ mb: 2 }}>
          4. If the verification fails, restart from the beginning.
        </Typography>
        <Button variant="contained" color="primary" sx={{ mb: 2 }} fullWidth onClick={handleSubmit(onSubmit)}>
          VALIDATE
        </Button>
        <div
          style={{
            display: 'flex',
            justifyContent: 'flex-end',
          }}>
          <Button variant="text" color="secondary">
            CLOSE
          </Button>
        </div>
      </div>
    </Box>
  );
}

const styles = {
  container: {
    display: 'flex',
    height: '98vh',
    alignItems: 'center',
    justifyContent: 'flex-start',
    width: '100%',
    flexDirection: 'column',
  },
  leftBoxStyle: {
    width: '100%',
    display: 'flex',
    justifyContent: 'flex-start',
    flexDirection: 'column',
    alignItems: 'center',
    borderRadius: 2,
    padding: 4,
  },
};
