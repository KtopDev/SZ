'use client';
import React from 'react';
import { Grid } from '@mui/material';
import { useLogin } from '@/context/LoginContext';
import OTPVerification from './components/OTPVerification';
import MFARegistration from './components/MFARegistration';

export default function MFAPage() {
  const { mfaTokenDtoResponse } = useLogin();

  return (
    <Grid item xs={6} lg={6} md={6} sm={12} sx={{ width: '100%', height: '90%' }}>
      {mfaTokenDtoResponse.registered ? <OTPVerification /> : <MFARegistration />}
    </Grid>
  );
}
