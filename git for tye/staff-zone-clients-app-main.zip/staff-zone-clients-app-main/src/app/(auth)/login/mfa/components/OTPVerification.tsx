'use client';
import React from 'react';
import { Box, Typography, Button } from '@mui/material';
import Image from 'next/image';
import { SubmitHandler, useForm } from 'react-hook-form';
import { useRouter } from 'next/navigation';
import RHTextField from '@/components/shared/Form/RHTextField';
import { LoginMFAVerifyDto, LoginMFAVerifyResponseDto } from '@/types/dto/LoginFormDto';
import { useCreateVerifyMFA } from '@/requests/api/loginApi/loginApi';
import { useLogin } from '@/context/LoginContext';
import UserClosure from '@/utils/UserClosure';

export default function OTPVerification() {
  const [verifyMFA] = useCreateVerifyMFA();
  const { email, setFirstName } = useLogin();
  const router = useRouter();
  const {
    control,
    formState: { errors },
    handleSubmit,
  } = useForm<LoginMFAVerifyDto>({
    defaultValues: { email },
    mode: 'onBlur',
  });

  const renderAuthenticationMethod = () => {
    const authMethod = UserClosure.getMfaPreference();
    return authMethod && authMethod === 'EMAIL' ? 'EMAIL' : 'SMS';
  };

  const onSubmit: SubmitHandler<LoginMFAVerifyDto> = async (data) => {
    const response = await verifyMFA(data);
    if (response && response.data) {
      const mfaResponseDto = response.data as LoginMFAVerifyResponseDto;
      setFirstName(mfaResponseDto.firstName);
      router.push('/home');
    }
  };

  return (
    <Box sx={styles.container}>
      <Image src="/img/sz-logo-small.png" alt="Picture of the author" width={80} height={80} />
      <Typography variant="subtitle1" gutterBottom sx={{ color: '#616161' }}>
        <b>CLIENT</b> APP
      </Typography>
      <Typography variant="h4" component="h4" gutterBottom>
        Authentication Code
      </Typography>
      <Typography variant="caption" display="block" gutterBottom textAlign="center">
        {`We've sent you a 6-digit code by ${renderAuthenticationMethod()}. Insert that code below to proceed.`}
      </Typography>

      <RHTextField<LoginMFAVerifyDto>
        label="6-digit verification code"
        propName="token"
        type="text"
        isInteger
        rhProps={{
          required: true,
          errors,
          control,
          minLength: 6,
          maxLength: 6,
        }}
      />

      <Button variant="text" color="primary" fullWidth sx={{ marginBottom: -1 }} onClick={handleSubmit(onSubmit)}>
        RESEND AUTHENTICATION CODE
      </Button>
      <Typography variant="caption" display="block" textAlign="center" sx={{ marginBottom: 3 }}>
        3 attepmts left
      </Typography>
      <Button variant="contained" color="primary" fullWidth sx={{ marginBottom: 1 }} onClick={handleSubmit(onSubmit)}>
        LOG IN
      </Button>
      <Button variant="outlined" color="primary" fullWidth sx={{ marginBottom: 1 }} onClick={handleSubmit(onSubmit)}>
        CHANGE AUTHENTICATION METHOD
      </Button>
    </Box>
  );
}

const styles = {
  container: {
    width: '90%',
    height: '90vh',
    display: 'flex',
    justifyContent: 'center',
    flexDirection: 'column',
    alignItems: 'center',
    padding: 4,
  },
};
