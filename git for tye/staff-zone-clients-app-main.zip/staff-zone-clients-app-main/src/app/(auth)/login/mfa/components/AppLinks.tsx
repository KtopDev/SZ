import React from 'react';
import { Box, Link, Typography } from '@mui/material';
import Image from 'next/image';

const renderImage = (src: string, alt: string) => <Image src={src} alt={alt} width={140} height={60} />;

export default function AppLinks() {
  const gaAppleStoreLink = 'https://apps.apple.com/us/app/google-authenticator/id388497605';
  const gaPlayStoreLink =
    'https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2&hl=en&gl=US&pli=1';
  const maAppleStoreLink = 'https://apps.apple.com/us/app/microsoft-authenticator/id983156458';
  const maPlayStoreLink = 'https://play.google.com/store/apps/details?id=com.azure.authenticator&hl=en';

  return (
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'space-around',
        width: '100%',
      }}>
      <div>
        <Typography variant="body1">Google Authenticator</Typography>
        <Link href={gaAppleStoreLink} target="_blank" style={{ marginRight: 5 }}>
          {renderImage('/img/app-store.svg', 'Google Auth. on Apple Store')}
        </Link>
        <Link href={gaPlayStoreLink} target="_blank" style={{ marginRight: 5 }}>
          {renderImage('/img/play-store.svg', 'Google Auth. on Play Store')}
        </Link>
      </div>
      <div>
        <Typography variant="body1">Microsoft Authenticator</Typography>
        <Link href={maAppleStoreLink} target="_blank" style={{ marginRight: 5 }}>
          {renderImage('/img/app-store.svg', 'Microsoft Auth. on Apple Store')}
        </Link>
        <Link href={maPlayStoreLink} target="_blank" style={{ marginRight: 5 }}>
          {renderImage('/img/play-store.svg', 'Microsoft Auth. on Play Store')}
        </Link>
      </div>
    </Box>
  );
}
