import React from 'react';
import { Container, Box, Typography, TextField, Button } from '@mui/material';
import Image from 'next/image';

export default function LoginPage() {
  return (
    <Container
      sx={{
        display: 'flex',
        height: '100vh',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'green',
      }}>
      <Box
        sx={{
          width: '100%',
          display: 'flex',
          justifyContent: 'center',
          flexDirection: 'column',
          alignItems: 'center',
          p: 4,
          boxShadow: 3,
          borderRadius: 2,
          background: 'white',
        }}>
        <Image src="/img/sz-logo-small.png" alt="Picture of the author" width={100} height={100} />
        <Typography variant="subtitle1" gutterBottom sx={{ color: '#616161' }}>
          <b>CLIENT</b> APP
        </Typography>
        <Typography variant="h4" component="h4" gutterBottom>
          Welcome back!
        </Typography>
        <Typography variant="caption" display="block" gutterBottom textAlign="center">
          Please enter your login information to access the application
        </Typography>

        <TextField
          margin="normal"
          required
          fullWidth
          id="email"
          label="Email address"
          name="email"
          autoComplete="email"
          autoFocus
          color="secondary"
        />
        <TextField
          margin="normal"
          required
          fullWidth
          name="password"
          label="Password"
          type="password"
          id="password"
          autoComplete="current-password"
          color="secondary"
        />
        <Button variant="text" color="secondary" sx={{ alignSelf: 'flex-end', marginBottom: 1 }}>
          I FORGOT MY PASSWORD
        </Button>
        <Button variant="contained" color="primary" fullWidth sx={{ marginBottom: 1 }}>
          LOG IN
        </Button>
        <Button variant="text" color="secondary">
          SET UP MY PASSWORD
        </Button>
      </Box>
    </Container>
  );
}
