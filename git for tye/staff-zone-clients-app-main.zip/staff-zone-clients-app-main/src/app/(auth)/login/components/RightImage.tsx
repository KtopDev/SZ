import React from 'react';
import { Box } from '@mui/material';
import Image from 'next/image';

export default function RightImage() {
  return (
    <Box sx={styles.container}>
      <div style={styles.imagesContainer}>
        <Image src="/img/sz-logo-big.png" alt="Workers on a ladder" width={500} height={400} style={{ zIndex: 10 }} />
      </div>
    </Box>
  );
}

const styles = {
  container: {
    height: '100%',
    justifyContent: 'center',
    flexDirection: 'column',
    alignItems: 'center',
    display: 'flex',
  },
  imagesContainer: {
    display: 'flex',
    justifyContent: 'center',
    width: '98%',
    height: '98%',
    borderRadius: 10,
    backgroundImage: 'url("/img/client-app-login.jpeg")',
    backgroundSize: 'cover',
    backgroundPosition: 'center',
  },
};
