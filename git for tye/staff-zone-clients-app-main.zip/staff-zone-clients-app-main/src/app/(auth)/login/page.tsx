'use client';
import React, { useState } from 'react';
import { Button, Typography } from '@mui/material';
import Image from 'next/image';
import { SubmitHandler, useForm } from 'react-hook-form';
import { useRouter } from 'next/navigation';
import RHTextField from '@/components/shared/Form/RHTextField';
import { LoginUserDto } from '@/types/dto/LoginFormDto';
import { useCreateLogin } from '@/requests/api/loginApi/loginApi';
import { RHPasswordInput } from '@/components/shared/Form/RHPasswordInput';
import UserClosure from '@/utils/UserClosure';

export default function LoginPage() {
  const router = useRouter();
  const {
    control,
    formState: { errors },
    // setError,
    handleSubmit,
  } = useForm<LoginUserDto>({
    defaultValues: { userType: 'CLIENT' },
    mode: 'onBlur',
  });
  const [login] = useCreateLogin();
  const [shouldShowIncorrectCredentialsError, setShouldShowIncorrectCredentialsError] = useState(false);

  const onSubmit: SubmitHandler<LoginUserDto> = async (data) => {
    try {
      const response = await login(data);
      if (response.data.token) {
        UserClosure.handleLogin(response.data.token);
        if (UserClosure.getUserTerms()) {
          router.push('/auth/terms-of-use');
        } else {
          router.push('/home');
        }
      } else if (response.data.status === 'MFA') {
        UserClosure.setAuthProcessId(response.data.authProcessId);
        UserClosure.setMfaPreference(response.data.mfaPreference);
        const authMethod = response.data.mfaPreference;
        if (authMethod === 'SMS' || authMethod === 'EMAIL') {
          router.push('/login/sms');
        } else if (authMethod === 'AUTH_APP') {
          router.push('/login/mfa');
        }
      }
    } catch (e: any) {
      setShouldShowIncorrectCredentialsError(true);
      // setError('password', { message: 'Invalid password' });
      // if (e.response.data.status === 401) {
      //   setShouldShowIncorrectCredentialsError(true);
      //   setError('username', {});
      //   setError('password', {});
      // }
    }
  };

  return (
    <>
      <Image src="/img/sz-logo-small.png" alt="Picture of the author" width={80} height={80} />
      <Typography variant="subtitle1" gutterBottom sx={{ color: '#616161' }}>
        <b>CLIENT</b> APP
      </Typography>
      <Typography variant="h4" component="h4" gutterBottom>
        Welcome back!
      </Typography>
      <Typography variant="caption" display="block" gutterBottom textAlign="center">
        Please enter your login information to access the application
      </Typography>

      <RHTextField<LoginUserDto>
        label="Email address"
        propName="username"
        type="text"
        rhProps={{
          required: true,
          errors,
          control,
        }}
      />

      <RHPasswordInput<LoginUserDto>
        label="Password"
        propName="password"
        rhProps={{
          errors,
          control,
        }}
      />

      {shouldShowIncorrectCredentialsError && (
        <Typography color="error" variant="caption" gutterBottom sx={{ alignSelf: 'flex-start' }}>
          Email address and/or Password incorrect
        </Typography>
      )}

      <Button
        variant="text"
        color="secondary"
        sx={{ alignSelf: 'flex-end', marginBottom: 1 }}
        href="/auth/send-email-password?origin=forgot">
        I FORGOT MY PASSWORD
      </Button>
      <Button variant="contained" color="primary" fullWidth sx={{ marginBottom: 1 }} onClick={handleSubmit(onSubmit)}>
        LOG IN
      </Button>
      <Button
        variant="text"
        color="secondary"
        onClick={() => {
          router.push('/auth/send-email-password?origin=setup');
        }}>
        SET UP MY PASSWORD
      </Button>
    </>
  );
}
