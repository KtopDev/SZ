'use client';
import React, { useState } from 'react';
import { Backdrop, Button, CircularProgress, Typography } from '@mui/material';
import Image from 'next/image';
import { SubmitHandler, useForm } from 'react-hook-form';
import { useRouter } from 'next/navigation';
import { useVerifyMfaPhoneCode } from '@/requests/api/loginApi/loginApi';
import { MfaVerifyDto } from '@/types/dto/AuthForms';
import UserClosure from '@/utils/UserClosure';
import RHMaskedInput from '@/components/shared/Form/RHMaskedInput';
import AuthenticationMethodModal from '../components/AuthenticationMethodModal';

export default function LoginPage() {
  const router = useRouter();
  const {
    control,
    formState: { errors },
    setError,
    handleSubmit,
  } = useForm<MfaVerifyDto>({
    defaultValues: { userType: 'CLIENT' },
    mode: 'onBlur',
  });
  const [showModal, setShowModal] = useState(false);
  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(false);
  const [verifyMfaPhoneCode, { loading: smsVerificationLoading }] = useVerifyMfaPhoneCode();

  const renderAuthenticationMethod = () => {
    const authMethod = UserClosure.getMfaPreference();
    return authMethod && authMethod === 'EMAIL' ? 'EMAIL' : 'SMS';
  };

  const onSubmit: SubmitHandler<MfaVerifyDto> = async (formValues) => {
    try {
      const res = await verifyMfaPhoneCode(
        {
          code: formValues.code,
          authProcessId: UserClosure.getAuthProcessId() || '',
        },
        { useSnackbarPopup: false }
      );
      if (res.data.token) {
        UserClosure.handleLogin(res.data.token);
        if (UserClosure.getUserTerms()) {
          router.push('/auth/terms-of-use');
        } else {
          router.push('/home');
        }
      }
    } catch (e: any) {
      if (e.response?.message) {
        setError('code', {
          message: e.response?.message,
        });
      } else {
        setError('code', {
          message: 'Wrong verification code',
        });
      }
    }
  };

  return (
    <>
      <Backdrop sx={{ color: '#fff' }} open={smsVerificationLoading}>
        <CircularProgress color="inherit" />
      </Backdrop>
      <Image src="/img/sz-logo-small.png" alt="Picture of the author" width={80} height={80} />
      <Typography variant="subtitle1" gutterBottom sx={{ color: '#616161' }}>
        <b>STAFF ZONE</b> SYSTEMS
      </Typography>
      <Typography variant="h4" component="h4" gutterBottom>
        Authentication Code
      </Typography>
      <Typography variant="caption" display="block" gutterBottom textAlign="center">
        {`We've sent you a 6-digit code by ${renderAuthenticationMethod()}. Insert that code below to proceed.`}
      </Typography>
      <RHMaskedInput<MfaVerifyDto>
        label="6-digit verification code"
        propName="code"
        mask="999999"
        rhProps={{
          errors,
          control,
          minLength: 6,
        }}
      />

      <Button variant="text" color="primary" fullWidth sx={{ marginBottom: -1 }} onClick={() => {}}>
        RESEND AUTHENTICATION CODE
      </Button>
      <Typography variant="caption" display="block" textAlign="center" sx={{ marginTop: 1, marginBottom: 3 }}>
        3 attepmts left
      </Typography>
      <Button variant="contained" color="primary" fullWidth sx={{ marginBottom: 3 }} onClick={handleSubmit(onSubmit)}>
        LOG IN
      </Button>
      <Button
        variant="outlined"
        color="primary"
        fullWidth
        sx={{ marginBottom: 1 }}
        onClick={() => {
          openModal();
        }}>
        CHANGE AUTHENTICATION METHOD
      </Button>
      <AuthenticationMethodModal showModal={showModal} closeModal={closeModal} />
    </>
  );
}
