'use client';
import React, { useState } from 'react';
import { Button, Typography } from '@mui/material';
import Image from 'next/image';
import { useForm } from 'react-hook-form';
import RHMaskedInput from '@/components/shared/Form/RHMaskedInput';
import { VerificationCodeDto } from '@/types/dto/AuthForms';
import AuthenticationMethodModal from '../../components/AuthenticationMethodModal';
import UserClosure from '@/utils/UserClosure';

export default function LoginPage() {
  const [showModal, setShowModal] = useState(false);
  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(false);

  const mfaPreference = UserClosure.getMfaPreference();

  const {
    getValues,
    control,
    formState: { errors },
  } = useForm<VerificationCodeDto>({
    defaultValues: {} as VerificationCodeDto,
    mode: 'onBlur',
  });

  const renderDescription = () => {
    // prettier-ignore
    switch (mfaPreference) {
    case 'AUTH_APP':
      return 'Insert the code you see in your app for Staff Zone System here:';
    case 'EMAIL':
      return "We've sent you a 6-digit code by EMAIL. Insert that code below to proceed.";
    case 'SMS':
      return "We've sent you a 6-digit code by SMS. Insert that code below to proceed.";
    default:
      return '';
    }
  };

  return (
    <>
      <Image src="/img/sz-logo-small.png" alt="Picture of the author" width={80} height={80} />
      <Typography variant="subtitle1" gutterBottom sx={{ color: '#616161' }}>
        <b>STAFF ZONE</b> SYSTEMS
      </Typography>
      <Typography variant="h4" component="h4" gutterBottom>
        Authentication Code
      </Typography>
      <Typography variant="caption" display="block" gutterBottom textAlign="center">
        {renderDescription()}
      </Typography>
      <RHMaskedInput<VerificationCodeDto>
        label="6-digit verification code"
        propName="verificationCode"
        mask="999999"
        rhProps={{
          errors,
          control,
          required: true,
          minLength: 6,
          maxLength: 6,
        }}
      />

      <Button variant="text" color="primary" fullWidth sx={{ marginBottom: -1 }} onClick={() => {}}>
        RESEND AUTHENTICATION CODE
      </Button>
      <Typography variant="caption" display="block" textAlign="center" sx={{ marginTop: 1, marginBottom: 3 }}>
        3 attepmts left
      </Typography>
      <Button
        variant="contained"
        color="primary"
        fullWidth
        sx={{ marginBottom: 3 }}
        onClick={() => {}}
        disabled={!!errors.verificationCode || !getValues('verificationCode')}>
        LOG IN
      </Button>
      <Button
        variant="outlined"
        color="primary"
        fullWidth
        sx={{ marginBottom: 1 }}
        onClick={() => {
          openModal();
        }}>
        CHANGE AUTHENTICATION METHOD
      </Button>
      <AuthenticationMethodModal showModal={showModal} closeModal={closeModal} />
    </>
  );
}
