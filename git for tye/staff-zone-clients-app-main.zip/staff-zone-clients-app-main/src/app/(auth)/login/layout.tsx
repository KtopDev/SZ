import { Container, Grid, Box } from '@mui/material';
import { ReactNode } from 'react';
import RightImage from './components/RightImage';
import styles from '@/assets/css/responsiveness.module.css';

interface AuthLayoutProps {
  children: ReactNode;
}

export default function AuthLayout({ children }: AuthLayoutProps) {
  return (
    <Container
      maxWidth={false}
      sx={{
        display: 'flex',
        alignItems: 'center',
        height: '98vh',
        padding: '0 !important',
      }}>
      <Grid item xs={6} lg={6} md={6} sm={12} sx={{ width: '100%' }}>
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            flexDirection: 'column',
            padding: 5,
          }}>
          {children}
        </Box>
      </Grid>
      <Grid item lg={6} sx={{ width: '100%', height: '100%' }} className={styles.mdHide}>
        <RightImage />
      </Grid>
    </Container>
  );
}
