/* eslint-disable @next/next/no-page-custom-font */
'use client';

import { Inter } from 'next/font/google';
import theme from '@/theme/theme';
import { GlobalStyles, ThemeProvider } from '@mui/material';
import { LoginProvider } from '@/context/LoginContext';
import { SnackBarProvider } from '@/context/SnackbarContext';
import SnackBar from '@/components/shared/SnackBar/SnackBar';
import { LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { SidebarProvider } from '@/context/SidebarContext';

const inter = Inter({ subsets: ['latin'] });

const globalSvgRotation = {
  'svg[data-testid="MoreHorizIcon"]': {
    transform: 'rotate(90deg)',
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className={inter.className} style={{ margin: 0, padding: 0, display: 'flex' }}>
        <GlobalStyles styles={globalSvgRotation} />
        <ThemeProvider theme={theme}>
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <SidebarProvider>
              <SnackBarProvider>
                <SnackBar />
                <LoginProvider>{children}</LoginProvider>
              </SnackBarProvider>
            </SidebarProvider>
          </LocalizationProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
