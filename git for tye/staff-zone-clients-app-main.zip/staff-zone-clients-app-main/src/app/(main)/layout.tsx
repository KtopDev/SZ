import Layout from '@/components/Layout';
import {ReactNode} from 'react';

interface AuthLayoutProps {
    children: ReactNode;
}

export default function MainLayout({children}: AuthLayoutProps) {
  return <Layout>{children}</Layout>;
}
