'use client';

import Box from '@mui/material/Box';
import Grid from '@mui/material/Unstable_Grid2';
import Typography from '@mui/material/Typography';
import {Alert, Button, Dialog, DialogActions, DialogContent, DialogTitle, TextField} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import Table from '@/components/shared/Table/Table';
import * as React from 'react';
import {useMemo, useState} from 'react';
import {MRT_TablePagination} from 'material-react-table';
import {SortingState} from '@tanstack/table-core';
import RHChipGroup from '@/components/shared/Form/RHChipGroup';
import {useForm, useWatch} from 'react-hook-form';
import {debounce} from 'lodash';
import RHSelect from '@/components/shared/Form/RHSelect';
import RHDatePicker from '@/components/shared/Form/RHDatePicker';
import {IProjectListFilter} from '@/app/(main)/projects/types';
import {columns} from '@/app/(main)/projects/constants/tableColumns';
import ActionColumnContent from '@/components/shared/Table/components/ActionColumnContent/ActionColumnContent';
import LoadingButton from '@mui/lab/LoadingButton';
import SelectBranchModal from '@/app/(main)/projects/components/SelectBranchModal';
import {useGetProjectList} from '@/requests/api/projectApi/projectApi';
import {useGetDropdownBranchList} from '@/requests/api/branchesApi/branchesApi';

const ProjectPage = () => {
  const {
    control,
    formState: {errors},
    setValue,
  } = useForm<IProjectListFilter>({
    defaultValues: {
      searchBy: '',
      status: '',
      lastVisitDateEnd: '',
      lastVisitDateStart: '',
      branchId: '',
    },
  });

  const searchBy = useWatch({control: control, name: 'searchBy'});
  const lastVisitDateStart = useWatch({control: control, name: 'lastVisitDateStart'});
  const lastVisitDateEnd = useWatch({control: control, name: 'lastVisitDateEnd'});
  const status = useWatch({control: control, name: 'status'});
  const branchId = useWatch({control: control, name: 'branchId'});

  const [pagination, setPagination] = useState({pageIndex: 1, pageSize: 10});
  const [sorting, setSorting] = useState<SortingState>([]);
  const [deleteDialog, setDeleteDialog] = useState(false);
  const [selectBranchModal, setSelectBranchModal] = useState(false);
  const filter = useMemo(
    () => ({
      size: pagination.pageSize,
      page: pagination.pageIndex + 1,
      sort: sorting[0] ? `projectCode,${sorting[0].desc ? 'desc' : 'asc'}` : 'projectCode,asc',
      searchBy,
      status,
      lastVisitDateStart,
      lastVisitDateEnd,
      branchId,
    }),
    //eslint-disable-next-line react-hooks/exhaustive-deps
    [lastVisitDateStart, branchId, lastVisitDateEnd, searchBy, status, sorting, pagination.pageIndex]
  );

  const {data: branchesList, loading: isBranchesListLoading} = useGetDropdownBranchList();
  const {data: projectList, loading} = useGetProjectList(filter);

  const renderTopToolbar = ({table}: any) => (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        backgroundColor: 'common.white',
        justifyContent: 'space-between',
        paddingX: '24px',
      }}>
      <Box sx={{paddingBottom: '16px'}}>
        <Typography fontSize="14px">Status</Typography>
        <RHChipGroup
          chips={[
            {label: 'All status', color: 'secondary', value: ''},
            {label: 'Active', color: 'success', value: 'Active'},
            {label: 'Incomplete', color: 'warning', value: 'Incomplete'},
            {label: 'Inactive', color: 'default', value: 'Inactive'},
            {label: 'closed', color: 'default', value: 'Closed'},
          ]}
          propName="status"
          rhProps={{errors, control, required: false}}
        />
      </Box>
      <MRT_TablePagination table={table}/>
    </Box>
  );

  const renderRowActions = (data: any) => {
    const menuItems = [
      {
        label: 'See Orders',
        onClick: () => null,
      },
      {
        label: 'See signed rates',
        onClick: () => null,
      },
    ];

    return (
      <Box key={data.row.original.appUserId}>
        <ActionColumnContent menuItems={menuItems} row={data.row}>
          <Button startIcon={<AddIcon/>}>CREATE ORDER</Button>
        </ActionColumnContent>
      </Box>
    );
  };

  const debouncedSetValue = debounce(setValue, 1000);

  const handleNameInputChange = (e: any) => {
    debouncedSetValue('searchBy', e.target.value);
  };

  return (
    <>
      <Box paddingY="8px" paddingX="24px" bgcolor="common.white" border="none">
        <Grid container direction="row" justifyContent="space-between">
          <Typography paddingY="4px" fontWeight="regular" fontSize={24}>
                        Projects
          </Typography>
          <Box paddingY="5px">
            <Button
              onClick={() => setSelectBranchModal(true)}
              variant="contained"
              startIcon={<AddIcon/>}>
                            REQUEST PROJECT
            </Button>
          </Box>
        </Grid>
        <Box sx={{flexGrow: 1}}>
          <Grid container alignItems="end" spacing={2} columns={16}>
            <Grid xs={6}>
              <TextField
                fullWidth
                InputProps={{
                  startAdornment: <SearchIcon/>,
                }}
                placeholder=" Search by name"
                id="outlined-basic"
                variant="outlined"
                onChange={handleNameInputChange}
              />
            </Grid>
            <Grid xs={6} py="0px" container>
              <Grid xs={16} px="0px">
                <RHSelect<IProjectListFilter>
                  label="Branch"
                  propName="branchId"
                  options={branchesList}
                  isLoading={isBranchesListLoading}
                  rhProps={{errors, control, required: false}}
                />
              </Grid>
            </Grid>
            <Grid xs={2}>
              <Typography fontSize={14} paddingBottom="8px">
                                Last visit date
              </Typography>
              <RHDatePicker<IProjectListFilter>
                label="Start date"
                propName="lastVisitDateStart"
                rhProps={{errors, control, required: false}}
              />
            </Grid>
            <Grid xs={2}>
              <RHDatePicker<IProjectListFilter>
                label="End date"
                propName="lastVisitDateEnd"
                rhProps={{errors, control, required: false}}
              />
            </Grid>
          </Grid>
        </Box>
      </Box>
      <Table
        mrtProps={{
          data: projectList.content || [],
          columns: columns() as any,
          renderTopToolbar,
          renderRowActions,
          enableRowActions: true,
          displayColumnDefOptions: {
            'mrt-row-actions': {
              header: 'Actions',
              size: 210,
            },
          },
          state: {
            sorting,
            pagination,
            isLoading: loading,
          },
          onPaginationChange: setPagination,
          onSortingChange: setSorting,
          manualPagination: true,
        }}
        rowCount={projectList.totalSize || 0}
      />
      <Dialog
        open={deleteDialog}
        onClose={() => setDeleteDialog(false)}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description">
        <DialogTitle id="alert-dialog-title">Close project</DialogTitle>
        <DialogContent>
          <Alert severity="error">
                        Are you sure you want to close this project? This project cannot be activated again once it has
                        been closed.
                        No new orders can be created on it.
          </Alert>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialog(false)}>CANCEL</Button>
          <LoadingButton loading={false} color="error" variant="contained" onClick={() => null} autoFocus>
                        CLOSE PROJECT
          </LoadingButton>
        </DialogActions>
      </Dialog>
      <SelectBranchModal open={selectBranchModal} handleClose={() => setSelectBranchModal(false)}/>
    </>
  );
};

export default ProjectPage;
