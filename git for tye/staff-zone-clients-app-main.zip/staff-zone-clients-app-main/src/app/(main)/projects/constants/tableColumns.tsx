import {MRT_ColumnDef, MRT_Row} from 'material-react-table';
import Typography from '@mui/material/Typography';
import {Chip} from '@mui/material';

enum Status {
    ACTIVE = 'ACTIVE',
    INACTIVE = 'INACTIVE',
    INCOMPLETE = 'INCOMPLETE',
    CLOSED = 'CLOSED',
    DNS = 'DNS',
}

const chipStatusMap: any = {
  [Status.ACTIVE]: <Chip size="small" label="Active" color="success"/>,
  [Status.INACTIVE]: <Chip size="small" label="Inactive"/>,
  [Status.INCOMPLETE]: <Chip size="small" label="Incomplete" color="warning"/>,
  [Status.CLOSED]: <Chip size="small" label="Closed"/>,
};

export const columns = (): MRT_ColumnDef<any>[] => [
  {
    accessorKey: 'project_code',
    header: 'ID',
    Cell: ({row}: { row: MRT_Row<any> }) => (
      <Typography fontWeight="500" color="primary" sx={{cursor: 'pointer'}}>
                #{row.original.project_code}
      </Typography>
    ),
  },
  {accessorKey: 'project_name', header: 'Project Name', enableSorting: false},
  {accessorKey: 'branch_name', header: 'Branch', enableSorting: false},
  {accessorKey: 'visit_date', header: 'Last visit date', enableSorting: false},
  {
    header: 'Status',
    accessorKey: 'status',
    enableSorting: false,
    Cell: ({row}: { row: MRT_Row<any> }) => {
      const state: Status = row.original.status;

      return chipStatusMap[state];
    },
  },
];
