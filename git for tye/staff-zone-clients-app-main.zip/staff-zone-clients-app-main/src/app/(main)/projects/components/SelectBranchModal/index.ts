import SelectBranchModal from '@/app/(main)/projects/components/SelectBranchModal/SelectBranchModal';

export default SelectBranchModal;
