import Modal from '@mui/material/Modal';
import {Backdrop, Button, Card, CardContent, Stack} from '@mui/material';
import {commonModalStyle} from '@/theme/constants';
import React from 'react';
import {Alert} from '@mui/lab';
import Typography from '@mui/material/Typography';
import {useForm} from 'react-hook-form';
import RHSelect from '@/components/shared/Form/RHSelect';
import {useGetDropdownBranchList} from '@/requests/api/branchesApi/branchesApi';
import {useRouter} from 'next/navigation';

const SelectBranchModal = ({open, handleClose}: any) => {
  const {
    control,
    formState: {errors, isValid},
    handleSubmit,
    getValues,
  } = useForm<{ branchId: string }>({
    mode: 'onBlur',
  });

  const router = useRouter();
  const {data: branchesList, loading: isBranchesListLoading} = useGetDropdownBranchList();

  const handleClickContinue = ({branchId}: any) => {
    router.push(`/projects/${branchId}/request-project`);
  };

  return (
    <Modal
      open={open}
      onClose={handleClose}
      closeAfterTransition
      slots={{backdrop: Backdrop}}
      slotProps={{
        backdrop: {
          timeout: 500,
        },
      }}>
      <Card sx={commonModalStyle}>
        <CardContent>
          <Typography>Select a branch to continue</Typography>
          <Alert severity="warning" sx={{marginTop: '25px', marginBottom: '10px'}}>
                        You are currently viewing the data under All Branches option. Please select a bracnh in order to
                        continue
          </Alert>
          <RHSelect<{ branchId: string }>
            label="Branch"
            propName="branchId"
            options={branchesList}
            rhProps={{errors, control, getValues}}
            isLoading={isBranchesListLoading}
          />
          <Stack spacing={2} direction="row" sx={{display: 'flex', justifyContent: 'flex-end'}} mt={2}>
            <Button variant="text" onClick={handleClose}>
                            CANCEL
            </Button>
            <Button variant="contained" color="primary" disabled={!isValid}
              onClick={handleSubmit(handleClickContinue)}>
                            CONTINUE
            </Button>
          </Stack>
        </CardContent>
      </Card>
    </Modal>
  );
};

export default SelectBranchModal;
