export interface IProjectListFilter {
    searchBy: string;
    status: string;
    lastVisitDateStart: string;
    lastVisitDateEnd: string;
    branchId: string;
}
