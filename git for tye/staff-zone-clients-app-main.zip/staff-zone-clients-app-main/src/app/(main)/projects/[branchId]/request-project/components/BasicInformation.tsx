'use client';
import React from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import {Typography} from '@mui/material';
import type {Dropdown} from '@/types/Dropdown';
import {ReactHookProps} from '@/types/forms/RHProps';
import RHTextField from '@/components/shared/Form/RHTextField';
import {FieldValues} from 'react-hook-form';
import {ProjectForm} from '@/types/dto/Project';
import {useGetDropdownBranchList} from '@/requests/api/branchesApi/branchesApi';
import RHSelect from '@/components/shared/Form/RHSelect';

type Props<T extends FieldValues> = {
    rhProps: ReactHookProps<T>;
};

export default function BasicInformation({rhProps}: Props<ProjectForm>) {
  const {data: branchesList, loading: isBranchesListLoading} = useGetDropdownBranchList();
  const {control, getValues, errors} = rhProps;

  return (
    <>
      <Typography variant="h6" gutterBottom mt={2}>
                Basic information
      </Typography>
      <Grid container spacing={2} mb={2}>
        <Grid xs={12} sm={12} md={12} lg={12} mb={-1}>
          <RHTextField<ProjectForm>
            label="Project name"
            propName="projectName"
            rhProps={{errors, getValues, control, minLength: 3}}
          />
        </Grid>
        <Grid xs={12} sm={12} lg={12}>
          <RHSelect<ProjectForm>
            label="Branch"
            propName="branchId"
            options={branchesList as Dropdown}
            isLoading={isBranchesListLoading}
            rhProps={{errors, control, getValues}}
          />
        </Grid>
      </Grid>
    </>
  );
}
