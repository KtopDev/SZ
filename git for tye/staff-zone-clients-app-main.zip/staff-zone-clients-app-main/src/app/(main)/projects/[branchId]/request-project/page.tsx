'use client';
import Container from '@mui/material/Container';
import Divider from '@mui/material/Divider';
import {useForm, useWatch} from 'react-hook-form';
import {ProjectForm as ProjectFormType} from '@/types/dto/Project';
import {Alert, Box, Button} from '@mui/material';
import {useRouter} from 'next/navigation';
import BasicInformation from './components/BasicInformation';
import Address from './components/ProjectAddress';
import {useSnackbar} from '@/context/SnackbarContext';
import {useGetBranchDetails} from '@/requests/api/branchesApi/branchesApi';
import UserClosure from '@/utils/UserClosure';
import {useRequestProject} from '@/requests/api/projectApi/projectApi';
import LoadingButton from '@mui/lab/LoadingButton';
import {formatApiErrors} from '@/utils/general/general';

const RequestProject = ({params}: any) => {
  const router = useRouter();
  const {setMessage} = useSnackbar();
  const {
    control,
    formState: {errors, isValid},
    setValue,
    getValues,
    setError,
    clearErrors,
    trigger,
    handleSubmit,
  } = useForm<ProjectFormType>({defaultValues: {branchId: params.branchId}, mode: 'onBlur'});
  const rhProps = {control, errors, getValues, setValue, setError, clearErrors, trigger};

  const branchId = useWatch({control, name: 'branchId'})
  const {data: selectedBranch} = useGetBranchDetails(branchId);

  const [requestProject, {loading}] = useRequestProject();

  const onSubmit = async (formValues: ProjectFormType) => {
    try {
      await requestProject({...formValues, clientId: UserClosure.getUser()?.auth_user_details.user.client_id})
      setMessage('Project requested. Staff Zone will contact you soon');
      router.push('/projects')
    } catch (e) {
      formatApiErrors(e, setError, setMessage);
    }
  }

  return (
    <Container maxWidth="xl">
      <BasicInformation rhProps={rhProps}/>
      <Divider/>
      <Address rhProps={rhProps}/>
      <Divider/>
      {selectedBranch.branchName &&
                <Alert severity="warning" sx={{display: 'flex', justifyContent: 'space-between'}}>
                    Project will be created in branch {selectedBranch.branchName} - {selectedBranch.branchCode}. Verify
                    that
                    this is
                    the branch in which you intended to create this project. Continue if this is correct.
                </Alert>}

      <Box display="flex" justifyContent="flex-end" mt={2} mb={2}>
        <Button variant="text" color="secondary" onClick={() => router.push('/home')}>
                    CANCEL
        </Button>
        <LoadingButton
          disabled={!isValid}
          variant="contained"
          color="primary"
          sx={{marginLeft: 1}}
          loading={loading}
          onClick={handleSubmit(onSubmit)}>
                    REQUEST PROJECT
        </LoadingButton>
      </Box>
    </Container>
  );
};

export default RequestProject;
