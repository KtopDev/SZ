import { MRT_Row } from 'material-react-table';
import Grid from '@mui/material/Unstable_Grid2';
import Typography from '@mui/material/Typography';
import { Avatar, Box } from '@mui/material';
import DoNotDisturbAltIcon from '@mui/icons-material/DoNotDisturbAlt';
import dayjs from 'dayjs';
import HandymanIcon from '@mui/icons-material/Handyman';

export const getColumns = (router: any, warningsModal: () => void, skillsModal: () => void) => [
  {
    accessorKey: 'workerCode',
    header: 'Worker',
    grow: 1000,
    Cell: ({ row }: { row: MRT_Row<any> }) => (
      <Grid container onClick={() => router.push(`workers/${row.original.worker_id}/worker-details`)}>
        <Avatar sx={{ mr: 1 }} src="/images/common/avatar.png" />
        <Grid>
          <Typography fontWeight="500" color="primary" sx={{ cursor: 'pointer' }}>
            {row.original.first_name} {} {row.original.last_name}
          </Typography>
          <Typography fontSize={12}>ID {row.original?.worker_code}</Typography>
        </Grid>
      </Grid>
    ),
  },
  {
    accessorKey: 'skills',
    header: 'Skills',
    enableSorting: false,
    size: 180,
    Cell: ({ row }: any) => {
      return (
        <Box sx={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }} onClick={skillsModal}>
          <HandymanIcon fontSize="small" htmlColor='#438BCD'/>{' '}
          <Typography fontSize={14} pl={1}>
            {`${row.original.skills?.length || '-'} skills`}
          </Typography>
        </Box>
      );
    },
  },
  {
    accessorKey: 'last_day_worked',
    header: 'Last Date Worked',
    enableSorting: false,
    size: 180,
    Cell: ({ row }: any) => (
      <Typography>
        {row.original.last_day_worked ? dayjs(row.original.last_day_worked).format('MM/DD/YYYY') : ''}
      </Typography>
    ),
  },
  {
    accessorKey: 'hoursWorked',
    header: 'Hours worked this week',
    enableSorting: false,
    size: 180,
    Cell: ({ row }: any) => {
      return (
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <Typography fontSize={14} pl={1}>
            {(row.original.hours_worked_current_week || '0') + 'h'}
          </Typography>
        </Box>
      );
    },
  },
  {
    accessorKey: 'rating',
    header: 'Rating',
    enableSorting: false,
    size: 90,
    Cell: ({ row }: any) => {
      return (
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <Typography fontSize={14} pl={1}>
            {row.original.rating || '-'}
          </Typography>
        </Box>
      );
    },
  },
  {
    accessorKey: 'warnings',
    header: 'Warnings',
    size: 110,
    enableSorting: false,
    Cell: ({ row }: any) => {
      return row.original.warnings > 0 ? (
        <Box sx={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }} onClick={warningsModal}>
          <DoNotDisturbAltIcon color="error" fontSize="small" />
          <Typography color="error" fontSize={14} pl={1}>
            {row.original.warnings}
          </Typography>
        </Box>
      ) : (
        <Typography ml={1}>---</Typography>
      );
    },
  },
];
