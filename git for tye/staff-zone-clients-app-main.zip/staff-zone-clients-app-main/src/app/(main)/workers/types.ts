export type WorkersListFilter = {
  searchBy: string;
  certificationsId: string;
  skills: string;
  projectId: string;
  startDate: string;
  endDate: string;
  status: string;
};

export interface WorkerContactForm {
  name: string;
  lastName: string;
  cellPhone: string;
  email: string;
}

export interface WorkerDTO {
  id: string;
  workerName: string;
  workerLastName: string;
  workerMiddleInitial: string;
  workerOtherLastNames: string;
  workerSocialSecurityNumber: string;
  workerDateOfBirth: Date;
  streetAddressLine1: string;
  streetAddressLine2: string;
  city: string;
  state: string;
  zipCode: string;
  mainPhone: string;
  name: string;
  lastName: string;
  email: string;
  cellPhone: string;
  certifications: string[];
  skills: string[];
}
