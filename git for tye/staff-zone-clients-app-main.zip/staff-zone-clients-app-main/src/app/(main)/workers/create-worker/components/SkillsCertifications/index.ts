import SkillsCertifications from './SkillsCertifications';

export default SkillsCertifications;
