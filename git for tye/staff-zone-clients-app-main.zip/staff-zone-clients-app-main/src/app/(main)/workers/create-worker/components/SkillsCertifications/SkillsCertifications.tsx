import Grid from '@mui/material/Unstable_Grid2';
import React from 'react';
import { Typography } from '@mui/material';
import RHMultiSelect from '@/components/shared/Form/RHMultiSelect';
import { FormSectionProps, ICreateWorker } from '../../types';
import { useGetCertificationDropdown } from '@/requests/api/certificationBadgeApi/certificationBadgeApi';
import { useGetSkillDropdown } from '@/requests/api/skillsApi/skillsApi';

const SkillsCertifications = ({ rhProps }: FormSectionProps<ICreateWorker>) => {
  const { errors, control, getValues } = rhProps;
  const {data: certificationData, loading: certLoading} = useGetCertificationDropdown()
  const {data: skillsData, loading: dataLoading} = useGetSkillDropdown()

  return (
    <>
      <Typography variant="h6">Skills and Certifications</Typography>
      <Grid container spacing={2}>
        <Grid xs={12} sm={12} lg={6} mb={-1} marginBottom={1} marginTop={1}>
          <RHMultiSelect<ICreateWorker>
            label="Skills"
            propName="skills"
            options={skillsData}
            rhProps={{ errors, control, getValues, required: false }}
            isLoading={dataLoading}
          />
        </Grid>
        <Grid xs={12} sm={12} lg={6} mb={-1} marginBottom={1} marginTop={1}>
          <RHMultiSelect<ICreateWorker>
            label="Certifications/badges"
            propName="certifications"
            options={certificationData}
            rhProps={{ errors, control, getValues, required: false }}
            isLoading={certLoading}
          />
        </Grid>
      </Grid>
    </>
  );
};

export default SkillsCertifications;
