import { ICreateWorker } from '@/app/(main)/workers/create-worker/types';

export const defaultCreateWorker: ICreateWorker = {
  branches: [],
  dateOfBirth: '',
  firstName: '',
  lastName: '',
  middleInitial: '',
  otherNames: '',
  ssnNumber: '',
  address: '',
  addressLine2: '',
  city: '',
  state: '',
  postalCode: '',
  phone: '',
  name: '',
  email: '',
  cellPhone: '',
  certifications: [],
  skills: [],
};
