'use client';

import { useRouter } from 'next/navigation';
import { SubmitHandler } from 'react-hook-form';
import { useGetDropdownBranchList } from '@/requests/api/branchesApi/branchesApi';
import { useSnackbar } from '@/context/SnackbarContext';
import { ICreateWorker } from './types';
import BaseWorkerForm from '../components/BaseWorkerForm';
import { useCreateWorker } from '@/requests/api/workersApi/workersApi';

const CreateWorker = () => {
  const { data: branchesList } = useGetDropdownBranchList();
  const [createWorker, { loading: isCreateWorkerLoading }] = useCreateWorker();

  const { setMessage, setErrorMessage } = useSnackbar();
  const router = useRouter();

  const onSubmit: SubmitHandler<ICreateWorker> = async (formData: ICreateWorker) => {
    try {
      await createWorker(formData);
      setMessage('Worker created successfully');
      router.push('/workers');
    } catch (e: any) {
      if (e.response?.data?.message) {
        let formattedText = e.response?.data?.message.toLowerCase();
        formattedText = formattedText.charAt(0).toUpperCase() + formattedText.slice(1);
        setMessage(formattedText);
      } else {
        setErrorMessage('Error creating worker');
      }
    }
  };

  return (
    <BaseWorkerForm isCreate={true} onSubmit={onSubmit} isLoading={isCreateWorkerLoading} branchesList={branchesList} />
  );
};

export default CreateWorker;
