import { Typography } from '@mui/material';
import React from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import RHTextField from '@/components/shared/Form/RHTextField';
import { Dropdown } from '@/types/Dropdown';
import { FieldValues } from 'react-hook-form';
import { ReactHookProps } from '@/types/forms/RHProps';
import { ICreateWorker } from '@/app/(main)/workers/create-worker/types';
import RHDatePicker from '@/components/shared/Form/RHDatePicker';
import RHMaskedInput from '@/components/shared/Form/RHMaskedInput';
import dayjs from 'dayjs';

type Props<T extends FieldValues> = {
  rhProps: ReactHookProps<T>;
  branchesList?: Dropdown;
  isBranchesListLoading?: boolean;
};

const BasicInformation = ({ rhProps }: Props<ICreateWorker>) => {
  const { control, errors, getValues } = rhProps;

  return (
    <>
      <Typography variant="h6">Basic information</Typography>
      <Typography variant="subtitle2" mb={1}>
        Worker&apos;s basic details
      </Typography>

      <Grid container spacing={2}>
        <Grid xs={12} sm={12} lg={6} mb={-2}>
          <RHTextField<ICreateWorker>
            label="First name"
            propName="firstName"
            rhProps={{ errors, control, getValues, minLength: 2, errorMessage: 'Please enter a valid name' }}
          />
        </Grid>
        <Grid xs={12} sm={12} lg={6} mb={-2}>
          <RHTextField<ICreateWorker>
            label="Last name"
            propName="lastName"
            rhProps={{ errors, control, getValues, minLength: 2, errorMessage: 'Please enter a valid last name' }}
          />
        </Grid>
        <Grid xs={12} sm={12} lg={6} mb={-2}>
          <RHTextField<ICreateWorker>
            label="Middle initial"
            propName="middleInitial"
            rhProps={{ errors, control, getValues, required: false, maxLength: 5 }}
          />
        </Grid>
        <Grid xs={12} sm={12} lg={6} mb={-2}>
          <RHTextField<ICreateWorker>
            label="Other last names used (if any)"
            propName="otherNames"
            rhProps={{ errors, control, getValues, required: false }}
          />
        </Grid>
        <Grid xs={12} sm={12} lg={6}>
          <RHMaskedInput<ICreateWorker>
            mask="999-99-9999"
            label="Social security number"
            propName="ssnNumber"
            rhProps={{
              errors,
              control,
              minLength: 9,
              errorMessage: 'SSN should have the format 555-55-5555. SSN must be unique',
            }}
          />
        </Grid>
        <Grid xs={12} sm={12} lg={6} mt={1}>
          <RHDatePicker<ICreateWorker>
            label="Date of birth"
            propName="dateOfBirth"
            maxDate={dayjs().subtract(18, 'year')}
            fullWidth
            rules={{
              validate: (value: any) => {
                if (!value) {
                  return 'Date of birth is required';
                }
                const selectedDate = dayjs(value);
                const isOlderThan18 = dayjs().diff(selectedDate, 'year') >= 18;
                return isOlderThan18 || 'You must be over 18 years old';
              },
            }}
            rhProps={{ errors, control, required: true }}
          />
        </Grid>
      </Grid>
    </>
  );
};

export default BasicInformation;
