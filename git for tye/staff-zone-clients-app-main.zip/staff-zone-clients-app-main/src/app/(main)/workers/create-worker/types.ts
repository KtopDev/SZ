import { FieldValues } from 'react-hook-form';
import { WorkerContactForm } from '../types';
import { ReactHookProps } from '@/types/forms/RHProps';

export interface ICreateWorker extends WorkerContactForm {
  branches: string[];
  firstName: string;
  lastName: string;
  middleInitial: string;
  otherNames: string;
  ssnNumber: string;
  dateOfBirth: Date | string;
  address: string;
  addressLine2: string;
  city: string;
  state: string;
  postalCode: string;
  email: string;
  phone: string;
  certifications: string[];
  skills: string[];
}

export type FormSectionProps<T extends FieldValues> = {
  rhProps: ReactHookProps<T>;
};
