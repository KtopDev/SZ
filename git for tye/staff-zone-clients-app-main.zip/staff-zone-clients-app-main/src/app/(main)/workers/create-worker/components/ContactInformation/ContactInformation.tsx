import { Typography } from '@mui/material';
import React from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import { FormSectionProps, ICreateWorker } from '@/app/(main)/workers/create-worker/types';
import RHMaskedInput from '@/components/shared/Form/RHMaskedInput';
import RHTextField from '@/components/shared/Form/RHTextField';

const ContactInformation = ({ rhProps }: FormSectionProps<ICreateWorker>) => {
  const { control, errors } = rhProps;

  return (
    <>
      <Typography variant="h6">Contact Information</Typography>
      <Typography variant="subtitle2" mb={1}>
        Phone email and address for account
      </Typography>

      <Grid container spacing={2}>
        <Grid xs={12} sm={12} lg={6}>
          <RHMaskedInput<ICreateWorker>
            mask="(999) 999 9999"
            label="Phone number"
            propName="phone"
            rhProps={{
              errors,
              control,
              minLength: 10,
              errorMessage: 'Phone number should have the format (555) 555-5555. Phone number must be unique',
            }}
          />
        </Grid>
        <Grid xs={12} sm={12} lg={6}>
          <RHTextField<ICreateWorker>
            label="Email address"
            propName="email"
            type="text"
            rhProps={{
              errors,
              control,
              isEmail: true,
              minLength: 3,
              errorMessage: 'Email should have the format example@email.com. Email address must be unique',
            }}
          />
        </Grid>
      </Grid>
    </>
  );
};

export default ContactInformation;
