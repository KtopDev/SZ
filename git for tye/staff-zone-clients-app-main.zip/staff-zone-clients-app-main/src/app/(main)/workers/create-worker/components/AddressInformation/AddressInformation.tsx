import { Typography } from '@mui/material';
import Grid from '@mui/material/Unstable_Grid2';
import RHTextField from '@/components/shared/Form/RHTextField';
import RHSelect from '@/components/shared/Form/RHSelect';
import RHMaskedInput from '@/components/shared/Form/RHMaskedInput';
import * as React from 'react';
import { FormSectionProps, ICreateWorker } from '@/app/(main)/workers/create-worker/types';
import { useGetDropdownState } from '@/requests/api/statesApi/statesApi';

const AddressInformation = ({ rhProps }: FormSectionProps<ICreateWorker>) => {
  const { errors, control, getValues } = rhProps;
  const { data: states, loading: isStateDropdownLoading } = useGetDropdownState();

  return (
    <>
      <Typography mb={2}>Address</Typography>
      <Grid container spacing={2}>
        <Grid xs={12} sm={12} md={12} lg={12} mb={-1}>
          <RHTextField<ICreateWorker>
            label="Street address"
            propName="address"
            margin="none"
            rhProps={{ errors, control }}
          />
        </Grid>
        <Grid xs={12} sm={12} md={6} lg={6} mb={-2}>
          <RHTextField<ICreateWorker>
            label="Street address line 2"
            propName="addressLine2"
            helperText="Optional"
            rhProps={{ errors, control, required: false }}
          />
        </Grid>
        <Grid xs={12} sm={12} md={6} lg={6} mb={-2}>
          <RHTextField<ICreateWorker> label="City" propName="city" rhProps={{ errors, control }} />
        </Grid>
        <Grid xs={12} sm={12} md={6} lg={6}>
          <RHSelect<ICreateWorker>
            label="State"
            propName="state"
            options={states}
            rhProps={{ errors, control, getValues }}
            isLoading={isStateDropdownLoading}
          />
        </Grid>
        <Grid xs={12} sm={12} md={6} lg={6}>
          <RHMaskedInput<ICreateWorker>
            label="Zip code"
            propName="postalCode"
            mask="99999"
            rhProps={{ errors, control, minLength: 5, errorMessage: 'Please enter a valid zip code' }}
          />
        </Grid>
      </Grid>
    </>
  );
};

export default AddressInformation;
