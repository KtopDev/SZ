'use client';

import { useRouter } from 'next/navigation';
import { useGetDropdownBranchList } from '@/requests/api/branchesApi/branchesApi';
import { useSnackbar } from '@/context/SnackbarContext';
import { useGetWorkerData, useUpdateWorker } from '@/requests/api/workersApi/workersApi';
import BaseWorkerForm from '@/app/(main)/workers/components/BaseWorkerForm';
import { Backdrop, Box } from '@mui/material';
import { grey } from '@mui/material/colors';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import CircularProgress from '@mui/material/CircularProgress';
import { useMemo } from 'react';

const EditWorker = ({ params }: any) => {
  const { data: branchesList } = useGetDropdownBranchList();

  const { data: workerData, loading: isLoading } = useGetWorkerData(params.workerId);
  const [updateWorker, { loading: isUpdateWorkerLoading }] = useUpdateWorker();

  const { setMessage, setErrorMessage } = useSnackbar();
  const router = useRouter();

  const onSubmit = async (formData: any) => {
    try {
      await updateWorker(formData);
      setMessage('Worker created successfully');
      router.push('/workers');
    } catch (e: any) {
      if (e.response?.data?.message) {
        let formattedText = e.response?.data?.message.toLowerCase();
        formattedText = formattedText.charAt(0).toUpperCase() + formattedText.slice(1);
        setMessage(formattedText);
      } else {
        setErrorMessage('Error creating worker');
      }
    }
  };

  const formData = useMemo(
    () => ({
      ...workerData,
      certifications: workerData.certifications?.map((certification: any) => certification.certificationId),
      skills: workerData.skills?.map((skill: any) => skill.skillId),
    }),
    [workerData]
  );

  return (
    <>
      <Backdrop sx={{ color: '#fff' }} open={isLoading}>
        <CircularProgress color="inherit" />
      </Backdrop>
      <Box
        display="flex"
        px={3}
        py={4}
        borderBottom={1}
        borderColor={grey[300]}
        alignItems="center"
        gap={2}
        fontSize={16}>
        Workers <ArrowForwardIosIcon sx={{ fontSize: 'small' }} /> Edit worker
      </Box>
      <BaseWorkerForm
        isCreate={false}
        onSubmit={onSubmit}
        workerData={formData}
        branchesList={branchesList}
        isLoading={isUpdateWorkerLoading}
      />
    </>
  );
};

export default EditWorker;
