'use client';

import Box from '@mui/material/Box';
import Grid from '@mui/material/Unstable_Grid2';
import Typography from '@mui/material/Typography';
import { Button, TextField } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import Table from '@/components/shared/Table/Table';
import * as React from 'react';
import { useState } from 'react';
import { MRT_TablePagination } from 'material-react-table';
import { SortingState } from '@tanstack/table-core';
import { useForm, useWatch } from 'react-hook-form';
import { debounce } from 'lodash';
import RHSelect from '@/components/shared/Form/RHSelect';
import RHDatePicker from '@/components/shared/Form/RHDatePicker';
import { getColumns } from '@/app/(main)/workers/constants/tableColumns';
import { useRouter } from 'next/navigation';
import RHMultiSelect from '@/components/shared/Form/RHMultiSelect';
import Link from '@/components/shared/Link';
import ActionColumnContent from '@/components/shared/Table/components/ActionColumnContent/ActionColumnContent';
import { WorkersListFilter } from './types';
import WorkerWarningsModal from './components/WorkerWarningsModal';
import WorkerSkillsAndCertificationsModal from './components/WorkerSkillsAndCertificationsModal';
import { useGetWorkersList } from '@/requests/api/workerApi/workerApi';
import { useSidebar } from '@/context/SidebarContext';
import { useGetSkillDropdown } from '@/requests/api/skillsApi/skillsApi';
import { useGetCertificationDropdown } from '@/requests/api/certificationBadgeApi/certificationBadgeApi';
import UserClosure from '@/utils/UserClosure';
import { useGetProjectsDropdown } from '@/requests/api/projectApi/projectApi';

const WorkersPage = () => {
  const {
    control,
    formState: { errors },
    setValue,
    getValues,
  } = useForm<WorkersListFilter>({
    defaultValues: {
      searchBy: '',
      projectId: '',
      status: '',
      startDate: '',
      endDate: '',
      certificationsId: '',
      skills: '',
    },
  });

  const searchBy = useWatch({ control: control, name: 'searchBy' });
  const startDate = useWatch({ control: control, name: 'startDate' });
  const skills = useWatch({ control: control, name: 'skills' });
  const certifications = useWatch({ control: control, name: 'certificationsId' });
  const projectId = useWatch({ control: control, name: 'projectId' });
  const endDate = useWatch({ control: control, name: 'endDate' });
  const { selectedBranchId } = useSidebar();
  const [pagination, setPagination] = useState({ pageIndex: 1, pageSize: 10 });
  const [sorting, setSorting] = useState<SortingState>([]);



  const filter = React.useMemo(
    () => {
      const projectFilter = projectId && projectId.length > 0 ? {
        projectId,
      } : {}
      return {
        size: pagination.pageSize,
        page: pagination.pageIndex + 1,
        sort: sorting[0] ? `${sorting[0].id},${sorting[0].desc ? 'desc' : 'asc'}` : 'workerCode,asc',
        searchBy,
        branchId: selectedBranchId,
        lastDayWorkedStartDate: startDate,
        lastDayWorkedEndDate: endDate,
        status: ['ACTIVE', 'INACTIVE', 'INCOMPLETE', 'DNR', 'TERMINATED'],
        skills,
        certifications,
        ...projectFilter,
      }},
    //eslint-disable-next-line react-hooks/exhaustive-deps
    [startDate, endDate, searchBy, skills, sorting, pagination.pageIndex, selectedBranchId, projectId]
  );

  const {data: skillsDropdown, loading: skillsLoading } = useGetSkillDropdown()
  const {data: certDropdown, loading: certLoading} = useGetCertificationDropdown();
  const clientId = UserClosure.getUser()?.auth_user_details.user.client_id || ''
  const {data: projectData, loading: loadingProjects} = useGetProjectsDropdown(clientId)

  const [isWarningsOpen, setIsWarningsOpen] = useState<boolean>(false)

  const [isSkillsOpen, setIsSkillsOpen] = useState<boolean>(false)

  const {data: workerData, loading: workerLoading} = useGetWorkersList(filter)


  const router = useRouter();



  const renderTopToolbar = ({ table }: any) => (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        backgroundColor: 'common.white',
        justifyContent: 'end',
        paddingX: '24px',
      }}>
      <MRT_TablePagination table={table} />
    </Box>
  );

  const debouncedSetValue = debounce(setValue, 1000);

  const handleNameInputChange = (e: any) => {
    debouncedSetValue('searchBy', e.target.value);
  };

  const renderRowActionMenuItems = ({ row }: { row: any }) => {
    const options = [
      {
        label: 'Edit worker',
        onClick: () => router.push(`/workers/${row.original.worker_id}/edit-worker`),
      },
      {
        label: 'Reset password',
        onClick: () => null,
      },
      {
        label: 'Do not repeat',
        onClick: () => {
        },
        color: 'error',
        disabled: row.original.status === 'TERMINATED',
      },
    ];

    return (
      <Box key={row.original.worker_code}>
        <ActionColumnContent menuItems={options} row={row} />
      </Box>
    );
  };

  return (
    <>
      <Box paddingY="8px" paddingX="24px" bgcolor="common.white" border="none">
        <Grid container direction="row" justifyContent="space-between">
          <Typography paddingY="4px" fontWeight="regular" fontSize={24}>
            Workers
          </Typography>
          <Box paddingY="5px">
            <Link href={'/workers/create-worker'}>
              <Button variant="contained" startIcon={<AddIcon />}>
                CREATE
              </Button>
            </Link>
          </Box>
        </Grid>
        <Box sx={{ flexGrow: 1 }} pt={1}>
          <Grid container alignItems="end" spacing={2} columns={180}>
            <Grid xs={55} py="14px">
              <TextField
                fullWidth
                InputProps={{
                  startAdornment: <SearchIcon />,
                }}
                placeholder="Search by name/phone number/SSN"
                id="outlined-basic"
                variant="outlined"
                onChange={handleNameInputChange}
              />
            </Grid>
            <Grid xs={25} px="0px" py="14px">
              <RHMultiSelect<WorkersListFilter>
                label="Project"
                propName="projectId"
                options={projectData}
                isLoading={loadingProjects}
                shouldUseChipRender={false}
                inputStyles={{
                  borderRadius: '5px 0 0 5px',
                }}
                rhProps={{ errors, control, required: false, getValues }}
              />
            </Grid>
            <Grid xs={25} px="0px" py="14px">
              <RHMultiSelect<WorkersListFilter>
                label="Certifications"
                propName="certificationsId"
                options={certDropdown}
                isLoading={certLoading}
                shouldUseChipRender={false}
                inputStyles={{
                  borderRadius: '0px',
                  maxWidth: '100%',
                  flexWrap: 'wrap',
                }}
                rhProps={{ errors, control, required: false, getValues }}
              />
            </Grid>
            <Grid xs={25} px="0px" py="6px">
              <RHSelect<WorkersListFilter>
                label="Skills"
                propName="skills"
                options={skillsDropdown}
                isLoading={skillsLoading}
                inputStyles={{
                  '& .MuiOutlinedInput-root': {
                    borderRadius: '0  5px 5px 0',
                  },
                }}
                rhProps={{ errors, control, required: false, getValues }}
              />
            </Grid>
            <Grid xs={23} pb="6px">
              <Typography fontSize={14} paddingBottom="8px">
                Last day worked
              </Typography>
              <RHDatePicker<WorkersListFilter>
                label="Start date"
                propName="startDate"
                rhProps={{ errors, control, required: false }}
              />
            </Grid>
            <Grid xs={4}>
              <Typography mb={2}>To</Typography>
            </Grid>
            <Grid xs={23} pb="6px">
              <RHDatePicker<WorkersListFilter>
                label="End date"
                propName="endDate"
                rhProps={{ errors, control, required: false }}
              />
            </Grid>
          </Grid>
        </Box>
      </Box>
      <Table
        mrtProps={{
          layoutMode: 'grid-no-grow',
          data: workerData?.content || [],
          columns: getColumns(router, () => setIsWarningsOpen(true), () => setIsSkillsOpen(true)),
          renderTopToolbar,
          renderRowActions: (props) => renderRowActionMenuItems({ ...props }),
          enableRowActions: true,
          displayColumnDefOptions: {
            'mrt-row-actions': {
              header: '',
            },
          },
          state: {
            sorting,
            pagination,
            isLoading: workerLoading,
          },
          onPaginationChange: setPagination,
          onSortingChange: setSorting,
          manualPagination: true,
          muiTableBodyRowProps: ({ row }) => ({
            sx: {
              borderBottom: '1px solid #e0e0e0',
              backgroundColor: row.original.warning_type === 'ERROR' ? '#DF144514' : 'inherit',
            },
          }),
        }}
        rowCount={workerData?.totalSize || 0}
      />
      <WorkerWarningsModal open={isWarningsOpen} handleClose={() => setIsWarningsOpen(false)}/>
      <WorkerSkillsAndCertificationsModal open={isSkillsOpen} handleClose={() => setIsSkillsOpen(false)}/>
    </>
  );
};

export default WorkersPage;
