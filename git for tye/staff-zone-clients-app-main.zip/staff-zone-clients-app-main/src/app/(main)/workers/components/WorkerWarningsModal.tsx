import { commonModalStyle } from '@/theme/constants';
import { Alert, Avatar, Backdrop, Button, Card, CardContent, Grid, Modal, Stack, Typography } from '@mui/material';
import React from 'react';

const WorkerWarningsModal = ({ open, handleClose }: any) => {
  return (
    <Modal
      open={open}
      onClose={handleClose}
      closeAfterTransition
      slots={{ backdrop: Backdrop }}
      slotProps={{
        backdrop: {
          timeout: 500,
        },
      }}>
      <Card sx={{ ...commonModalStyle, width: 750 }}>
        <CardContent>
          <Typography fontSize={18} fontWeight={600}>
            Warnings
          </Typography>

          <Grid container onClick={() => {}} width="100%" padding="12px" border="1px solid #E0E0E0" mt="40px">
            <Avatar sx={{ mr: 1 }} src="/images/common/avatar.png" />
            <Grid>
              <Typography fontWeight="500" color="primary" sx={{ cursor: 'pointer' }}>
                Devon Lane
              </Typography>
              <Typography fontSize={12}>ID 007</Typography>
            </Grid>
          </Grid>

          <Grid container spacing={1} rowGap={1} mt={1} pl={1}>
            <Alert severity="error">
              <Typography fontSize={16}>Disciplinary form pending to be signed</Typography>
              <Typography fontSize={14}>
                Disciplinary form sent on 11/11/2022. Worker can’t be placed on an order until this issue is solved.
              </Typography>
            </Alert>

            <Alert severity="warning" sx={{width: '100%'}}>
              <Typography fontSize={14}>
                Tax information needs to be updated.
              </Typography>
            </Alert>
          </Grid>

          <Stack spacing={2} direction="row" sx={{ display: 'flex', justifyContent: 'flex-end' }} mt={2}>
            <Button variant="text" onClick={handleClose}>
              DISMISS
            </Button>
          </Stack>
        </CardContent>
      </Card>
    </Modal>
  );
};

export default WorkerWarningsModal;
