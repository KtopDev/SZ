import { commonModalStyle } from '@/theme/constants';
import { Avatar, Backdrop, Box, Button, Card, CardContent, Grid, Modal, Stack, Typography } from '@mui/material';
import React from 'react';

const WorkerSkillsAndCertificationsModal = ({ open, handleClose }: any) => {
  return (
    <Modal
      open={open}
      onClose={handleClose}
      closeAfterTransition
      slots={{ backdrop: Backdrop }}
      slotProps={{
        backdrop: {
          timeout: 500,
        },
      }}>
      <Card sx={{ ...commonModalStyle, width: 400 }}>
        <CardContent>
          <Typography fontSize={18} fontWeight={600}>
            Skills and certifications
          </Typography>

          <Grid container onClick={() => {}} width="100%" padding="12px" border="1px solid #E0E0E0" mt="40px">
            <Avatar sx={{ mr: 1 }} src="/images/common/avatar.png" />
            <Grid>
              <Typography fontWeight="500" color="primary" sx={{ cursor: 'pointer' }}>
                Devon Lane
              </Typography>
              <Typography fontSize={12}>ID 007</Typography>
            </Grid>
          </Grid>

          <Grid container mt="20px">
            <Box width="100%" padding="16px">
              <Typography fontSize={12} color="#00000099">Skills</Typography>
            </Box>

            <Box padding="16px" borderBottom="1px solid #E0E0E0">
              <Typography fontSize={16}>Item name</Typography>
              <Typography fontSize={12} color="#00000099">Item description, lorem ipsum dolorem sit ammet</Typography>
            </Box>

            <Box padding="16px" borderBottom="1px solid #E0E0E0">
              <Typography fontSize={16}>Item name</Typography>
              <Typography fontSize={12} color="#00000099">Item description, lorem ipsum dolorem sit ammet</Typography>
            </Box>
          </Grid>

          <Grid container mt="20px">
            <Box width="100%" padding="16px">
              <Typography fontSize={12} color="#00000099">Certifications</Typography>
            </Box>

            <Box padding="16px" borderBottom="1px solid #E0E0E0">
              <Typography fontSize={16}>Item name</Typography>
              <Typography fontSize={12} color="#00000099">Item description, lorem ipsum dolorem sit ammet</Typography>
            </Box>

            <Box padding="16px" borderBottom="1px solid #E0E0E0">
              <Typography fontSize={16}>Item name</Typography>
              <Typography fontSize={12} color="#00000099">Item description, lorem ipsum dolorem sit ammet</Typography>
            </Box>
          </Grid>

          <Stack spacing={2} direction="row" sx={{ display: 'flex', justifyContent: 'flex-end' }} mt={2}>
            <Button variant="text" onClick={handleClose}>
              CLOSE
            </Button>
          </Stack>
        </CardContent>
      </Card>
    </Modal>
  );
};

export default WorkerSkillsAndCertificationsModal;
