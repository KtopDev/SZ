import React, { useEffect } from 'react';
import Divider from '@mui/material/Divider';
import { WorkerDTO } from '@/app/(main)/workers/types';
import { Box, Button, Typography } from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import { useForm, useWatch } from 'react-hook-form';
import { ICreateWorker } from '@/app/(main)/workers/create-worker/types';
import { defaultCreateWorker } from '@/app/(main)/workers/create-worker/constants/constants';
import { Alert } from '@mui/lab';
import { Dropdown } from '@/types/Dropdown';
import Link from '@/components/shared/Link';
import BasicInformation from '../create-worker/components/BasicInformation';
import ContactInformation from '../create-worker/components/ContactInformation';
import AddressInformation from '../create-worker/components/AddressInformation';
import SkillsCertifications from '../create-worker/components/SkillsCertifications';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';

type Props = {
  isCreate: boolean;
  isLoading: boolean;
  workerData?: WorkerDTO;
  branchesList?: Dropdown;
  onSubmit: (formData: any, setError: any) => void;
};

const BaseWorkerForm = ({ onSubmit, isLoading, isCreate, workerData, branchesList }: Props) => {
  const {
    control,
    formState: { errors, isValid },
    handleSubmit,
    getValues,
    setError,
    reset,
  } = useForm<ICreateWorker>({ defaultValues: isCreate ? defaultCreateWorker : workerData, mode: 'onChange' });

  const branches = useWatch({ control: control, name: 'branches' });

  useEffect(() => {
    reset(workerData);
  }, [workerData, reset]);

  const getFirstBranchDisplayName = () =>
    branchesList?.dropdown.find((branch) => branches[0] === branch.id)?.displayName;

  return (
    <Box paddingX="24px" py={2}>
      <BasicInformation rhProps={{ control, errors, getValues }} />
      <Box py={2}>
        <Divider />
      </Box>
      <ContactInformation rhProps={{ control, errors, getValues }} />
      <AddressInformation rhProps={{ control, errors, getValues }} />
      <Box py={2}>
        <Divider />
      </Box>
      <SkillsCertifications rhProps={{ control, errors, getValues }} />
      {branches?.length > 0 && (
        <Box py={2}>
          {isCreate && (
            <Alert severity="warning" sx={{ justifyContent: 'space-between' }}>
              Worker will be created in branch {getFirstBranchDisplayName()}. Verify that this is the branch in which
              you intended to create this client. Continue if this is correct.
            </Alert>
          )}
        </Box>
      )}
      <Box display="flex" sx={{backgroundColor: '#ecf3fa'}} padding="16px" mt={4}>
        <ErrorOutlineIcon htmlColor='#438BCD'/>
        <Typography ml="10px" fontSize={14} color="#00000099">This worker will be notified by SMS. They must download the StaffZone Worker app in order to finish their application, we will notify you once this is completed.</Typography>
      </Box>
      <Box display="flex" justifyContent="flex-end" mt={4}>
        <Link href={'/workers'}>
          <Button variant="outlined">CANCEL</Button>
        </Link>
        <LoadingButton
          disabled={!isValid}
          startIcon={null}
          loading={isLoading}
          variant="contained"
          color="primary"
          sx={{ marginLeft: 1 }}
          onClick={handleSubmit((formValues) => onSubmit(formValues, setError))}>
          {isCreate ? 'CREATE WORKER' : 'SAVE CHANGES'}
        </LoadingButton>
      </Box>
    </Box>
  );
};

export default BaseWorkerForm;
