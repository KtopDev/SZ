'use client';
import Image from 'next/image';
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Unstable_Grid2';
import { Box, Button, Typography } from '@mui/material';
import React from 'react';
import { useRouter } from 'next/navigation';

const MainContainer = styled('main')(({ theme }) => ({
  flexGrow: 1,
  display: 'flex',
  height: '100vh',
  flexDirection: 'column',
  justifyContent: 'center',
  alignItems: 'center',
  backgroundColor: theme.palette.background.default,
}));

const OrderCreated = () => {
  const router = useRouter();

  const goToOrderDetails = () => router.push('/projects');

  return (
    <MainContainer>
      <Grid container xs={12} lg={6} md={6} sm={12} alignItems="center" justifyContent="center">
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            flexDirection: 'column',
            padding: 5,
          }}>
          <Image src="/images/common/success.png" alt="Picture of the author" width={136} height={136} />
          <Typography pb={1} variant="h5" component="h5">
            Order created successfully
          </Typography>
          <Typography pb={4} fontSize={16} gutterBottom>
            Your request for workers was sent successfully, this will be reviewed and we will let you know when it’s
            approved.
          </Typography>

          <Button onClick={goToOrderDetails} fullWidth variant="contained">
            VIEW ORDER DETAILS
          </Button>
        </Box>
      </Grid>
    </MainContainer>
  );
};

export default OrderCreated;
