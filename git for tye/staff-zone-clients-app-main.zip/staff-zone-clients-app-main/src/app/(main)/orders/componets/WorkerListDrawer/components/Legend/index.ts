import Legend from '@/app/(main)/orders/componets/WorkerListDrawer/components/Legend/Legend';

export default Legend;
