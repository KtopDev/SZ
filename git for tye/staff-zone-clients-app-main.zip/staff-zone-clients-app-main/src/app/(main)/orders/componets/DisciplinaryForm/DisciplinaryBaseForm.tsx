'use client';
import { useForm, useWatch } from 'react-hook-form';
import { Backdrop, Button, Card, CardContent, Stack } from '@mui/material';
import { commonModalStyle } from '@/theme/constants';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Unstable_Grid2';
import LoadingButton from '@mui/lab/LoadingButton';
import React, { useEffect, useState } from 'react';
import Modal from '@mui/material/Modal';
import RHDatePicker from '@/components/shared/Form/RHDatePicker';
import RHSelect from '@/components/shared/Form/RHSelect';
import RHTextareaAutosize from '@/components/shared/Form/RHTextarea';
import dayjs from 'dayjs';
import { useGetProjectsDropdown } from '@/requests/api/projectApi/projectApi';
import { useLazyGetOrdersDropdownByProject } from '@/requests/api/orderApi/orderApi';
import useGet from '@/hooks/useGet';
import { Dropdown } from '@/types/Dropdown';
import { DISCIPLINARY_WARNING_TYPES } from '@/requests/endpoints';
import UserClosure from '@/utils/UserClosure';
import { useGetWorkerData } from '@/requests/api/workersApi/workersApi';

interface IDisciplinaryForm {
  dateOfIncident: string;
  project: string;
  typeOfWarning: string;
  description: string;
  expectedResults: string;
  order: string;
}

const DisciplinaryBaseForm = ({ open, handleClose, isLoading, onSubmit, workerName, lastActive, workerCode, workerId }: any) => {


  const clientId = UserClosure.getUser()?.auth_user_details.user.client_id || ''
  const {data: projectData, loading: loadingProjects} = useGetProjectsDropdown(clientId)
  const [getOrders, {loading: ordersLoading}] = useLazyGetOrdersDropdownByProject()
  const { getData: warningTypeData, isLoading: warningTypeLoading } = useGet<Dropdown>(DISCIPLINARY_WARNING_TYPES);
  const {data: workerData} = useGetWorkerData(workerId)
  const [ordersDropdown, setOrdersDropdown] = useState<any>([])

  const {
    control,
    formState: { errors, isValid },
    handleSubmit,
    reset,
    setError,
  } = useForm<IDisciplinaryForm>({
    mode: 'onBlur',
    defaultValues: {
      dateOfIncident: '',
      project: '',
      typeOfWarning: '',
      description: '',
      expectedResults: '',
      order: '',
    },
  });
  const projectId = useWatch({control: control, name: 'project'})

  useEffect(() => {
    const handleProjectChange = async () => {
      if (projectId) {
        const orderData = await getOrders(projectId)
        setOrdersDropdown(orderData?.data || [])
      } else {
        setOrdersDropdown([])
      }
    }
    handleProjectChange()
  }, [projectId, getOrders])



  const onCloseButtonClick = () => {
    reset();
    handleClose();
  };

  return (
    <Modal
      open={open}
      onClose={onCloseButtonClick}
      closeAfterTransition
      slots={{ backdrop: Backdrop }}
      slotProps={{
        backdrop: {
          timeout: 500,
        },
      }}>
      <Card sx={commonModalStyle}>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            Send disciplinary
          </Typography>
          <Grid container maxHeight={'100%'} overflow={'none'}>
            <Grid xs={12} sm={12} md={12} lg={12}>
              <Typography variant="subtitle2" fontSize={20} mb={2} mt={2}>
                {workerName}
              </Typography>
            </Grid>
            <Grid xs={4} sm={4} md={4} lg={4} mb={3}>
              <Typography variant="subtitle2" fontSize={12} color="#00000099">
                SSN
              </Typography>
              <Typography variant="subtitle2" fontSize={16}>
                {workerData.ssnNumber}
              </Typography>
            </Grid>
            <Grid xs={4} sm={4} md={4} lg={4}>
              <Typography variant="subtitle2" fontSize={12} color="#00000099">
                Worker ID
              </Typography>
              <Typography variant="subtitle2" fontSize={16}>
                {workerCode}
              </Typography>
            </Grid>
            <Grid xs={4} sm={4} md={4} lg={4}>
              <Typography variant="subtitle2" fontSize={12} color="#00000099">
                Last active on
              </Typography>
              <Typography variant="subtitle2" fontSize={16}>
                {dayjs(lastActive).format('MM/DD/YYYY')}
              </Typography>
            </Grid>
            <Grid xs={12} sm={12} md={12} lg={12} mb={-2}>
              <>
                <RHDatePicker<IDisciplinaryForm>
                  label="Date of incident"
                  propName="dateOfIncident"
                  fullWidth
                  maxDate={dayjs()}
                  rhProps={{ errors, control, required: true }}
                />
                <RHSelect<IDisciplinaryForm>
                  label="Project"
                  propName="project"
                  options={projectData}
                  isLoading={loadingProjects}
                  rhProps={{ errors, control, required: true }}
                  inputStyles={{
                    '& .MuiOutlinedInput-root': {
                      borderRadius: '0  5px 5px 0',
                    },
                  }}
                />
                <RHSelect<IDisciplinaryForm>
                  label="Order"
                  propName="order"
                  options={ordersDropdown}
                  isLoading={ordersLoading}
                  rhProps={{ errors, control, required: true }}
                  inputStyles={{
                    '& .MuiOutlinedInput-root': {
                      borderRadius: '0  5px 5px 0',
                    },
                  }}
                />
                <RHSelect<IDisciplinaryForm>
                  label="Type of warning"
                  propName="typeOfWarning"
                  options={warningTypeData}
                  isLoading={warningTypeLoading}
                  rhProps={{ errors, control, required: true }}
                  inputStyles={{
                    '& .MuiOutlinedInput-root': {
                      borderRadius: '0  5px 5px 0',
                    },
                  }}
                />
                <RHTextareaAutosize<IDisciplinaryForm>
                  minRows={8}
                  label="Description of violation/infraction"
                  propName="description"
                  rhProps={{ errors, control, required: true }}
                />
                <RHTextareaAutosize<IDisciplinaryForm>
                  minRows={8}
                  label="Expected results/corrective actions"
                  propName="expectedResults"
                  rhProps={{ errors, control, required: true }}
                />
              </>
            </Grid>
          </Grid>
          <Stack spacing={2} direction="row" sx={{ display: 'flex', justifyContent: 'flex-end' }} mt={2}>
            <Button variant="text" onClick={onCloseButtonClick}>
              CANCEL
            </Button>
            <LoadingButton
              variant="contained"
              color="primary"
              disabled={!isValid}
              loading={isLoading}
              onClick={handleSubmit((formValues) => onSubmit(formValues, setError, reset))
              }>
              SEND TO WORKER
            </LoadingButton>
          </Stack>
        </CardContent>
      </Card>
    </Modal>
  );
};

export default DisciplinaryBaseForm;
