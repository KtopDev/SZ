'use client';

import * as React from 'react';
import { useMemo, useState } from 'react';
import { Drawer } from '@/components/Layout/components/SideMenu/SideMenu.styled';
import { styled } from '@mui/material/styles';
import ToggleMenuButton from '@/components/Layout/components/SideMenu/components/ToggleMenuButton';
import { Backdrop, Box, Divider, Typography } from '@mui/material';
import { debounce } from 'lodash';
import { useForm, useWatch } from 'react-hook-form';
import { useSidebar } from '@/context/SidebarContext';
import { IWorkerListFilter } from '@/app/(main)/orders/componets/WorkerListDrawer/types';
import FilterPanel from '@/app/(main)/orders/componets/WorkerListDrawer/components/FilterPanel';
import Legend from '@/app/(main)/orders/componets/WorkerListDrawer/components/Legend';
import TableColumns from '@/app/(main)/orders/componets/WorkerListDrawer/components/TableColumns';
import WorkerCard from '@/app/(main)/orders/componets/WorkerListDrawer/components/WorkerCard';
import Image from 'next/image';
import CircularProgress from '@mui/material/CircularProgress';
import { useGetWorkerListForDispatch } from '@/requests/api/workerApi/workerApi';

const DrawerContainer = styled('nav')({
  flexShrink: 0,
  height: '80vh',
});

const WorkerListDrawer = () => {
  const [open, setOpen] = useState(false);
  const {
    control,
    formState: { isValid, errors },
    setValue,
    getValues,
    reset,
  } = useForm<IWorkerListFilter>({
    defaultValues: { status: '', warningType: '', vehicleType: '', lastPay: '' } as IWorkerListFilter,
  });

  const [sortConfig, setSortConfig] = useState<any>({
    key: 'fullName',
    direction: 'asc',
  });

  const { selectedBranchId } = useSidebar();

  const searchBy = useWatch({ control, name: 'searchBy' });

  // const filteredFilters = useMemo(
  //   () => omitBy(filterSelection, (value) => isNil(value) || value === ''),
  //   [filterSelection],
  // );

  const payload = useMemo(
    () => ({
      branchId: selectedBranchId,
      searchBy,
      // ...filterSelection,
      size: 500,
      ...(sortConfig.direction && { sort: `firstName,${sortConfig.direction}` }),
    }),
    //eslint-disable-next-line react-hooks/exhaustive-deps
    [selectedBranchId, sortConfig.direction, sortConfig.key, searchBy]
  );

  const { data: workersList, loading } = useGetWorkerListForDispatch(payload);

  const handleToggle = () => {
    setOpen((val) => !val);
  };

  const handleSort = (columnKey: string) => {
    setSortConfig((prevSortConfig: any) => {
      if (prevSortConfig.key === columnKey) {
        if (prevSortConfig.direction === 'asc') {
          return { key: columnKey, direction: 'desc' };
        } else if (prevSortConfig.direction === 'desc') {
          return { key: '', direction: null };
        }
      }
      return { key: columnKey, direction: 'asc' };
    });
  };

  const debouncedSetValue = debounce(setValue, 1000);

  return (
    <DrawerContainer>
      <Backdrop sx={{ color: '#fff' }} open={loading}>
        <CircularProgress color="inherit" />
      </Backdrop>
      <Drawer
        openDrawerWidth={'50vw'}
        anchor="right"
        sx={{ justifyContent: 'space-between' }}
        variant="permanent"
        open={open}
        color={'white'}>
        <Box py="6px">
          <Box px={2} display="flex" justifyContent={open ? 'space-between' : 'center'} pt={2}>
            {open && <Typography>Drag a worker to the job to assign he/she on this worker</Typography>}
            <ToggleMenuButton position="right" handleToggle={handleToggle} open={open} />
          </Box>
          <Box py={2}>
            <Divider />
          </Box>
          {!open ? (
            <Box display="flex" justifyContent="center" pt={5}>
              <Typography
                variant="body1"
                sx={{
                  writingMode: 'vertical-rl',
                  transform: 'rotate(180deg)',
                }}>
                Select Workers
              </Typography>
            </Box>
          ) : (
            <Box>
              <FilterPanel
                filters={{}}
                rhProps={{ control, setValue, getValues, reset, isValid, errors, debouncedSetValue }}
                // openFilter={() => setFilterModalVisible(true)}
              />
              <Legend />
              <TableColumns sortConfig={sortConfig} onSort={handleSort} />
              {workersList?.content?.length ? (
                workersList.content.map((worker: any) => <WorkerCard worker={worker} key={worker.id} />)
              ) : (
                <Box display="flex" flexDirection="column" alignItems="center" paddingTop={10}>
                  <Image src={'/images/empty-table/staff-zone.svg'} alt="Logo" width={180} height={140} />
                  <Typography>There is no data to show here yet</Typography>
                </Box>
              )}
            </Box>
          )}
        </Box>
      </Drawer>
    </DrawerContainer>
  );
};

export default WorkerListDrawer;
