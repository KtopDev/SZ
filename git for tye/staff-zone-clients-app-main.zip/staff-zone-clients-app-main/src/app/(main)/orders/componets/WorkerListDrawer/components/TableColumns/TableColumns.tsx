import Grid from '@mui/material/Unstable_Grid2';
import { Typography } from '@mui/material';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
import ImportExportIcon from '@mui/icons-material/ImportExport';
import StarIcon from '@mui/icons-material/Star';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';

const TableColumns = ({ sortConfig, onSort }: any) => {
  const renderSortIcon = (columnKey: string) => {
    if (sortConfig.key !== columnKey) {
      return <ImportExportIcon fontSize="small" />;
    }
    if (sortConfig.direction === 'asc') {
      return <ArrowUpwardIcon fontSize="small" />;
    }
    return <ArrowDownwardIcon fontSize="small" />;
  };

  return (
    <Grid container columns={100} alignItems="center" py={2} px={1}>
      <Grid xs={41} px="4px" container alignItems="end" onClick={() => onSort('fullName')} sx={{ cursor: 'pointer' }}>
        <Typography fontSize={12}>Name</Typography>
        {renderSortIcon('fullName')}
      </Grid>
      <Grid
        xs={13}
        px="4px"
        container
        alignItems="end"
        onClick={() => onSort('skills_count')}
        sx={{ cursor: 'pointer' }}>
        <Typography fontSize={12}>Skills</Typography>
      </Grid>
      <Grid
        xs={13}
        px="4px"
        container
        alignItems="end"
        onClick={() => onSort('last_worked')}
        sx={{ cursor: 'pointer' }}>
        <Typography fontSize={12}>Last Worked</Typography>
      </Grid>

      <Grid
        xs={11}
        px="4px"
        container
        alignItems="end"
        onClick={() => onSort('hours_worked')}
        sx={{ cursor: 'pointer' }}>
        <Typography fontSize={12}>H. worked</Typography>
      </Grid>

      <Grid xs={11} px="4px" container alignItems="end" onClick={() => onSort('rating')} sx={{ cursor: 'pointer' }}>
        <StarIcon fontSize="small" />
      </Grid>
      <Grid xs={11} px="4px" container alignItems="end" onClick={() => onSort('warnings')} sx={{ cursor: 'pointer' }}>
        <WarningAmberIcon fontSize="small" />
      </Grid>
    </Grid>
  );
};

export default TableColumns;
