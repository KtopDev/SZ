import React from 'react';
import { Avatar, Box, Checkbox, Chip, Dialog, DialogActions, DialogContent, Typography } from '@mui/material';
import PersonIcon from '@mui/icons-material/Person';
import Grid from '@mui/material/Unstable_Grid2';
import Button from '@mui/material/Button';

const OrderSkillAndCertificationsModal = ({ open, onClose, orderData }: any) => {
  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogContent>
        <Typography fontSize={16} pb={2} fontWeight={500}>
          Worker Skills
        </Typography>
        <Box mb={3}>
          <Box mt={1} display="flex" alignItems="center" p={2} border="1px solid #E5E2E1" borderRadius={1}>
            <Avatar src={orderData.worker.avatar || ''}>{!orderData.worker.avatar && <PersonIcon />}</Avatar>
            <Box ml={2}>
              <Typography variant="body1">{orderData.worker.name}</Typography>
              <Typography variant="body2" color="textSecondary">
                ID: {orderData.worker.id}
              </Typography>
            </Box>
          </Box>
        </Box>

        {orderData.sections.map((section: any, index: number) => (
          <Box key={index} mb={3}>
            <Grid container spacing={2} pb={1} columns={100}>
              <Grid xs={49}>
                <Typography variant="caption" color="textSecondary">
                  Site requirements
                </Typography>
              </Grid>
              <Grid xs={23}>
                <Typography pl={2} borderLeft="1px solid #E5E2E1" variant="caption" color="textSecondary">
                  Status
                </Typography>
              </Grid>
              <Grid xs={28}>
                <Typography pl={2} borderLeft="1px solid #E5E2E1" variant="caption" color="textSecondary">
                  Add to worker
                </Typography>
              </Grid>
            </Grid>

            {section.items.map((item: any, idx: number) => (
              <Grid
                container
                bgcolor={item.status === 'PRESENT' ? '#fff' : 'rgba(223, 20, 69, 0.08)'}
                p={1}
                key={idx}
                alignItems="center"
                borderBottom="1px solid #E5E2E1">
                <Grid xs={6}>
                  <Typography variant="body1">{item.name}</Typography>
                  <Typography fontSize={12} variant="body2" color="textSecondary">
                    {item.description}
                  </Typography>
                </Grid>
                <Grid xs={3}>
                  <Chip
                    color={item.status === 'PRESENT' ? 'success' : 'error'}
                    size="small"
                    label={item.status === 'PRESENT' ? 'Present' : 'Missing'}
                  />
                </Grid>
                <Grid xs={3}>
                  <Checkbox
                    disabled={item.status === 'PRESENT'}
                    checked={item.status === 'PRESENT' ? item.addToWorker : undefined}
                  />
                </Grid>
              </Grid>
            ))}
          </Box>
        ))}
      </DialogContent>
      <DialogActions>
        <Box display="flex" gap={2} p={1}>
          <Button onClick={onClose} color="primary">
            CLOSE
          </Button>
          <Button onClick={onClose} variant="contained" color="primary">
            SAVE CHANGES
          </Button>
        </Box>
      </DialogActions>
    </Dialog>
  );
};

export default OrderSkillAndCertificationsModal;
