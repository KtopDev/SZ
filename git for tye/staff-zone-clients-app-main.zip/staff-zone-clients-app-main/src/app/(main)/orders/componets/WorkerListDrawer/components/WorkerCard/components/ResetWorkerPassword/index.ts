import ResetWorkerPasswordModal from '@/app/(main)/orders/componets/WorkerListDrawer/components/WorkerCard/components/ResetWorkerPassword/ResetWorkerPasswordModal';

export default ResetWorkerPasswordModal;
