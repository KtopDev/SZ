import WorkerCard from '@/app/(main)/orders/componets/WorkerListDrawer/components/WorkerCard/WorkerCard';

export default WorkerCard;

