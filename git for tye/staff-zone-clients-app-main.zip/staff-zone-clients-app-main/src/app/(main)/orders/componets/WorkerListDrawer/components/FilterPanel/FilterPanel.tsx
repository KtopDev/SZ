import { Badge, Box, IconButton, TextField } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import Button from '@mui/material/Button';
import FilterAltIcon from '@mui/icons-material/FilterAlt';
import { useWatch } from 'react-hook-form';
import CancelIcon from '@mui/icons-material/Cancel';
import { useState } from 'react';

const FilterPanel = ({ openFilter, rhProps, filters }: any) => {
  const [inputValue, setInputValue] = useState('');
  const searchBy = useWatch({ control: rhProps.control, name: 'searchBy' });

  const handleCodeNameInputChange = (e: any) => {
    rhProps.debouncedSetValue('searchBy', e.target.value);
    setInputValue(e.target.value);
  };

  const handleClearInput = () => {
    rhProps.setValue('searchBy', '');
    setInputValue('');
  };

  return (
    <Box display="flex" gap={1} px={1}><TextField
      fullWidth
      value={inputValue}
      InputProps={{
        startAdornment: <SearchIcon />,
        endAdornment: searchBy ? (
          <IconButton onClick={handleClearInput}>
            <CancelIcon fontSize="small" />
          </IconButton>
        ) : (
          <Box px="20px" />
        ),
      }}
      label="Search"
      placeholder=" Search workers"
      variant="outlined"
      onChange={handleCodeNameInputChange}
    />
    <Badge
      badgeContent={Object.keys(filters).length > 0 ? Object.keys(filters).length : null}
      color="primary"
      overlap="circular"
      anchorOrigin={{
        vertical: 'top',
        horizontal: 'right',
      }}>
      <Button onClick={openFilter} variant="outlined" sx={{ paddingX: 1, minWidth: 0 }}>
        <FilterAltIcon />
      </Button>
    </Badge></Box>
  );
};

export default FilterPanel;
