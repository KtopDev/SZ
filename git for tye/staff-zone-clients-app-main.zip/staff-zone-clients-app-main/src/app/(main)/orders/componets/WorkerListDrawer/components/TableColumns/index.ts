import TableColumns from '@/app/(main)/orders/componets/WorkerListDrawer/components/TableColumns/TableColumns';

export default TableColumns;
