import OrderSkillAndCertificationsModal from '@/app/(main)/orders/componets/WorkerListDrawer/components/OrderSkillAndCertificationsModal/OrderSkillAndCertificationsModal';

export default OrderSkillAndCertificationsModal;
