import React from 'react';
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Typography,
} from '@mui/material';
import { useSendEmail } from '@/requests/api/authApi/authApi';
import LoadingButton from '@mui/lab/LoadingButton';

const ResetWorkerPasswordModal = ({ open, onClose, email }: any) => {
  const [sendEmail, { loading }] = useSendEmail();

  const submit = async () => {
    try {
      await sendEmail({ email, userType: 'WORKER' });
      onClose();
    } catch (e) {
      // Handle error
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth>
      <DialogTitle>Reset password</DialogTitle>
      <DialogContent>
        <DialogContentText mt={2}>Send a reset link to the email address of the worker</DialogContentText>
        <Box mt={1} p={1} bgcolor="#F3E8FF" borderRadius="4px">
          <Typography variant="body1" color="textPrimary">
            {email}
          </Typography>
        </Box>
      </DialogContent>
      <DialogActions>
        <Box display="flex" p={1} gap={1}>
          <Button onClick={onClose} color="primary">
            CANCEL
          </Button>
          <LoadingButton onClick={submit} loading={loading} variant="contained" color="primary">
            SEND RESET LINK
          </LoadingButton>
        </Box>
      </DialogActions>
    </Dialog>
  );
};

export default ResetWorkerPasswordModal;
