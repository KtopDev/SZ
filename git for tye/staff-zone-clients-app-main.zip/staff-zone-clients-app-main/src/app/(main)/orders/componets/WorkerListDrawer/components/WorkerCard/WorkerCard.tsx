import Grid from '@mui/material/Unstable_Grid2';
import DragIndicatorIcon from '@mui/icons-material/DragIndicator';
import { Avatar, Box, IconButton, Menu, MenuItem } from '@mui/material';
import Typography from '@mui/material/Typography';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { useState } from 'react';
import ResetWorkerPasswordModal from '@/app/(main)/orders/componets/WorkerListDrawer/components/WorkerCard/components/ResetWorkerPassword/ResetWorkerPasswordModal';
import dayjs from 'dayjs';
import ConstructionIcon from '@mui/icons-material/Construction';
import { useRouter } from 'next/navigation';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorIcon from '@mui/icons-material/Error';
import OrderSkillAndCertificationsModal from '@/app/(main)/orders/componets/WorkerListDrawer/components/OrderSkillAndCertificationsModal';
import DisciplinaryBaseForm from '../../../DisciplinaryForm/DisciplinaryBaseForm';
import { useSnackbar } from '@/context/SnackbarContext';
import { useCreateDisciplinaryForm } from '@/requests/api/disciplinaryFormApi/disciplinaryFormApi';

const workerCardStyles = (isBlurred: boolean, isRedBg: boolean) => ({
  padding: '8px',
  backgroundColor: isRedBg ? 'rgba(223, 20, 69, 0.08)' : '#fff',
  boxShadow: '0px 2px 5px rgba(0, 0, 0, 0.1)',
  marginBottom: '4px',
  border: '1px solid #e0e0e0',
  opacity: isBlurred ? 0.5 : 1,
  filter: isBlurred ? 'blur(0.3px)' : 'none',
  transition: 'opacity 0.3s, filter 0.3s',
});

const WorkerCard = ({ worker, jobToSuggestWorkers = true }: any) => {
  const [showChangePassword, setShowChangePassword] = useState(false);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [showSkillsModal, setShowSkillsModal] = useState(false);
  const [orderData, setOrderData] = useState(orderDataAllNotPresent);
  const [isOpenDisciplinary, setIsOpenDisciplinary] = useState<boolean>(false);
  const { setMessage } = useSnackbar();
  const [createDisciplinaryForm] = useCreateDisciplinaryForm();

  const onSubmit = async (formValues: any, setError: any, reset: any) => {
    try {
      setIsOpenDisciplinary(false);
      reset();

      await createDisciplinaryForm({
        workerId: worker.worker_id,
        payload: {
          orderId: formValues.order,
          warningType: formValues.typeOfWarning,
          formDate: formValues.dateOfIncident,
          infraction: formValues.description,
          expectedBehavior: formValues.expectedResults,
        },
      });

      setMessage('Disciplinary order sent successfully');
    } catch (e: any) {
      if (e?.response?.status === 400) {
        e.response.data.details.map((err: any) => {
          setError(err.field, { message: err.message });
        });
      }
    }
  };

  const open = Boolean(anchorEl);
  const router = useRouter();
  const handleClick = (event: any) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleShowSkills = () => {
    setOrderData(worker.skills?.length === 5 ? orderDataAllPresent : orderDataAllNotPresent);
    setShowSkillsModal(true);
  };

  return (
    <>
      <Grid
        container
        columns={100}
        mx={1}
        borderRadius={1}
        alignItems="center"
        sx={{
          ...workerCardStyles(false, false),
        }}>
        <Grid xs={39}>
          <Box display="flex" gap={1} alignItems="center">
            <DragIndicatorIcon />
            <Avatar />

            <Box>
              <Typography fontSize={12} variant="subtitle1" fontWeight="bold">
                {worker.firstName} {worker.lastName}
              </Typography>
              <Typography fontSize={12} variant="body2" color="textSecondary">
                ID: {worker.workerCode}
              </Typography>
            </Box>
          </Box>
        </Grid>

        <Grid xs={16} display="flex" alignItems="center">
          {jobToSuggestWorkers ? (
            <Box display="flex" alignItems="center" onClick={handleShowSkills}>
              {worker.skills?.length === 5 ? (
                <CheckCircleIcon sx={{ color: '#4caf50', marginRight: '4px' }} />
              ) : (
                <ErrorIcon sx={{ color: '#FAAF00', marginRight: '4px' }} />
              )}
              <Box>
                <Typography color="green" fontSize={11}>
                  {worker.skills?.length === 5 ? 'Qualified' : 'Unqualified'}
                </Typography>
                <Typography fontSize={12}>5/{worker.skills?.length || 0} skills</Typography>
              </Box>
            </Box>
          ) : (
            <>
              <ConstructionIcon sx={{ color: '#1976d2', marginRight: '4px' }} />
              <Typography fontSize={12}>{worker.skills?.length || 0} skills</Typography>
            </>
          )}
        </Grid>

        <Grid xs={13} display="flex" alignItems="center">
          <Typography fontSize={12}>{dayjs(worker.lastDayWorked).format('MM/DD/YYYY')}</Typography>
        </Grid>

        <Grid xs={11} display="flex" alignItems="center">
          <Typography fontSize={12}>{worker.hoursWorkedCurrentWeek}</Typography>
        </Grid>

        <Grid xs={11}>
          <Typography fontSize={12}>{worker.rating}</Typography>
        </Grid>

        <Grid xs={5}>
          <Typography fontSize={12}>{worker.warnings > 0 ? worker.warnings : '---'}</Typography>
        </Grid>

        <Grid xs={5}>
          <IconButton
            onClick={handleClick}
            id="basic-button"
            aria-haspopup="true"
            aria-controls={open ? 'basic-menu' : undefined}
            aria-expanded={open ? 'true' : undefined}>
            <MoreVertIcon />
          </IconButton>
          <Menu
            id="basic-menu"
            anchorEl={anchorEl}
            open={open}
            onClose={handleClose}
            MenuListProps={{
              'aria-labelledby': 'basic-button',
            }}>
            <MenuItem onClick={() => router.push(`/workers/${worker.worker_id}/edit-worker`)}>Edit worker</MenuItem>
            <MenuItem onClick={() => setShowChangePassword(true)}>Reset password</MenuItem>
            <MenuItem
              onClick={() => {
                handleClose();
                setIsOpenDisciplinary(true);
              }}>
              Send disciplinary form
            </MenuItem>
            <MenuItem onClick={handleClose}>
              <Typography color="error">Do not repeat</Typography>
            </MenuItem>
          </Menu>
        </Grid>
        <ResetWorkerPasswordModal
          email={worker.email}
          open={showChangePassword}
          onClose={() => setShowChangePassword(false)}
        />
        <OrderSkillAndCertificationsModal
          open={showSkillsModal}
          onClose={() => setShowSkillsModal(false)}
          orderData={orderData}
        />
      </Grid>
      <DisciplinaryBaseForm
        open={isOpenDisciplinary}
        handleClose={() => setIsOpenDisciplinary(false)}
        onSubmit={onSubmit}
        workerName={worker.firstName + ' ' + worker.lastName}
        lastActive={worker.last_day_worked}
        workerCode={worker.workerCode}
        workerId={worker.workerId}
      />
    </>
  );
};

export default WorkerCard;

const orderDataAllNotPresent = {
  orderId: '123457',
  title: 'Warehouse Construction',
  project: 'Harvest Moon',
  worker: {
    avatar: '', // Optional: image URL of the worker
    name: 'Han Solo',
    id: '9876543',
  },
  sections: [
    {
      title: 'Site requirements',
      items: [
        {
          name: 'Safety Gear',
          description: 'Safety helmet and vest required',
          status: 'NOT_PRESENT',
          addToWorker: false,
        },
        {
          name: 'First Aid Kit',
          description: 'Must have a basic first aid kit available',
          status: 'PRESENT',
          addToWorker: true,
        },
      ],
    },
    {
      title: 'Skill',
      items: [
        {
          name: 'Carpentry',
          description: 'Skilled in woodwork and frame building',
          status: 'NOT_PRESENT',
          addToWorker: false,
        },
        {
          name: 'Electrical Wiring',
          description: 'Ability to handle electrical components safely',
          status: 'NOT_PRESENT',
          addToWorker: false,
        },
      ],
    },
    {
      title: 'Certification',
      items: [
        {
          name: 'CPR Certification',
          description: 'Certification in basic CPR',
          status: 'PRESENT',
          addToWorker: true,
        },
        {
          name: 'Safety Training',
          description: 'Completed safety training for construction sites',
          status: 'NOT_PRESENT',
          addToWorker: false,
        },
      ],
    },
  ],
};

const orderDataAllPresent = {
  orderId: '123456',
  title: 'New farm building',
  project: 'Stardew Valley',
  worker: {
    avatar: '', // Optional: image URL of the worker
    name: 'Luke Skywalker',
    id: '1234890',
  },
  sections: [
    {
      title: 'Site requirements',
      items: [
        {
          name: 'Safety Gear',
          description: 'Safety helmet and vest required',
          status: 'PRESENT',
          addToWorker: true,
        },
        {
          name: 'First Aid Kit',
          description: 'Must have a basic first aid kit available',
          status: 'PRESENT',
          addToWorker: true,
        },
      ],
    },
    {
      title: 'Skill',
      items: [
        {
          name: 'Carpentry',
          description: 'Skilled in woodwork and frame building',
          status: 'PRESENT',
          addToWorker: true,
        },
        {
          name: 'Electrical Wiring',
          description: 'Ability to handle electrical components safely',
          status: 'PRESENT',
          addToWorker: true,
        },
      ],
    },
    {
      title: 'Certification',
      items: [
        {
          name: 'CPR Certification',
          description: 'Certification in basic CPR',
          status: 'PRESENT',
          addToWorker: true,
        },
        {
          name: 'Safety Training',
          description: 'Completed safety training for construction sites',
          status: 'PRESENT',
          addToWorker: true,
        },
      ],
    },
  ],
};
