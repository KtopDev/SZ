export interface IWorkerListFilter {
  searchBy: string;
  branchId: string;
  status: string;
  isCheckedIn: boolean;
  warningType: string;
  vehicleType: string;
  skills: string[];
  certifications: string[];
  lastPay: string;
}
