import Grid from '@mui/material/Unstable_Grid2';
import Box from '@mui/material/Box';
import { grey } from '@mui/material/colors';
import Typography from '@mui/material/Typography';

const Legend = () => {
  return (
    <Grid container spacing={1} paddingX="16px" pt="6px" alignItems="center" borderBottom="0.4px solid #cecece" py={1}>
      <Grid display="flex" alignItems="center">
        <Box
          sx={{
            height: '10px',
            width: '10px',
            backgroundColor: grey[100],
            borderRadius: '50%',
            marginRight: '8px',
            border: '1px solid #cecece',
          }}
        />
        <Typography fontSize={14}>Worker</Typography>
      </Grid>

      <Grid display="flex" alignItems="center">
        <Box
          sx={{
            height: '10px',
            width: '10px',
            backgroundColor: '#149D8480',
            borderRadius: '50%',
            marginRight: '8px',
          }}
        />
        <Typography fontSize={14}>Suggested</Typography>
      </Grid>

      <Grid display="flex" alignItems="center">
        <Box
          sx={{
            height: '10px',
            width: '10px',
            backgroundColor: '#DF144580',
            borderRadius: '50%',
            marginRight: '8px',
          }}
        />
        <Typography fontSize={14}>Has Blocker</Typography>
      </Grid>
    </Grid>
  );
};

export default Legend;
