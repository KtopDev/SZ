'use client';

import React from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import { Button, Typography } from '@mui/material';
import { useRouter } from 'next/navigation';
import WorkerListDrawer from '@/app/(main)/orders/componets/WorkerListDrawer';
import Link from '@/components/shared/styled/Link';

const OrdersPage = () => {
  const router = useRouter();

  return (
    <>
      <Grid display="flex" width="100%" justifyContent="space-between" p={2} pr={9}>
        <Typography>Orders</Typography>
        <Button onClick={() => router.push('/orders/create-order')} variant="contained">
          CREATE
        </Button>
      </Grid>
      <Link href={'orders/assign-workers'}>
        <Button>Go to Assign workers</Button>
      </Link>
      <WorkerListDrawer />
    </>
  );
};

export default OrdersPage;
