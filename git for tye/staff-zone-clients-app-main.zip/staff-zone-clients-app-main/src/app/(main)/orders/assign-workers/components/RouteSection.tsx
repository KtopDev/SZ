'use client';
import Grid from '@mui/material/Unstable_Grid2';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import RouteLabor from './RouteLabor';
import { TempDispatcher } from '@/types/dto/TempDispatcher';

type Props = {
  dispatch: TempDispatcher;
  refetchDispatcher: () => void;
};

const RouteSection = ({ dispatch, refetchDispatcher }: Props) => {
  return (
    <Box sx={{ padding: 2 }}>
      <Typography variant="h5">Assign workers to your order</Typography>
      <Typography variant="body2">
        Click on the Workers to see the list of workers available and drag them to the jobs assign them on this order
      </Typography>
      <br />
      <Grid
        xs={6}
        flexGrow={1}
        height="100%"
        borderRight="0.4px solid #cecece"
        mr="3px"
        sx={{ padding: 1, border: '1px solid #0000003B', borderRadius: 1 }}>
        <Grid
          display="flex"
          paddingTop={2}
          paddingX={1}
          paddingBottom={1}
          alignItems="center"
          gap={1}
          sx={{ border: '1px solid #0000003B', borderRadius: 1 }}>
          <Typography fontSize={12}>Overall Workers Needed</Typography>
          <Box display="flex" alignItems="center" sx={{ marginLeft: 3 }}>
            <Box
              sx={{
                backgroundColor: '#757575',
                borderRadius: '50%',
                height: '15px',
                width: '15px',
                alignItems: 'center',
                fontSize: '11px',
                color: 'white',
                textAlign: 'center',
                marginRight: '4px',
              }}>
              4
            </Box>
            <Typography fontSize={13} color="#757575">
              General labor
            </Typography>
          </Box>
          <Box display="flex" alignItems="center" sx={{ marginLeft: 3 }}>
            <Box
              sx={{
                backgroundColor: '#757575',
                borderRadius: '50%',
                height: '15px',
                width: '15px',
                alignItems: 'center',
                fontSize: '11px',
                color: 'white',
                textAlign: 'center',
                marginRight: '4px',
              }}>
              0
            </Box>
            <Typography fontSize={13} color="#757575">
              Advanced
            </Typography>
          </Box>
          <Box display="flex" alignItems="center" sx={{ marginLeft: 3 }}>
            <Box
              sx={{
                backgroundColor: '#757575',
                borderRadius: '50%',
                height: '15px',
                width: '15px',
                alignItems: 'center',
                fontSize: '11px',
                color: 'white',
                textAlign: 'center',
                marginRight: '4px',
              }}>
              0
            </Box>
            <Typography fontSize={13} color="#757575">
              Semi skilled
            </Typography>
          </Box>
          <Box display="flex" alignItems="center" sx={{ marginLeft: 3 }}>
            <Box
              sx={{
                backgroundColor: '#757575',
                borderRadius: '50%',
                height: '15px',
                width: '15px',
                alignItems: 'center',
                fontSize: '11px',
                color: 'white',
                textAlign: 'center',
                marginRight: '4px',
              }}>
              0
            </Box>
            <Typography fontSize={13} color="#757575">
              Skilled
            </Typography>
          </Box>
        </Grid>

        <Grid padding="4px">
          <RouteLabor dispatch={dispatch} refetchDispatcher={refetchDispatcher} />
        </Grid>
      </Grid>
    </Box>
  );
};

export default RouteSection;
