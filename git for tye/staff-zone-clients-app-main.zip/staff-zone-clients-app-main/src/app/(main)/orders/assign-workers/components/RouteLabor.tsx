import React, { useState } from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Chip from '@mui/material/Chip';
import { Button } from '@mui/material';
import FilterAltIcon from '@mui/icons-material/FilterAlt';
import AddIcon from '@mui/icons-material/Add';
import ConfirmationModal from '@/components/shared/Modal/ConfirmationModal';
import WorkerSlot from './WorkerSlot';
import { useSnackbar } from '@/context/SnackbarContext';
import { TempDispatcher } from '@/types/dto/TempDispatcher';
import { bucketDetailsId2, useIncrementSlot, useReduceSlot } from '@/requests/api/dispatcherApi/dispatcherApi';

type Props = { dispatch: TempDispatcher; refetchDispatcher: () => void };

const RouteLabor = ({ dispatch, refetchDispatcher }: Props) => {
  const { setMessage } = useSnackbar();
  const isDragging = false;
  const [showModal, setShowModal] = useState(false);
  const [incrementSlot] = useIncrementSlot();
  const [reduceSlot] = useReduceSlot();

  const callIncrementSlot = async () => {
    await incrementSlot(bucketDetailsId2);
  };

  const callReduceSlot = async () => {
    await reduceSlot(bucketDetailsId2);
  };

  return (
    <>
      <Grid container columns={16} border="1px solid #0000003B" borderRadius="4px">
        <Grid xs={16} sx={{ backgroundColor: '#EEEEEE' }}>
          <Grid xs={16} display="flex" justifyContent="space-between" alignItems="center" paddingX={1} paddingTop={1}>
            <Box display="flex" alignItems="center" gap={1}>
              <Typography fontSize={14} fontWeight={600} color="#000000DE">
                General labour - Cleaning
              </Typography>
              <Chip size="small" label="2/3" variant="outlined" sx={{ color: '#424242' }} />
              <Chip size="small" label="8h" variant="outlined" sx={{ color: '#424242' }} />
            </Box>
            <Box display="flex" alignItems="center" gap={1}>
              <Button variant="text">
                <FilterAltIcon htmlColor="#149D84" />
                <Typography pl={1} fontSize={14} fontWeight={600} color="#149D84">
                  FIND WORKERS
                </Typography>
              </Button>
            </Box>
          </Grid>
          <Grid xs={16} display="flex" padding={1} spacing={1} gap={1}>
            <Typography fontSize={12} color="#00000099">
              Skills: weight lifting, painting, programming, cleaning
            </Typography>
            <Typography fontSize={12} color="#00000099">
              Certifications needed: Martial arts golden medal
            </Typography>
          </Grid>
        </Grid>
        <Grid xs={16} paddingX={1} paddingY="12px">
          <Grid container columns={16}>
            <Grid xs={1}></Grid>
            <Grid xs={4}>
              <Typography fontSize={12} color="#00000099">
                Worker
              </Typography>
            </Grid>
            <Grid xs={2}>
              <Typography fontSize={12} color="#00000099">
                Pay
              </Typography>
            </Grid>
            <Grid xs={2}>
              <Typography fontSize={12} color="#00000099">
                Trans
              </Typography>
            </Grid>
            <Grid xs={7}>
              <Typography fontSize={12} color="#00000099">
                Site requirements
              </Typography>
            </Grid>
          </Grid>

          {Array.from({ length: dispatch.additionalSlots }).map((_, idx) => (
            <WorkerSlot
              key={idx}
              isDragging={isDragging}
              onClose={async () => {
                await callReduceSlot();
                refetchDispatcher();
                setMessage('Additional slots reduced successfully');
              }}
            />
          ))}
          <Grid
            container
            columns={16}
            alignItems="center"
            mt={1}
            padding={2}
            textAlign="center"
            justifyContent="center">
            <Button onClick={() => setShowModal(true)}>
              <AddIcon />
              <Typography color="#6F3AE0" fontSize={13} fontWeight={600}>
                ADD ADDITIONAL SLOT
              </Typography>
            </Button>
          </Grid>
        </Grid>
      </Grid>

      <ConfirmationModal
        title="Adding an additional slot"
        description="This order has exceeded the number of worker slots; do you wish to override the number of workers to add additional ones?"
        confirmationButtonText="ADD ADDITIONAL SLOT TO ORDER"
        showModal={showModal}
        closeModal={() => setShowModal(false)}
        isLoading={false}
        width={500}
        callSubmit={async () => {
          await callIncrementSlot();
          refetchDispatcher();
          setMessage('Additional slots incremented successfully');
        }}
      />
    </>
  );
};

export default RouteLabor;
