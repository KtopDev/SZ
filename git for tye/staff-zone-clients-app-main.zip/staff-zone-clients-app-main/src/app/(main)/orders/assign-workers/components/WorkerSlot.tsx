import React, { useState } from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import { Typography, IconButton } from '@mui/material';
import CancelIcon from '@mui/icons-material/Cancel';

type Props = {
  isDragging: boolean;
  onClose: () => void;
};

const WorkerSlot = ({ isDragging, onClose }: Props) => {
  const [hover, setHover] = useState(false);

  return (
    <Grid
      container
      columns={16}
      border={isDragging ? '1px dashed rgba(20, 157, 132, 0.5)' : '1px dashed #6F3AE080'}
      alignItems="center"
      mt={1}
      padding={2}
      sx={{ backgroundColor: isDragging ? 'rgba(20, 157, 132, 0.08)' : '#6F3AE014', position: 'relative' }}
      textAlign="center"
      justifyContent="center"
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}>
      <Typography color={isDragging ? 'rgba(20, 157, 132, 1)' : '#6F3AE0'} fontSize={13} fontWeight={600}>
        {isDragging ? 'DROP WORKER HERE' : 'DRAG WORKERS HERE TO ASSIGN THEM TO THIS JOB'}

        {hover && (
          <IconButton
            onClick={onClose}
            sx={{
              color: '#7b1fa2',
              position: 'absolute',
              top: 4,
              right: 4,
            }}>
            <CancelIcon />
          </IconButton>
        )}
      </Typography>
    </Grid>
  );
};

export default WorkerSlot;
