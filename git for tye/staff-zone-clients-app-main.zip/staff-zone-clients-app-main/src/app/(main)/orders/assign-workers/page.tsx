'use client';

import React from 'react';
import RouteSection from './components/RouteSection';
import { bucketDetailsId2, useGetTempDispatcher } from '@/requests/api/dispatcherApi/dispatcherApi';

const OrdersPage = () => {
  const { data: tempDispatcher, refetch } = useGetTempDispatcher(bucketDetailsId2);

  return (
    <>
      Assign workers
      <RouteSection dispatch={tempDispatcher} refetchDispatcher={refetch} />
    </>
  );
};

export default OrdersPage;
