import React from 'react'
import Grid from '@mui/material/Unstable_Grid2';
import { Box } from '@mui/material';
import Typography from '@mui/material/Typography';

const legendStyle = {
  width: 14,
  height: 14,
  borderRadius: '50%',
  marginRight: '8px',
}


const OrdersFormLegend = () => {
  return (
    <Grid container display="flex" spacing={3} columnGap={3} paddingLeft={1}>
      <Box display="flex" alignItems="center">
        <Box sx={{...legendStyle, border: '1px solid #0000003B'}}/>
        <Typography fontSize={12}>
          Will NOT be included for this order
        </Typography>
      </Box>
      <Box display="flex" alignItems="center">
        <Box sx={{...legendStyle, backgroundColor: '#149D8480'}}/>
        <Typography fontSize={12}>
          Will be included
        </Typography>
      </Box>
      <Box display="flex" alignItems="center">
        <Box sx={{...legendStyle, backgroundColor: '#DF144580'}}/>
        <Typography fontSize={12}>
          Information is missing
        </Typography>
      </Box>
    </Grid>
  )
}

export default OrdersFormLegend
