'use client';

import React, { useCallback, useEffect, useMemo, useState } from 'react';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Unstable_Grid2';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import Table from '@/components/shared/Table/Table';
import { Box, Button, Stack } from '@mui/material';
import { LoadingButton } from '@mui/lab';
import { useForm, useWatch } from 'react-hook-form';
import RHDateTimePicker from '@/components/shared/Form/RHDateTimePicker';
import OrdersFormLegend from './OrdersFormLegend';
import { orderFormColumns, orderFormColumnsWithHours } from './OrdersFormColumns';
import RHSelect from '@/components/shared/Form/RHSelect';
import RHSwitchGroup from '@/components/shared/Form/RHSwitchGroup';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
import UserClosure from '@/utils/UserClosure';
import { useGetProjectsDropdown, useGetProjectWorkerBasedBillingList } from '@/requests/api/projectApi/projectApi';
import dayjs from 'dayjs';


const customDateFormat = 'DD / MM / YYYY hh:mm A';


const OrdersForm = ({ orderData, submit, loading, isUpdate = false }: any) => {

  const clientId = UserClosure.getUser()?.auth_user_details.user.client_id || ''
  const {data, loading: loadingProjects} = useGetProjectsDropdown(clientId)

  const [localWbb, setLocalWbb] = useState<any>([]);
  const [initialValues, setInitialValues] = useState({});

  const {
    control,
    watch,
    formState: { errors, isValid },
    handleSubmit,
    getValues,
  } = useForm<any>({
    defaultValues: {
      ...initialValues,
      onSiteProject: false
    },
    mode: 'onBlur',
  });

  const onSiteProject = useWatch({ control, name: 'onSiteProject' });

  const projectId = useWatch({ control, name: 'project' });

  const filter = React.useMemo(
    () =>
      ({
        projectId: projectId,
        payload: {
          size: 1000,
          page: 1,
          searchBy: '',
          status: 'ACTIVE',
          sort: 'description,asc',
        },
      }) as any,
    [projectId]
  );

  const { data: wbbData } = useGetProjectWorkerBasedBillingList(filter);

  const processData = useCallback((): void => {
    if (wbbData.content) {
      const skillTiersMap: Record<string, boolean> = {};

      wbbData?.content.forEach(({ skill_tier }: { skill_tier: string }) => {
        if (skill_tier) {
          skillTiersMap[skill_tier] = true;
        }
      });

      const tableKeys = Object.keys(skillTiersMap);

      const newLocalState = tableKeys?.map((skill_tier) => {
        const tableKey = `${skill_tier}`;
        return {
          id: skill_tier,
          tableName: skill_tier
            .toLowerCase()
            .replace(/_/g, ' ')
            .replace(/\b\w/g, (char) => char.toUpperCase()),
          [tableKey]: wbbData?.content
            .filter((item: any) => item.skill_tier === skill_tier)
            .map((item: any) => {
              const itemInOrder = orderData?.projectOrderDetails?.find(
                ({ projectWorkerBasedBillingId }: { projectWorkerBasedBillingId: string }) =>
                  projectWorkerBasedBillingId === item.project_worker_based_billing_id
              );
              return {
                id: item.project_worker_based_billing_id,
                name: item.description,
                selected: !!itemInOrder,
                input1: itemInOrder ? itemInOrder.numberOfWorkers : '',
                input2: itemInOrder ? itemInOrder.hoursNeeded : '',
              };
            }),
        };
      });

      const intialRowState = newLocalState.reduce((acc: any, item: any) => {
        // Set the value from another property, e.g., description
        acc[item.id] = item[item.id];

        return acc;
      }, {});

      if (isUpdate) {
        setInitialValues({ ...intialRowState, eventDateTime: dayjs(orderData.orderStartTs).format(customDateFormat), onSiteProject: false });
      }

      setLocalWbb(newLocalState);
    }
  }, [wbbData, orderData, isUpdate]);

  useEffect(() => {
    processData();
  }, [wbbData, orderData, processData]);

  const formValues = watch();

  const isFormValid = useMemo(() => {
    return Object.keys(formValues).every((tableName) => {
      const rows = formValues[tableName];
      if (typeof rows === 'string') {
        return true;
      }
      if (typeof rows === 'boolean') {
        return true;
      }

      return rows?.every((row: any) => {
        if (row.selected && !onSiteProject) {
          return row.input1 && row.input2 && row.input1 > 0 && row.input2 > 0;
        }
        if (row.selected) {
          return row.input1 && row.input1 > 0;
        }
        return true;
      });
    });
  }, [formValues, onSiteProject]);

  const getRowBackgroundColor = (row: any, tableName: string) => {
    const isSelected = watch(`${tableName}.${row.index}.selected`);
    const input1 = watch(`${tableName}.${row.index}.input1`);

    if (isSelected && (!input1 || input1 === '' || input1 <= 0)) {
      return '#f8d7da';
    } else if (isSelected && input1) {
      return '#d4edda';
    }
    return 'inherit';
  };

  const getRowBackgroundColorWithHours = (row: any, tableName: string) => {
    const isSelected = watch(`${tableName}.${row.index}.selected`);
    const input1 = watch(`${tableName}.${row.index}.input1`);
    const input2 = watch(`${tableName}.${row.index}.input2`);

    if (isSelected && (!input1 || !input2 || input1 === '' || input2 === '' || input1 <= 0 || input2 <= 0)) {
      return '#f8d7da';
    } else if (isSelected && (input2 < 4 || input2 > 8)) {
      return '#FAAF0014';
    } else if (isSelected && input1 && input2) {
      return '#d4edda';
    }
    return 'inherit';
  };

  const onSubmit = async (formValues: any): Promise<void> => {
    submit(formValues);
  };

  const isProjectSelected = watch('project');

  return (
    <Box paddingX="24px">
      <Typography fontSize={24} fontWeight={500} mt={3}>
        {isUpdate ? 'Edit' : 'Create'} order
      </Typography>

      <Grid container xs={12} sm={12} mt={4} mb={1} spacing={3} display="flex">
        <Grid xs={6}>
          <RHSelect<any>
            label="Project name"
            propName="project"
            options={data}
            isLoading={loadingProjects}
            rhProps={{ errors, control, getValues, required: true }}
          />
        </Grid>
        <Grid xs={6} spacing={4} paddingTop="19px">
          <RHDateTimePicker
            label="Event Date and Time"
            propName="eventDateTime"
            rhProps={{ control, errors, required: true }}
            fullWidth
          />
        </Grid>
      </Grid>
      <Grid mb={3}>
        <RHSwitchGroup<any>
          labels={['On site project']}
          propNames={['onSiteProject']}
          rhProps={{ errors, control, required: false }}
        />
      </Grid>

      <Grid container xs={12} mb={2} display="block">
        <Typography fontSize={20}>Workers needed</Typography>
        <Typography fontSize={16}>
          {isProjectSelected
            ? 'Select the jobs you’ll be requiring for this order. After selecting you should enter the number of workers needed.'
            : 'Please select a project to load the skill list linked to the rate agreements signed.'}
        </Typography>
      </Grid>

      {isProjectSelected && (
        <>
          <Grid padding={1}>
            <OrdersFormLegend />
          </Grid>
          <Grid>
            {!isFormValid && (
              <Grid display="flex" border="1px solid #DF1445" borderRadius={1} padding={2} alignItems="center" mt={2}>
                <ErrorOutlineIcon htmlColor="#DF1445" />
                <Typography fontSize={14} color="#00000099" ml="12px">
                  Please complete all the fields to continue. If you want to request workers for any of the skills, you
                  must also add the number of hours expected to be completed by each worker.
                </Typography>
              </Grid>
            )}
          </Grid>

          {localWbb.map((table: any) => (
            <Grid paddingY={2} key={table.id}>
              <Typography fontSize={16} fontWeight={600}>
                {table.tableName}
              </Typography>
              <Table
                mrtProps={{
                  layoutMode: 'grid-no-grow',
                  data: table[table.id],
                  columns: onSiteProject ? orderFormColumns(table.id, control, watch) : orderFormColumnsWithHours(table.id, control, watch),
                  enableRowActions: false,
                  positionPagination: 'none',
                  enablePagination: false,
                  renderTopToolbar: false,
                  muiTableBodyRowProps: ({ row }) => ({
                    sx: {
                      borderBottom: '1px solid #e0e0e0',
                      backgroundColor: onSiteProject ? getRowBackgroundColor(row, table.id) : getRowBackgroundColorWithHours(row, table.id),
                    },
                  }),
                }}
                rowCount={table[table.id]?.length}
              />
            </Grid>
          ))}
        </>
      )}

      <Stack spacing={2} direction="row" sx={{ display: 'flex', justifyContent: 'flex-end' }} mt={2} padding={3}>
        <Button variant="text" onClick={() => {}}>
          CANCEL
        </Button>
        <LoadingButton
          variant="contained"
          color="primary"
          disabled={!isValid || !isFormValid}
          loading={loading}
          onClick={handleSubmit((formValues) => onSubmit(formValues))}
          endIcon={<ArrowForwardIcon />}>
          CONTINUE
        </LoadingButton>
      </Stack>
    </Box>
  );
};

export default OrdersForm;
