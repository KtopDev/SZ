import { Controller } from 'react-hook-form';
import Typography from '@mui/material/Typography';
import { Checkbox, TextField, Box } from '@mui/material';
import OrdersFormRowMessage, { OrderRowWarning } from './OrdersFormRowMessage';


const getRowMessage = (row: any, tableName: string, watch: any) => {
  const isSelected = watch(`${tableName}.${row.index}.selected`);
  const input1 = watch(`${tableName}.${row.index}.input1`);

  if (isSelected && (!input1 || input1 === '' || input1 <= 0 )) {
    return <OrdersFormRowMessage warning={OrderRowWarning.ERROR} />;
  } else if (isSelected && input1) {
    return <OrdersFormRowMessage warning={OrderRowWarning.SUCCESS} />;
  }
  return <></>;
};

const getRowMessageWithHours = (row: any, tableName: string, watch: any) => {
  const isSelected = watch(`${tableName}.${row.index}.selected`);
  const input1 = watch(`${tableName}.${row.index}.input1`);
  const input2 = watch(`${tableName}.${row.index}.input2`);

  if (isSelected && (!input1 || !input2 || input1 === '' || input2 === '' || input1 <= 0 || input2 <= 0)) {
    return <OrdersFormRowMessage warning={OrderRowWarning.ERROR} hoursNeeded/>;
  } else if (isSelected && input2 < 4) {
    return <OrdersFormRowMessage warning={OrderRowWarning.MIN_HOUR} />;
  } else if (isSelected && input2 > 8) {
    return <OrdersFormRowMessage warning={OrderRowWarning.MAX_HOUR} />;
  } else if (isSelected && input1 && input2) {
    return <OrdersFormRowMessage warning={OrderRowWarning.SUCCESS} />;
  }
  return <></>;
};

export const orderFormColumns = (tableName: string, control: any, watch: any) => [
  {
    accessorKey: 'selected',
    enableSorting: false,
    size: 60,
    header: '',
    Cell: ({ row }: any) => (
      <>
        <Controller
          name={`${tableName}.${row.index}.selected`}
          control={control}
          render={({ field }) => (
            <Checkbox {...field} checked={!!field.value} inputProps={{ 'aria-label': 'Select Row' }} />
          )}
        />
        <Controller
          name={`${tableName}.${row.index}.id`}
          control={control}
          defaultValue={row.original.id} // Set the default value here
          render={({ field }) => <input {...field} type="hidden" />}
        />
      </>
    ),
  },
  {
    accessorKey: 'name', // Add a column for the name
    header: 'Job description',
    grow: 1000,
    enableSorting: false,
    Cell: ({ row }: any) => {
      return (
        <Box>
          <Typography padding="16px 0">{row.original.name}</Typography>
          {getRowMessage(row, tableName, watch)}
        </Box>
      );
    },
  },
  {
    accessorKey: 'input1',
    header: 'Number of workers',
    enableSorting: false,
    size: 200,
    Cell: ({ row }: any) => {
      return (
        <Controller
          name={`${tableName}.${row.index}.input1`}
          control={control}
          rules={{
            required: watch(`${tableName}.${row.index}.selected`),
            min: watch(`${tableName}.${row.index}.selected`) ? 0 : undefined,
            validate: (value) => !watch(`${tableName}.${row.index}.selected`) || value !== '' || '',
          }}
          render={({ field }) => (
            <>
              <TextField
                {...field}
                type="number"
                disabled={!watch(`${tableName}.${row.index}.selected`)}
                error={watch(`${tableName}.${row.index}.selected`) && (field.value === '' || field.value <= 0)}
                helperText={
                  watch(`${tableName}.${row.index}.selected`) && (field.value === '' || field.value <= 0) ? '' : ''
                }
              />
            </>
          )}
        />
      );
    },
  },
];


export const orderFormColumnsWithHours = (tableName: string, control: any, watch: any) => [
  {
    accessorKey: 'selected',
    enableSorting: false,
    size: 60,
    header: '',
    Cell: ({ row }: any) => (
      <>
        <Controller
          name={`${tableName}.${row.index}.selected`}
          control={control}
          render={({ field }) => (
            <Checkbox {...field} checked={!!field.value} inputProps={{ 'aria-label': 'Select Row' }} />
          )}
        />
        <Controller
          name={`${tableName}.${row.index}.id`}
          control={control}
          defaultValue={row.original.id} // Set the default value here
          render={({ field }) => <input {...field} type="hidden" />}
        />
      </>
    ),
  },
  {
    accessorKey: 'name', // Add a column for the name
    header: 'Job description',
    grow: 1000,
    enableSorting: false,
    Cell: ({ row }: any) => {
      return (
        <Box>
          <Typography padding="16px 0">{row.original.name}</Typography>
          {getRowMessageWithHours(row, tableName, watch)}
        </Box>
      );
    },
  },
  {
    accessorKey: 'input1',
    header: 'Number of workers',
    enableSorting: false,
    size: 200,
    Cell: ({ row }: any) => {
      return (
        <Controller
          name={`${tableName}.${row.index}.input1`}
          control={control}
          rules={{
            required: watch(`${tableName}.${row.index}.selected`),
            min: watch(`${tableName}.${row.index}.selected`) ? 0 : undefined,
            validate: (value) => !watch(`${tableName}.${row.index}.selected`) || value !== '' || '',
          }}
          render={({ field }) => (
            <>
              <TextField
                {...field}
                type="number"
                disabled={!watch(`${tableName}.${row.index}.selected`)}
                error={watch(`${tableName}.${row.index}.selected`) && (field.value === '' || field.value <= 0)}
                helperText={
                  watch(`${tableName}.${row.index}.selected`) && (field.value === '' || field.value <= 0) ? '' : ''
                }
              />
            </>
          )}
        />
      );
    },
  },
  {
    accessorKey: 'input2',
    header: 'Hours needed for each',
    enableSorting: false,
    size: 200,
    Cell: ({ row }: any) => (
      <Controller
        name={`${tableName}.${row.index}.input2`}
        control={control}
        rules={{
          required: watch(`${tableName}.${row.index}.selected`),
          min: watch(`${tableName}.${row.index}.selected`) ? 0 : undefined,
          validate: (value) => !watch(`${tableName}.${row.index}.selected`) || value !== '' || '',
        }}
        render={({ field }) => (
          <TextField
            {...field}
            type="number"
            disabled={!watch(`${tableName}.${row.index}.selected`)}
            error={watch(`${tableName}.${row.index}.selected`) && (field.value === '' || field.value <= 0)}
            helperText={
              watch(`${tableName}.${row.index}.selected`) && (field.value === '' || field.value <= 0) ? '' : ''
            }
          />
        )}
      />
    ),
  },
];
