'use client';

import React from 'react'
import OrdersForm from './components/OrdersForm'
import { useSnackbar } from '@/context/SnackbarContext';
import { useRequestClientProjectOrder } from '@/requests/api/projectApi/projectApi';
import dayjs from 'dayjs';
import { useRouter } from 'next/navigation';

const customDateFormat = 'DD / MM / YYYY hh:mm A';


const CreateOrderPage = () => {
  const { setErrorMessage } = useSnackbar();
  const router = useRouter();


  const [requestClientProjectOrder, {loading}] = useRequestClientProjectOrder()



  const handleSubmit = async (formValues: any): Promise<void> => {


    const allItems = Object.values(formValues)
      .flat()
      .filter((wbb: any) => wbb && wbb?.selected);

    try {
      const response = await requestClientProjectOrder({
        projectId: formValues.project as string,
        payload: {
          orderStartTs: dayjs(formValues.eventDateTime, customDateFormat).toISOString(),
          projectOrderDetails: allItems.map((order:any) => ({
            projectWorkerBasedBillingId: order?.id,
            numberOfWorkers: parseInt(order.input1),
            hoursNeeded: order?.input2 ? parseInt(order.input2) : 1,
          }))
        }
      })
      router.push(`order-created?orderNumber=${response.data.orderNumber}`);
    } catch (err: any) {
      if (err?.response?.status === 400) {
        setErrorMessage('Failed to save changes');
      }
    }
  };

  return (
    <div>
      <OrdersForm submit={handleSubmit} loading={loading}/>
    </div>
  )
}

export default CreateOrderPage
