import React from 'react';
import { Box } from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import Typography from '@mui/material/Typography';
import WarningIcon from '@mui/icons-material/Warning';
import CancelIcon from '@mui/icons-material/Cancel';

export enum OrderRowWarning {
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR',
  MIN_HOUR = 'MIN_HOUR',
  MAX_HOUR = 'MAX_HOUR',
}

interface IOrdersFormRowMessage {
  warning: OrderRowWarning;
  hoursNeeded?: boolean
}

const OrdersFormRowMessage = ({ warning, hoursNeeded }: IOrdersFormRowMessage) => {
  switch (warning) {
  case OrderRowWarning.ERROR:
    return (
      <Box display="flex" alignItems="center" padding="4px 0">
        <CancelIcon htmlColor="#00000099" sx={{ width: 20, height: 20, marginRight: '8px' }} />
        <Typography fontSize={12} color="#00000099">
          {
            hoursNeeded ? 'Please include both the number of workers needed and the number of hours to be completed' : 'Please include the number of workers needed'
          }
        </Typography>
      </Box>
    );
  case OrderRowWarning.MAX_HOUR:
    return (
      <Box display="flex" alignItems="center" padding="4px 0">
        <WarningIcon htmlColor="#00000099" sx={{ width: 20, height: 20, marginRight: '8px' }} />
        <Typography fontSize={12} color="#00000099">
          Overtime policy
        </Typography>
      </Box>
    );
  case OrderRowWarning.MIN_HOUR:
    return (
      <Box display="flex" alignItems="center" padding="4px 0">
        <WarningIcon htmlColor="#00000099" sx={{ width: 20, height: 20, marginRight: '8px' }} />
        <Typography fontSize={12} color="#00000099">
          Minimum hour policy
        </Typography>
      </Box>
    );
  case OrderRowWarning.SUCCESS:
    return (
      <Box display="flex" alignItems="center" padding="4px 0">
        <CheckCircleIcon htmlColor="#00000099" sx={{ width: 20, height: 20, marginRight: '8px' }} />
        <Typography fontSize={12} color="#00000099">
            Job included for this order
        </Typography>
      </Box>
    );
  default:
    return <></>;
  }
};

export default OrdersFormRowMessage;
