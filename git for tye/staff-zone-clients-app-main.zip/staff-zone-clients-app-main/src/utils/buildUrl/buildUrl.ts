export const buildUrl = (path: string, params: any = {}): string => {
  let url = path;

  if (Object.keys(params).length > 0) {
    const searchParams = new URLSearchParams();
    Object.entries(params)
      .filter(([_, value]) => value !== undefined) // Filter out undefined values
      .forEach(([key, value]) => searchParams.append(key, String(value))); // Convert values to string
    if (searchParams.toString() !== '') {
      url += `?${searchParams.toString()}`;
    }
  }

  return url;
};
