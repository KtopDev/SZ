export const formatPhoneNumber = (phoneNumber: string) =>
  phoneNumber ? phoneNumber.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3') : null;

export const validateEmail = (email: string) => {
  const regex =
        /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return regex.test(String(email).toLowerCase());
};

export const formatApiErrors = (e: any, setError: any, setMessage: (message: string) => void) => {
  if (e?.response?.data?.details?.length) {
    e.response.data.details.forEach((errorField: any) => {
      setError(errorField.field, {message: errorField.message});
      setMessage(errorField.message);
    });
  }
};
