export interface IUserClosure {
    getUser: () => AuthenticatedUser | null;
    handleLogout: () => void;
    getToken: () => string | null;
    handleLogin: (newToken: string) => void;
    isAuthenticated: () => boolean;
    setAuthProcessId: (string: string) => void;
    getAuthProcessId: () => string | null;
    getUserTerms: () => Term[] | undefined;
    getMfaPreference: () => MfaPreference | null;
    setMfaPreference: (mfaPreference: MfaPreference) => void;
}

export type Role = {
    branches: string[] | null;
    role: string;
    roleClaims: any[] | null;
};

export type User = {
    status: string | null;
    email: string;
    phone: string;
    roles: Role[];
    isPrimary: boolean;
    first_name: string;
    last_name: string;
    session_id: string;
    session_expire_ts: string;
    password_expire_ts: string;
    app_user_id: string | null;
    app_user_code: string | null;
    job_title: string | null;
    client_id: string;
    contact_id: string;
    can_rate_workers: boolean;
    can_approve_hours: boolean;
    worker_id: string | null;
    worker_code: string | null;
};

export type Term = {
    client_app_term_id: string;
    worker_app_term_id: string | null;
    client_app_term_label: string;
    worker_app_term_label: string | null;
    client_app_term_file_uri: string;
    worker_app_term_file_uri: string | null;
    worker_app_term_es_file_uri: string | null;
    approval_request_ts: string;
    sort_order: number;
};

export type AuthUserDetails = {
    user: User;
    terms: Term[];
};

export type AuthenticatedUser = {
    userType: string;
    auth_status: string;
    auth_process_id: string;
    auth_user_details: AuthUserDetails;
    sub: string;
    iat: number;
    exp: number;
};

export type MfaPreference = 'SMS' | 'EMAIL' | 'AUTH_APP' | 'NONE';

