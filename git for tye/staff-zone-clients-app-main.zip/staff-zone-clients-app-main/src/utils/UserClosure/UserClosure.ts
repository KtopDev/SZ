import Cookies from 'js-cookie';
import isUndefined from 'lodash/isUndefined';
import {jwtDecode} from 'jwt-decode';
import {AuthenticatedUser, IUserClosure, MfaPreference, Term} from '@/utils/UserClosure/types';


const UserClosure: IUserClosure = (() => {
  let token: string | null = null;
  let authProcessId: string | null = null;
  let user: AuthenticatedUser | null = null;
  let mfaPreference: MfaPreference | null = null;

  const getToken = (): string | null => token;

  const getUser = () => user;

  const handleLogin = (newToken: string): void => {
    token = newToken;
    Cookies.set('token', token, {path: '/'});
    setUserFromToken(newToken);
  };

  const setUserFromToken = (token: string): void => {
    user = jwtDecode(token);
  }

  const getUserTerms = (): Term[] | undefined => user?.auth_user_details.terms;

  const loadTokenFromCookies = (): void => {
    const tokenFromCookies = Cookies.get('token');
    if (tokenFromCookies !== 'undefined' && !isUndefined(tokenFromCookies)) {
      token = tokenFromCookies;
      setUserFromToken(token);
    } else {
      if (typeof window !== 'undefined') {
        if (window.location.pathname !== '/login') {
          window.location.href = '/login';
        }
      }
    }
  };

  const getAuthProcessId = (): string | null => authProcessId;

  const setAuthProcessId = (id: string): void => {
    authProcessId = id;
  };

  const clearAuthenticatedUser = (): void => {
    token = null;
    Cookies.remove('token', {path: '/'});
  };

  const handleLogout = (): void => {
    clearAuthenticatedUser();
    // clear actual user through some BE endpoint
    if (typeof window !== 'undefined') {
      window.location.href = '/login';
    }
  };

  const getMfaPreference = (): MfaPreference | null => mfaPreference;

  const setMfaPreference = (newMfaPreference: MfaPreference): void => {
    mfaPreference = newMfaPreference;
    Cookies.set('mfaPreference', JSON.stringify(newMfaPreference), {path: '/'});
  };

  const isAuthenticated = (): boolean => !!token;

  loadTokenFromCookies();

  return {
    getUser,
    getToken,
    handleLogin,
    handleLogout,
    getUserTerms,
    isAuthenticated,
    setAuthProcessId,
    getAuthProcessId,
    getMfaPreference,
    setMfaPreference
  };
})();

export default UserClosure;
