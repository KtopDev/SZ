export const openDrawerWidth = '300px';
export const closedDrawerWidth = 64;

export const commonModalStyle = {
  position: 'absolute' as const,
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 550,
  textDecoration: 'none',
  p: 1,
};
