'use client';

import * as React from 'react';
import { useState } from 'react';
import List from '@mui/material/List';
import Divider from '@mui/material/Divider';
import ListItem from '@mui/material/ListItem';
import { Badge, Chip, Grid } from '@mui/material';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import { useRouter } from 'next/navigation';
import {
  badgeStyle,
  dividerStyle,
  listItemButtonStyle,
  listItemIconStyle,
  listItemStyle,
  listItemTextStyle,
} from './styles';
import Link from '../../../shared/Link';
import ListItemButton from '@mui/material/ListItemButton';
import { Drawer, DrawerHeader } from './SideMenu.styled';
import { menuItems } from '@/components/Layout/constants/menuItems';
import Footer from '@/components/Layout/components/SideMenu/components/Footer/Footer';
import DrawerHeaderContent from '@/components/Layout/components/SideMenu/components/DrawerHeaderContent';
import { useSidebar } from '@/context/SidebarContext';
import { grey } from '@mui/material/colors';
import { openDrawerWidth } from '@/theme/constants';
import { usePathname } from 'next/navigation';

interface Props {
  open: boolean;
  setOpen: React.Dispatch<React.SetStateAction<boolean>>;
}

const SideMenu = ({ open, setOpen }: Props) => {
  const router = useRouter();
  const pathname = usePathname();
  const { selectedBranchId } = useSidebar();

  const [isAnimationFinished, setIsAnimationFinished] = useState(true);

  const handleToggle = () => {
    setIsAnimationFinished(false);
    setOpen((val) => !val);
  };

  const onAnimationEnd = () => {
    setIsAnimationFinished(true);
  };

  return (
    <Drawer
      openDrawerWidth={openDrawerWidth}
      color={grey[900]}
      sx={{ justifyContent: 'space-between' }}
      variant="permanent"
      open={open}
      onTransitionEnd={onAnimationEnd}>
      <div>
        <DrawerHeader>
          <DrawerHeaderContent open={open} isAnimationFinished={isAnimationFinished} handleToggle={handleToggle} />
        </DrawerHeader>
        <Divider sx={dividerStyle} />
        <List>
          {menuItems.map(({ name, label, icon, href, notificationCount }) => (
            <Link href={href} passHref key={name}>
              <ListItem disablePadding sx={listItemStyle}>
                <ListItemButton sx={listItemButtonStyle(open)}>
                  <ListItemIcon sx={listItemIconStyle(open)}>
                    <Badge color="secondary" variant="dot" invisible={true}>
                      {icon}
                    </Badge>
                  </ListItemIcon>
                  <ListItemText primary={label} sx={listItemTextStyle(open)} />
                  {open && notificationCount > 0 && (
                    <ListItemIcon>
                      <Badge badgeContent={1} color="secondary" sx={badgeStyle} />
                    </ListItemIcon>
                  )}
                </ListItemButton>
              </ListItem>
            </Link>
          ))}
        </List>
      </div>
      <div>
        {open && (
          <Chip
            label="REQUEST PROJECT"
            variant="outlined"
            onClick={() => {
              router.push(`/projects/${selectedBranchId}/request-project`);
            }}
            sx={{
              display: 'flex',
              width: 'auto',
              marginLeft: 3,
              marginRight: 3,
              padding: '20px 32px',
              color: 'white',
              border: '2px solid white',
              borderRadius: 10,
            }}
          />
        )}
        {pathname.startsWith('/orders') && (
          <Chip
            label="CREATE ORDER"
            variant="outlined"
            onClick={() => {
              router.push('/orders/create-order');
            }}
            sx={{
              display: 'flex',
              width: 'auto',
              marginLeft: 3,
              marginRight: 3,
              padding: '20px 32px',
              color: 'white',
              border: '2px solid #6F3AE080',
              borderRadius: 10,
              backgroundColor: '#6F3AE0',
              marginTop: '48px'
            }}
          />
        )}
      </div>
      <Grid>
        <Footer open={open} />
      </Grid>
    </Drawer>
  );
};

export default SideMenu;
