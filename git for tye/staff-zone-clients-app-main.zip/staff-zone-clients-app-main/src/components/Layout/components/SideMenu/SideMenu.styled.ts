import {CSSObject, styled, Theme} from '@mui/material/styles';
import {grey} from '@mui/material/colors';
import MuiDrawer, {DrawerProps as MuiDrawerProps} from '@mui/material/Drawer';

interface CustomDrawerProps extends MuiDrawerProps {
    openDrawerWidth: string;
    color: string;
    open: boolean;
    theme?: any
}

const openedMixin = (theme: Theme, color: any, openDrawerWidth: string): CSSObject => ({
  width: openDrawerWidth,
  transition: theme.transitions.create('width', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  overflowX: 'hidden',
  backgroundColor: color,
  justifyContent: 'space-between',
});

const closedMixin = (theme: Theme, color: any): CSSObject => ({
  transition: theme.transitions.create('width', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  overflowX: 'hidden',
  width: `calc(${theme.spacing(7)} + 1px)`,
  [theme.breakpoints.up('sm')]: {
    width: `calc(${theme.spacing(8)} + 1px)`,
  },
  backgroundColor: color,
  justifyContent: 'space-between',
});

export const DrawerHeader = styled('div')(({theme}) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'flex-end',
  padding: theme.spacing(0, 1),
  ...theme.mixins.toolbar,
  backgroundColor: grey[900],
}));

export const Drawer = styled(MuiDrawer, {
  shouldForwardProp: (prop) => prop !== 'open' && prop !== 'openDrawerWidth' && prop !== 'color',
})<CustomDrawerProps>(({theme, open, color, openDrawerWidth}: CustomDrawerProps) => ({
  flexShrink: 0,
  whiteSpace: 'nowrap',
  width: openDrawerWidth,
  boxSizing: 'border-box',
  ...(open && {
    ...openedMixin(theme, color, openDrawerWidth),
    '& .MuiDrawer-paper': openedMixin(theme, color, openDrawerWidth),
  }),
  ...(!open && {
    ...closedMixin(theme, color),
    '& .MuiDrawer-paper': closedMixin(theme, color),
  }),
}));
