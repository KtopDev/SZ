'use client';

import * as React from 'react';
import {Avatar} from '@mui/material';
import {Theme} from '@mui/material/styles';
import IconButton from '@mui/material/IconButton';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';

interface Props {
    open: boolean;
    handleToggle: () => void;
    position?: 'left' | 'right';
    variant?: 'outlined' | 'text'
}

const styles = {
  iconProps: (theme: Theme) => ({color: theme.palette.primary.light}),
  avatar: (variant: string) => ({
    backgroundColor: 'transparent',
    border: (theme: Theme) => variant === 'outlined' ? `1px solid ${theme.palette.primary.light}` : '',
    width: 30,
    height: 30,
  }),
};

const ToggleMenuButton = ({open, handleToggle, position = 'left', variant = 'text'}: Props) => {
  const isLeftPosition = position === 'left';

  return (
    <IconButton
      onClick={handleToggle}
      sx={{
        padding: 0,
      }}>
      <Avatar sx={styles.avatar(variant)}>
        {isLeftPosition ? (
          open ? (
            <ChevronLeftIcon sx={styles.iconProps}/>
          ) : (
            <ChevronRightIcon sx={styles.iconProps}/>
          )
        ) : (
          open ? (
            <ChevronRightIcon sx={styles.iconProps}/>
          ) : (
            <ChevronLeftIcon sx={styles.iconProps}/>
          )
        )}
      </Avatar>
    </IconButton>
  );
};

export default ToggleMenuButton;
