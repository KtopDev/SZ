import SideMenu from './SideMenu';

export default SideMenu;
