import { Theme } from '@mui/material/styles';

const gridStyles = (open: boolean) => ({ paddingY: 1, ...(!open && { paddingX: 1 }) });
const inputLabelStyles = { color: (theme: Theme) => theme.palette.grey['500'] };
const selectBranchStyles = {
  'color': 'white',
  '& .MuiSelect-filled': {
    borderRadius: '3px',
    backgroundColor: '#303030',
  },
  '& .MuiSvgIcon-root': {
    color: 'white',
  },
};

const styles = {
  gridStyles,
  inputLabelStyles,
  selectBranchStyles,
};

export default styles;
