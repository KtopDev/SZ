import * as React from 'react';
import { capitalize } from 'lodash';
import Link from 'next/link';
import { Breadcrumbs } from '@mui/material';
import Typography from '@mui/material/Typography';
import { usePathname } from 'next/navigation';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import { BASE_URL } from '@/requests/axios-conf';
import { useEffect, useState } from 'react';

const Breadcrumb = () => {
  const paths = usePathname();
  const rawPathNames = paths.split('/').filter((path: string) => path);
  const [formattedBreadcrumb, setFormattedBreadcrumb] = useState('');
  const [breadcrumbFetched, setBreadcrumbFetched] = useState(false);

  const isValidUUID = (str: string) => {
    const regex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    return regex.test(str);
  };

  useEffect(() => {
    const fetchBreadcrumbs = async () => {
      const isUUIDRoute = (serviceName: string) => {
        const branchUUID = rawPathNames[3];
        return rawPathNames.includes(serviceName) && branchUUID;
      };

      if (isUUIDRoute('branches')) {
        const response = await fetch(`${BASE_URL}/api/v1/branches/${rawPathNames[3]}`);
        const data = await response.json();
        setFormattedBreadcrumb(data.branchName);
        setBreadcrumbFetched(true);
      } else if (isUUIDRoute('clients')) {
        const response = await fetch(`${BASE_URL}/clients/${rawPathNames[3]}`);
        const data = await response.json();
        setFormattedBreadcrumb(data.clientName);
        setBreadcrumbFetched(true);
      }
    };
    if (!breadcrumbFetched) {
      fetchBreadcrumbs();
    }
  }, [rawPathNames, breadcrumbFetched]);

  return (
    <Breadcrumbs separator={<ChevronRightIcon fontSize="small" />} aria-label="breadcrumb">
      {rawPathNames.map((pathName: string, index: number) => {
        const href =
          pathName === 'branch-details' && isValidUUID(rawPathNames[index + 1])
            ? `/${rawPathNames.slice(0, index).join('/')}`
            : `/${rawPathNames.slice(0, index + 1).join('/')}`;

        return (
          <Link key={`${pathName}${index}`} href={href} style={{ textDecoration: 'none', color: 'inherit' }}>
            <Typography fontWeight="500" fontSize="16px" color="common.black">
              {isValidUUID(pathName) ? formattedBreadcrumb : capitalize(pathName.replace('-', ' '))}
            </Typography>
          </Link>
        );
      })}
    </Breadcrumbs>
  );
};

export default Breadcrumb;
