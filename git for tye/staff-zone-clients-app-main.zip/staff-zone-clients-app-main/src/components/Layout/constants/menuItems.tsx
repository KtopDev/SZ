import {ReactNode} from 'react';
import HomeIcon from '@mui/icons-material/Home';
import CollectionsBookmarkIcon from '@mui/icons-material/CollectionsBookmark';
import ReceiptIcon from '@mui/icons-material/Receipt';
import FolderIcon from '@mui/icons-material/Folder';
import SupervisedUserCircleIcon from '@mui/icons-material/SupervisedUserCircle';
import ArchitectureIcon from '@mui/icons-material/Architecture';
import MailIcon from '@mui/icons-material/Mail';
import SettingsIcon from '@mui/icons-material/Settings';
import {common} from '@mui/material/colors';

interface MenuItem {
    name: string;
    label: string;
    icon: ReactNode;
    href: string;
    notificationCount: number;
}

export const menuItems: MenuItem[] = [
  {
    name: 'dashboard',
    label: 'Dashboard',
    icon: <HomeIcon sx={{color: common.white}}/>,
    href: '/home',
    notificationCount: 0,
  },
  {
    name: 'orders',
    label: 'Orders',
    icon: <CollectionsBookmarkIcon sx={{color: common.white}}/>,
    href: '/orders',
    notificationCount: 0,
  },
  {
    name: 'invoices',
    label: 'Invoices',
    icon: <ReceiptIcon sx={{color: common.white}}/>,
    href: '/home',
    notificationCount: 13,
  },
  {
    name: 'documents',
    label: 'Documents',
    icon: <FolderIcon sx={{color: common.white}}/>,
    href: '/home',
    notificationCount: 0,
  },
  {
    name: 'workers',
    label: 'Workers',
    icon: <SupervisedUserCircleIcon sx={{color: common.white}}/>,
    href: '/workers',
    notificationCount: 0,
  },
  {
    name: 'projects',
    label: 'Projects',
    icon: <ArchitectureIcon sx={{color: common.white}}/>,
    href: '/projects',
    notificationCount: 0,
  },
  {
    name: 'contact',
    label: 'Contact',
    icon: <MailIcon sx={{color: common.white}}/>,
    href: '/home',
    notificationCount: 0,
  },
  {
    name: 'settings',
    label: 'Settings',
    icon: <SettingsIcon sx={{color: common.white}}/>,
    href: '/home',
    notificationCount: 0,
  },
];
