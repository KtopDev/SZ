import Link from './Link.styled';

export default Link;
