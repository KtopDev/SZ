'use client';
import * as React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Checkbox,
  Button,
  Typography,
} from '@mui/material';
import DownloadIcon from '@mui/icons-material/Download';

function createData(name: string, lastUpdated: string) {
  return { name, lastUpdated, isChecked: false };
}

const initialRows = [
  createData('Basic legal statement', '11/11/2022'),
  createData('Terms and conditions', '11/11/2022'),
  createData('State law', '11/11/2022'),
  createData('Confidentiality agreements', '11/11/2022'),
  createData('Final notification', '11/11/2022'),
];

export default function ClientApp() {
  const [rows, setRows] = React.useState(initialRows);

  const handleToggleAll = () => {
    const allChecked = rows.every((row) => row.isChecked);
    const updatedRows = rows.map((row) => ({
      ...row,
      isChecked: !allChecked,
    }));
    setRows(updatedRows);
  };

  const handleToggle = (name: string) => {
    const updatedRows = rows.map((row) => {
      if (row.name === name) {
        return { ...row, isChecked: !row.isChecked };
      }
      return row;
    });
    setRows(updatedRows);
  };

  return (
    <TableContainer component={Paper}>
      <Typography variant="h6" gutterBottom ml={1} mt={1}>
        Client app
      </Typography>
      <Table aria-label="customized table">
        <TableHead>
          <TableRow>
            <TableCell padding="checkbox">
              <Checkbox onChange={handleToggleAll} checked={rows.length > 0 && rows.every((row) => row.isChecked)} />
            </TableCell>
            <TableCell align="left">Title</TableCell>
            <TableCell>Last updated</TableCell>
            <TableCell align="right">Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.name} selected={row.isChecked}>
              <TableCell padding="checkbox">
                <Checkbox checked={row.isChecked} onChange={() => handleToggle(row.name)} />
              </TableCell>
              <TableCell component="th" scope="row">
                {row.name}
              </TableCell>
              <TableCell>{row.lastUpdated}</TableCell>
              <TableCell align="right">
                <Button
                  startIcon={<DownloadIcon />}
                  onClick={() => {
                    /* handle download */
                  }}>
                  DOWNLOAD PDF
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
