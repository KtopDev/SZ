import { MouseEvent, ReactElement, useState } from 'react';
import IconButton from '@mui/material/IconButton';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { Menu, MenuItem } from '@mui/material';
import Typography from '@mui/material/Typography';

type Props = {
  children?: ReactElement;
  menuItems: any[];
  row: any;
};

const ActionColumnContent = ({ menuItems, children, row }: Props) => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const handleClick = (event: MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <div>
      {children}
      {menuItems && (
        <>
          <IconButton
            aria-label="more"
            id="long-button"
            aria-controls={open ? 'long-menu' : undefined}
            aria-expanded={open ? 'true' : undefined}
            aria-haspopup="true"
            onClick={handleClick}>
            <MoreVertIcon />
          </IconButton>
          <Menu
            id="long-menu"
            MenuListProps={{
              'aria-labelledby': 'long-button',
            }}
            anchorEl={anchorEl}
            open={open}
            onClose={handleClose}>
            {menuItems.map((option, index) => (
              <MenuItem
                key={`${option.label}-${index}`}
                disabled={option.disabled}
                onClick={() => {
                  option.onClick(row);
                  handleClose();
                }}>
                <Typography color={option.color}>{option.label} </Typography>
              </MenuItem>
            ))}
          </Menu>
        </>
      )}
    </div>
  );
};

export default ActionColumnContent;
