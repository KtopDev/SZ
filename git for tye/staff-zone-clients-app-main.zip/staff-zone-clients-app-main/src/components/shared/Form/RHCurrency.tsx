'use client';
import { FormControl, FormHelperText, InputAdornment, InputLabel, OutlinedInput } from '@mui/material';
import { Controller, FieldValues, Path } from 'react-hook-form';
import { ReactHookProps } from '@/types/forms/RHProps';
import { generateRules } from './utils';

type Props<T extends FieldValues> = {
  label: string;
  propName: keyof T;
  helperText?: string;
  rhProps: ReactHookProps<T>;
};

export default function RHCurrency<T extends FieldValues>({ label, propName, helperText, rhProps }: Props<T>) {
  return (
    <FormControl fullWidth margin="dense" error={!!rhProps.errors.payLimitWeekly}>
      <InputLabel size="small" error={!!rhProps.errors[propName]}>
        {label}
      </InputLabel>
      <Controller
        name={propName as Path<T>}
        control={rhProps.control}
        rules={generateRules(rhProps)}
        render={({ field, fieldState }) => (
          <>
            <OutlinedInput
              {...field}
              type="text"
              label={label}
              value={field.value}
              size="small"
              inputProps={{
                min: 0,
                pattern: '\\d*',
              }}
              onChange={(e) => {
                const sanitizedValue = e.target.value.replace(/[^0-9]/g, '');
                field.onChange(sanitizedValue);
              }}
              startAdornment={<InputAdornment position="start">$</InputAdornment>}
              error={!!fieldState.error}
            />
            <FormHelperText error={!!fieldState.error}>
              {fieldState.error ? fieldState.error.message : helperText}
            </FormHelperText>
          </>
        )}
      />
    </FormControl>
  );
}
