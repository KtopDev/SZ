import * as React from 'react';
import { useState } from 'react';
import { FormHelperText, TextField } from '@mui/material';
import { Controller, FieldValues, Path, PathValue } from 'react-hook-form';
import InputMask from 'react-input-mask';
import { ReactHookProps } from '@/types/forms/RHProps';
import { generateRules } from './utils';

type Props<T extends FieldValues> = {
  label: string;
  propName: keyof T;
  helperText?: string;
  mask: string;
  maskPlaceholder?: string;
  rhProps: ReactHookProps<T>;
  shrink?: boolean;
  disabled?: boolean;
};

export default function RHMaskedInput<T extends FieldValues>({
  label,
  propName,
  helperText = '',
  mask,
  maskPlaceholder = '',
  rhProps,
  shrink = false,
  disabled = false,
}: Props<T>) {
  const [isFocused, setIsFocused] = useState(false);

  return (
    <Controller
      name={propName as Path<T>}
      control={rhProps.control}
      rules={generateRules(rhProps)}
      render={({ field, fieldState }) => (
        <>
          <InputMask
            mask={mask}
            value={field.value}
            maskPlaceholder={maskPlaceholder}
            onChange={(event: { target: { value: string } }) => {
              const unmaskedValue = event.target.value.replace(/\D+/g, '');
              if (rhProps.setValue) {
                rhProps.setValue(propName as Path<T>, unmaskedValue as PathValue<T, Path<T>>);
              }
              field.onChange(unmaskedValue);
            }}
            disabled={disabled}
            onFocus={() => setIsFocused(true)}
            onBlur={() => {
              field.onBlur();
              setIsFocused(false);
              if (rhProps.trigger) {
                rhProps.trigger(propName as Path<T>);
              }
            }}>
            <TextField
              fullWidth
              InputLabelProps={{
                shrink: shrink || !!field.value || isFocused,
              }}
              label={label.toString()}
              variant="outlined"
              margin="dense"
              size="small"
              error={!!fieldState.error}
            />
          </InputMask>
          <FormHelperText error={!!fieldState.error}>
            {fieldState.error ? fieldState.error.message : helperText}
          </FormHelperText>
        </>
      )}
    />
  );
}
