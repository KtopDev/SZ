import * as React from 'react';
import { Controller, FieldValues, Path } from 'react-hook-form';
import { DatePicker } from '@mui/x-date-pickers';
import { ReactHookProps } from '@/types/forms/RHProps';
import dayjs, { Dayjs } from 'dayjs';
import { FormHelperText } from '@mui/material';

type Props<T extends FieldValues> = {
  label: string;
  propName: keyof T;
  rhProps: ReactHookProps<T>;
  fullWidth?: boolean;
  minDate?: dayjs.Dayjs | undefined;
  maxDate?: dayjs.Dayjs | undefined;
  helperText?: string;
  rules?: any
};

export default function RHDatePicker<T extends FieldValues>({
  label,
  propName,
  rhProps,
  fullWidth = false,
  minDate,
  maxDate,
  helperText = '',
  rules,
}: Props<T>) {
  return (
    <Controller
      name={propName as Path<T>}
      control={rhProps.control}
      rules={rules}
      render={({ field, fieldState }) => (
        <>
          <DatePicker
            minDate={minDate}
            maxDate={maxDate}
            slotProps={{
              textField: {
                fullWidth,
              },
              actionBar: {
                actions: ['clear'],
              },
            }}
            label={label}
            value={field.value ? dayjs(field.value) : null}
            onChange={(date: Dayjs | null) => {
              if (date) {
                field.onChange(date.format('YYYY-MM-DD'));
              } else {
                field.onChange('');
              }
            }}
          />
          <FormHelperText error={!!fieldState.error} sx={{ marginTop: 0.9 }}>
            {fieldState.error ? fieldState.error.message : helperText}
          </FormHelperText>
        </>
      )}
    />
  );
}
