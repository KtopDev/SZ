'use client';
import React, {ReactNode, useEffect, useState} from 'react';
import {Controller, FieldValues, Path} from 'react-hook-form';
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import {FormControl, FormHelperText} from '@mui/material';
import {ReactHookProps} from '@/types/forms/RHProps';
import {Dropdown, SelectOption} from '@/types/Dropdown';
import {generateRules} from './utils';

type Props<T extends FieldValues> = {
    label: string;
    propName: keyof T;
    helperText?: string;
    options: Dropdown;
    rhProps: ReactHookProps<T>;
    isLoading?: boolean;
    disabled?: boolean;
    inputStyles?: any;
    getOptionLabel?: (option: SelectOption) => string;
    renderOption?: (props: React.HTMLAttributes<HTMLLIElement>, option: SelectOption) => ReactNode;
};

export default function RHSelect<T extends FieldValues>({
  label,
  propName,
  helperText = '',
  options,
  isLoading,
  getOptionLabel,
  inputStyles,
  rhProps,
  disabled = false,
}: Props<T>) {
  const [selectedOption, setSelectedOption] = useState<SelectOption | null>(null);

  useEffect(() => {
    if (rhProps.getValues) {
      const initialValue = rhProps.getValues(propName as Path<T>);
      if (initialValue) {
        const initialOption =
                    options.dropdown?.find((option) => {
                      return option.id === initialValue;
                    }) || null;
        setSelectedOption(initialOption);
      }
    }
  }, [propName, options.dropdown, rhProps]);

  return (
    <FormControl fullWidth error={!!rhProps.errors[propName]} size="small">
      <Controller
        name={propName as Path<T>}
        control={rhProps.control}
        rules={generateRules(rhProps)}
        render={({field, fieldState}) => (
          <Autocomplete
            size="small"
            loading={isLoading}
            multiple={false}
            options={options.dropdown || []}
            getOptionLabel={getOptionLabel ? getOptionLabel : (option) => option.displayName.toString() || ''}
            value={selectedOption}
            onChange={(event, newValue) => {
              field.onChange(newValue ? newValue.id : '');
              setSelectedOption(newValue);
            }}
            disabled={disabled}
            isOptionEqualToValue={(option, value) => option.id === value.id}
            renderInput={(params) => (
              <>
                <TextField
                  {...params}
                  margin="dense"
                  size="small"
                  label={label}
                  error={!!rhProps.errors[propName]}
                  sx={inputStyles}
                />
                <FormHelperText error={!!fieldState.error}>
                  {fieldState.error ? fieldState.error.message : helperText}
                </FormHelperText>
              </>
            )}
          />
        )}
      />
    </FormControl>
  );
}
