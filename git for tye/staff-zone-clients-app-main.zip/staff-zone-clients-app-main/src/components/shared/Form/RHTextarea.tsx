'use client';
import * as React from 'react';
import { Controller, FieldValues, Path } from 'react-hook-form';
import { FormHelperText } from '@mui/material';
import { TextareaAutosize } from '@mui/base/TextareaAutosize';
import { ReactHookProps } from '@/types/forms/RHProps';
import { generateRules } from './utils';

type Props<T extends FieldValues> = {
  propName: keyof T;
  helperText?: string;
  rhProps: ReactHookProps<T>;
  minRows?: number;
  label?: string;
};

export default function RHTextareaAutosize<T extends FieldValues>({
  propName,
  helperText = '',
  rhProps,
  minRows = 3,
  label = '',
}: Props<T>) {
  return (
    <Controller
      name={propName as Path<T>}
      control={rhProps.control}
      rules={generateRules(rhProps)}
      render={({ field, fieldState }) => (
        <>
          <TextareaAutosize
            {...field}
            minRows={minRows}
            placeholder={label}
            style={{ width: '100%' }}
            onChange={(e) => field.onChange(e.target.value)}
          />
          <FormHelperText error={!!fieldState.error}>
            {fieldState.error ? fieldState.error.message : helperText}
          </FormHelperText>
        </>
      )}
    />
  );
}
