import React from 'react';
import { FormControl, FormControlLabel, FormHelperText, Radio, RadioGroup } from '@mui/material';
import { Controller, FieldValues, Path } from 'react-hook-form';
import { ReactHookProps } from '@/types/forms/RHProps';
import { generateRules } from './utils';

type Props<T extends FieldValues> = {
  labels: string[];
  values: string[];
  propName: Path<T>;
  helperText?: string;
  rhProps: ReactHookProps<T>;
};

export default function RHRadioGroup<T extends FieldValues>({
  labels,
  values,
  propName,
  helperText = '',
  rhProps,
}: Props<T>) {
  return (
    <FormControl>
      <Controller
        name={propName}
        control={rhProps.control}
        rules={generateRules(rhProps)}
        render={({ field, fieldState }) => (
          <>
            <RadioGroup {...field} aria-labelledby="demo-radio-buttons-group-label">
              {labels.map((label, index) => (
                <FormControlLabel key={label} value={values[index]} control={<Radio />} label={label} />
              ))}
            </RadioGroup>
            <FormHelperText error={!!fieldState.error}>
              {fieldState.error ? fieldState.error.message : helperText}
            </FormHelperText>
          </>
        )}
      />
    </FormControl>
  );
}
