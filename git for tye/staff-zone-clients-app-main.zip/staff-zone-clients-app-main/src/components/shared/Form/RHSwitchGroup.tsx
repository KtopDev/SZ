'use client';

import React from 'react';
import { FormControlLabel, FormGroup, FormHelperText, Switch } from '@mui/material';
import { Controller, FieldValues, Path } from 'react-hook-form';
import { ReactHookProps } from '@/types/forms/RHProps';
import { generateRules } from './utils';

type Props<T extends FieldValues> = {
  labels: string[];
  propNames: Array<Path<T>>;
  helperTexts?: string[];
  rhProps: ReactHookProps<T>;
};

export default function RHSwitchGroup<T extends FieldValues>({
  labels,
  propNames,
  helperTexts = [],
  rhProps,
}: Props<T>) {
  return (
    <FormGroup>
      {labels.map((label, index) => (
        <Controller
          key={label}
          name={propNames[index]}
          control={rhProps.control}
          rules={generateRules(rhProps)}
          render={({ field }) => (
            <FormControlLabel control={<Switch checked={field.value} {...field} />} label={label} />
          )}
        />
      ))}
      {helperTexts.map((text, index) => (
        <FormHelperText key={index}>{text}</FormHelperText>
      ))}
    </FormGroup>
  );
}
