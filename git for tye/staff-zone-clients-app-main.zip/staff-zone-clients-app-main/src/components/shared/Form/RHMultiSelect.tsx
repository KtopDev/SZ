import * as React from 'react';
import { useState } from 'react';
import {
  Checkbox,
  Chip,
  FormControl,
  FormHelperText,
  InputLabel,
  ListItemText,
  MenuItem,
  OutlinedInput,
  Select,
} from '@mui/material';
import { Controller, ControllerFieldState, ControllerRenderProps, FieldValues, Path } from 'react-hook-form';
import { ReactHookProps } from '@/types/forms/RHProps';
import { Dropdown, SelectOption } from '@/types/Dropdown';
import { generateRules } from './utils';
import CancelIcon from '@mui/icons-material/Cancel';

type Props<T extends FieldValues> = {
  label: string;
  propName: keyof T;
  helperText?: string;
  isLoading?: boolean;
  options: Dropdown;
  rhProps: ReactHookProps<T>;
  inputStyles?: any;
  shouldUseChipRender?: boolean;
  parseIdProp?: string;
};

export default function RHMultiSelect<T extends FieldValues>({
  label,
  propName,
  parseIdProp,
  helperText = '',
  options,
  rhProps,
  inputStyles,
  isLoading,
  shouldUseChipRender = true,
}: Props<T>) {
  const [selectedOptions, setSelectedOptions] = React.useState<string[]>([]);
  const ITEM_HEIGHT = 48;
  const ITEM_PADDING_TOP = 8;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
        width: 250,
      },
    },
  };

  const watchedValue = rhProps.watch ? rhProps.watch(propName as Path<T>) : null;

  React.useEffect(() => {
    if (!rhProps.getValues) {
      return;
    }
    // const currentValues = rhProps.getValues ? rhProps.getValues(propName as Path<T>) : null;
    const currentValues = rhProps.getValues(propName as Path<T>);
    if (currentValues && Array.isArray(currentValues)) {
      const parsedValues = parseIdProp ? currentValues.map((value: any) => value[parseIdProp]) : currentValues;

      if (parsedValues.some((value: any) => value === undefined)) {
        return;
      }

      setSelectedOptions(parsedValues);
    }
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [propName, rhProps, watchedValue, rhProps.getValues]);

  const handleDeleteChip = (
    field: ControllerRenderProps<T, Path<T>>,
    selectedItems: string[],
    clickedValue: string
  ) => {
    const updatedSelectedItems = selectedItems.filter((item) => item !== clickedValue);
    field.onChange(updatedSelectedItems);
    setSelectedOptions(updatedSelectedItems);
    if (!updatedSelectedItems.length) {
      setHasError(true);
      if (rhProps.setError) {
        rhProps.setError(propName as Path<T>, { type: 'manual' });
      }
    }
  };

  const handleIsChipSelected = (option: SelectOption) => {
    if (rhProps.getValues && rhProps.getValues(propName as Path<T>)) {
      const rhValue = rhProps.getValues(propName as Path<T>);
      const parsedOptions = rhValue.filter(Boolean).map((opt: { id: any }) => opt.id);
      const rawOptions = rhValue.filter(Boolean);
      return parsedOptions.length > 0 && !!parsedOptions[0]
        ? parsedOptions.includes(option.id)
        : rawOptions.includes(option.id);
    }
    return false;
  };

  const getOptionById = (optionId: string) => options.dropdown?.find((option) => option.id === optionId);

  const [hasError, setHasError] = useState(false);

  const renderErrorMessage = (fieldState: ControllerFieldState) => {
    if (fieldState && fieldState.error && fieldState.error.message) {
      return fieldState.error ? fieldState.error.message : helperText;
    }
    if (hasError) {
      return helperText;
    }
  };

  return (
    <FormControl fullWidth>
      <InputLabel id={`${String(propName)}-label`} error={!!rhProps.errors[propName]} size="small">
        {isLoading ? 'loading' : label}
      </InputLabel>
      <Controller
        name={propName as Path<T>}
        control={rhProps.control}
        rules={generateRules(rhProps)}
        render={({ field, fieldState }) => (
          <>
            <Select
              {...field}
              size="small"
              sx={inputStyles}
              multiple
              labelId={`${String(propName)}-label`}
              id={`${String(propName)}-select`}
              error={!!rhProps.errors[propName] || hasError}
              input={<OutlinedInput sx={inputStyles} label={label} />}
              inputProps={{ sx: inputStyles }}
              renderValue={(selected) =>
                shouldUseChipRender ? (
                  <div style={{ display: 'flex', flexWrap: 'wrap', maxWidth: '100%' }}>
                    {(selected as string[]).map((value, index) => {
                      const option = getOptionById(value);
                      return (
                        <Chip
                          key={option?.id || index}
                          label={getOptionById(value)?.displayName}
                          clickable
                          variant="outlined"
                          sx={{ mx: '4px' }}
                          deleteIcon={<CancelIcon onMouseDown={(event) => event.stopPropagation()} />}
                          onDelete={() => handleDeleteChip(field, selected, value)}
                        />
                      );
                    })}
                  </div>
                ) : (
                  selected
                    .slice(0, 3)
                    .map((value) => options.dropdown?.find((option) => option.id === value)?.displayName || '')
                    .filter((name) => name)
                    .join(', ')
                )
              }
              MenuProps={MenuProps}
              onChange={(event) => {
                const { value } = event.target;
                const newSelectedOptions = typeof value === 'string' ? [value] : value;
                field.onChange(newSelectedOptions);
                setSelectedOptions(newSelectedOptions);
              }}
              value={selectedOptions}>
              {options.dropdown?.map((option) => (
                <MenuItem key={option.id} value={option.id} sx={{  whiteSpace: 'pre-wrap' }}>
                  <Checkbox checked={handleIsChipSelected(option)} size="small" />
                  <ListItemText primary={option.displayName} sx={{ whiteSpace: 'pre-wrap' }}/>
                </MenuItem>
              ))}
            </Select>
            {!!fieldState.error ||
              (hasError && (
                <FormHelperText error={!!fieldState.error || hasError}>{renderErrorMessage(fieldState)}</FormHelperText>
              ))}
          </>
        )}
      />
    </FormControl>
  );
}
