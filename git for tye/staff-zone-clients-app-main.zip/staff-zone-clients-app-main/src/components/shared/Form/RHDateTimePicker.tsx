import * as React from 'react';
import { Controller, FieldValues, Path } from 'react-hook-form';
import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import { ReactHookProps } from '@/types/forms/RHProps';
import dayjs, { Dayjs } from 'dayjs';
import 'dayjs/locale/en-gb';

const dateTimeFormat = 'DD / MM / YYYY hh:mm A';

type Props<T extends FieldValues> = {
  label: string;
  propName: keyof T;
  rhProps: ReactHookProps<T>;
  fullWidth?: boolean;
  minDateTime?: dayjs.Dayjs | undefined;
  maxDateTime?: dayjs.Dayjs | undefined;
};

export default function RHDateTimePicker<T extends FieldValues>({
  label,
  propName,
  rhProps,
  fullWidth = false,
  minDateTime,
  maxDateTime,
}: Props<T>) {
  return (
    <Controller
      name={propName as Path<T>}
      control={rhProps.control}
      render={({ field }) => (
        <DateTimePicker
          minDateTime={minDateTime}
          maxDateTime={maxDateTime}
          slotProps={{
            textField: {
              fullWidth,
              label,
              variant: 'outlined',
              size: 'small',
            },
            actionBar: {
              actions: ['clear'],
            },
          }}
          value={field.value ? dayjs(field.value, dateTimeFormat) : null}
          onChange={(date: Dayjs | null) => {
            if (date) {
              field.onChange(date.format(dateTimeFormat));
            } else {
              field.onChange('');
            }
          }}
        />
      )}
    />
  );
}
