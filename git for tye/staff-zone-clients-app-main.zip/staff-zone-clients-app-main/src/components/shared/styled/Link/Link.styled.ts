'use client';

import NextLink from 'next/link';
import { styled } from '@mui/material/styles';

const Link = styled(NextLink)(({ theme, color = theme.palette.common.black }) => ({
  textDecoration: 'none',
  color: color,
}));

export default Link;
