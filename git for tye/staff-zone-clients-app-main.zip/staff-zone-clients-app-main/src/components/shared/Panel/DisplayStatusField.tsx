import * as React from 'react';
import Box from '@mui/material/Box';
import { Chip, Typography } from '@mui/material';
import { capitalize, upperCase } from 'lodash';

type Props = {
  label: string;
  value: string;
};

export default function DisplayStatusField({ label, value }: Props) {
  const getStatusColor = () => {
    switch (value.toLowerCase()) {
    case 'active':
      return 'success';
    case 'in legal':
      return 'secondary';
    case 'dns':
      return 'error';
    default:
      return 'default';
    }
  };

  return (
    <Box component="div" sx={styles.box}>
      <Typography variant="caption" color="gray" component="label">
        {label}
      </Typography>
      {value && (
        <Chip
          label={value === 'DNS' ? upperCase(value) : capitalize(value)}
          variant={getStatusColor() ? 'filled' : 'outlined'}
          color={getStatusColor()}
          size="small"
        />
      )}
    </Box>
  );
}

const styles = {
  box: { display: 'inline-flex', flexDirection: 'column', alignItems: 'flex-start', marginRight: 3 },
};
