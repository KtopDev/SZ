import * as React from 'react';
import Snackbar from '@mui/material/Snackbar';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import Alert from '@mui/material/Alert';
import { useSnackbar } from '@/context/SnackbarContext';

export default function SnackBar() {
  const { showMessage, message, clearMessage, severity } = useSnackbar();

  const action = (
    <React.Fragment>
      <IconButton size="small" aria-label="close" color="inherit" onClick={clearMessage}>
        <CloseIcon fontSize="small" />
      </IconButton>
    </React.Fragment>
  );

  return (
    <Snackbar
      anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      open={showMessage}
      autoHideDuration={6000}
      onClose={clearMessage}>
      <Alert
        variant="filled"
        onClose={clearMessage}
        severity={severity}
        action={action}
        icon={false}
        style={{ backgroundColor: '#313131' }}>
        <div>
          {message.split('\n').map((line, index) => (
            <div key={index}>{line}</div>
          ))}
        </div>
      </Alert>
    </Snackbar>
  );
}
