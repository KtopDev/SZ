export type TempDispatcher = {
  dispatchBucketDetailId: string;
  dispatchBucketId: string;
  projectId: string;
  orderId: string;
  projectWorkerBasedBillingId: string;
  slots: number;
  additionalSlots: number;
  isRowActive: boolean;
};
