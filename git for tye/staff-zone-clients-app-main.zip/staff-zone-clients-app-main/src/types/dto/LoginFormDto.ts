export type LoginFormDto = {
    email: string;
    password: string;
};

export type LoginUserDto = {
    username: string;
    password: string;
    userType: string;
};

export type MFATokenDto = {
    qrCode: string;
    mfaCode: string;
    registered: boolean;
};

export type LoginMFAVerifyDto = {
    token: string;
    email: string;
};

export type LoginMFAVerifyResponseDto = {
    valid: boolean;
    firstName: string;
};

export type SetPasswordDto = {
    email: string;
    userType: string;
};

export type PasswordVerifyResponse = {
    id: string;
    url: string;
    urlKey: string;
    email: string;
    expireDate: string;
    expired: boolean;
};

export type SavePasswordDto = {
    token: string | null;
    password: string;
    confirmPassword: string;
    userType: string;
    email: string;
    id: string;
};

export type TermsOfUsePayload = {
    clientId: string;
    contactId: string;
    clientAppTerms: string[];
}