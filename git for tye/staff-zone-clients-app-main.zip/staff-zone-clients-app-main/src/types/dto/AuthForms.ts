export type VerificationCodeDto = {
  verificationCode: string;
};

export type MfaVerifyDto = {
  authProcessId: string;
  code: string;
  userType: string;
};
