export interface BranchDTO {
  branchId: string;
  branchName: string;
  branchCode: string;
  status: string;
  statusTs: string;
  phone: string;
  fax: string;
  address: string;
  addressLine2: string;
  state: State;
  city: string;
  postalCode: string;
  geoLocation: string;
  payLimitDaily: number;
  payLimitWeekly: number;
  payCycle: PayCycle;
  isVoluntaryDeductionApproveRequired: boolean;
  scannerIp: string;
  checkPrinterIp: string;
  reportPrinterIp: string;
  defaultCheckPrintingFormat: PrintingFormat;
  sickCheckPrintingFormat: PrintingFormat;
  depositPrintingFormat: PrintingFormat;
  compCode: CompCode;
  taxJurisdictions: Jurisdiction[];
  unemploymentJurisdictions: UnemploymentJurisdiction[];
  sickPayJurisdictions: SickPayJurisdiction[];
  rowActive: boolean;
  createdAt: string;
  createdBy: string;
  modifiedBy: string;
  modifiedAt: string;
}

export interface State {
  state: string;
  stateName: string;
  isRowActive: boolean;
}

export interface PayCycle {
  payCycle: string;
  label: string;
  isRowActive: boolean;
}

export interface PrintingFormatType {
  printingFormatType: string;
  label: string;
  isRowActive: boolean;
}

export interface PrintingFormat {
  printingFormatId: string;
  lkPrintingFormatType: PrintingFormatType;
  printingFormatName: string;
  printingFormatUri: string;
  isRowActive: boolean;
}

export interface CompCode {
  compCode: string;
  compCodeDescription: string;
  compCodeBillingDescription: string;
  lkState: State;
  burdenPerHour: number;
  costPerHundred: number;
  billRatePreHundred: number;
  date: string;
  isRowActive: boolean;
}

export interface Jurisdiction {
  id: string;
  name: string;
  type: string;
  isRowActive: boolean;
}

export interface UnemploymentJurisdiction {
  id: string;
  lkStates: State;
  minWage: number;
  maxWage: number;
  rate: number;
  federalCreditRate: number;
  employeeRate: number;
  companyRate: number;
  status: string;
  statusTs: string;
  isRowActive: boolean;
}

export interface AnniversaryMethod {
  anniversaryMethod: string;
  label: string;
  isRowActive: boolean;
}

export interface SickPayJurisdiction {
  id: string;
  state: string;
  effectiveDate: string;
  anniversaryMethod: AnniversaryMethod;
  vestingDays: number;
  suspendedDays: number;
  loseAfterDays: number;
  accrualHours: number;
  workedHours: number;
  maxCarryForwardHours: number;
  maxPerYearHours: number;
  minConsumableHours: number;
  isRowActive: boolean;
}
