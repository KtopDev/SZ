export interface ProjectForm {
    projectName: string;
    branchId: string;
    phone: string;
    fax: string;
    address: string;
    addressLine2?: string;
    state: string;
    city: string;
    postalCode: string;
}
