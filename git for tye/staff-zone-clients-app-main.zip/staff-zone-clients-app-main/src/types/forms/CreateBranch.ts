export interface ICreateBranch {
  branchName: string;
  branchCode: string;
  phone: string;
  fax: string;
  address: string;
  addressLine2?: string;
  state: string;
  city: string;
  postalCode: string;
  geoLocation: string;
  payLimitDaily: number | null;
  payLimitWeekly: number | null;
  payCycle: string;
  isVoluntaryDeductionApproveRequired: boolean;
  scannerIp: string;
  checkPrinterIp: string;
  reportPrinterIp: string;
  defaultCheckPrintingFormatId: string;
  sickCheckPrintingFormatId: string;
  depositPrintingFormatId: string;
  compCode: string;
  futaSutaSdi: string[];
  taxJurisdictions: string[];
  sickPayJurisdictions: string[];
}

export const defaultBranch = {
  branchName: '',
  branchCode: '',
  phone: '',
  fax: '',
  address: '',
  addressLine2: '',
  state: '',
  city: '',
  postalCode: '',
  geoLocation: '',
  payLimitDaily: null,
  payLimitWeekly: null,
  payCycle: '',
  isVoluntaryDeductionApproveRequired: false,
  scannerIp: '',
  checkPrinterIp: '',
  reportPrinterIp: '',
  defaultCheckPrintingFormatId: '',
  sickCheckPrintingFormatId: '',
  depositPrintingFormatId: '',
  compCode: '',
  futaSutaSdi: [],
  taxJurisdictions: [],
  sickPayJurisdictions: [],
} as ICreateBranch;
