import {
  Control,
  FieldErrors,
  FieldValues,
  UseFormClearErrors,
  UseFormGetValues,
  UseFormRegister,
  UseFormSetError,
  UseFormSetValue,
  UseFormTrigger,
  UseFormWatch,
} from 'react-hook-form';

export interface ReactHookProps<T extends FieldValues> {
  register?: UseFormRegister<T>;
  control: Control<T>;
  errors: FieldErrors<T>;
  errorMessage?: string;
  setError?: UseFormSetError<T>;
  clearErrors?: UseFormClearErrors<T>;
  getValues?: UseFormGetValues<T>;
  setValue?: UseFormSetValue<T>;
  required?: boolean;
  minLength?: number;
  maxLength?: number;
  min?: number;
  max?: number;
  trigger?: UseFormTrigger<T>;
  isIp?: boolean;
  isLatLong?: boolean;
  isEmail?: boolean;
  customMessages?: {
    min?: string;
    max?: string;
    minLength?: string;
    maxLength?: string;
    pattern?: string;
  };
  validate?: any;
  watch?: UseFormWatch<T>;
}

export interface FormElementProps<T extends FieldValues> {
  label: string;
  propName: keyof T;
  rhProps: ReactHookProps<T>;
}
