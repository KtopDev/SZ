export interface Dropdown {
  dropdown: SelectOption[];
}

export interface SelectOption {
  id: string | string;
  displayName: string;
}
