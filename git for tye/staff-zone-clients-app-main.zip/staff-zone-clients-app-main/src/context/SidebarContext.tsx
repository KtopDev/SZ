'use client';
import React, { createContext, useContext, ReactNode, useState } from 'react';

interface SidebarContextType {
  selectedBranchId: string;
  setSelectedBranchId: (id: string) => void;
}

const SidebarContext = createContext<SidebarContextType | undefined>(undefined);

export const SidebarProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [selectedBranchId, setSelectedBranchId] = useState('4f468106-1ed2-44cc-8951-f2c682937d24');

  return (
    <SidebarContext.Provider
      value={{
        selectedBranchId,
        setSelectedBranchId,
      }}>
      {children}
    </SidebarContext.Provider>
  );
};

export const useSidebar = () => {
  const context = useContext(SidebarContext);
  if (context === undefined) {
    throw new Error('useSidebar must be used within an SidebarProvider');
  }
  return context;
};
