'use client';
import { MFATokenDto } from '@/types/dto/LoginFormDto';
import React, { createContext, ReactNode, useContext, useState } from 'react';

interface LoginContextType {
  mfaTokenDtoResponse: MFATokenDto;
  setMfaTokenDtoResponse: (mfaTokenDto: MFATokenDto) => void;
  email: string;
  setEmail: (email: string) => void;
  firstName: string;
  setFirstName: (email: string) => void;
}

const LoginContext = createContext<LoginContextType | undefined>(undefined);

export const LoginProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [mfaTokenDtoResponse, setMfaTokenDtoResponse] = useState<MFATokenDto>({} as MFATokenDto);
  const [email, setEmail] = useState('');
  const [firstName, setFirstName] = useState('');

  return (
    <LoginContext.Provider
      value={{
        mfaTokenDtoResponse,
        setMfaTokenDtoResponse,
        email,
        setEmail,
        firstName,
        setFirstName,
      }}>
      {children}
    </LoginContext.Provider>
  );
};

export const useLogin = () => {
  const context = useContext(LoginContext);
  if (context === undefined) {
    throw new Error('useLogin must be used within an LoginProvider');
  }
  return context;
};
