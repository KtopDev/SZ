import { LoginResponse, MfaPreference, MfaTokenDto } from '@/requests/api/authApi/types';
import Cookies from 'js-cookie';
import isUndefined from 'lodash/isUndefined';
import { jwtDecode } from 'jwt-decode';
import { AuthUser } from '@/utils/UserClosure/types';
import { allowedRoutes } from '@/utils/allowed-routes';

interface IUserClosure {
  getUser: () => AuthUser | null;
  handleLogout: () => void;
  getToken: () => string | null;
  handleLogin: (newToken: string) => void;
  isAuthenticated: () => boolean;
  setAuthProcessId: (string: string) => void;
  getMfaPreference: () => MfaPreference | null;
  setMfaPreference: (mfaPreference: MfaPreference) => void;
  getMfaTokenDto: () => MfaTokenDto | null;
  setMfaTokenDto: (mfaTokenDto: MfaTokenDto) => void;
  setUsername: (email: string) => void;
  getUsername: () => string | null;
  getAuthProcessId: () => string | null;
  saveLoginResponse: (response: LoginResponse) => void;
  getDaysSinceLastPasswordChange: () => number;
}

const UserClosure: IUserClosure = (() => {
  let token: string | null = null;
  let authProcessId: string | null = null;
  let loginResponse: LoginResponse | null = null;
  let mfaTokenDto: MfaTokenDto | null = null;
  let mfaPreference: MfaPreference | null = null;
  let username: string | null = null;

  const getToken = (): string | null => token;

  const getLoginResponse = (): LoginResponse | null => loginResponse;

  const saveLoginResponse = (response: LoginResponse): void => {
    loginResponse = response;
  };
  let user: AuthUser | null = null;

  const getUser = () => user;

  const handleLogin = (newToken: string): void => {
    token = newToken;
    Cookies.set('token', token, { path: '/' });
    setUserFromToken(newToken);
  };

  const setUserFromToken = (token: string): void => {
    user = jwtDecode(token);
  };

  const loadTokenFromCookies = (): void => {
    const tokenFromCookies = Cookies.get('token');
    if (tokenFromCookies !== 'undefined' && !isUndefined(tokenFromCookies)) {
      token = tokenFromCookies;
      setUserFromToken(token);
    } else {
      if (typeof window !== 'undefined') {
        const requestPath = window.location.pathname;
        if (!allowedRoutes.includes(requestPath)) {
          if (requestPath !== '/login') {
            // window.location.href = '/login';
          }
        }
      }
    }
  };

  const loadMfaDataFromCookies = (): void => {
    const mfaPreferenceFromCookies = Cookies.get('mfaPreference');
    const mfaTokenDtoFromCookies = Cookies.get('mfaTokenDto');
    if (mfaPreferenceFromCookies) {
      mfaPreference = JSON.parse(mfaPreferenceFromCookies);
    }
    if (mfaTokenDtoFromCookies) {
      mfaTokenDto = JSON.parse(mfaTokenDtoFromCookies);
    }
  };

  const getAuthProcessId = (): string | null => authProcessId;

  const setAuthProcessId = (id: string): void => {
    authProcessId = id;
  };

  const getUsername = (): string | null => username;

  const setUsername = (newUsername: string): void => {
    username = newUsername;
  };

  const getMfaPreference = (): MfaPreference | null => mfaPreference;

  const setMfaPreference = (newMfaPreference: MfaPreference): void => {
    mfaPreference = newMfaPreference;
    Cookies.set('mfaPreference', JSON.stringify(newMfaPreference), { path: '/' });
  };

  const getMfaTokenDto = (): MfaTokenDto | null => mfaTokenDto;

  const setMfaTokenDto = (newMfaTokenDto: MfaTokenDto): void => {
    mfaTokenDto = newMfaTokenDto;
    Cookies.set('mfaTokenDto', JSON.stringify(newMfaTokenDto), { path: '/' });
  };

  const clearAuthenticatedUser = (): void => {
    token = null;
    Cookies.remove('token');
    Cookies.remove('mfaPreference');
    Cookies.remove('mfaTokenDto');
    Cookies.remove('hasIgnorePasswordResetReminder');
  };

  const handleLogout = (): void => {
    clearAuthenticatedUser();
    // clear actual user through some BE endpoint
    // if (typeof window !== 'undefined') {
    //   window.location.href = '/login';
    // }
  };

  const isAuthenticated = (): boolean => !!token;

  const getDaysSinceLastPasswordChange = () => {
    return user?.auth_user_details.user.days_since_last_password_change || 0;
  };

  loadTokenFromCookies();
  loadMfaDataFromCookies();

  return {
    getUser,
    getToken,
    handleLogin,
    handleLogout,
    isAuthenticated,
    setAuthProcessId,
    getAuthProcessId,
    getMfaPreference,
    setMfaPreference,
    getMfaTokenDto,
    setMfaTokenDto,
    saveLoginResponse,
    getLoginResponse,
    getUsername,
    setUsername,
    getDaysSinceLastPasswordChange,
  };
})();

export default UserClosure;
