import UserClosure from './UserClosure';

export default UserClosure;
