type UserRole = {
  branches: string[] | null;
  role: string;
  roleClaims: string[] | null;
};

type UserDetails = {
  status: string;
  email: string;
  phone: string;
  roles: UserRole[];
  isPrimary: boolean | null;
  first_name: string;
  last_name: string;
  session_id: string;
  session_expire_ts: string;
  password_expire_ts: string;
  days_since_last_password_change: number | null;
  app_user_id: string;
  app_user_code: string;
  job_title: string;
  client_id: string | null;
  contact_id: string | null;
  can_rate_workers: boolean | null;
  can_approve_hours: boolean | null;
  worker_id: string | null;
  worker_code: string | null;
};

type AuthUserDetails = {
  user: UserDetails;
  terms: any | null;
};

export type AuthUser = {
  userType: string;
  auth_status: string;
  auth_process_id: string;
  auth_user_details: AuthUserDetails;
  sub: string;
  iat: number;
  exp: number;
};
