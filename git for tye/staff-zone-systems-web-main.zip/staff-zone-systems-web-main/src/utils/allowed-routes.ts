export const allowedRoutes = [
  '/reset-password',
  '/setup-password',
  '/settings',
  '/branches',
  '/company-settings',
  '/futa-suta-sdi',
];
