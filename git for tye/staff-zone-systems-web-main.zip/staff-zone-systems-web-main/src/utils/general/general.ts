export const formatPhoneNumber = (phoneNumber: string) =>
  phoneNumber ? phoneNumber.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3') : null;

export const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  const formattedDate = `${day}/${month}/${year}`;
  return formattedDate;
};

export const currencyFormatter = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
});

export const formatApiErrors = (e: any, setError: any, setMessage: (message: string) => void) => {
  if (e?.response?.data?.details?.length) {
    e.response.data.details.forEach((errorField: any) => {
      setError(errorField.field, { message: errorField.message });
      setMessage(errorField.message);
    });
  }
};

export const handleApiError = (error: any, setMessage: (message: string) => void, defaultMessage: string) => {
  const message = error?.response?.data?.message;
  const details = error?.response?.data?.details;
  if (message) {
    setMessage(error.response.data.message);
  }
  if (details) {
    if (details[0]) {
      setMessage(details[0].message);
    }
  } else {
    setMessage(defaultMessage);
  }
};
