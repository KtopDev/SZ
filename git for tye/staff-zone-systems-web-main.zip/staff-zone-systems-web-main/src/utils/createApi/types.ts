import { AxiosHeaders } from 'axios';

export enum ApiHookType {
  Query = 'query',
  LazyQuery = 'lazyQuery',
  Mutation = 'mutation',
}

export enum HttpMethod {
  GET = 'GET',
  POST = 'POST',
  PUT = 'PUT',
  PATCH = 'PATCH',
  DELETE = 'DELETE',
}

export interface EndpointConfig {
  query: (param: any) => { url: string; method?: HttpMethod; data?: any; headers?: any };
  successMessage?: string;
  errorMessage?: string | ((error: any) => string);
  transformResponse?: (response: any) => any;
  defaultValue?: any;
  headers?: AxiosHeaders | any;
}

export interface PaginatedListResponse<T> {
  content: T[];
  filters: any;
  page: number;
  totalPages: number;
  totalSize: number;
  hasNext: boolean;
  sort: string;
}
