/* eslint-disable react-hooks/rules-of-hooks */
import { useCallback, useEffect, useState } from 'react';
import isUndefined from 'lodash/isUndefined';
import isFunction from 'lodash/isFunction';
import { AxiosRequestConfig } from 'axios';
import { axiosInstance as axios } from '@/requests/axios-conf';
import { useSnackbar } from '@/context/SnackbarContext';
import { ApiHookType, EndpointConfig, HttpMethod } from '@/utils/createApi/types';

const QUERY_DEFAULT_HTTP_METHOD: HttpMethod = HttpMethod.GET;
const MUTATION_DEFAULT_HTTP_METHOD: HttpMethod = HttpMethod.POST;
const QUERY_DEFAULT_VALUE: any[] = [];

const capitalizeFirstLetter = (string: string) => string.charAt(0).toUpperCase() + string.slice(1);

const callApi = async ({ url, method, data, transformResponse, signal, headers }: AxiosRequestConfig) => {
  return axios({ url, method, data, signal, transformResponse, headers });
};

const handleError = ({
  error,
  errorMessage,
  dispatchErrorToContext,
}: {
  error: any;
  errorMessage?: string | ((error: any) => string);
  dispatchErrorToContext: (message: string) => void;
}) => {
  // eslint-disable-next-line no-console
  if (errorMessage) {
    const msg = isFunction(errorMessage) ? errorMessage(error) : errorMessage;
    dispatchErrorToContext(msg);
  }
};

const buildQueryHook = <T>(endpointConfig: EndpointConfig) => {
  return (
    param: any,
    config: {
      initialValue?: T;
      dependencies?: any[];
    } = {}
  ) => {
    const { query, errorMessage, transformResponse, defaultValue = QUERY_DEFAULT_VALUE } = endpointConfig;
    const { initialValue, dependencies } = config;
    const hookDependencies = isUndefined(dependencies) ? [param] : dependencies;

    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<any>(null);
    const [data, setData] = useState(() => (isUndefined(initialValue) ? defaultValue : initialValue));
    const { setMessage: dispatchErrorToContext } = useSnackbar();
    const [refetchIndex, setRefetchIndex] = useState(0); // Adding a refetch trigger

    useEffect(() => {
      const abortController = new AbortController();

      (async () => {
        setLoading(true);
        setError(null);

        try {
          const { url, method = QUERY_DEFAULT_HTTP_METHOD, data, headers } = query(param);
          const response = await callApi({
            url,
            method,
            data,
            headers,
            ...(transformResponse && { transformResponse: (json: string) => transformResponse(JSON.parse(json)) }),
            signal: abortController.signal,
          });
          setData(response.data);
        } catch (e) {
          if (!abortController.signal.aborted) {
            handleError({ error: e, errorMessage, dispatchErrorToContext });
            setData(defaultValue);
            setError(e);
          }
        } finally {
          if (!abortController.signal.aborted) {
            setLoading(false);
          }
        }
      })();

      return () => abortController.abort();
    }, [...hookDependencies, refetchIndex]); // Add refetchIndex to dependencies array

    const refetch = useCallback(() => setRefetchIndex((i) => i + 1), []);

    return { data, error, loading, refetch };
  };
};

const buildLazyHook = (endpointConfig: EndpointConfig, defaultMethod: HttpMethod) => () => {
  const { query, errorMessage, transformResponse } = endpointConfig;

  const [loading, setLoading] = useState(false);
  const { setMessage: dispatchErrorToContext } = useSnackbar();

  const handler = useCallback(
    async (param: any) => {
      setLoading(true);
      try {
        const { url, method = defaultMethod, data, headers } = query(param);
        return await callApi({ url, method, data, transformResponse, headers });
      } catch (e) {
        handleError({ error: e, errorMessage, dispatchErrorToContext });
        throw e;
      } finally {
        setLoading(false);
      }
    },
    [query, transformResponse, errorMessage, dispatchErrorToContext]
  );

  return [handler, { loading }];
};

const buildApiCallFunction =
  <T>(endpointConfig: EndpointConfig, defaultMethod: HttpMethod) =>
  async (param: any): Promise<T> => {
    const { query, errorMessage, transformResponse } = endpointConfig;
    const { setMessage: dispatchErrorToContext } = useSnackbar();

    try {
      const { url, method = defaultMethod, data } = query(param);
      const response = await callApi({ url, method, data, transformResponse });
      return response.data as T;
    } catch (e) {
      handleError({ error: e, errorMessage, dispatchErrorToContext });
      throw e;
    }
  };

export const createApi = ({
  queryApis = {},
  mutationApis = {},
}: {
  queryApis?: Record<string, EndpointConfig>;
  mutationApis?: Record<string, EndpointConfig>;
}) => {
  const api: Record<string, any> = {};

  Object.entries(queryApis).forEach(([endpointName, endpointConfig]) => {
    api[endpointName] = buildApiCallFunction(endpointConfig, QUERY_DEFAULT_HTTP_METHOD);

    const capitalizedEndpointName = capitalizeFirstLetter(endpointName);
    const hookName = `use${capitalizedEndpointName}`;
    api[hookName] = buildQueryHook(endpointConfig);
    api[hookName].config = {
      ...endpointConfig,
      type: ApiHookType.Query,
    };

    const lazyHookName = `useLazy${capitalizedEndpointName}`;
    api[lazyHookName] = buildLazyHook(endpointConfig, QUERY_DEFAULT_HTTP_METHOD);
    api[lazyHookName].config = {
      ...endpointConfig,
      type: ApiHookType.LazyQuery,
    };
  });

  Object.entries(mutationApis).forEach(([endpointName, endpointConfig]) => {
    api[endpointName] = buildApiCallFunction(endpointConfig, MUTATION_DEFAULT_HTTP_METHOD);

    const capitalizedEndpointName = capitalizeFirstLetter(endpointName);
    const hookName = `use${capitalizedEndpointName}`;
    api[hookName] = buildLazyHook(endpointConfig, MUTATION_DEFAULT_HTTP_METHOD);
    api[hookName].config = {
      ...endpointConfig,
      type: ApiHookType.Mutation,
    };
  });

  return api;
};
