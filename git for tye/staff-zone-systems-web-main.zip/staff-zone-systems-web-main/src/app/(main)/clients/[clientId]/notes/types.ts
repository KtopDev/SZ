export interface IClientNotesList {
  title: string;
  noteType: string;
  startDate: string;
  endDate: string;
}

export interface Note {
  clientNoteId: string;
  title: string;
  noteType: string;
  note: string;
  isRowActive: boolean;
  createdAt: string;
  createdBy: string;
  modifiedBy: string;
  modifiedAt: string;
}
