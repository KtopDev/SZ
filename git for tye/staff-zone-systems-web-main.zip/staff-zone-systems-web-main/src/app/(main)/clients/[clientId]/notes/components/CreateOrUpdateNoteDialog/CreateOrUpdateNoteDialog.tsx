import { useCreateNote, useUpdateNote } from '@/requests/api/clientsApi/clientsApi';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle } from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import * as React from 'react';
import { useMemo } from 'react';
import { ICreateOrUpdateNote } from '@/requests/api/clientsApi/types';
import { SubmitHandler, useForm } from 'react-hook-form';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Unstable_Grid2';
import RHTextField from '@/components/shared/Form/RHTextField';
import RHSelect from '@/components/shared/Form/RHSelect';
import { useSnackbar } from '@/context/SnackbarContext';
import RHTextareaAutosize from '@/components/shared/Form/RHTextarea';
import { Note } from '@/app/(main)/clients/[clientId]/notes/types';
import { noteTypes } from '@/app/(main)/clients/[clientId]/notes/components/CreateOrUpdateNoteDialog/constants/constants';

type Props = {
  open: boolean;
  setOpen: (param: boolean) => void;
  clientId: string;
  noteData?: Note;
  onSubmit: () => void;
};

const CreateOrUpdateNoteDialog = ({ open, setOpen, clientId, noteData, onSubmit }: Props) => {
  const {
    control,
    formState: { errors, isValid },
    handleSubmit,
    reset,
    getValues,
  } = useForm<ICreateOrUpdateNote>({
    defaultValues: {
      title: noteData?.title,
      noteType: noteData?.noteType,
      note: noteData?.note,
    },
    mode: 'onBlur',
  });

  const isCreate = useMemo(() => !noteData, [noteData]);

  const [createNote, { loading: isCreatingNote }] = useCreateNote();
  const [updateNote, { loading: isUpdatingNote }] = useUpdateNote();
  const { setMessage } = useSnackbar();
  const handleCreateNote: SubmitHandler<ICreateOrUpdateNote> = async (payload: ICreateOrUpdateNote) => {
    try {
      const mutationFn = isCreate ? createNote : updateNote;
      await mutationFn({ payload, clientId, noteId: noteData?.clientNoteId });
      setMessage(`Note ${isCreate ? 'added' : 'Edited'} successfully`);
      setOpen(false);
      onSubmit();
      reset();
    } catch (err) {
      // handle error
    }
  };

  const handleClose = (_?: any, reason?: string) => {
    if (reason !== 'backdropClick') {
      setOpen(false);
      reset();
    }
  };

  return (
    <>
      <Dialog open={open} onClose={handleClose} fullWidth>
        <DialogTitle>{isCreate ? 'Add' : 'Edit'} note</DialogTitle>
        <DialogContent>
          <Box py={2}>
            <Grid>
              <RHTextField<ICreateOrUpdateNote>
                label="Title"
                propName="title"
                margin="none"
                rhProps={{ errors, control }}
              />
              <RHSelect<ICreateOrUpdateNote>
                label="Type of note"
                propName="noteType"
                options={noteTypes}
                rhProps={{ errors, control, getValues }}
              />
              <RHTextareaAutosize<ICreateOrUpdateNote>
                minRows={8}
                label="Description"
                propName="note"
                rhProps={{ errors, control, maxLength: 300 }}
              />
            </Grid>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>CANCEL</Button>
          <LoadingButton
            disabled={!isValid}
            loading={isCreatingNote || isUpdatingNote}
            variant="contained"
            onClick={handleSubmit(handleCreateNote)}>
            {isCreate ? 'ADD NOTE' : 'EDIT NOTE'}
          </LoadingButton>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default CreateOrUpdateNoteDialog;
