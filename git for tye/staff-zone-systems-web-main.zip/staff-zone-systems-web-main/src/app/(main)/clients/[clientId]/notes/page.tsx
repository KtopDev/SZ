'use client';

import Box from '@mui/material/Box';
import Grid from '@mui/material/Unstable_Grid2';
import Typography from '@mui/material/Typography';
import { Button, TablePagination, TextField } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import * as React from 'react';
import { useEffect, useState } from 'react';
import { useForm, useWatch } from 'react-hook-form';
import { debounce } from 'lodash';
import RHSelect from '@/components/shared/Form/RHSelect';
import RHDatePicker from '@/components/shared/Form/RHDatePicker';
import { IClientNotesList } from '@/app/(main)/clients/[clientId]/notes/types';
import { useGetClientNotes } from '@/requests/api/clientsApi/clientsApi';
import CreateOrUpdateNoteDialog from '@/app/(main)/clients/[clientId]/notes/components/CreateOrUpdateNoteDialog/CreateOrUpdateNoteDialog';
import NoteCard from '@/app/(main)/clients/[clientId]/notes/components/NoteCard';
import { noteTypes } from '@/app/(main)/clients/[clientId]/notes/components/CreateOrUpdateNoteDialog/constants/constants';
import Image from 'next/image';

type Props = {
  params: {
    clientId: string;
  };
};

const ClientNotesPage = ({ params }: Props) => {
  const {
    control,
    formState: { errors },
    setValue,
    reset,
  } = useForm<IClientNotesList>({
    defaultValues: {
      title: '',
      noteType: '',
      startDate: '',
      endDate: '',
    },
  });

  const formValues = useWatch({ control: control });

  const [isCreateNoteModalOpen, setIsCreateNoteModalOpen] = useState(false);
  const [filter, setFilter] = useState<any>({
    payload: {
      page: 1,
      size: 20,
      title: '',
      noteType: '',
      startDate: '',
      endDate: '',
    },
    clientId: params.clientId,
  });

  useEffect(() => {
    setFilter((prevState: any) => ({
      ...prevState,
      payload: {
        ...prevState.payload,
        page: 1,
        title: formValues.title,
        noteType: formValues.noteType,
        startDate: formValues.startDate,
        endDate: formValues.endDate,
      },
    }));
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [formValues]);

  const handlePaginationChange = (pageIndex: number) => {
    setFilter((prevState: any) => ({
      ...prevState,
      payload: {
        ...prevState.payload,
        page: pageIndex,
      },
    }));
  };

  const { data: noteList } = useGetClientNotes(filter);

  const debouncedSetValue = debounce(setValue, 1000);
  const handleNameInputChange = (e: any) => {
    debouncedSetValue('title', e.target.value);
  };

  const onSubmit = () => {
    reset();
  };

  return (
    <>
      <CreateOrUpdateNoteDialog
        clientId={params.clientId}
        open={isCreateNoteModalOpen}
        setOpen={setIsCreateNoteModalOpen}
        onSubmit={onSubmit}
      />
      <Box paddingY="8px" paddingX="24px" bgcolor="common.white" border="none">
        <Grid container direction="row" justifyContent="space-between">
          <Grid>
            <Typography paddingTop="4px" fontWeight="regular" fontSize={16}>
              Notes
            </Typography>
            <Typography fontWeight="regular" fontSize={18}>
              Phillip and Steve furniture
            </Typography>
          </Grid>
          <Box paddingY="5px">
            <Button onClick={() => setIsCreateNoteModalOpen(true)} variant="contained" startIcon={<AddIcon />}>
              CREATE
            </Button>
          </Box>
        </Grid>
        <Box sx={{ flexGrow: 1 }}>
          <Grid container alignItems="end" spacing={2} columns={16}>
            <Grid xs={6}>
              <TextField
                fullWidth
                InputProps={{
                  startAdornment: <SearchIcon />,
                }}
                placeholder="Search by title"
                id="outlined-basic"
                variant="outlined"
                onChange={handleNameInputChange}
              />
            </Grid>
            <Grid xs={6} py="0px">
              <RHSelect<IClientNotesList>
                label="Type of note"
                propName="noteType"
                options={noteTypes}
                // isLoading={isBranchListLoading}
                rhProps={{ errors, control, required: false }}
              />
            </Grid>
            <Grid xs={2}>
              <Typography fontSize={14} paddingBottom="8px">
                Creation date
              </Typography>
              <RHDatePicker<IClientNotesList>
                label="Start date"
                propName="startDate"
                rhProps={{ errors, control, required: false }}
              />
            </Grid>
            <Grid xs={2}>
              <RHDatePicker<IClientNotesList>
                label="End date"
                propName="endDate"
                rhProps={{ errors, control, required: false }}
              />
            </Grid>
          </Grid>
          <Grid>
            <Box paddingY="8px">
              <TablePagination
                component="div"
                count={noteList.totalSize || 0}
                sx={{
                  padding: 0,
                }}
                rowsPerPage={20}
                rowsPerPageOptions={[]}
                page={filter.payload.page - 1}
                onPageChange={(_, pageIndex) => handlePaginationChange(pageIndex + 1)}
                onRowsPerPageChange={() => null}
              />
            </Box>
          </Grid>
        </Box>
      </Box>
      <Box paddingY="16px" paddingX="24px" border="none">
        {noteList?.content?.length ? (
          noteList.content.map((note) => (
            <NoteCard clientId={params.clientId} key={note.clientNoteId} item={note} onSubmit={onSubmit} />
          ))
        ) : (
          <Box display="flex" flexDirection="column" justifyContent="center" alignItems="center" paddingTop={10}>
            <Image src={'/images/empty-table/staff-zone.svg'} alt="Logo" width={180} height={140} />
            <Typography>There is no data to show here yet</Typography>
          </Box>
        )}
      </Box>
    </>
  );
};

export default ClientNotesPage;
