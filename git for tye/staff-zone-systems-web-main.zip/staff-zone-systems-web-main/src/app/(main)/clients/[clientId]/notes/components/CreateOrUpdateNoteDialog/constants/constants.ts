import { Dropdown } from '@/types/Dropdown';

export const noteTypes: Dropdown = {
  dropdown: [
    {
      id: 'GENERAL_NOTE',
      displayName: 'General Note',
    },
    {
      id: 'CREDIT_AND_COLLECTIONS',
      displayName: 'Credit and Collections',
    },
    {
      id: 'HUMAN_RESOURCES',
      displayName: 'Human Resources',
    },
    {
      id: 'SALES_SERVICE',
      displayName: 'Sales & Service',
    },
  ],
};
