'use client';

import { SubmitHandler } from 'react-hook-form';
import { IUpdateClient } from '@/app/(main)/clients/create-client/types';
import BaseClientForm from '@/app/(main)/clients/components/BaseClientForm';
import { useGetClientDetails, useUpdateClient } from '@/requests/api/clientsApi/clientsApi';
import { useRouter } from 'next/navigation';
import { useGetDropdownBranchList } from '@/requests/api/branchesApi/branchesApi';
import { useSnackbar } from '@/context/SnackbarContext';

type Props = {
  params: {
    clientId: string;
  };
};

const UpdateClient = ({ params }: Props) => {
  const { setMessage } = useSnackbar();
  const router = useRouter();
  const [updateClient, { loading: isClientUpdateLoading }] = useUpdateClient();
  const { data: branchesList, loading: isBranchesListLoading } = useGetDropdownBranchList();
  const { data: clientData, loading: isClientDataLoading } = useGetClientDetails(params.clientId);

  const onSubmit: SubmitHandler<IUpdateClient> = async (formData: IUpdateClient) => {
    try {
      await updateClient({ ...formData, client_id: params.clientId, contactId: clientData.contact.id.contactId });
      setMessage('Client updated successfully');
      router.push('/clients');
    } catch (e) {
      // handle error
    }
  };

  return (
    !isClientDataLoading &&
    !isBranchesListLoading && (
      <BaseClientForm
        clientData={clientData}
        onSubmit={onSubmit}
        branchesList={branchesList}
        isBranchesListLoading={isBranchesListLoading}
        isLoading={isClientUpdateLoading || isClientDataLoading}
        isCreate={false}
      />
    )
  );
};

export default UpdateClient;
