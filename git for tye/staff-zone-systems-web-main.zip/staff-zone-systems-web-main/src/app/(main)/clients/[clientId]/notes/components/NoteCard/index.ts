import NoteCard from './NoteCard';

export default NoteCard;
