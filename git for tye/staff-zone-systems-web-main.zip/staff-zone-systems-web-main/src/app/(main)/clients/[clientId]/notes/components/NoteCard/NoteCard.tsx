import {
  Button,
  Card,
  CardContent,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Menu,
  MenuItem,
} from '@mui/material';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import DownloadIcon from '@mui/icons-material/Download';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import IconButton from '@mui/material/IconButton';
import { useState } from 'react';
import CreateOrUpdateNoteDialog from '../CreateOrUpdateNoteDialog';
import { useSnackbar } from '@/context/SnackbarContext';
import { useDeleteNote } from '@/requests/api/clientsApi/clientsApi';
import LoadingButton from '@mui/lab/LoadingButton';
import dayjs from 'dayjs';
import { Note } from '@/app/(main)/clients/[clientId]/notes/types';

type Props = {
  item: Note;
  onSubmit: () => void;
  clientId: string;
};

const NoteCard = ({ item, onSubmit, clientId }: Props) => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const [openDeleteModal, setDeleteModalOpen] = useState(false);
  const [isUpdateNoteModalOpen, setIsUpdateNoteModalOpen] = useState(false);
  const [deleteNote, { loading: isDeletingNote }] = useDeleteNote();
  const { setMessage } = useSnackbar();

  const handleClick = (event: any) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleCloseModal = () => {
    setDeleteModalOpen(false);
  };

  const onEditClick = () => {
    setIsUpdateNoteModalOpen(true);
    handleClose();
  };

  const onDeleteClick = async () => {
    try {
      await deleteNote({ clientId, noteId: item.clientNoteId });
      setMessage('Note deleted successfully');
      handleClose();
      onSubmit();
    } catch (e) {
      // handle error
    }
  };

  return (
    <Box paddingBottom="24px">
      <CreateOrUpdateNoteDialog
        clientId={clientId}
        onSubmit={onSubmit}
        open={isUpdateNoteModalOpen}
        setOpen={setIsUpdateNoteModalOpen}
        noteData={item}
      />
      <Card elevation={2}>
        <CardContent>
          <Box pb={2} display="flex" justifyContent="space-between" alignContent="center">
            <div>
              <Typography fontWeight={500}>{item.title}</Typography>
              <Typography color="grey" fontWeight={500} fontSize={12}>
                Created on {dayjs(item.createdAt).format('YYYY/MM/DD')}
              </Typography>
            </div>

            <div>
              <Button component="label" variant="text" startIcon={<DownloadIcon />}>
                EXPORT NOTE
              </Button>
              <IconButton
                id="options-button"
                aria-controls={open ? 'card-menu' : undefined}
                aria-haspopup="true"
                aria-expanded={open ? 'true' : undefined}
                onClick={handleClick}>
                <MoreVertIcon />
              </IconButton>
              <Menu
                id="card-menu"
                anchorEl={anchorEl}
                open={open}
                onClose={handleClose}
                MenuListProps={{
                  'aria-labelledby': 'options-button',
                }}>
                <MenuItem onClick={onEditClick}>Edit note</MenuItem>
                <MenuItem onClick={() => setDeleteModalOpen(true)}>
                  <Typography color="error">Delete note</Typography>
                </MenuItem>
              </Menu>
            </div>
          </Box>
          <Typography variant="body2">{item.note}</Typography>
        </CardContent>
      </Card>

      <Dialog
        open={openDeleteModal}
        onClose={handleCloseModal}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description">
        <DialogTitle id="alert-dialog-title">Delete note</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            Are you sure you want to delete this note? this action can’t be reversed.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseModal}>CANCEL</Button>
          <LoadingButton loading={isDeletingNote} color="error" variant="contained" onClick={onDeleteClick} autoFocus>
            DELETE NOTE
          </LoadingButton>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default NoteCard;
