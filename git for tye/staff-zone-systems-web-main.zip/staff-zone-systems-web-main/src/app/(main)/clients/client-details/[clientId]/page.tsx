'use client';
import BasicInformation from '@/app/(main)/clients/client-details/components/BasicInformation';
import BillingInformation from '@/app/(main)/clients/client-details/components/BillingInformation';
import MainContact from '@/app/(main)/clients/client-details/components/MainContact';
import { Box, CircularProgress, Container, Divider } from '@mui/material';
import { useGetRawClientDetails } from '@/requests/api/clientsApi/clientsApi';
import Actions from '@/app/(main)/clients/client-details/components/Actions';

export default function BranchDetails({ params }: { params: { clientId: string } }) {
  const { data: clientData, loading: isClientDataLoading } = useGetRawClientDetails(params.clientId);
  return (
    <>
      <Container maxWidth={false}>
        <Actions client={clientData} />
        <Divider />
        {isClientDataLoading ? (
          <Box sx={{ display: 'flex' }}>
            <CircularProgress />
          </Box>
        ) : (
          <>
            <BasicInformation client={clientData} />
            <Divider />
            <BillingInformation client={clientData} />
            <Divider />
            <MainContact client={clientData} />
          </>
        )}
      </Container>
    </>
  );
}
