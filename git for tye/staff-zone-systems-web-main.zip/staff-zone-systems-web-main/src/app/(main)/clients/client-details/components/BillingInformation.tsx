'use client';
import React from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import { Typography } from '@mui/material';
import NonEditableTextField from '@/components/shared/Panel/DisplayTextField';
import { ClientDTO } from '@/types/dto/Client';

type Props = {
  client: ClientDTO;
};

export default function BillingInformation({ client }: Props) {
  return (
    <>
      <Typography variant="h6" gutterBottom mt={2} mb={-1}>
        Billing information
      </Typography>
      <Grid container spacing={2} mb={2}>
        <Grid xs={10} sm={10} md={10} lg={12}>
          <NonEditableTextField label="Invoice method" value={client.invoiceMethod?.label} />
          <NonEditableTextField label="Invoice format" value={client.invoicePrintingFormat?.printingFormatName} />
          <NonEditableTextField label="Main phone" formatType="phone" value={client.phone} />
          <NonEditableTextField label="Fax line" formatType="phone" value={client.fax} />
          <NonEditableTextField label="Address" value={client.address} />
        </Grid>
      </Grid>
    </>
  );
}
