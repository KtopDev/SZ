'use client';
import React from 'react';
import EditIcon from '@mui/icons-material/Edit';
import { Button, Typography } from '@mui/material';
import { ClientDTO } from '@/types/dto/Client';

type Props = {
  client: ClientDTO;
};

export default function Actions({ client }: Props) {
  return (
    <div style={styles.container}>
      <Typography variant="h4" gutterBottom mt={1}>
        {client.clientName}
      </Typography>
      <div>
        <Button variant="outlined" startIcon={<EditIcon sx={{ marginRight: 1 }} />}>
          EDIT
        </Button>
      </div>
    </div>
  );
}

const styles = {
  container: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  activationButon: {
    marginRight: 5,
  },
};
