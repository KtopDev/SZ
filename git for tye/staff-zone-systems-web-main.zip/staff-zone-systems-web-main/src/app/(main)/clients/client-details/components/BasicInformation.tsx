'use client';
import React from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import { Typography } from '@mui/material';
import NonEditableTextField from '@/components/shared/Panel/DisplayTextField';
import DisplayStatusField from '@/components/shared/Panel/DisplayStatusField';
import { ClientDTO } from '@/types/dto/Client';
import DisplayValues from '@/components/shared/Panel/DisplayValues';

type Props = {
  client: ClientDTO;
};

export default function BasicInformation({ client }: Props) {
  return (
    <>
      <Typography variant="h6" gutterBottom mt={2} mb={-1}>
        Basic information
      </Typography>
      <Grid container spacing={2} mb={2}>
        <Grid xs={10} sm={10} md={10} lg={12}>
          <DisplayStatusField label="Status" value={client.status} />
          <NonEditableTextField label="Credit limit" formatType="currency" value={client.creditLimit} />
          <NonEditableTextField label="Client terms" value={client.paymentTerm?.label} />
          <NonEditableTextField label="Comp code" value={client.compCode?.compCode} />
        </Grid>
        <Grid xs={12} sm={12} md={12} lg={12}>
          <DisplayValues label="Branches" values={client.branchNames} />
        </Grid>
      </Grid>
    </>
  );
}
