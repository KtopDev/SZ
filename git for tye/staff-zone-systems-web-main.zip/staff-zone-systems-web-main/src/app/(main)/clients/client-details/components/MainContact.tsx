'use client';
import React from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import { Card, CardContent, Typography } from '@mui/material';
import { ClientDTO } from '@/types/dto/Client';

type Props = {
  client: ClientDTO;
};

export default function MainContact({ client }: Props) {
  return (
    <>
      <Typography variant="h6" gutterBottom mt={2} mb={-1}>
        Main contact
      </Typography>
      <Grid container spacing={2} mb={2}>
        <Grid xs={12} sm={12} md={12} lg={12}>
          <Card>
            <CardContent>
              <Typography gutterBottom variant="h5" component="div" mb={0}>
                {client.contact?.name} {client.contact?.lastName}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Email addess: {client.contact?.email}
                <br />
                Phone number: {client.contact?.phone}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </>
  );
}
