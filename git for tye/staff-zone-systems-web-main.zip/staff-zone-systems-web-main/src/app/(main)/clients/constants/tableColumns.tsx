import { MRT_ColumnDef, MRT_Row } from 'material-react-table';
import Typography from '@mui/material/Typography';
import { Chip, Stack } from '@mui/material';

enum Status {
  ACTIVE = 'ACTIVE',
  INACTIVE = 'INACTIVE',
  IN_LEGAL = 'IN LEGAL',
  DNS = 'DNS',
}

const chipStatusMap: Record<Status, JSX.Element> = {
  [Status.ACTIVE]: <Chip size="small" label="Active" color="success" />,
  [Status.INACTIVE]: <Chip size="small" label="Inactive" />,
  [Status.IN_LEGAL]: <Chip size="small" label="In Legal" color="secondary" />,
  [Status.DNS]: <Chip size="small" label="DNS" color="error" />,
};

export const columns = (router: any): MRT_ColumnDef<any>[] => [
  {
    accessorKey: 'client_code',
    header: 'ID',
    Cell: ({ row }: { row: MRT_Row<any> }) => (
      <Typography
        fontWeight="500"
        color="primary"
        sx={{ cursor: 'pointer' }}
        onClick={() => {
          const client_id = row.original.client_id;
          router.push(`/clients/client-details/${client_id}`);
        }}>
        #{row.original.client_code}
      </Typography>
    ),
  },
  { accessorKey: 'client_name', header: 'Client Name' },
  { accessorKey: 'last_order_branch', header: "Last order's branch" },
  { accessorKey: 'last_order_date', header: "Last order's date" },
  { accessorKey: 'last_invoice_date', header: "Last invoice's date" },
  {
    header: 'Status',
    accessorKey: 'status',
    Cell: ({ row }: { row: MRT_Row<any> }) => {
      const state: Status = row.original.status;

      return chipStatusMap[state];
    },
  },
  {
    accessorKey: 'unpaid_invoices',
    header: 'Unpaid invoices',
    Cell: ({ row }: { row: MRT_Row<any> }) => (
      <Stack direction="row" spacing={1}>
        <Chip size="small" label={row.original.unpaidInvoices} color="error" variant="outlined" />
        <Typography fontWeight="500" color="primary" component="label">
          INVOICES
        </Typography>
      </Stack>
    ),
  },
];
