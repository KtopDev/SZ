import MainContactCard from '@/app/(main)/clients/components/MainContactCard/MainContactCard';

export default MainContactCard;
