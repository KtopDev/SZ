import BaseClientForm from './BaseClientForm';

export default BaseClientForm;
