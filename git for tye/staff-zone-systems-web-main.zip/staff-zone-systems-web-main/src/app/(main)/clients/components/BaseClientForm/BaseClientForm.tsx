import React from 'react';
import Divider from '@mui/material/Divider';
import Link from '@/components/shared/Link';
import { ClientDTO } from '@/app/(main)/clients/types';
import { Alert, Box, Button } from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import { useForm, useWatch } from 'react-hook-form';
import { ICreateClient } from '@/app/(main)/clients/create-client/types';
import MainContact from '@/app/(main)/clients/create-client/components/MainContact';
import OtherSettings from '@/app/(main)/clients/create-client/components/OtherSettings';
import { defaultCreateClient } from '@/app/(main)/clients/create-client/constants/contants';
import BasicInformation from '@/app/(main)/clients/create-client/components/BasicInformation';
import BillingInformation from '@/app/(main)/clients/create-client/components/BillingInformation';
import AddressInformation from '@/app/(main)/clients/create-client/components/AddressInformation';
import AuthenticationSection from '@/app/(main)/clients/create-client/components/AuthenticationSection';
import { Dropdown } from '@/types/Dropdown';
import MainContactCard from '@/app/(main)/clients/components/MainContactCard';

type Props = {
  isCreate: boolean;
  isLoading: boolean;
  branchesList?: Dropdown;
  clientData?: ClientDTO;
  isBranchesListLoading?: boolean;
  onSubmit: (formData: any, setError: any) => void;
};

const BaseClientForm = ({ onSubmit, isLoading, isCreate, clientData, branchesList, isBranchesListLoading }: Props) => {
  const {
    control,
    formState: { errors, isValid },
    handleSubmit,
    getValues,
    setError,
  } = useForm<ICreateClient>({ defaultValues: isCreate ? defaultCreateClient : clientData, mode: 'onChange' });
  const branches = useWatch({ control: control, name: 'branches' });

  const getFirstBranchDisplayName = () =>
    branchesList?.dropdown.find((branch) => branches[0] === branch.id)?.displayName;

  return (
    <Box paddingX="24px" py={2}>
      <BasicInformation
        rhProps={{ control, errors, getValues }}
        branchesList={branchesList}
        isBranchesListLoading={isBranchesListLoading}
      />
      <Box py={2}>
        <Divider />
      </Box>
      <BillingInformation rhProps={{ control, errors, getValues }} />
      <AddressInformation rhProps={{ control, errors, getValues }} />
      <Box py={2}>
        <Divider />
      </Box>
      <OtherSettings rhProps={{ control, errors, getValues }} />
      <Box py={2}>
        <Divider />
      </Box>
      {isCreate ? (
        <MainContact rhProps={{ control, errors, getValues }} />
      ) : (
        <MainContactCard contact={clientData?.contact} />
      )}
      {isCreate && <AuthenticationSection rhProps={{ control, errors, getValues }} />}
      {branches?.length > 0 && (
        <Box py={2}>
          {isCreate && (
            <Alert severity="warning" sx={{ justifyContent: 'space-between' }}>
              Client will be created in branch {getFirstBranchDisplayName()} Verify that this is the branch in which you
              intended to create this client. Continue if this is correct.
            </Alert>
          )}
        </Box>
      )}
      <Box display="flex" justifyContent="flex-end">
        <Link href={'/clients'}>
          <Button variant="outlined">CANCEL</Button>
        </Link>
        <LoadingButton
          disabled={!isValid}
          startIcon={null}
          loading={isLoading}
          variant="contained"
          color="primary"
          sx={{ marginLeft: 1 }}
          onClick={handleSubmit((formValues) => onSubmit(formValues, setError))}>
          {isCreate ? 'CREATE CLIENT' : 'SAVE CHANGES'}
        </LoadingButton>
      </Box>
    </Box>
  );
};

export default BaseClientForm;
