import { Button, Card, CardContent, Chip } from '@mui/material';
import React from 'react';
import Box from '@mui/material/Box';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import { formatPhoneNumber } from '@/utils/general/general';
import DoneIcon from '@mui/icons-material/Done';
import { ContactDTO } from '@/app/(main)/clients/types';

type Props = {
  contact: ContactDTO | undefined;
};

const mainContactCard = ({ contact }: Props) => {
  return contact ? (
    <>
      <Typography variant="h6">Main contact</Typography>
      <Card>
        <CardContent>
          <Box pb={2} display="flex" justifyContent="space-between" alignContent="center">
            <div>
              <Typography fontSize={18} fontWeight={500}>
                {contact.name} {contact.lastName}
              </Typography>
              <Chip color="secondary" size="small" label="Main contact" />
              <Typography>{contact.email}</Typography>
              <Typography>{formatPhoneNumber(contact.phone)}</Typography>
            </div>
            <div>
              <Button variant="text">Edit</Button>
              <IconButton>
                <MoreVertIcon />
              </IconButton>
            </div>
          </Box>
          <Box pb={2}>
            <Typography fontSize="12px">Permissions</Typography>
            <Box display="flex">
              {contact.isAppAccessEnabled && (
                <Box pr={1}>
                  <Chip
                    size="small"
                    icon={<DoneIcon />}
                    label="Can access to Client app"
                    color="success"
                    variant="outlined"
                  />
                </Box>
              )}
              {contact.canReceiveInvoices && (
                <Box pr={1}>
                  <Chip size="small" icon={<DoneIcon />} label="Can recieve bills" color="success" variant="outlined" />
                </Box>
              )}
              {contact.canApproveHours && (
                <Box pr={1}>
                  <Chip
                    size="small"
                    icon={<DoneIcon />}
                    label="Can approve hours and create orders"
                    color="success"
                    variant="outlined"
                  />
                </Box>
              )}
              {contact.canRateWorkers && (
                <Box pr={1}>
                  <Chip size="small" icon={<DoneIcon />} label="Can rate workers" color="success" variant="outlined" />
                </Box>
              )}
            </Box>
          </Box>
          <Box>
            <Typography fontSize="12px">Active projects</Typography>
            <Box display="flex">
              <Box pr={1}>
                <Chip size="small" label="Some project" variant="outlined" />
              </Box>
            </Box>
          </Box>
        </CardContent>
      </Card>
      <Button sx={{ mt: 2 }} variant="outlined">
        CHANGE MAIN CONTACT
      </Button>
    </>
  ) : null;
};

export default mainContactCard;
