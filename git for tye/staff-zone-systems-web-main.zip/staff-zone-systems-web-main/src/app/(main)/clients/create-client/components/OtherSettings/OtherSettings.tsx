import RHSelect from '@/components/shared/Form/RHSelect';
import type { SelectOption } from '@/types/Dropdown';
import Grid from '@mui/material/Unstable_Grid2';
import React from 'react';
import { Typography } from '@mui/material';
import { useGetDropdownCompCodes } from '@/requests/api/compCodesApi/compCodesApi';
import { useWatch } from 'react-hook-form';
import { FormSectionProps, ICreateClient } from '@/app/(main)/clients/create-client/types';

const OtherSettings = ({ rhProps }: FormSectionProps<ICreateClient>) => {
  const { errors, control, getValues } = rhProps;
  const state = useWatch({ control: control, name: 'state' });
  const { data: compCodes, loading: isCompCodeLoading } = useGetDropdownCompCodes(state);

  return (
    <>
      <Typography variant="h6">Other settings</Typography>
      <Grid xs={12} sm={12} lg={12}>
        <RHSelect<ICreateClient>
          label="Comp code for this client"
          propName="clientCompCodeId"
          options={compCodes}
          getOptionLabel={(option: SelectOption) => `${option.displayName}`}
          renderOption={(props, option: SelectOption) => <li {...props}>{`${option.displayName}`}</li>}
          isLoading={isCompCodeLoading}
          rhProps={{ errors, control, getValues }}
        />
      </Grid>
    </>
  );
};

export default OtherSettings;
