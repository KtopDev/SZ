import { ReactHookProps } from '@/types/forms/RHProps';
import { FieldValues } from 'react-hook-form';

export interface ICreateClient {
  clientName: string;
  creditLimit: number | null;
  clientTerms: string;
  branches: string[];
  invoiceMethod: string;
  invoiceFormat: string;
  streetAddressLine1: string;
  streetAddressLine2: string;
  city: string;
  state: string;
  zipCode: string;
  mainPhone: string;
  faxLine: string;
  clientCompCodeId: string;
  name: string;
  lastName: string;
  email: string;
  cellPhone: string;
  preferredMultiFactor: string;
  isClientAppEnable: boolean;
  isBillAndInvoiceEnable: boolean;
  isApprovalAndCreationEnable: boolean;
  isRateWorkersEnable: boolean;
  multiFactorAuthenticationTtlDays: string;
}

export interface IUpdateClient {
  client_id: string;
  clientId: string;
  contactId: string;
  clientName: string;
  creditLimit: number | null;
  clientTerms: string;
  branches: string[];
  invoiceMethod: string;
  invoiceFormat: string;
  streetAddressLine1: string;
  streetAddressLine2: string;
  city: string;
  state: string;
  status: string;
  zipCode: string;
  mainPhone: string;
  faxLine: string;
  clientCompCodeId: string;
  preferredMultiFactor: string;
}

export type FormSectionProps<T extends FieldValues> = {
  rhProps: ReactHookProps<T>;
};
