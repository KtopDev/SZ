'use client';
import React from 'react';
import Link from '@/components/shared/Link';
import { MenuItem } from '@mui/material';
import Typography from '@mui/material/Typography';
import { capitalize, startCase, toLower, upperCase } from 'lodash';
import { IUpdateClient } from '../../types';

interface RenderRowActionMenuItemsProps {
  row: any;
  executeAction: (row: any, oldClient: IUpdateClient, newClient: IUpdateClient, closeMenu: () => void) => void;
  closeMenu: () => void;
}

const renderInactiveButton = (status: string) => capitalize(status) === 'Active';
const renderInLegalButton = (status: string) => capitalize(status) === 'Active';
const renderDNSButton = (status: string) => capitalize(status) === 'Active';
const renderActiveButton = (status: string) => capitalize(status) === 'Inactive';
const renderRemoveInLegalButton = (status: string) => startCase(toLower(status)) === 'In Legal';
const renderDisabledDNSButton = (status: string) => startCase(toLower(status)) === 'In Legal';
const renderRemoveDNSButton = (status: string) => upperCase(status) === 'DNS';

export const RenderRowActionMenuItems = ({ closeMenu, row, executeAction }: RenderRowActionMenuItemsProps) => {
  const handleBody = (row: { original: any }, newStatus: string) => {
    const clientId = row.original.id;
    const clientClone = { ...row.original } as IUpdateClient;
    clientClone.clientId = clientId;
    clientClone.status = newStatus;
    return clientClone;
  };

  const callAction = (newStatus: string) => {
    executeAction(row, row.original, handleBody(row, newStatus), closeMenu);
  };

  return [
    <Link key="editClient" href={`clients/${row.original.client_id}/update-client`}>
      <MenuItem>Edit client</MenuItem>
    </Link>,
    <MenuItem key="addNote">Add note {startCase(toLower(row.original.status))}</MenuItem>,
    <Link key="notes" href={`clients/${row.original.client_id}/notes`}>
      <MenuItem>Go to notes</MenuItem>
    </Link>,
    <MenuItem key="deleteClient">Delete client</MenuItem>,
    renderInLegalButton(row.original.status) && (
      <MenuItem onClick={() => callAction('IN LEGAL')}>{'Set status as “In Legal“'}</MenuItem>
    ),
    renderRemoveInLegalButton(row.original.status) && (
      <MenuItem onClick={() => callAction('ACTIVE')}>{'Remove “In Legal“ status'}</MenuItem>
    ),
    renderInactiveButton(row.original.status) && (
      <MenuItem onClick={() => callAction('INACTIVE')}>{'Set status as “Inactive“'}</MenuItem>
    ),
    renderActiveButton(row.original.status) && (
      <MenuItem onClick={() => callAction('ACTIVE')}>
        <Typography color="green">{'Set status as “Active“'}</Typography>
      </MenuItem>
    ),
    renderDisabledDNSButton(row.original.status) && (
      <MenuItem disabled>
        <Typography color="gray">DNS</Typography>
      </MenuItem>
    ),
    renderDNSButton(row.original.status) && (
      <MenuItem onClick={() => callAction('DNS')}>
        <Typography color="error">DNS</Typography>
      </MenuItem>
    ),
    renderRemoveDNSButton(row.original.status) && (
      <MenuItem onClick={() => callAction('ACTIVE')}>
        <Typography color="error">Remove DNS</Typography>
      </MenuItem>
    ),
  ];
};
