import React from 'react';
import { Typography } from '@mui/material';
import Box from '@mui/material/Box';
import RHRadioGroup from '@/components/shared/Form/RHRadioGroup';
import { FormSectionProps, ICreateClient } from '@/app/(main)/clients/create-client/types';
import RHMaskedInput from '@/components/shared/Form/RHMaskedInput';
import Grid from '@mui/material/Unstable_Grid2';

const AuthenticationSection = ({ rhProps }: FormSectionProps<ICreateClient>) => {
  return (
    <>
      <Typography variant="h6" py={2}>
        Multi-Factor Authentication (MFA)
      </Typography>
      <Typography>Method</Typography>
      <Typography fontSize="12px">Choose where to receive the authentication code</Typography>

      <Box px={2}>
        <RHRadioGroup
          labels={['SMS', 'Email', 'Authenticator app', 'None (not recommended)']}
          values={['SMS', 'EMAIL', 'authApp', 'NONE']}
          propName="preferredMultiFactor"
          rhProps={rhProps}
        />
      </Box>

      <Grid xs={12} sm={12} lg={12}>
        <RHMaskedInput<ICreateClient>
          label="Request MFA again after _ days"
          propName="multiFactorAuthenticationTtlDays"
          mask="99 days"
          maskPlaceholder="_  days"
          rhProps={rhProps}
          helperText="Days before client's Users are logged out and new code is needed"
        />
      </Grid>
    </>
  );
};

export default AuthenticationSection;
