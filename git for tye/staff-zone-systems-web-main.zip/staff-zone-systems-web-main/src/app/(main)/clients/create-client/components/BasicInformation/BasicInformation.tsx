import { Typography } from '@mui/material';
import React from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import RHTextField from '@/components/shared/Form/RHTextField';
import RHSelect from '@/components/shared/Form/RHSelect';
import RHCurrency from '@/components/shared/Form/RHCurrency';
import RHMultiSelect from '@/components/shared/Form/RHMultiSelect';
import { useGetDropdownPaymentMethods } from '@/requests/api/clientsApi/clientsApi';
import { Dropdown } from '@/types/Dropdown';
import { FieldValues } from 'react-hook-form';
import { ReactHookProps } from '@/types/forms/RHProps';
import { ICreateClient } from '@/app/(main)/clients/create-client/types';

type Props<T extends FieldValues> = {
  rhProps: ReactHookProps<T>;
  branchesList?: Dropdown;
  isBranchesListLoading?: boolean;
};

const BasicInformation = ({ rhProps, branchesList, isBranchesListLoading }: Props<ICreateClient>) => {
  const { control, errors, getValues } = rhProps;
  const { data: paymentMethods, loading: isPaymentMethodsLoading } = useGetDropdownPaymentMethods();

  return (
    <>
      <Typography variant="h6">Basic information</Typography>
      <Typography variant="subtitle2" mb={1}>
        Client&apos;s basic details
      </Typography>

      <Grid container spacing={2}>
        <Grid xs={12} sm={12} lg={4} mb={-2}>
          <RHTextField<ICreateClient>
            label="Client name"
            propName="clientName"
            rhProps={{ errors, control, getValues }}
          />
        </Grid>
        <Grid xs={12} sm={12} lg={4} mb={-2}>
          <RHCurrency<ICreateClient>
            label="Credit limit"
            propName="creditLimit"
            rhProps={{ errors, control, getValues }}
          />
        </Grid>
        <Grid xs={12} sm={12} lg={4} mb={-2}>
          <RHSelect<ICreateClient>
            label="Client terms"
            propName="clientTerms"
            options={paymentMethods}
            isLoading={isPaymentMethodsLoading}
            rhProps={{ errors, control, getValues }}
          />
        </Grid>
        <Grid xs={12} sm={12} lg={12}>
          <RHMultiSelect<ICreateClient>
            label="Branches"
            propName="branches"
            options={branchesList as Dropdown}
            isLoading={isBranchesListLoading}
            rhProps={{ errors, control, getValues }}
          />
        </Grid>
      </Grid>
    </>
  );
};

export default BasicInformation;
