import { Typography } from '@mui/material';
import Grid from '@mui/material/Unstable_Grid2';
import RHTextField from '@/components/shared/Form/RHTextField';
import RHSelect from '@/components/shared/Form/RHSelect';
import RHMaskedInput from '@/components/shared/Form/RHMaskedInput';
import * as React from 'react';
import { useGetDropdownState } from '@/requests/api/statesApi/statesApi';
import { FormSectionProps, ICreateClient } from '@/app/(main)/clients/create-client/types';

const AddressInformation = ({ rhProps }: FormSectionProps<ICreateClient>) => {
  const { errors, control, getValues } = rhProps;
  const { data: states, loading: isStateDropdownLoading } = useGetDropdownState();
  return (
    <>
      <Typography mb={2}>Address</Typography>
      <Grid container spacing={2}>
        <Grid xs={12} sm={12} md={12} lg={12} mb={-1}>
          <RHTextField<ICreateClient>
            label="Street address"
            propName="streetAddressLine1"
            margin="none"
            rhProps={{ errors, control }}
          />
        </Grid>
        <Grid xs={12} sm={12} md={6} lg={6} mb={-2}>
          <RHTextField<ICreateClient>
            label="Street address line 2"
            propName="streetAddressLine2"
            helperText="Optional"
            rhProps={{ errors, control, required: false }}
          />
        </Grid>
        <Grid xs={12} sm={12} md={6} lg={6} mb={-2}>
          <RHTextField<ICreateClient> label="City" propName="city" rhProps={{ errors, control }} />
        </Grid>
        <Grid xs={12} sm={12} md={6} lg={6} mb={-2}>
          <RHSelect<ICreateClient>
            label="State"
            propName="state"
            options={states}
            rhProps={{ errors, control, getValues }}
            isLoading={isStateDropdownLoading}
          />
        </Grid>

        <Grid xs={12} sm={12} md={6} lg={6} mb={-2}>
          <RHMaskedInput<ICreateClient>
            label="Zip code"
            propName="zipCode"
            mask="99999"
            rhProps={{ errors, control, minLength: 5, errorMessage: 'Please enter a valid zip code' }}
          />
        </Grid>
        <Grid xs={12} sm={12} md={6} lg={6}>
          <RHMaskedInput<ICreateClient>
            mask="(999) 999 9999"
            label="Main Phone"
            propName="mainPhone"
            rhProps={{
              errors,
              control,
              minLength: 10,
              errorMessage: 'Please enter a valid phone number, the format should be (555) 555-5555',
            }}
          />
        </Grid>
        <Grid xs={12} sm={12} md={6} lg={6}>
          <RHMaskedInput<ICreateClient>
            mask="(999) 999 9999"
            label="Fax line"
            propName="faxLine"
            rhProps={{
              errors,
              control,
              minLength: 10,
              errorMessage: 'Please enter a valid fax line number, the format should be (555) 555-5555',
            }}
          />
        </Grid>
      </Grid>
    </>
  );
};

export default AddressInformation;
