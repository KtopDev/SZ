'use client';

import { useRouter } from 'next/navigation';
import { SubmitHandler } from 'react-hook-form';
import { ICreateClient } from '@/app/(main)/clients/create-client/types';
import BaseClientForm from '@/app/(main)/clients/components/BaseClientForm';
import { useCreateClient } from '@/requests/api/clientsApi/clientsApi';
import { useGetDropdownBranchList } from '@/requests/api/branchesApi/branchesApi';
import { useSnackbar } from '@/context/SnackbarContext';
import { formatApiErrors } from '@/utils/general/general';

const CreateClient = () => {
  const [createClient, { loading: isCreateClientLoading }] = useCreateClient();
  const { data: branchesList, loading: isBranchesListLoading } = useGetDropdownBranchList();
  const { setErrorMessage } = useSnackbar();
  const router = useRouter();

  const onSubmit: SubmitHandler<ICreateClient> = async (formData: ICreateClient, setError: any) => {
    try {
      await createClient(formData);
      router.push('/clients');
    } catch (e) {
      formatApiErrors(e, setError, setErrorMessage);
    }
  };

  return (
    <BaseClientForm
      isCreate={true}
      onSubmit={onSubmit}
      branchesList={branchesList}
      isLoading={isCreateClientLoading}
      isBranchesListLoading={isBranchesListLoading}
    />
  );
};

export default CreateClient;
