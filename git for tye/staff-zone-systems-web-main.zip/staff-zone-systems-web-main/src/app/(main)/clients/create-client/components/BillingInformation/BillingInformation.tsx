import { Typography } from '@mui/material';
import React from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import RHSelect from '@/components/shared/Form/RHSelect';
import { useGetDropdownInvoiceFormat, useGetDropdownInvoiceMethod } from '@/requests/api/invoiceApi/invoiceApi';
import { FormSectionProps, ICreateClient } from '@/app/(main)/clients/create-client/types';

const BillingInformation = ({ rhProps }: FormSectionProps<ICreateClient>) => {
  const { control, errors, getValues } = rhProps;

  const { data: invoiceMethods, loading: isInvoiceMethodsLoading } = useGetDropdownInvoiceMethod();
  const { data: invoiceFormats, loading: isInvoiceFormatsLoading } = useGetDropdownInvoiceFormat();

  return (
    <>
      <Typography variant="h6">Billing information</Typography>
      <Typography variant="subtitle2" mb={1}>
        Client&apos;s basic details
      </Typography>

      <Grid container spacing={2}>
        <Grid xs={12} sm={12} lg={6} mb={-2}>
          <RHSelect<ICreateClient>
            label="Invoice method"
            propName="invoiceMethod"
            options={invoiceMethods}
            rhProps={{ errors, control, getValues }}
            isLoading={isInvoiceMethodsLoading}
          />
        </Grid>
        <Grid xs={12} sm={12} lg={6}>
          <RHSelect<ICreateClient>
            label="Invoice format"
            propName="invoiceFormat"
            options={invoiceFormats}
            rhProps={{ errors, control, getValues }}
            isLoading={isInvoiceFormatsLoading}
          />
        </Grid>
      </Grid>
    </>
  );
};

export default BillingInformation;
