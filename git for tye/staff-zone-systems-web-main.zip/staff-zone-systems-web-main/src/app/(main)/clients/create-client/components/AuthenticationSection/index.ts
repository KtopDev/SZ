import AuthenticationSection from './AuthenticationSection';

export default AuthenticationSection;
