import OtherSettings from './OtherSettings';

export default OtherSettings;
