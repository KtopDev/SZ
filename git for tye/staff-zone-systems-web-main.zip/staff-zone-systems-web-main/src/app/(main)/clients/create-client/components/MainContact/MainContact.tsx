import { Typography } from '@mui/material';
import React from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import RHTextField from '@/components/shared/Form/RHTextField';
import RHMaskedInput from '@/components/shared/Form/RHMaskedInput';
import RHSwitchGroup from '@/components/shared/Form/RHSwitchGroup';
import { FormSectionProps, ICreateClient } from '@/app/(main)/clients/create-client/types';

const MainContact = ({ rhProps }: FormSectionProps<ICreateClient>) => {
  const { control, errors } = rhProps;

  return (
    <>
      <Typography variant="h6">Main contact</Typography>
      <Typography variant="subtitle2" mb={1}>
        You can edit this information later or add new contact on the contact section
      </Typography>

      <Grid container spacing={2}>
        <Grid xs={12} sm={12} md={6} lg={6}>
          <RHTextField<ICreateClient> label="Name" propName="name" rhProps={{ errors, control }} />
        </Grid>
        <Grid xs={12} sm={12} md={6} lg={6}>
          <RHTextField<ICreateClient> label="Last name" propName="lastName" rhProps={{ errors, control }} />
        </Grid>
        <Grid xs={12} sm={12} md={6} lg={6}>
          <RHMaskedInput<ICreateClient>
            mask="(999) 999 9999"
            label="Cell phone"
            propName="cellPhone"
            rhProps={{
              errors,
              control,
              minLength: 10,
              errorMessage: 'Please enter a valid phone number, the format should be (555) 555-5555',
            }}
          />
        </Grid>
        <Grid xs={12} sm={12} md={6} lg={6}>
          <RHTextField<ICreateClient>
            label="Email address for account"
            propName="email"
            rhProps={{ errors, control, isEmail: true }}
          />
        </Grid>
      </Grid>
      <RHSwitchGroup<ICreateClient>
        labels={[
          'This contact will have access to the client app',
          'This contact can receive bills via email and pay invoices through the client app.',
          'This contact can approve hours and create orders',
          'This contact can rate workers',
        ]}
        propNames={[
          'isClientAppEnable',
          'isBillAndInvoiceEnable',
          'isApprovalAndCreationEnable',
          'isRateWorkersEnable',
        ]}
        rhProps={{ ...rhProps, required: false }}
      />
    </>
  );
};

export default MainContact;
