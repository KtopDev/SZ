import AddressInformation from './AddressInformation';

export default AddressInformation;
