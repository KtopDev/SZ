export interface Client {
  id: string;
  clientName: string;
  lastOrderBranch: string;
  lastOrderDate: string;
  lastInvoiceDate: string;
  status: string;
  unpaidInvoices: string;
}

export interface IClientListFilter {
  name: string;
  branch: string;
  status: string;
  startDate: string;
  endDate: string;
}

export interface ClientDTO {
  id: string;
  clientCode: string;
  clientName: string;
  status: string;
  creditLimit: number;
  clientTerms: string;
  invoiceMethod: string;
  invoiceFormat: string;
  mainPhone: string;
  faxLine: string;
  streetAddressLine1: string;
  streetAddressLine2: string;
  state: string;
  city: string;
  zipCode: string;
  clientCompCodeId: string;
  branches: string[];
  preferredMultiFactor: string;
  contact: ContactDTO;
  isClientAppEnable: boolean;
  isBillAndInvoiceEnable: boolean;
  isApprovalAndCreationEnable: boolean;
  isRateWorkersEnable: boolean;
  multiFactorAuthenticationTtlDays: string;
}

export interface ContactDTO {
  id: {
    clientId: string;
    contactId: string;
  };
  isRowActive: true;
  name: string;
  lastName: string;
  phone: string;
  email: string;
  isPrimary: boolean;
  isAppAccessEnabled: boolean;
  canReceiveInvoices: boolean;
  canApproveHours: boolean;
  canRateWorkers: boolean;
}

export const mapClientDTO = (data: any): ClientDTO => ({
  id: data.id,
  clientCode: data.clientCode,
  clientName: data.clientName,
  status: data.status,
  creditLimit: data.creditLimit,
  clientTerms: data.paymentTerm?.paymentTerm,
  invoiceMethod: data.invoiceMethod?.invoiceMethod,
  invoiceFormat: data.invoicePrintingFormat?.printingFormatId,
  mainPhone: data.phone,
  faxLine: data.fax,
  streetAddressLine1: data.address,
  streetAddressLine2: data.addressLine2,
  state: data.state?.state,
  city: data.city,
  zipCode: data.postalCode,
  clientCompCodeId: data.compCode?.compCodeId,
  contact: data?.contact,
  branches: data.branchesIds,
  preferredMultiFactor: data?.contact?.multiFactorAuthenticationPreference,
  isClientAppEnable: data.contact?.isAppAccessEnabled,
  isBillAndInvoiceEnable: data.contact?.canReceiveInvoices,
  isApprovalAndCreationEnable: data.contact?.canApproveHours,
  isRateWorkersEnable: data.contact?.canRateWorkers,
  multiFactorAuthenticationTtlDays: data.contact?.multiFactorAuthenticationTtlDays.toString(),
});
