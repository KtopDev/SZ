'use client';

import Box from '@mui/material/Box';
import Grid from '@mui/material/Unstable_Grid2';
import Typography from '@mui/material/Typography';
import Link from '@/components/shared/Link';
import { Button, TextField } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import Table from '@/components/shared/Table/Table';
import * as React from 'react';
import { useMemo, useState } from 'react';
import { MRT_TablePagination } from 'material-react-table';
import { useGetClientsList, usePatchClient } from '@/requests/api/clientsApi/clientsApi';
import { SortingState } from '@tanstack/table-core';
import RHChipGroup from '@/components/shared/Form/RHChipGroup';
import { useForm, useWatch } from 'react-hook-form';
import { IClientListFilter } from '@/app/(main)/clients/types';
import { capitalize, debounce } from 'lodash';
import RHSelect from '@/components/shared/Form/RHSelect';
import { useGetDropdownBranchList } from '@/requests/api/branchesApi/branchesApi';
import RHDatePicker from '@/components/shared/Form/RHDatePicker';
import { columns } from '@/app/(main)/clients/constants/tableColumns';
import ConfirmationModal from '@/components/shared/Modal/ConfirmationModal';
import { RenderRowActionMenuItems } from './create-client/components/ActionsButton/RenderRowActionMenuItems';
import { IUpdateClient } from './create-client/types';
import { useSnackbar } from '@/context/SnackbarContext';
import { useRouter } from 'next/navigation';

const ClientPage = () => {
  const {
    control,
    formState: { errors },
    setValue,
  } = useForm<IClientListFilter>({
    defaultValues: {
      name: '',
      branch: '',
      status: '',
      startDate: '',
      endDate: '',
    },
  });
  const { setMessage, setSeverity } = useSnackbar();
  const [patchClient] = usePatchClient();
  const branch = useWatch({ control: control, name: 'branch' });
  const name = useWatch({ control: control, name: 'name' });
  const startDate = useWatch({ control: control, name: 'startDate' });
  const endDate = useWatch({ control: control, name: 'endDate' });
  const status = useWatch({ control: control, name: 'status' });

  const [pagination, setPagination] = useState({ pageIndex: 1, pageSize: 10 });
  const [sorting, setSorting] = useState<SortingState>([]);

  const [showModal, setShowModal] = useState(false);
  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(false);
  const [modalTitle, setModalTitle] = useState('');
  const [modalDescription, setModalDescription] = useState('');
  const [confirmationButtonText, setConfirmationButtonText] = useState('');
  const [confirmationButtonColor, setConfirmationButtonColor] = useState<'primary' | 'error'>('primary');
  const [clientToUpdate, setClientToUpdate] = useState({} as IUpdateClient);
  const [row, setRow] = useState({} as any);
  const router = useRouter();

  const executeAction = async (row: any, oldClient: IUpdateClient, newClient: IUpdateClient, closeMenu: () => void) => {
    closeMenu();
    if (newClient.status === 'IN LEGAL' && !showModal) {
      setRow(row);
      setClientToUpdate(newClient);
      setModalTitle('Set status as “In Legal”');
      setModalDescription('Are you sure you want to change the status of this client as “In Legal”?');
      setConfirmationButtonText('SET STATUS AS “IN LEGAL”');
      setConfirmationButtonColor('error');
      openModal();
    } else if (oldClient.status === 'IN LEGAL' && !showModal) {
      setRow(row);
      setClientToUpdate(newClient);
      setModalTitle('Remove “In Legal” status');
      setModalDescription(
        'Are you sure you want to remove the “In Legal” status. This will reset the status back to the value it had before.'
      );
      setConfirmationButtonText('REMOVE “IN LEGAL” STATUS');
      setConfirmationButtonColor('primary');
      openModal();
    } else {
      try {
        await patchClient(newClient);
        setSeverity('success');
        row.original.status = newClient.status;
        setMessage(`Status set as ${newClient.status !== 'DNS' ? capitalize(newClient.status) : 'DNS'}`);
      } catch (error) {
        setSeverity('error');
        setMessage(`Error updating status to ${capitalize(clientToUpdate.status)}`);
      }
    }
  };

  const executeActionFromModal = async () => {
    try {
      await patchClient(clientToUpdate);
      row.original.status = clientToUpdate.status;
      setSeverity('success');
      setMessage(`Status set as ${capitalize(clientToUpdate.status)}`);
      closeModal();
    } catch (error) {
      setSeverity('error');
      setMessage(`Error updating status to ${capitalize(clientToUpdate.status)}`);
    }
  };

  const filter = useMemo(
    () => ({
      size: pagination.pageSize,
      page: pagination.pageIndex + 1,
      sort: sorting[0] ? `${sorting[0].id},${sorting[0].desc ? 'desc' : 'asc'}` : 'clientName,asc',
      name,
      branch,
      status,
      startDate,
      endDate,
    }),
    //eslint-disable-next-line react-hooks/exhaustive-deps
    [startDate, endDate, name, branch, status, sorting, pagination.pageIndex]
  );

  const { data: clientList, loading } = useGetClientsList(filter);
  const { data: branchList, loading: isBranchListLoading } = useGetDropdownBranchList();

  const renderTopToolbar = ({ table }: any) => (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        backgroundColor: 'common.white',
        justifyContent: 'space-between',
        paddingX: '24px',
      }}>
      <Box sx={{ paddingBottom: '16px' }}>
        <Typography fontSize="14px">Status</Typography>
        <RHChipGroup
          chips={[
            { label: 'All status', color: 'secondary', value: '' },
            { label: 'Inactive', color: 'default', value: 'Inactive' },
            { label: 'Active', color: 'success', value: 'Active' },
            { label: 'DNS', color: 'error', value: 'DNS' },
            { label: 'In Legal', color: 'secondary', value: 'In Legal' },
          ]}
          propName="status"
          rhProps={{ errors, control, required: false }}
        />
      </Box>
      <MRT_TablePagination table={table} />
    </Box>
  );

  const debouncedSetValue = debounce(setValue, 1000);

  const handleNameInputChange = (e: any) => {
    debouncedSetValue('name', e.target.value);
  };

  return (
    <>
      <Box paddingY="8px" paddingX="24px" bgcolor="common.white" border="none">
        <Grid container direction="row" justifyContent="space-between">
          <Typography paddingY="4px" fontWeight="regular" fontSize={24}>
            Clients
          </Typography>
          <Box paddingY="5px">
            <Link href={'/clients/create-client'}>
              <Button variant="contained" startIcon={<AddIcon />}>
                CREATE
              </Button>
            </Link>
          </Box>
        </Grid>
        <Box sx={{ flexGrow: 1 }}>
          <Grid container alignItems="end" spacing={2} columns={16}>
            <Grid xs={6}>
              <TextField
                fullWidth
                InputProps={{
                  startAdornment: <SearchIcon />,
                }}
                placeholder=" Search by name"
                id="outlined-basic"
                variant="outlined"
                onChange={handleNameInputChange}
              />
            </Grid>
            <Grid xs={6} py="0px">
              <RHSelect<IClientListFilter>
                label="Branch"
                propName="branch"
                options={branchList}
                isLoading={isBranchListLoading}
                rhProps={{ errors, control, required: false }}
              />
            </Grid>
            <Grid xs={2}>
              <Typography fontSize={14} paddingBottom="8px">
                Last order&apos;s date
              </Typography>
              <RHDatePicker<IClientListFilter>
                label="Start date"
                propName="startDate"
                rhProps={{ errors, control, required: false }}
              />
            </Grid>
            <Grid xs={2}>
              <RHDatePicker<IClientListFilter>
                label="End date"
                propName="endDate"
                rhProps={{ errors, control, required: false }}
              />
            </Grid>
          </Grid>
        </Box>
      </Box>
      <Table
        mrtProps={{
          data: clientList.content || [],
          columns: columns(router),
          renderTopToolbar,
          enableRowActions: true,
          renderRowActionMenuItems: (props) => RenderRowActionMenuItems({ ...props, executeAction }),
          displayColumnDefOptions: {
            'mrt-row-actions': {
              header: '',
            },
          },
          state: {
            sorting,
            pagination,
            isLoading: loading,
          },
          onPaginationChange: setPagination,
          onSortingChange: setSorting,
          manualPagination: true,
        }}
        rowCount={clientList.totalSize || 0}
      />

      <ConfirmationModal
        title={modalTitle}
        description={modalDescription}
        confirmationButtonText={confirmationButtonText}
        confirmationButtonColor={confirmationButtonColor}
        showModal={showModal}
        closeModal={closeModal}
        isLoading={false}
        callSubmit={executeActionFromModal}
      />
    </>
  );
};

export default ClientPage;
