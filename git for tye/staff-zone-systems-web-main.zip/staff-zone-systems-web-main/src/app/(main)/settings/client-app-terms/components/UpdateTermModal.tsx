'use client';
import { useEffect, useState } from 'react';
import { Backdrop, Box, Button, Fade, Modal, Typography, Stack } from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import TextField from '@mui/material/TextField';
import { Dropzone, ExtFile, FileMosaic } from '@dropzone-ui/react';
import FormControlLabel from '@mui/material/FormControlLabel';
import Switch from '@mui/material/Switch';
import { useSnackbar } from '@/context/SnackbarContext';
import { ClientTermDto } from '@/types/dto/ClientAppTerm';
import { useUpdateClientTerm } from '@/requests/api/clientTermsApi/clientTermsApi';
import stylesModule from '../client-app-terms.module.css';
import { loadSampleFile } from '../functions';

type Props = {
  showModal?: boolean;
  closeModal?: () => void;
  afterSubmission?: () => void;
  termId: string;
  termLabel: string;
  fileUrl: string;
};

export default function UpdateTermModal({ termId, termLabel, fileUrl, showModal, closeModal, afterSubmission }: Props) {
  const [updateClientTerm, { loading: updating }] = useUpdateClientTerm();
  const { setSuccessMessage, setErrorMessage } = useSnackbar();
  const [sampleFile, setSampleFile] = useState({});
  const [title, setTitle] = useState(termLabel);
  const [files, setFiles] = useState<ExtFile[]>([]);
  const [showDropzone, setShowDropzone] = useState(false);
  const [showMosaic, setShowMosaic] = useState(true);
  const disableSubmission = !title || (files.length === 0 && !showMosaic);

  const clearForm = () => {
    setTitle('');
    setFiles([]);
  };
  const updateFiles = (incommingFiles: ExtFile[]) => {
    setFiles(incommingFiles);
  };

  const handleFormData = (fileDto: ClientTermDto) => {
    const formData = new FormData();
    formData.append('fileName', fileDto.fileName);
    if (fileDto.document) {
      formData.append('document', fileDto.document);
    }
    return formData;
  };

  const handleDelete = () => {
    setShowDropzone(true);
    setShowMosaic(false);
  };

  const submit = async () => {
    const termDto = {
      fileName: title,
      document: showMosaic ? null : files[0].file,
    } as ClientTermDto;
    const formData = await handleFormData(termDto);
    try {
      await updateClientTerm({ termId, data: formData });
      if (closeModal) {
        closeModal();
        clearForm();
        if (afterSubmission) {
          afterSubmission();
        }
        setSuccessMessage('Term updated successfully');
      }
    } catch (error) {
      setErrorMessage('Error during file upload');
    }
  };

  useEffect(() => {
    if (fileUrl && showModal) {
      setSampleFile(loadSampleFile(fileUrl));
    }
    if (termLabel) {
      setTitle(termLabel);
    }
  }, [fileUrl, showModal, termLabel]);

  return (
    <Modal
      aria-labelledby="transition-modal-title"
      aria-describedby="transition-modal-description"
      open={showModal ? showModal : false}
      onClose={closeModal}
      closeAfterTransition
      slots={{ backdrop: Backdrop }}
      slotProps={{
        backdrop: {
          timeout: 500,
        },
      }}>
      <Fade in={showModal}>
        <Box sx={styles.modal}>
          <Typography variant="h6" gutterBottom>
            Edit item
          </Typography>
          <Typography variant="body2" gutterBottom>
            All fields are required
          </Typography>
          <TextField
            required
            id="outlined-required"
            label="Title"
            value={title}
            onChange={(e) => {
              setTitle(e.target.value);
            }}
            fullWidth
            sx={{ marginBottom: 2 }}
          />
          <Typography variant="caption" display="block" gutterBottom>
            This document must be mobile-friendly since it will be displayed on the Worker app. There must be no margins
            or padding on the document borders. A single column must contain all content.
          </Typography>

          {showMosaic && (
            <div className={stylesModule.mosaic}>
              <FileMosaic id={0} {...sampleFile} onDelete={handleDelete} />
            </div>
          )}

          {showDropzone && (
            <Dropzone
              fakeUpload={true}
              onChange={updateFiles}
              value={files}
              maxFiles={1}
              maxFileSize={41943040}
              accept=".txt,.pdf,image/*">
              {files.map((file) => (
                <FileMosaic key={file.id} {...file} info />
              ))}
            </Dropzone>
          )}

          <FormControlLabel control={<Switch defaultChecked />} label="Request sign again for this new version" />
          <Stack spacing={2} direction="row" sx={{ display: 'flex', justifyContent: 'flex-end' }} mt={2}>
            <Button variant="text" onClick={closeModal}>
              CANCEL
            </Button>
            <LoadingButton
              variant="contained"
              disabled={disableSubmission}
              loading={updating}
              loadingPosition="start"
              color="primary"
              onClick={submit}>
              SAVE CHANGES
            </LoadingButton>
          </Stack>
        </Box>
      </Fade>
    </Modal>
  );
}

const styles = {
  modal: {
    position: 'absolute' as const,
    top: '40%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 700,
    bgcolor: 'background.paper',
    boxShadow: 24,
    p: 2,
  },
};
