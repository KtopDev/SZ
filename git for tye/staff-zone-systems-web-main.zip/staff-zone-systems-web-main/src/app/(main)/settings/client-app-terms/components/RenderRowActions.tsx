'use client';
import React, { useState } from 'react';
import { Box, Button, IconButton } from '@mui/material';
import DownloadIcon from '@mui/icons-material/Download';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import UpdateTermModal from './UpdateTermModal';
import { ClientAppTerm } from '@/types/dto/ClientAppTerm';
import DeleteTermModal from './DeleteTermModal';

type Props = {
  rowData: ClientAppTerm;
  refetchTerms: () => void;
};

export const RenderRowActions = ({ rowData, refetchTerms }: Props) => {
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const openUpdateModal = () => setShowUpdateModal(true);
  const closeUpdateModal = () => setShowUpdateModal(false);

  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const openDeleteModal = () => setShowDeleteModal(true);
  const closeDeleteModal = () => setShowDeleteModal(false);

  return (
    <>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
        <div>
          <Button href={rowData.client_app_term_file_uri} startIcon={<DownloadIcon />}>
            DOWNLOAD ENGLISH VERSION
          </Button>

          <IconButton onClick={openUpdateModal}>
            <EditIcon color="secondary" />
          </IconButton>
          <IconButton color="error" onClick={openDeleteModal}>
            <DeleteIcon />
          </IconButton>
        </div>
      </Box>

      <UpdateTermModal
        termId={rowData.client_app_term_id}
        termLabel={rowData.client_app_term_label}
        fileUrl={rowData.client_app_term_file_uri}
        showModal={showUpdateModal}
        closeModal={closeUpdateModal}
        afterSubmission={refetchTerms}
      />

      <DeleteTermModal
        termId={rowData.client_app_term_id}
        showModal={showDeleteModal}
        closeModal={closeDeleteModal}
        afterSubmission={refetchTerms}
      />
    </>
  );
};
