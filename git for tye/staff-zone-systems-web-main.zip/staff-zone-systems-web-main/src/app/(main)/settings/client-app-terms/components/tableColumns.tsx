import { MRT_ColumnDef, MRT_Row } from 'material-react-table';
import { ClientAppTerm } from '@/types/dto/ClientAppTerm';
import { formatDate } from '@/utils/general/general';

export const columns = (): MRT_ColumnDef<ClientAppTerm>[] => [
  {
    accessorKey: 'id',
    header: '',
    enableSorting: false,
    size: 5,
    Cell: ({ row }: { row: MRT_Row<ClientAppTerm> }) => <div style={{ marginLeft: -15 }}>{row.index + 1}</div>,
  },
  { accessorKey: 'client_app_term_label', header: 'Title' },
  {
    accessorKey: 'modified_at',
    header: 'Last update',
    size: 50,
    Cell: ({ row }: { row: MRT_Row<ClientAppTerm> }) => <>{formatDate(row.original.modified_at)}</>,
  },
  {
    accessorKey: 'in_use_branches',
    header: 'Branches using this',
    size: 250,
    Cell: ({ row }: { row: MRT_Row<ClientAppTerm> }) => (
      <>
        {row.original.in_use_branches &&
          row.original.in_use_branches.map((branchInUse) => (
            <span key={branchInUse.branch_id}>{branchInUse.branch_name}</span>
          ))}
      </>
    ),
  },
];
