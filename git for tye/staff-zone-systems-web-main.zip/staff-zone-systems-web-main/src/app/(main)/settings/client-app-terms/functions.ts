/* eslint-disable */
export const getMimeType = (extension: string) => {
  switch (extension.toLowerCase()) {
    case 'txt':
      return 'text/plain';
    case 'pdf':
      return 'application/pdf';
    case 'csv':
      return 'text/csv';
    case 'jpg':
    case 'jpeg':
      return 'image/jpeg';
    case 'png':
      return 'image/png';
    case 'gif':
      return 'image/gif';
    case 'bmp':
      return 'image/bmp';
    case 'svg':
      return 'image/svg+xml';
    case 'xls':
      return 'application/vnd.ms-excel';
    case 'xlsx':
      return 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    case 'ods':
      return 'application/vnd.oasis.opendocument.spreadsheet';
    default:
      return 'application/octet-stream';
  }
};

export const loadSampleFile = (fileUrl: string) => {
  let parts = fileUrl.split('/');
  const fileName = parts[parts.length - 1];
  parts = fileUrl.split('.');
  const extension = parts[parts.length - 1];
  return {
    type: getMimeType(extension),
    name: fileName,
    valid: true,
  };
};
