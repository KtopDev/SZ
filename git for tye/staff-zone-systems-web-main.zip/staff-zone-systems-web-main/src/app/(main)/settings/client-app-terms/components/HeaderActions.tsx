'use client';

import React from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import AddIcon from '@mui/icons-material/Add';
import { Box, Button, Typography } from '@mui/material';

type Props = {
  openModal: () => void;
};

export const HeaderActions = ({ openModal }: Props) => {
  return (
    <>
      <Box paddingY="8px" paddingX="24px" bgcolor="common.white" border="none">
        <Grid container direction="row" justifyContent="space-between">
          <Typography paddingY="4px" fontWeight="regular" fontSize={24}>
            {"Client app's terms and conditions"}
          </Typography>
          <Box paddingY="5px">
            <Button
              variant="contained"
              startIcon={<AddIcon />}
              onClick={() => {
                openModal();
              }}>
              CREATE
            </Button>
          </Box>
        </Grid>
      </Box>
      <Typography variant="caption" display="block" gutterBottom sx={{ padding: 3 }}>
        The “order” column represents the order in which the legal statements appears in the Terms and conditions list
        of statements the worker must read and accept while completing their application on the Client app.
      </Typography>
    </>
  );
};
