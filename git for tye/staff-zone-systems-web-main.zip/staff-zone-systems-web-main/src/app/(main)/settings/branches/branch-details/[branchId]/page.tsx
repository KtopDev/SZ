'use client';
import BasicInformation from '@/app/(main)/settings/branches/branch-details/components/BasicInformation';
import Location from '@/app/(main)/settings/branches/branch-details/components/Location';
import { Box, CircularProgress, Container, Divider } from '@mui/material';
import Taxes from '@/app/(main)/settings/branches/branch-details/components/Taxes/Taxes';
import Printer from '@/app/(main)/settings/branches/branch-details/components/Printer';
import Other from '@/app/(main)/settings/branches/branch-details/components/Other';
import Actions from '@/app/(main)/settings/branches/branch-details/components/Actions';
import { BranchDTO } from '@/types/dto/Branch';
import useGet from '@/hooks/useGet';
import { GET_BRANCH } from '@/requests/endpoints';
import TermsAndConditions from '@/components/shared/Form/BranchForm/components/TermsAndConditions';

export default function BranchDetails({ params }: { params: { branchId: string } }) {
  const { getData, isLoading, fetchData } = useGet<BranchDTO>(GET_BRANCH(params.branchId));
  return (
    <>
      <Container maxWidth={false}>
        <Actions branch={getData} updateBranch={fetchData} />
        <Divider />
        {isLoading ? (
          <Box sx={{ display: 'flex' }}>
            <CircularProgress />
          </Box>
        ) : (
          <>
            <BasicInformation branch={getData} />
            <Divider />
            <Location branch={getData} />
            <Divider />
            <Taxes branch={getData} />
            <Divider />
            <Printer branch={getData} />
            <Divider />
            <Other branch={getData} />
            <Divider />
            <TermsAndConditions branch={getData} />
            <br />
          </>
        )}
      </Container>
    </>
  );
}
