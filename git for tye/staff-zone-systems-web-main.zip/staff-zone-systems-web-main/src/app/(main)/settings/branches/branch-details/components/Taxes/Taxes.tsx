'use client';
import React from 'react';
import { BranchDTO } from '@/types/dto/Branch';
import DefaultTaxesTable from './DefaultTaxesTable';
import FutaSutaTable from './FutaSutaTable';
import SickPayRulesTable from './SickPayRulesTable';

type Props = {
  branch: BranchDTO;
};

export default function BasicInformation({ branch }: Props) {
  return (
    <>
      <DefaultTaxesTable rows={branch.taxJurisdictions} />
      <FutaSutaTable rows={branch.unemploymentJurisdictions} />
      <SickPayRulesTable rows={branch.sickPayJurisdictions} />
    </>
  );
}
