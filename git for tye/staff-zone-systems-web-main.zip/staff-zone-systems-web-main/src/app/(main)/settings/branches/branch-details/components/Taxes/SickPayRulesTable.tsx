'use client';
import * as React from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from '@mui/material';
import { SickPayJurisdiction } from '@/types/dto/Branch';

type Props = {
  rows: SickPayJurisdiction[];
};

export default function SickPayRulesTable({ rows = [] }: Props) {
  return (
    <TableContainer component="div">
      <Typography variant="h6" gutterBottom ml={1} mt={1}>
        Sick pay rules
      </Typography>
      <Table aria-label="customized table">
        <TableHead>
          <TableRow>
            <TableCell align="left">Jurisdiction</TableCell>
            <TableCell align="left">Effective date</TableCell>
            <TableCell align="left">Anniversary Method</TableCell>
            <TableCell align="left">Vesting Period (days)</TableCell>
            <TableCell align="left">Suspended Period (days)</TableCell>
            <TableCell align="left">Lose After (days)</TableCell>
            <TableCell align="left">Accrual hours</TableCell>
            <TableCell align="left">Max carry forward</TableCell>
            <TableCell align="left">Max unused hours</TableCell>
            <TableCell align="left">Max Per Year Usable</TableCell>
            <TableCell align="left">MinConsumableHours</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.id}>
              <TableCell>{row.state.stateName}</TableCell>
              <TableCell>{row.effectiveDate}</TableCell>
              <TableCell>{row.anniversaryMethod.anniversaryMethod}</TableCell>
              <TableCell>{row.vestingDays}</TableCell>
              <TableCell>{row.suspendedDays}</TableCell>
              <TableCell>{row.loseAfterDays}</TableCell>
              <TableCell>{row.accrualHours}</TableCell>
              <TableCell>{row.maxCarryForwardHours}</TableCell>
              <TableCell></TableCell>
              <TableCell>{row.maxPerYearHours}</TableCell>
              <TableCell>{row.minConsumableHours}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
