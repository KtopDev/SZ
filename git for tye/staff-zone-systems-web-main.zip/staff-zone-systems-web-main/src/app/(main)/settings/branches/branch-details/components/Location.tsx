'use client';
import React from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import { Typography } from '@mui/material';
import { BranchDTO } from '@/types/dto/Branch';
import DisplayTextField from '@/components/shared/Panel/DisplayTextField';

type Props = {
  branch: BranchDTO;
};

export default function Location({ branch }: Props) {
  return (
    <>
      <Typography variant="h6" gutterBottom mt={2} mb={-1}>
        Location
      </Typography>
      <Typography variant="subtitle2" gutterBottom mb={2}>
        Address of the branch main building
      </Typography>
      <Grid container spacing={2}>
        <Grid xs={6} sm={6} md={12} lg={12}>
          <DisplayTextField label="Address" value={branch.address} />
          <DisplayTextField label="Address line 2" value={branch.addressLine2 ? branch.addressLine2 : ''} />
          <DisplayTextField label="State" value={branch.state?.stateName} />
          <DisplayTextField label="Zip code" value={branch.postalCode} />
          <DisplayTextField label="Coordinates" value={branch.geoLocation} />
        </Grid>
      </Grid>
    </>
  );
}
