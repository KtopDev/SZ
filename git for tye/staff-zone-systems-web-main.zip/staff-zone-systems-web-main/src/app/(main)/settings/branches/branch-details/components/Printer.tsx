'use client';
import React from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import { Typography } from '@mui/material';
import { BranchDTO } from '@/types/dto/Branch';
import DisplayTextField from '@/components/shared/Panel/DisplayTextField';

type Props = {
  branch: BranchDTO;
};

export default function Printer({ branch }: Props) {
  return (
    <>
      <Typography variant="h6" gutterBottom mt={2} mb={-1}>
        Printer IP configuration
      </Typography>
      <Typography variant="subtitle2" gutterBottom mb={2}>
        IP addresses of the default printers for this branch
      </Typography>
      <Grid container spacing={2} mb={2}>
        <Grid xs={6} sm={6} md={12} lg={12}>
          <DisplayTextField label="Scanner IP" value={branch.scannerIp} />
          <DisplayTextField label="Check printer IP" value={branch.checkPrinterIp} />
          <DisplayTextField label="Report printer IP" value={branch.reportPrinterIp} />
        </Grid>
      </Grid>
    </>
  );
}
