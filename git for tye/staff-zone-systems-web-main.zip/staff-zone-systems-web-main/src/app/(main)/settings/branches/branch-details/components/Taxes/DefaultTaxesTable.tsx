'use client';
import * as React from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from '@mui/material';
import { Jurisdiction } from '@/types/dto/Branch';

type Props = {
  rows: Jurisdiction[];
};

export default function DefaultTaxesTable({ rows = [] }: Props) {
  return (
    <TableContainer component="div">
      <Typography variant="h6" gutterBottom ml={1} mt={1}>
        Default taxes
      </Typography>
      <Table aria-label="customized table">
        <TableHead>
          <TableRow>
            <TableCell align="left">Jurisdiction</TableCell>
            <TableCell align="left">Tax type</TableCell>
            <TableCell align="left">Rate</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.name}>
              <TableCell>{row.name}</TableCell>
              <TableCell>{row.type}</TableCell>
              <TableCell></TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
