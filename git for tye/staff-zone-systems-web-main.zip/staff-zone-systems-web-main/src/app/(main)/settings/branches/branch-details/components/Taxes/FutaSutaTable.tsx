'use client';
import * as React from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from '@mui/material';
import { UnemploymentJurisdiction } from '@/types/dto/Branch';

type Props = {
  rows: UnemploymentJurisdiction[];
};

export default function FutaSutaTable({ rows = [] }: Props) {
  return (
    <TableContainer component="div">
      <Typography variant="h6" gutterBottom ml={1} mt={1}>
        FUTA, SUTA, SDI configurations
      </Typography>
      <Table aria-label="customized table">
        <TableHead>
          <TableRow>
            <TableCell align="left">Jurisdiction</TableCell>
            <TableCell align="left">Min wage</TableCell>
            <TableCell align="left">Max wage</TableCell>
            <TableCell align="left">Rate</TableCell>
            <TableCell align="left">Federal Credit Rate</TableCell>
            <TableCell align="left">Employee rate</TableCell>
            <TableCell align="left">Company rate</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.id}>
              <TableCell>{row.lkStates.stateName}</TableCell>
              <TableCell>{row.minWage}</TableCell>
              <TableCell>{row.maxWage}</TableCell>
              <TableCell>{row.rate}</TableCell>
              <TableCell>{row.federalCreditRate}</TableCell>
              <TableCell>{row.employeeRate}</TableCell>
              <TableCell>{row.companyRate}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
