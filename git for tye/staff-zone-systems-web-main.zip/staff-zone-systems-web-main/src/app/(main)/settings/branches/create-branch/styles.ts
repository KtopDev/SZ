export const mapsInfoStyle = {
  paddingLeft: 18,
};
