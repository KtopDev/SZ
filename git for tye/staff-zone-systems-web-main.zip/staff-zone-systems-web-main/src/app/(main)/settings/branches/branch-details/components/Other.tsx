'use client';
import React from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import { Typography } from '@mui/material';
import { BranchDTO } from '@/types/dto/Branch';
import DisplayTextField from '@/components/shared/Panel/DisplayTextField';

type Props = {
  branch: BranchDTO;
};

export default function Other({ branch }: Props) {
  return (
    <>
      <Typography variant="h6" gutterBottom mt={2} mb={2}>
        Other settings
      </Typography>
      <Grid container spacing={2} mb={2}>
        <Grid xs={6} sm={6} md={12} lg={12}>
          <DisplayTextField label="Comp code" value={branch.compCode?.lkState.stateName} />
          <DisplayTextField
            label="Voluntary deduction approval"
            value={branch.isVoluntaryDeductionApproveRequired as unknown as string}
          />
          <DisplayTextField
            label="Default check format"
            value={branch.defaultCheckPrintingFormat?.printingFormatName}
          />
          <DisplayTextField label="Sick pay check format" value={branch.sickCheckPrintingFormat?.printingFormatName} />
        </Grid>
      </Grid>
    </>
  );
}
