'use client';
import { useEffect, useState } from 'react';
import BasicInformation from '@/components/shared/Form/BranchForm/components/BasicInformation';
import Location from '@/components/shared/Form/BranchForm/components/Location';
import Taxes from '@/components/shared/Form/BranchForm/components/Taxes';
import Printer from '@/components/shared/Form/BranchForm/components/Printer';
import Other from '@/components/shared/Form/BranchForm/components/Other';
import TermsAndConditions from '@/components/shared/Form/BranchForm/components/TermsAndConditions';
import Divider from '@mui/material/Divider';
import Button from '@mui/material/Button';
import SaveIcon from '@mui/icons-material/Save';
import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import { SubmitHandler, useForm } from 'react-hook-form';
import { defaultBranch, ICreateBranch } from '@/types/forms/CreateBranch';
import usePut from '@/hooks/usePut';
import useGet from '@/hooks/useGet';
import { GET_BRANCH } from '@/requests/endpoints';
import { useRouter } from 'next/navigation';
import { useSnackbar } from '@/context/SnackbarContext';
import ConfirmationModal from '@/components/shared/Modal/ConfirmationModal';
import { BranchDTO } from '@/types/dto/Branch';

export default function EditBranchPage({ params }: { params: { branchId: string } }) {
  const { getData } = useGet<BranchDTO>(GET_BRANCH(params.branchId));
  const router = useRouter();
  const {
    control,
    formState: { errors, isValid, isSubmitted },
    setValue,
    handleSubmit,
    getValues,
    reset,
    trigger,
  } = useForm<ICreateBranch>({ defaultValues: defaultBranch, mode: 'onChange' });
  const { data, putData, isLoading, error, setError: setPostError } = usePut(GET_BRANCH(params.branchId));
  const [showModal, setShowModal] = useState(false);
  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(false);
  const { setMessage, setSeverity } = useSnackbar();

  const onSubmit: SubmitHandler<ICreateBranch> = async (formData) => {
    setPostError('');
    await putData(formData);
  };

  const callSubmit = () => {
    const submitHandler = handleSubmit(onSubmit);
    submitHandler();
  };

  const transformBranchForEditing = (branchDto: BranchDTO) => {
    const {
      defaultCheckPrintingFormat,
      sickCheckPrintingFormat,
      depositPrintingFormat,
      taxJurisdictions,
      unemploymentJurisdictions,
      sickPayJurisdictions,
      compCode,
      payCycle,
      state,
      ...otherFields
    } = branchDto;

    const transformed = {
      payCycle: payCycle.payCycle,
      state: state.state,
      defaultCheckPrintingFormatId: defaultCheckPrintingFormat.printingFormatId,
      sickCheckPrintingFormatId: sickCheckPrintingFormat.printingFormatId,
      depositPrintingFormatId: depositPrintingFormat.printingFormatId,
      taxJurisdictions: taxJurisdictions.map((jurisdiction) => jurisdiction.id),
      futaSutaSdi: unemploymentJurisdictions.map((jurisdiction) => jurisdiction.id),
      sickPayJurisdictions: sickPayJurisdictions.map((jurisdiction) => jurisdiction.id),
      compCodeId: compCode.compCodeId,
      ...otherFields,
    } as unknown as ICreateBranch;
    return transformed;
  };

  useEffect(() => {
    if (error) {
      setSeverity('error');
      setMessage(error);
      setShowModal(false);
    } else {
      if (isSubmitted) {
        setSeverity('success');
        setMessage('Changes saved');
        reset();
        setShowModal(false);
        router.push(`/settings/branches/branch-details/${data.branchId}`);
      }
    }

    if (getData) {
      if (getData && getData.defaultCheckPrintingFormat && getData.payCycle && getData.state) {
        const transformed = transformBranchForEditing(getData);
        reset(transformed);
      }
    }
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [error, isSubmitted, reset, router, getData]);

  return (
    <>
      <Container maxWidth="xl">
        <BasicInformation branch={getData} rhProps={{ control, errors, getValues, setValue, trigger }} />
        <Divider />
        <Location rhProps={{ control, errors, getValues }} />
        <Divider />
        <Taxes rhProps={{ control, errors, getValues }} />
        <Divider />
        <Printer rhProps={{ control, errors, getValues }} />
        <Divider />
        <Other rhProps={{ control, errors, setValue, getValues }} />
        <TermsAndConditions branch={getData} rhProps={{ control, errors, getValues, setValue }} />
        <Box display="flex" justifyContent="flex-end" mt={2} mb={2}>
          <Button variant="text" color="secondary" onClick={() => router.push('/settings/branches')}>
            CANCEL
          </Button>
          <Button
            disabled={!isValid}
            startIcon={<SaveIcon />}
            variant="contained"
            color="primary"
            sx={{ marginLeft: 1 }}
            onClick={openModal}>
            EDIT BRANCH
          </Button>
        </Box>
      </Container>

      <ConfirmationModal
        title="Edit branch"
        description="Please confirm you want to edit branch for StaffZone"
        confirmationButtonText="EDIT BRANCH"
        showModal={showModal}
        closeModal={closeModal}
        isLoading={isLoading}
        callSubmit={callSubmit}
      />
    </>
  );
}
