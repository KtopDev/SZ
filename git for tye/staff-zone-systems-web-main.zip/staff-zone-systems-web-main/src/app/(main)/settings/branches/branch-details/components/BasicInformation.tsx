'use client';
import React from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import { Typography } from '@mui/material';
import { BranchDTO } from '@/types/dto/Branch';
import NonEditableTextField from '@/components/shared/Panel/DisplayTextField';
import DisplayStatusField from '@/components/shared/Panel/DisplayStatusField';

type Props = {
  branch: BranchDTO;
};

export default function BasicInformation({ branch }: Props) {
  return (
    <>
      <Typography variant="h6" gutterBottom mt={2} mb={-1}>
        Basic information
      </Typography>
      <Typography variant="subtitle2" gutterBottom mb={2}>
        Branch main information
      </Typography>
      <Grid container spacing={2} mb={2}>
        <Grid xs={10} sm={10} md={10} lg={12}>
          <DisplayStatusField label="Status" value={branch.status} />
          <NonEditableTextField label="Branch name" value={branch.branchName} />
          <NonEditableTextField label="Branch code location number" value={branch.branchCode} />
          <NonEditableTextField label="Phone number" value={branch.phone} />
          <NonEditableTextField label="Fax number" value={branch.fax} />
          <NonEditableTextField label="Daily limit pay" value={branch.payLimitDaily} />
          <NonEditableTextField label="Weekly limit pay" value={branch.payLimitWeekly} />
          <NonEditableTextField label="Default pay cycle" value={branch.payCycle?.payCycle} />
        </Grid>
      </Grid>
    </>
  );
}
