import { Chip } from '@mui/material';
import { MRT_ColumnDef, MRT_Row } from 'material-react-table';
import dayjs from 'dayjs';
import Typography from '@mui/material/Typography';

export const columns = (router: any): MRT_ColumnDef<any>[] => [
  {
    accessorKey: 'branchName',
    header: 'Branch name',
    Cell: ({ row }: { row: MRT_Row<any> }) => (
      <Typography
        fontWeight="500"
        color="primary"
        sx={{ cursor: 'pointer' }}
        onClick={() => {
          const branchId = row.original.branchId;
          router.push(`/settings/branches/branch-details/${branchId}`);
        }}>
        {row.original.branchName}
      </Typography>
    ),
  },
  { accessorKey: 'phone', header: 'Phone number', enableSorting: false },
  { accessorKey: 'fax', header: 'Fax number', enableSorting: false },
  { accessorKey: 'address', header: 'Address' },
  {
    accessorKey: 'modifiedAt',
    header: 'Last updated',

    Cell: ({ row }: { row: MRT_Row<any> }) => <span>{`${dayjs(row.original.lastUpdated).format('MM/DD/YYYY')}`}</span>,
  },
  {
    header: 'Status',
    accessorKey: 'status',
    Cell: ({ row }: { row: MRT_Row<any> }) => {
      const state = row.original.status;
      const isActive = state === 'ACTIVE';

      return isActive ? <Chip size="small" label="active" color="success" /> : <Chip size="small" label="Inactive" />;
    },
  },
];
