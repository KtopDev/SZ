'use client';
import React from 'react';
import EditIcon from '@mui/icons-material/Edit';
import LoadingButton from '@mui/lab/LoadingButton';
import { Button, Typography } from '@mui/material';
import usePost from '@/hooks/usePost';
import { ACTIVATE_BRANCH, DEACTIVATE_BRANCH } from '@/requests/endpoints';
import { BranchDTO } from '@/types/dto/Branch';

type Props = {
  branch: BranchDTO;
  updateBranch: () => void;
};

export default function Actions({ branch, updateBranch }: Props) {
  const { postData: activateBranch, isLoading: isActivating } = usePost(ACTIVATE_BRANCH(branch.branchId));
  const { postData: deactivateBranch, isLoading: isDeactivating } = usePost(DEACTIVATE_BRANCH(branch.branchId));
  const isLoading = isActivating || isDeactivating;

  const toggleActivation = async () => {
    if (branch.status === 'ACTIVE') {
      await deactivateBranch({});
      updateBranch();
    } else {
      await activateBranch({});
      updateBranch();
    }
  };

  return (
    <div style={styles.container}>
      <Typography variant="h4" gutterBottom mt={1}>
        {branch.branchName} {!!branch.branchName ?? '-'} {branch.branchCode}
      </Typography>
      <div>
        <LoadingButton
          variant="outlined"
          color={branch.status === 'ACTIVE' ? 'error' : 'success'}
          style={styles.activationButon}
          loading={isLoading}
          disabled={isLoading}
          onClick={toggleActivation}>
          {branch.status === 'ACTIVE' ? 'DEACTIVATE' : 'REACTIVATE'}
        </LoadingButton>

        <Button variant="contained" startIcon={<EditIcon sx={{ marginRight: 1 }} />}>
          EDIT
        </Button>
      </div>
    </div>
  );
}

const styles = {
  container: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  activationButon: {
    marginRight: 5,
  },
};
