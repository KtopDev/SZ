'use client';

import * as React from 'react';
import { useMemo, useState } from 'react';
import Box from '@mui/material/Box';
import Link from '@/components/shared/Link';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import Grid from '@mui/material/Unstable_Grid2';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import Table from '@/components/shared/Table/Table';
import { MRT_TablePagination } from 'material-react-table';
import { useGetBranchList } from '@/requests/api/branchesApi/branchesApi';
import { columns } from '@/app/(main)/settings/branches/constants/tableColumns';
import { Button, TextField } from '@mui/material';
import { useGetDropdownState } from '@/requests/api/statesApi/statesApi';
import RHDatePicker from '@/components/shared/Form/RHDatePicker';
import RHSelect from '@/components/shared/Form/RHSelect';
import { useForm, useWatch } from 'react-hook-form';
import { IBranchListFilter } from '@/app/(main)/settings/branches/types';
import RHChipGroup from '@/components/shared/Form/RHChipGroup';
import { SortingState } from '@tanstack/table-core';
import { debounce } from 'lodash';
import SearchIcon from '@mui/icons-material/Search';
import { useRouter } from 'next/navigation';

const Branches = () => {
  const {
    control,
    formState: { errors },
    setValue,
  } = useForm<IBranchListFilter>({
    defaultValues: {
      nameCode: '',
      state: '',
      status: '',
      startDate: '',
      endDate: '',
    },
  });

  const state = useWatch({ control: control, name: 'state' });
  const nameCode = useWatch({ control: control, name: 'nameCode' });
  const startDate = useWatch({ control: control, name: 'startDate' });
  const endDate = useWatch({ control: control, name: 'endDate' });
  const status = useWatch({ control: control, name: 'status' });

  const { data: stateList, loading: isStateListLoading } = useGetDropdownState();
  const [pagination, setPagination] = useState({ pageIndex: 1, pageSize: 10 });
  const [sorting, setSorting] = useState<SortingState>([]);
  const router = useRouter();

  const filter = useMemo(
    () => ({
      size: pagination.pageSize,
      page: pagination.pageIndex + 1,
      sort: sorting[0] ? `${sorting[0].id},${sorting[0].desc ? 'desc' : 'asc'}` : 'branchName,asc',
      nameCode,
      state,
      status: status,
      startDate,
      endDate,
    }),
    //eslint-disable-next-line react-hooks/exhaustive-deps
    [endDate, nameCode, startDate, state, status, sorting, pagination.pageIndex]
  );

  const { data: branchList, loading } = useGetBranchList(filter);

  const renderRowActions = (data: any) => (
    <Box>
      <IconButton
        onClick={() => {
          const branchId = data.row.original.branchId;
          router.push(`/settings/branches/edit-branch/${branchId}`);
        }}>
        <EditIcon />
      </IconButton>
    </Box>
  );

  const renderTopToolbar = ({ table }: any) => (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        backgroundColor: 'common.white',
        justifyContent: 'space-between',
      }}>
      <Box sx={{ paddingLeft: '24px', paddingBottom: '16px' }}>
        <Typography fontSize="14px">Status</Typography>
        <RHChipGroup
          chips={[
            { label: 'All status', color: 'secondary', value: '' },
            { label: 'Active', color: 'success', value: 'Active' },
            { label: 'Inactive', color: 'default', value: 'Inactive' },
          ]}
          propName="status"
          rhProps={{ errors, control, required: false }}
        />
      </Box>
      <MRT_TablePagination table={table} />
    </Box>
  );

  const debouncedSetValue = debounce(setValue, 1000);

  const handleCodeNameInputChange = (e: any) => {
    debouncedSetValue('nameCode', e.target.value);
  };

  return (
    <>
      <Box paddingY="8px" paddingX="24px" bgcolor="common.white" border="none">
        <Grid container direction="row" justifyContent="space-between">
          <Typography paddingY="4px" fontWeight="regular" fontSize={24}>
            Branches
          </Typography>
          <Box paddingY="5px">
            <Link href={'/settings/branches/create-branch'}>
              <Button variant="contained" startIcon={<AddIcon />}>
                CREATE
              </Button>
            </Link>
          </Box>
        </Grid>
        <Box sx={{ flexGrow: 1 }}>
          <Grid container alignItems="end" spacing={2} columns={12}>
            <Grid xs={4}>
              <TextField
                InputProps={{
                  startAdornment: <SearchIcon />,
                }}
                fullWidth
                label="Search By Name or code"
                margin="none"
                onChange={handleCodeNameInputChange}
              />
            </Grid>
            <Grid xs={4} py="0px">
              <RHSelect<IBranchListFilter>
                label="State"
                propName="state"
                options={stateList}
                isLoading={isStateListLoading}
                rhProps={{ errors, control, required: false }}
              />
            </Grid>
            <Grid xs={2}>
              <Typography fontSize={14} paddingBottom="8px">
                Last update
              </Typography>
              <RHDatePicker<IBranchListFilter>
                label="Start date"
                propName="startDate"
                rhProps={{ errors, control, required: false }}
              />
            </Grid>
            <Grid xs={2}>
              <RHDatePicker<IBranchListFilter>
                label="End date"
                propName="endDate"
                rhProps={{ errors, control, required: false }}
              />
            </Grid>
          </Grid>
        </Box>
      </Box>
      <Table
        mrtProps={{
          data: branchList.content || [],
          columns: columns(router),
          renderTopToolbar,
          renderRowActions,
          state: {
            sorting,
            pagination,
            isLoading: loading,
          },
          onPaginationChange: setPagination,
          onSortingChange: setSorting,
          manualPagination: true,
        }}
        rowCount={branchList.totalSize || 0}
      />
    </>
  );
};

export default Branches;
