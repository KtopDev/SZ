export interface Branch {
  id: string;
  branchName: string;
  phoneNumber: string;
  faxNumber: string;
  address: string;
  lastUpdated: string;
  status: string;
}

export interface IBranchListFilter {
  nameCode: string;
  state: string;
  status: string;
  startDate: string;
  endDate: string;
}

export interface IBranchListRequest extends IBranchListFilter {
  size: number;
  page: number;
  sort: string;
  sortColumnName: string;
  sortOrder: string;
}
