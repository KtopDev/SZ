'use client';
import { useEffect, useState } from 'react';
import BasicInformation from '@/components/shared/Form/BranchForm/components/BasicInformation';
import Location from '@/components/shared/Form/BranchForm/components/Location';
import Taxes from '@/components/shared/Form/BranchForm/components/Taxes';
import Printer from '@/components/shared/Form/BranchForm/components/Printer';
import Other from '@/components/shared/Form/BranchForm/components/Other';
import TermsAndConditions from '@/components/shared/Form/BranchForm/components/TermsAndConditions';
import Divider from '@mui/material/Divider';
import Button from '@mui/material/Button';
import SaveIcon from '@mui/icons-material/Save';
import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import { SubmitHandler, useForm } from 'react-hook-form';
import { defaultBranch, ICreateBranch } from '@/types/forms/CreateBranch';
import usePost from '@/hooks/usePost';
import { CREATE_BRANCH } from '@/requests/endpoints';
import { useRouter } from 'next/navigation';
import { useSnackbar } from '@/context/SnackbarContext';
import ConfirmationModal from '@/components/shared/Modal/ConfirmationModal';

export default function CreateBranchForm() {
  const router = useRouter();
  const {
    control,
    formState: { errors, isValid, isSubmitted },
    setValue,
    handleSubmit,
    getValues,
    reset,
    trigger,
  } = useForm<ICreateBranch>({ defaultValues: defaultBranch, mode: 'onBlur' });
  const { data, postData, isLoading, error, setError: setPostError } = usePost(CREATE_BRANCH);
  const [showModal, setShowModal] = useState(false);
  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(false);
  const { setMessage, setSeverity } = useSnackbar();
  const rhProps = { control, errors, getValues, setValue, trigger };

  const onSubmit: SubmitHandler<ICreateBranch> = async (formData) => {
    formData.isVoluntaryDeductionApproveRequired = false;
    setPostError('');
    await postData(formData);
  };

  const callSubmit = () => {
    const submitHandler = handleSubmit(onSubmit);
    submitHandler();
  };

  useEffect(() => {
    if (error) {
      setSeverity('error');
      setMessage(error);
      setShowModal(false);
    } else {
      if (isSubmitted) {
        setSeverity('success');
        setMessage('Branch created successfully');
        reset();
        setShowModal(false);
        router.push(`/settings/branches/branch-details/${data.branchId}`);
      }
    }
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [error, isSubmitted, reset, router]);

  return (
    <>
      <Container maxWidth="xl">
        <BasicInformation rhProps={rhProps} />
        <Divider />
        <Location rhProps={rhProps} />
        <Divider />
        <Taxes rhProps={rhProps} />
        <Divider />
        <Printer rhProps={rhProps} />
        <Divider />
        <Other rhProps={rhProps} />
        <TermsAndConditions rhProps={{ control, errors, getValues, setValue }} />
        <Box display="flex" justifyContent="flex-end" mt={2} mb={2}>
          <Button variant="text" color="secondary" onClick={() => router.push('/settings/branches')}>
            CANCEL
          </Button>
          <Button
            disabled={!isValid}
            startIcon={<SaveIcon />}
            variant="contained"
            color="primary"
            sx={{ marginLeft: 1 }}
            onClick={openModal}>
            CREATE BRANCH
          </Button>
        </Box>
      </Container>

      <ConfirmationModal
        title="Create new branch"
        description="Please confirm you want to create a new branch for StaffZone"
        confirmationButtonText="CREATE NEW BRANCH"
        showModal={showModal}
        closeModal={closeModal}
        isLoading={isLoading}
        callSubmit={callSubmit}
      />
    </>
  );
}
