export interface IUserListFilter {
  nameOrCode: string;
  branchName: string;
  jobTitle: string;
  status: string;
  securityRole: string;
}
