import BaseUserForm from './BaseUserForm';

export default BaseUserForm;
