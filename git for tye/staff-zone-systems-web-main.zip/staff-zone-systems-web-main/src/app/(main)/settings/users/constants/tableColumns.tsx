import { MRT_ColumnDef, MRT_Row } from 'material-react-table';
import Typography from '@mui/material/Typography';
import { Chip } from '@mui/material';
import Grid from '@mui/material/Unstable_Grid2';

export const columns: MRT_ColumnDef<any>[] = [
  {
    accessorKey: 'name',
    header: 'Name',
    Cell: ({ row }: { row: MRT_Row<any> }) => (
      <Grid>
        <Typography fontWeight="500" color="primary" sx={{ cursor: 'pointer' }}>
          {row.original.firstName} {row.original.lastName}
        </Typography>
        <Typography fontSize={12}>ID {row.original?.userCode}</Typography>
      </Grid>
    ),
  },
  { accessorKey: 'jobTitle', header: 'Title' },
  { accessorKey: 'securityRole', header: 'Security role', enableSorting: false },
  { accessorKey: 'defaultBranch', header: 'Default branch', enableSorting: false },
  {
    header: 'Status',
    accessorKey: 'status',
    Cell: ({ row }: { row: MRT_Row<any> }) => {
      const state = row.original.status;
      const isActive = state === 'ACTIVE';

      return isActive ? <Chip size="small" label="Active" color="success" /> : <Chip size="small" label="Inactive" />;
    },
  },
];
