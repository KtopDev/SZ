import { Typography } from '@mui/material';
import React from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import RHTextField from '@/components/shared/Form/RHTextField';
import RHMaskedInput from '@/components/shared/Form/RHMaskedInput';
import { FormSectionProps } from '@/app/(main)/clients/create-client/types';
import { IUserForm } from '@/app/(main)/settings/users/components/BaseUserForm/types';

const ContactInformation = ({ rhProps }: FormSectionProps<IUserForm>) => {
  const { control, errors, setValue } = rhProps;

  return (
    <>
      <Typography variant="h6">Contact information</Typography>
      <Grid container spacing={2}>
        <Grid xs={12} sm={12} lg={6} mb={-2}>
          <RHMaskedInput<IUserForm>
            label="Phone number"
            propName="phone"
            mask="(999) 999 9999"
            rhProps={{
              errors,
              control,
              setValue,
              minLength: 9,
              errorMessage: 'Please enter a valid phone number, the correct format is (555) 555 5555',
            }}
          />
        </Grid>
        <Grid xs={12} sm={12} lg={6}>
          <RHTextField<IUserForm>
            label="Email address for account"
            propName="email"
            rhProps={{
              errors,
              control,
              isEmail: true,
              errorMessage: 'Please enter a valid email, the correct format is example@mail.com',
            }}
          />
        </Grid>
      </Grid>
    </>
  );
};

export default ContactInformation;
