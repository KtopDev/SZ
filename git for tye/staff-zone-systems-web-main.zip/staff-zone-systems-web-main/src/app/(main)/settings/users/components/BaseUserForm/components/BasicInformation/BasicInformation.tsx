import { Typography } from '@mui/material';
import React from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import RHTextField from '@/components/shared/Form/RHTextField';
import RHSelect from '@/components/shared/Form/RHSelect';
import { Dropdown } from '@/types/Dropdown';
import { FieldValues } from 'react-hook-form';
import { ReactHookProps } from '@/types/forms/RHProps';
import { IUserForm } from '@/app/(main)/settings/users/components/BaseUserForm/types';

type Props<T extends FieldValues> = {
  jobTitleList: Dropdown;
  rhProps: ReactHookProps<T>;
  isJobTitleLoading?: boolean;
};

const BasicInformation = ({ rhProps, jobTitleList, isJobTitleLoading }: Props<IUserForm>) => {
  const { control, errors, getValues } = rhProps;

  return (
    <>
      <Typography variant="h6">Basic information</Typography>
      <Grid container spacing={2}>
        <Grid xs={12} sm={12} lg={6} mb={-2}>
          <RHTextField<IUserForm>
            label="First name"
            propName="firstName"
            rhProps={{
              errors,
              control,
              getValues,
              errorMessage: 'The name should have at least 2 characters',
              minLength: 2,
            }}
          />
        </Grid>
        <Grid xs={12} sm={12} lg={6} mb={-2}>
          <RHTextField<IUserForm>
            label="Last name"
            propName="lastName"
            rhProps={{
              errors,
              control,
              getValues,
              errorMessage: 'The name should have at least 2 characters',
              minLength: 2,
            }}
          />
        </Grid>
        <Grid xs={12} sm={12} lg={12}>
          <RHSelect<IUserForm>
            label="Job Title"
            propName="jobTitle"
            options={jobTitleList}
            isLoading={isJobTitleLoading}
            rhProps={{
              errors,
              control,
              getValues,
            }}
          />
        </Grid>
      </Grid>
    </>
  );
};

export default BasicInformation;
