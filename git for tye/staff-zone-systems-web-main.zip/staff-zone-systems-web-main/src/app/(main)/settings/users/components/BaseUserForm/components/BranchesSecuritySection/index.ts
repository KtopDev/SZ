import BranchesSecuritySection from './BranchesSecuritySection';

export default BranchesSecuritySection;
