'use client';
import Grid from '@mui/material/Unstable_Grid2';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import Link from '@/components/shared/Link';
import { Button, TextField } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import SearchIcon from '@mui/icons-material/Search';
import RHSelect from '@/components/shared/Form/RHSelect';
import * as React from 'react';
import { useMemo, useState } from 'react';
import { useForm, useWatch } from 'react-hook-form';
import { debounce } from 'lodash';
import { IUserListFilter } from '@/app/(main)/settings/users/types';
import Table from '@/components/shared/Table/Table';
import { useGetEmployeesList, useGetJobTitleDropdown } from '@/requests/api/usersApi/usersApi';
import { columns } from '@/app/(main)/settings/users/constants/tableColumns';
import RHChipGroup from '@/components/shared/Form/RHChipGroup';
import { MRT_TablePagination } from 'material-react-table';
import IconButton from '@mui/material/IconButton';
import EditIcon from '@mui/icons-material/Edit';
import { useRouter } from 'next/navigation';
import { SortingState } from '@tanstack/table-core';
import ActionColumnContent from '@/components/shared/Table/components/ActionColumnContent/ActionColumnContent';

const UsersPage = () => {
  const {
    control,
    formState: { errors },
    setValue,
  } = useForm<IUserListFilter>({
    defaultValues: {
      nameOrCode: '',
      branchName: '',
      jobTitle: '',
      securityRole: '',
      status: 'Active',
    },
  });

  const router = useRouter();

  const nameOrCode = useWatch({ control: control, name: 'nameOrCode' });
  const branchName = useWatch({ control: control, name: 'branchName' });
  const jobTitle = useWatch({ control: control, name: 'jobTitle' });
  // const securityRole = useWatch({ control: control, name: 'securityRole' });
  const status = useWatch({ control: control, name: 'status' });

  const [pagination, setPagination] = useState({ pageIndex: 1, pageSize: 10 });
  const [sorting, setSorting] = useState<SortingState>([]);

  const filter = useMemo(
    () => ({
      size: pagination.pageSize,
      page: pagination.pageIndex + 1,
      sort: sorting[0] ? `${sorting[0].id},${sorting[0].desc ? 'desc' : 'asc'}` : 'name,asc',
      nameOrCode,
      branchName,
      status,
      jobTitle,
    }),
    //eslint-disable-next-line react-hooks/exhaustive-deps
    [nameOrCode, jobTitle, branchName, status, sorting, pagination.pageIndex]
  );

  const { data: jobTitleList, loading: isJobTitleListLoading } = useGetJobTitleDropdown();
  const { data: userList, loading: isUserListLoading } = useGetEmployeesList(filter);
  const debouncedSetValue = debounce(setValue, 1000);

  const handleCodeNameInputChange = (e: any) => {
    debouncedSetValue('nameOrCode', e.target.value);
  };

  const renderTopToolbar = ({ table }: any) => (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        backgroundColor: 'common.white',
        justifyContent: 'space-between',
      }}>
      <Box sx={{ paddingLeft: '24px', paddingBottom: '16px' }}>
        <Typography fontSize="14px">Status</Typography>
        <RHChipGroup<IUserListFilter>
          chips={[
            { label: 'Active', color: 'success', value: 'Active' },
            { label: 'Inactive', color: 'default', value: 'Inactive' },
          ]}
          propName="status"
          rhProps={{ errors, control, required: false }}
        />
      </Box>
      <MRT_TablePagination table={table} />
    </Box>
  );

  const renderRowActions = (data: any) => {
    const menuItems = [
      {
        label: 'Edit User',
        onClick: () => {
          router.push(`users/${data.row.original.appUserId}/update-user`);
        },
      },
      {
        label: 'Reset Password',
        onClick: () => null,
      },
      {
        label: 'Deactivate user',
        onClick: () => null,
      },
    ];

    return (
      <Box key={data.row.original.appUserId}>
        <ActionColumnContent menuItems={menuItems} row={data.row}>
          <IconButton
            onClick={() => {
              router.push(`users/${data.row.original.appUserId}/update-user`);
            }}>
            <EditIcon />
          </IconButton>
        </ActionColumnContent>
      </Box>
    );
  };

  return (
    <>
      <Box paddingY="8px" paddingX="24px" bgcolor="common.white" border="none">
        <Box sx={{ flexGrow: 1 }}>
          <Grid container direction="row" justifyContent="space-between">
            <Typography paddingY="4px" fontWeight="regular" fontSize={24}>
              Users
            </Typography>
            <Box paddingY="5px">
              <Link href={'/settings/users/create-user'}>
                <Button variant="contained" startIcon={<AddIcon />}>
                  CREATE
                </Button>
              </Link>
            </Box>
          </Grid>
          <Grid py={1} container rowSpacing={2} columns={12}>
            <Grid xs={6} pr={2}>
              <TextField
                InputProps={{
                  startAdornment: <SearchIcon />,
                }}
                fullWidth
                label="Search by name/id"
                margin="none"
                onChange={handleCodeNameInputChange}
              />
            </Grid>
            <Grid xs={6} py="0px" container>
              <Grid xs={4} px="0px">
                <RHSelect<IUserListFilter>
                  label="Branch"
                  propName="branchName"
                  options={[] as any}
                  isLoading={false}
                  inputStyles={{
                    '& .MuiOutlinedInput-root': {
                      borderRadius: '5px 0 0 5px',
                    },
                  }}
                  rhProps={{ errors, control, required: false }}
                />
              </Grid>
              <Grid xs={4} px="0px">
                <RHSelect<IUserListFilter>
                  label="Title"
                  propName="jobTitle"
                  options={jobTitleList}
                  isLoading={isJobTitleListLoading}
                  inputStyles={{
                    '& .MuiOutlinedInput-root': {
                      borderRadius: '0px',
                    },
                  }}
                  rhProps={{ errors, control, required: false }}
                />
              </Grid>
              <Grid xs={4} px="0px">
                <RHSelect<IUserListFilter>
                  label="Security role"
                  propName="securityRole"
                  options={[] as any}
                  isLoading={false}
                  inputStyles={{
                    '& .MuiOutlinedInput-root': {
                      borderRadius: '0  5px 5px 0',
                    },
                  }}
                  rhProps={{ errors, control, required: false }}
                />
              </Grid>
            </Grid>
          </Grid>
        </Box>
      </Box>
      <Table
        mrtProps={{
          data: userList.content || [],
          columns: columns,
          renderTopToolbar,
          renderRowActions,
          state: {
            sorting,
            pagination,
            isLoading: isUserListLoading,
          },
          onPaginationChange: setPagination,
          onSortingChange: setSorting,
          manualPagination: true,
        }}
        rowCount={userList.totalSize || 0}
      />
    </>
  );
};

export default UsersPage;
