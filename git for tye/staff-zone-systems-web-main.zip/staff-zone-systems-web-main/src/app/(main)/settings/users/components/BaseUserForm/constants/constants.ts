export const defaultUser = {
  id: 0,
  email: '',
  jobTitle: '',
  lastName: '',
  firstName: '',
  phone: '',
  securityRole: '',
  preferredMultiFactor: 'SMS',
  securityRoleByBranch: [
    {
      branch: '',
      securityRole: '',
    },
  ],
};
