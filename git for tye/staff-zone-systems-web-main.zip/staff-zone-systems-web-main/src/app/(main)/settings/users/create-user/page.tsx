'use client';
import BaseUserForm from '@/app/(main)/settings/users/components/BaseUserForm';
import { useGetDropdownBranchList } from '@/requests/api/branchesApi/branchesApi';
import { useCreateUser, useGetJobTitleDropdown } from '@/requests/api/usersApi/usersApi';
import { useSnackbar } from '@/context/SnackbarContext';
import { useRouter } from 'next/navigation';
import { IUserForm } from '@/app/(main)/settings/users/components/BaseUserForm/types';
import { formatApiErrors } from '@/utils/general/general';

const CreateUserPage = () => {
  const [createUser, { loading: isCreateUserLoading }] = useCreateUser();
  const { data: jobTitleList, loading: isJobTitleListLoading } = useGetJobTitleDropdown();
  const { data: branchesList, loading: isBranchesListLoading } = useGetDropdownBranchList();
  // const { data: securityRoleList, loading: isSecurityRoleListLoading } = useGetSecurityRoleDropdown();
  const { setErrorMessage, setSuccessMessage } = useSnackbar();
  const router = useRouter();

  const onSubmit = async (formValues: IUserForm, setError: any) => {
    try {
      await createUser(formValues);
      setSuccessMessage('User created successfully');
      router.push('/settings/users');
    } catch (e: any) {
      formatApiErrors(e, setError, setErrorMessage);
    }
  };

  return (
    <BaseUserForm
      isCreate={true}
      onSubmit={onSubmit}
      jobTitleList={jobTitleList}
      branchesList={branchesList}
      securityRoleList={[] as any}
      isLoading={isCreateUserLoading || isJobTitleListLoading || isBranchesListLoading}
    />
  );
};

export default CreateUserPage;
