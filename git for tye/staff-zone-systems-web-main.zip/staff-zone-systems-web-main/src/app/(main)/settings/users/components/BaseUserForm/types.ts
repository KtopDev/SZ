export interface IUserForm {
  appUserId?: number;
  email: string;
  lastName: string;
  jobTitle: string;
  firstName: string;
  phone: string;
  securityRole: string;
  branch: string;
  multiFactorAuthenticationPreference: 'SMS' | 'EMAIL' | 'AUTH_APP' | 'NONE';
  multiFactorAuthenticationTtlDays: string;
  securityRoleByBranch: IRoleByBranch[];
}

interface IRoleByBranch {
  securityRole: string;
  branch: string;
}
