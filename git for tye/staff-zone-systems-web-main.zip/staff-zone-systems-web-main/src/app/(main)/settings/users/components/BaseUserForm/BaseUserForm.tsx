import React from 'react';
import Box from '@mui/material/Box';
import { useForm } from 'react-hook-form';
import Divider from '@mui/material/Divider';
import { Dropdown } from '@/types/Dropdown';
import BasicInformation from './components/BasicInformation';
import ContactInformation from './components/ContactInformation';
import AuthenticationSection from './components/AuthenticationSection';
import Link from '@/components/shared/Link';
import { Button } from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import BranchesSecuritySection from './components/BranchesSecuritySection';
import { IUserForm } from '@/app/(main)/settings/users/components/BaseUserForm/types';
import { defaultUser } from '@/app/(main)/settings/users/components/BaseUserForm/constants/constants';

type Props = {
  userData?: any;
  isCreate: boolean;
  isLoading: boolean;
  onSubmit: (formValues: IUserForm, setError: any) => void;
  jobTitleList: Dropdown;
  branchesList: Dropdown;
  securityRoleList: Dropdown;
};

const BaseUserForm = ({
  userData,
  isCreate,
  onSubmit,
  jobTitleList,
  branchesList,
  securityRoleList,
  isLoading,
}: Props) => {
  const {
    control,
    formState: { errors, isValid },
    handleSubmit,
    getValues,
    setValue,
    register,
    setError,
  } = useForm<IUserForm>({ defaultValues: isCreate ? defaultUser : userData, mode: 'onBlur' });

  return (
    <Box paddingX="24px" py={2}>
      <BasicInformation
        jobTitleList={jobTitleList}
        isJobTitleLoading={isLoading}
        rhProps={{ errors, control, getValues }}
      />
      <Box py={2}>
        <Divider />
      </Box>
      <ContactInformation rhProps={{ setValue, control, errors }} />
      <Box py={2}>
        <Divider />
      </Box>
      <BranchesSecuritySection
        isLoading={isLoading}
        branchesList={branchesList}
        securityRoleList={securityRoleList}
        rhProps={{ register, control, errors, getValues }}
      />
      <AuthenticationSection rhProps={{ setValue, control, errors, getValues }} />
      <Box display="flex" justifyContent="flex-end">
        <Link href={'/settings/users'}>
          <Button variant="outlined">CANCEL</Button>
        </Link>
        <LoadingButton
          disabled={!isValid}
          startIcon={null}
          loading={isLoading}
          variant="contained"
          color="primary"
          sx={{ marginLeft: 1 }}
          onClick={handleSubmit((formValues) => onSubmit(formValues, setError))}>
          {isCreate ? 'CREATE USER' : 'SAVE CHANGES'}
        </LoadingButton>
      </Box>
    </Box>
  );
};

export default BaseUserForm;
