'use client';

import { useGetJobTitleDropdown, useGetUserDetails, useUpdateUser } from '@/requests/api/usersApi/usersApi';
import { useSnackbar } from '@/context/SnackbarContext';
import { useRouter } from 'next/navigation';
import { useGetDropdownBranchList } from '@/requests/api/branchesApi/branchesApi';
import BaseUserForm from '@/app/(main)/settings/users/components/BaseUserForm';
import { IUserForm } from '@/app/(main)/settings/users/components/BaseUserForm/types';
import { formatApiErrors } from '@/utils/general/general';

type Props = {
  params: {
    userId: string;
  };
};

const UpdateUser = ({ params }: Props) => {
  const router = useRouter();
  const { setSuccessMessage, setErrorMessage } = useSnackbar();
  const [updateUser, { loading: updateUserLoading }] = useUpdateUser();
  const { data: userData, loading: userDataLoading } = useGetUserDetails(params.userId);
  const { data: jobTitleList, loading: isJobTitleListLoading } = useGetJobTitleDropdown();
  const { data: branchesList, loading: isBranchesListLoading } = useGetDropdownBranchList();
  //const { data: securityRoleList, loading: isSecurityRoleListLoading } = useGetSecurityRoleDropdown();

  const onSubmit = async (formValues: IUserForm, setError: any) => {
    try {
      await updateUser(formValues);
      setSuccessMessage('Changes saved');
      router.push('/settings/users');
    } catch (e: any) {
      formatApiErrors(e, setError, setErrorMessage);
    }
  };

  return (
    !userDataLoading && (
      <BaseUserForm
        isCreate={false}
        onSubmit={onSubmit}
        userData={userData}
        jobTitleList={jobTitleList}
        branchesList={branchesList}
        securityRoleList={[] as any}
        isLoading={updateUserLoading || isJobTitleListLoading || isBranchesListLoading || userDataLoading}
      />
    )
  );
};

export default UpdateUser;
