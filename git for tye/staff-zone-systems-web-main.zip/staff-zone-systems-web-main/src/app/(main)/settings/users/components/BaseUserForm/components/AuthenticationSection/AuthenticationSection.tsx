import React from 'react';
import { Typography } from '@mui/material';
import Box from '@mui/material/Box';
import RHRadioGroup from '@/components/shared/Form/RHRadioGroup';
import Grid from '@mui/material/Unstable_Grid2';
import RHMaskedInput from '@/components/shared/Form/RHMaskedInput';
import { IUserForm } from '@/app/(main)/settings/users/components/BaseUserForm/types';
import { FormSectionProps } from '@/app/(main)/clients/create-client/types';

const AuthenticationSection = ({ rhProps }: FormSectionProps<IUserForm>) => {
  return (
    <>
      <Typography variant="h6" py={2}>
        Multi-Factor Authentication (MFA)
      </Typography>
      <Typography>Method</Typography>
      <Typography fontSize="12px">Choose where to receive the authentication code</Typography>

      <Box px={2}>
        <RHRadioGroup
          labels={['SMS', 'Email', 'Authenticator app', 'None (not recommended)']}
          values={['SMS', 'EMAIL', 'AUTH_APP', 'NONE']}
          propName="multiFactorAuthenticationPreference"
          rhProps={rhProps}
        />
      </Box>

      <Grid xs={12} sm={12} lg={12}>
        <RHMaskedInput<IUserForm>
          label="Request MFA again after _ days"
          propName="multiFactorAuthenticationTtlDays"
          mask="99 days"
          maskPlaceholder="_  days"
          rhProps={rhProps}
          helperText="Days before client's Users are logged out and new code is needed"
        />
      </Grid>
    </>
  );
};

export default AuthenticationSection;
