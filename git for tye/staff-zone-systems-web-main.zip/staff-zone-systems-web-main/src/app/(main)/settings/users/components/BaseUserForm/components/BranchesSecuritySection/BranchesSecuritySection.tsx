import { Controller, useFieldArray } from 'react-hook-form';
import Box from '@mui/material/Box';
import { Button, FormControl, InputLabel, MenuItem, Select, Typography } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import Grid from '@mui/material/Unstable_Grid2';
import * as React from 'react';
import DeleteIcon from '@mui/icons-material/Delete';
import IconButton from '@mui/material/IconButton';
import { ReactHookProps } from '@/types/forms/RHProps';
import { Dropdown } from '@/types/Dropdown';
import RHSelect from '@/components/shared/Form/RHSelect';
import { IUserForm } from '@/app/(main)/settings/users/components/BaseUserForm/types';

type Props = {
  isLoading: boolean;
  branchesList: Dropdown;
  securityRoleList: Dropdown;
  rhProps: ReactHookProps<IUserForm>;
};

const BranchesSecuritySection = ({ branchesList, securityRoleList, isLoading, rhProps }: Props) => {
  const { control, register, errors, getValues } = rhProps;
  const { fields, append, remove } = useFieldArray<IUserForm>({
    control,
    name: 'securityRoleByBranch',
  });

  const handleAddItem = () => {
    append({
      securityRole: '',
      branch: '',
    });
  };

  return (
    <>
      <Box>
        <Typography variant="h6">Branch and security roles</Typography>
        <Box py={2}>
          <Typography fontSize={14} fontWeight={500}>
            Default role and branch
          </Typography>
          <Grid container spacing={2}>
            <Grid xs={12} sm={12} lg={6} mb={-2}>
              <RHSelect<IUserForm>
                label="Security role"
                propName="securityRole"
                options={securityRoleList}
                isLoading={isLoading}
                rhProps={{ errors, control, getValues, required: false }}
              />
            </Grid>
            <Grid xs={12} sm={12} lg={6}>
              <RHSelect<IUserForm>
                label="Branch"
                propName="branch"
                options={branchesList}
                isLoading={isLoading}
                rhProps={{ errors, control, getValues, required: false }}
              />
            </Grid>
          </Grid>
        </Box>
        <Typography fontSize={14} fontWeight={500}>
          Other branches (optional)
        </Typography>
        {fields.map((field, index) => (
          <Grid container key={field.id} spacing={2}>
            <Grid xs={12} sm={12} lg={4} mb={-2}>
              <FormControl fullWidth error={!!errors.securityRoleByBranch?.[index]?.securityRole}>
                <InputLabel id={`select-${index}-label`}>Security role</InputLabel>
                <Controller
                  control={control}
                  name={`securityRoleByBranch.${index}.securityRole`}
                  rules={{ required: 'This field must not be empty' }}
                  render={({ field }) => (
                    <Select
                      {...register?.(`securityRoleByBranch.${index}.securityRole`)}
                      error={!!errors.securityRoleByBranch?.[index]?.securityRole}
                      labelId={`select-${index}-label`}
                      value={field.value}
                      label="Security role">
                      {securityRoleList.dropdown?.map((option) => (
                        <MenuItem key={option.id} value={option.displayName}>
                          {option.displayName}
                        </MenuItem>
                      ))}
                    </Select>
                  )}
                />
              </FormControl>
            </Grid>
            <Grid xs={11.5} sm={7.5} lg={7.5} mb={-2}>
              <FormControl fullWidth error={!!errors.securityRoleByBranch?.[index]?.branch}>
                <InputLabel id={`select-${index}-label`}>Branch</InputLabel>
                <Controller
                  control={control}
                  rules={{ required: 'This field must not be empty' }}
                  name={`securityRoleByBranch.${index}.branch`}
                  render={({ field }) => (
                    <Select
                      {...register?.(`securityRoleByBranch.${index}.branch`)}
                      error={!!errors.securityRoleByBranch?.[index]?.branch}
                      labelId={`select-${index}-label`}
                      value={field.value}
                      label="Branch">
                      {branchesList.dropdown?.map((option) => (
                        <MenuItem key={option.id} value={option.displayName}>
                          {option.displayName}
                        </MenuItem>
                      ))}
                    </Select>
                  )}
                />
              </FormControl>
            </Grid>
            <Grid xs={0.5} sm={0.5} lg={0.5}>
              <IconButton onClick={() => remove(index)}>
                <DeleteIcon />
              </IconButton>
            </Grid>
          </Grid>
        ))}
      </Box>
      <Button startIcon={<AddIcon />} onClick={handleAddItem} variant="text">
        ADD ANOTHER ROLE AND BRANCH
      </Button>
    </>
  );
};

export default BranchesSecuritySection;
