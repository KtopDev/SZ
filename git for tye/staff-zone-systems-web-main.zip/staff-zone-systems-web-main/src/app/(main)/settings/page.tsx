'use client';

import Box from '@mui/material/Box';
import List from '@mui/material/List';
import Divider from '@mui/material/Divider';
import Typography from '@mui/material/Typography';
import StoreIcon from '@mui/icons-material/Store';
import ListItemText from '@mui/material/ListItemText';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemButton from '@mui/material/ListItemButton';
import Link from '@/components/shared/Link';
import ManageAccountsIcon from '@mui/icons-material/ManageAccounts';
import PolicyIcon from '@mui/icons-material/Policy';
import SettingsIcon from '@mui/icons-material/Settings';
import LibraryBooksIcon from '@mui/icons-material/LibraryBooks';

const Settings = () => (
  <>
    <Box paddingY="18px" paddingX="24px" boxShadow={1} bgcolor="common.white">
      <Typography paddingY="4px" fontWeight="regular" fontSize={24}>
        Settings
      </Typography>
      <Typography fontWeight="regular" fontSize={14} color="secondary.dark">
        Manage the main configuration of the app
      </Typography>
    </Box>
    <Box padding={2}>
      <List component="nav">
        <Link href={'/settings/branches'}>
          <ListItemButton>
            <ListItemIcon>
              <StoreIcon />
            </ListItemIcon>
            <ListItemText primary="Branches" />
          </ListItemButton>
          <Divider variant="inset" component="li" />
        </Link>

        <Link href={'/settings/client-app-terms'}>
          <ListItemButton>
            <ListItemIcon>
              <PolicyIcon />
            </ListItemIcon>
            <ListItemText primary="Client app's terms and conditions" />
          </ListItemButton>
          <Divider variant="inset" component="li" />
        </Link>

        <Link href={'/settings/worker-app-terms'}>
          <ListItemButton>
            <ListItemIcon>
              <PolicyIcon />
            </ListItemIcon>
            <ListItemText primary="Worker app's terms and conditions" />
          </ListItemButton>
          <Divider variant="inset" component="li" />
        </Link>

        <Link href={'/settings/users'}>
          <ListItemButton>
            <ListItemIcon>
              <ManageAccountsIcon />
            </ListItemIcon>
            <ListItemText primary="Users" />
          </ListItemButton>
          <Divider variant="inset" component="li" />
        </Link>

        <Link href={'/settings/company-settings'}>
          <ListItemButton>
            <ListItemIcon>
              <SettingsIcon />
            </ListItemIcon>
            <ListItemText primary="Company settings" />
          </ListItemButton>
          <Divider variant="inset" component="li" />
        </Link>

        <Link href={'/settings/tax-management'}>
          <ListItemButton>
            <ListItemIcon>
              <LibraryBooksIcon />
            </ListItemIcon>
            <ListItemText primary="Tax management" />
          </ListItemButton>
          <Divider variant="inset" component="li" />
        </Link>
      </List>
    </Box>
  </>
);

export default Settings;
