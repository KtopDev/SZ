import React from 'react';
import Box from '@mui/material/Box';
import EditIcon from '@mui/icons-material/Edit';
import IconButton from '@mui/material/IconButton';
import DeleteIcon from '@mui/icons-material/Delete';
import { Button, Link } from '@mui/material'
import DownloadIcon from '@mui/icons-material/Download';


export const RowActions = () => {
  return (
    <>
      <Box sx={{ display: 'flex', justifyContent: 'flex-start' }}>
        <Button startIcon={<DownloadIcon />}>
          <Link
            target="_blank"
            underline="none"
            color="inherit">
            DOWNLOAD
          </Link>
        </Button>
        <IconButton onClick={() => {}}>
          <EditIcon />
        </IconButton>
        <IconButton color="error" onClick={() => {}}>
          <DeleteIcon />
        </IconButton>
      </Box>
    </>
  );
};
