import React from 'react';
import Box from '@mui/material/Box';
import { TextField } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import Grid from '@mui/material/Unstable_Grid2';
import Typography from '@mui/material/Typography';
import RHSelect from '@/components/shared/Form/RHSelect';
import RHDatePicker from '@/components/shared/Form/RHDatePicker';
import { Control, FieldErrors, UseFormSetValue } from 'react-hook-form';
import { debounce } from 'lodash';
import { MRT_TablePagination } from 'material-react-table';

type Props = {
  setValue: UseFormSetValue<any>;
  errors: FieldErrors<any>;
  control: Control<any, any, any>;
  table: any;
};

const TaxFormsSearchFields = ({ setValue, errors, control, table }: Props) => {
  const mockJurisdiction = {
    dropdown:[
      { id: '1', displayName: 'Kansas' },
      { id: '2', displayName: 'Florida' },
      { id: '3', displayName: 'Delaware' },
      { id: '4', displayName: 'Oregon' },
      { id: '5', displayName: 'South Dakota' },
    ],
  }

  const debouncedSetValue = debounce(setValue, 1000);

  const handleNameInputChange = (e: any) => {
    debouncedSetValue('taxFormName', e.target.value);
  };

  return (
    <Box paddingY="8px" paddingX="24px" bgcolor="common.white" border="none">
      <Box sx={{ flexGrow: 1 }}>
        <Grid container alignItems="end" spacing={2} columns={16}>
          <Grid xs={5}>
            <TextField
              fullWidth
              InputProps={{
                startAdornment: <SearchIcon />,
              }}
              placeholder=" Search by name"
              id="outlined-basic"
              variant="outlined"
              name="taxFormName"
              onChange={handleNameInputChange}
            />
          </Grid>
          <Grid xs={4} py="0px">
            <RHSelect<ITaxManagementListFilter>
              label="Jurisdiction"
              propName="jurisdiction"
              options={mockJurisdiction}
              isLoading={false}
              rhProps={{ errors, control, required: false }}
            />
          </Grid>
          <Grid xs={2}>
            <Typography fontSize={14} paddingBottom="8px">
              Last update
            </Typography>
            <RHDatePicker<ITaxManagementListFilter>
              label="Start date"
              propName="startDate"
              rhProps={{ errors, control, required: false }}
            />
          </Grid>
          <Grid xs={2}>
            <RHDatePicker<ITaxManagementListFilter>
              label="End date"
              propName="endDate"
              rhProps={{ errors, control, required: false }}
            />
          </Grid>
          <Grid xs={3}>
            <Box ml="auto" pr={2}>
              <MRT_TablePagination table={table} />
            </Box>
          </Grid>
        </Grid>
      </Box>
    </Box>
  );
};

export default TaxFormsSearchFields;

export interface ITaxManagementListFilter {
  taxFormName: string;
  jurisdiction: string;
  startDate: string;
  endDate: string;
}
