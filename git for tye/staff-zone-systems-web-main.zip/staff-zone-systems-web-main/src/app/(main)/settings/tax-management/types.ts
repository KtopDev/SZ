export enum TaxManagementTabs {
  TaxTables = 'tax-tables',
  TaxForms = 'tax-forms',
  Jurisdictions = 'jurisdictions',
  TaxQuestions = 'tax-questions',
}
