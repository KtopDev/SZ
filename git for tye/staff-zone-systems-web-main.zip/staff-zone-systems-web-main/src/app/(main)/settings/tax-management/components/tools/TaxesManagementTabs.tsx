import React from 'react';
import { Box, Tab, Tabs } from '@mui/material';
import { TaxManagementTabs } from '../../types';

interface Props {
  activeTab: number;
  handleTabChange: (newValue: TaxManagementTabs) => void;
}

const TaxesManagementTabs = ({ activeTab, handleTabChange }: Props) => {
  return (
    <>
      <Box>
        <Box>
          <Tabs value={activeTab} aria-label="basic tabs example">
            <Tab label="TAX TABLES" id="TAX TABLES" onClick={() => handleTabChange(TaxManagementTabs.TaxTables)} />
            <Tab label="TAX FORMS" id="TAX FORMS" onClick={() => handleTabChange(TaxManagementTabs.TaxForms)} />
            <Tab
              label="jurisdictions"
              id="jurisdictions"
              onClick={() => handleTabChange(TaxManagementTabs.Jurisdictions)}
            />
            <Tab
              label="TAX QUESTIONS"
              id="TAX QUESTIONS"
              onClick={() => handleTabChange(TaxManagementTabs.TaxQuestions)}
            />
          </Tabs>
        </Box>
      </Box>
    </>
  );
};

export default TaxesManagementTabs;
