import { MRT_ColumnDef, MRT_Row } from 'material-react-table';
import dayjs from 'dayjs';
import Typography from '@mui/material/Typography';
import Tooltip from '@mui/material/Tooltip';
import { TaxDto } from '@/types/dto/TaxesDto';

export const taxFormsColumns = (): MRT_ColumnDef<TaxDto>[] => [
  {
    accessorKey: 'taxFormName',
    header: 'Tax form name',
    Cell: ({ row }: { row: MRT_Row<TaxDto> }) => (
      <Tooltip title={<Typography sx={{ fontSize: '16px' }}>{row.original.tax_form_name}</Typography>} arrow>
        <Typography
          fontWeight="500"
          style={{
            maxWidth: '250px',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
          }}>
          {row.original.tax_form_name}
        </Typography>
      </Tooltip>
    ),
  },
  {
    accessorKey: 'taxFormJurisdiction',
    header: 'Jurisdiction',
    Cell: ({ row }: { row: MRT_Row<TaxDto> }) => (
      <Tooltip title={<Typography sx={{ fontSize: '16px' }}>{row.original.jurisdiction}</Typography>} arrow>
        <Typography
          fontWeight="500"
          style={{
            maxWidth: '250px',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
          }}>
          {row.original.jurisdiction}
        </Typography>
      </Tooltip>
    ),
  },
  {
    accessorKey: 'startDate',
    header: 'Effective form',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<TaxDto> }) => (
      <span>{`${dayjs(row.original.tax_start_date).format('MM/DD/YYYY')}`}</span>
    ),
  },
  {
    accessorKey: 'modifiedAt',
    header: 'Last updated',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<TaxDto> }) => (
      <span>{`${dayjs(row.original.tax_last_updated).format('MM/DD/YYYY')}`}</span>
    ),
  },

];
