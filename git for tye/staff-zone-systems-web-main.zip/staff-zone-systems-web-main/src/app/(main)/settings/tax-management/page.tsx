'use client';

import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Unstable_Grid2';
import TaxesManagementTabs from './components/tools/TaxesManagementTabs';
import { useState } from 'react';
import Table from '@/components/shared/Table/Table';
import { taxFormsColumns } from './components/tax-forms/tableColumns';
import { useForm } from 'react-hook-form';
import { SortingState } from '@tanstack/table-core';
import TaxFormsSearchFields from './components/tax-forms/TaxFormsSearchFields';
import TaxesManagementCreateButton from './components/tools/TaxesManagementCreateButton';
import { RowActions } from './components/tax-forms/RowActions';
import { TaxManagementTabs } from './types';

const TaxManagement = () => {
  const {
    formState: { errors },
    setValue,
    control,
  } = useForm<any>({
    defaultValues: {
      taxName: '',
      jurisdiction: '',
      startDate: '',
      endDate: '',
    },
  });
  const handleActiveTab = () => {
    switch (activeTab) {
    case TaxManagementTabs.TaxTables:
      return 0;
    case TaxManagementTabs.TaxForms:
      return 1;
    case TaxManagementTabs.Jurisdictions:
      return 2;
    case TaxManagementTabs.TaxQuestions:
      return 3;
    default:
      return 1;
    }
  };
  const [activeTab, setActiveTab] = useState<TaxManagementTabs>(TaxManagementTabs.TaxForms);
  const [sorting, setSorting] = useState<SortingState>([]);
  const [pagination, setPagination] = useState({ pageIndex: 1, pageSize: 10 });

  const handleTabChange = (newValue: TaxManagementTabs) => {
    setActiveTab(newValue);
  };

  const renderTopToolbar = ({ table }: any) => (
    <TaxFormsSearchFields setValue={setValue} errors={errors} control={control} table={table} />
  );

  return (
    <>
      <Box paddingY="8px" paddingX="24px" bgcolor="common.white" border="none">
        <Typography paddingY="4px" fontWeight="regular" fontSize={24}>
          Taxes management
        </Typography>

        <Grid container direction="row" justifyContent="space-between" mb={2}>
          <TaxesManagementTabs activeTab={handleActiveTab()} handleTabChange={handleTabChange} />
          <TaxesManagementCreateButton tabName={activeTab} refetch={() => {}} />
        </Grid>
      </Box>
      {activeTab === TaxManagementTabs.TaxForms && (
        <Table
          mrtProps={{
            data: [
              {
                tax_form_name: 'Federal W4',
                jurisdiction: 'Kansas',
                startDate: '2024-07-23T16:15:53.77377+00:00',
                lastUpdated: '2024-07-23T16:15:53.77377+00:00',
              },
            ],
            columns: taxFormsColumns() as any,
            renderTopToolbar,
            renderRowActions: () => <RowActions />,
            state: {
              sorting,
              pagination,
              isLoading: false,
            },
            onPaginationChange: setPagination,
            onSortingChange: setSorting,
            manualPagination: true,
          }}
          rowCount={1}
        />
      )}
    </>
  );
};

export default TaxManagement;
