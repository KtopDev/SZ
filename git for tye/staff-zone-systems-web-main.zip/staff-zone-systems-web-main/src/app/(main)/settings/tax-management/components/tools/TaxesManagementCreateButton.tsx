import React, { useState } from 'react';
import { Box, Button } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import CreateTool from '@/app/(main)/settings/company-settings/[manageRequirementsTab]/components/tools/CreateTool/CreateTool';
import CreateCertificationBadge from '@/app/(main)/settings/company-settings/[manageRequirementsTab]/components/manage-certification-badge/CreateCertificationBadge/CreateCertificationBadge';
import { TaxManagementTabs } from '../../types';

interface Props {
  tabName: string;
  refetch: () => void;
}

const TaxesManagementCreateButton = ({ tabName, refetch }: Props) => {
  const [showToolModal, setShowToolModal] = useState(false);
  const [showCertificatesModal, setShowCertificatesModal] = useState(false);
  // prettier-ignore
  const renderButtonText = () => {
    switch (tabName) {
    case TaxManagementTabs.TaxTables:
      return 'ADD ROW';
    default:
      return 'CREATE';
    }
  };

  return (
    <>
      <Box paddingY="5px">
        <Button variant="contained" startIcon={<AddIcon />} onClick={() => {}}>
          {renderButtonText()}
        </Button>
      </Box>


      <CreateTool open={showToolModal} handleClose={() => setShowToolModal(false)} refetch={refetch} />
      <CreateCertificationBadge
        open={showCertificatesModal}
        handleClose={() => setShowCertificatesModal(false)}
        refetch={refetch}
      />

    </>
  );
};

export default TaxesManagementCreateButton;
