'use client';
import React, { useState } from 'react';
import { Box, Button, IconButton } from '@mui/material';
import DownloadIcon from '@mui/icons-material/Download';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import UpdateTermModal from './UpdateTermModal';
import DeleteTermModal from './DeleteTermModal';
import { WorkerAppTerm } from '@/types/dto/WorkerAppTerm';

type Props = {
  rowData: WorkerAppTerm;
  refetchTerms: () => void;
};

export const RenderRowActions = ({ rowData, refetchTerms }: Props) => {
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const openUpdateModal = () => setShowUpdateModal(true);
  const closeUpdateModal = () => setShowUpdateModal(false);

  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const openDeleteModal = () => setShowDeleteModal(true);
  const closeDeleteModal = () => setShowDeleteModal(false);

  return (
    <>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
        <Button href={rowData.worker_app_term_file_uri} startIcon={<DownloadIcon />}>
          DOWNLOAD ENGLISH VERSION
        </Button>
        <Button href={rowData.worker_app_term_es_file_uri} startIcon={<DownloadIcon />}>
          DOWNLOAD SPANISH VERSION
        </Button>

        <IconButton onClick={openUpdateModal}>
          <EditIcon color="secondary" />
        </IconButton>
        <IconButton color="error" onClick={openDeleteModal}>
          <DeleteIcon />
        </IconButton>
      </Box>

      {showUpdateModal && (
        <UpdateTermModal
          term={rowData}
          showModal={showUpdateModal}
          closeModal={closeUpdateModal}
          afterSubmission={refetchTerms}
        />
      )}

      {showDeleteModal && (
        <DeleteTermModal
          termId={rowData.worker_app_term_id}
          showModal={showDeleteModal}
          closeModal={closeDeleteModal}
          afterSubmission={refetchTerms}
        />
      )}
    </>
  );
};
