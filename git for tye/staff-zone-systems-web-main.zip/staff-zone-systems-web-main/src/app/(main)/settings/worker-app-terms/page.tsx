'use client';

import Table from '@/components/shared/Table/Table';
import { columns } from './components/tableColumns';
import { SortingState } from '@tanstack/table-core';
import { useEffect, useState } from 'react';
import { useGetWorkerTermsList, useUpdateTermsOrder } from '@/requests/api/workerTermsApi/workerTermsApi';
import CreateTermModal from './components/CreateTermModal';
import { RenderRowActions } from './components/RenderRowActions';
import { HeaderActions } from './components/HeaderActions';
import { MRT_Row } from 'material-react-table';
import { WorkerAppTerm } from '@/types/dto/WorkerAppTerm';
import { UpdateWorkerTermsOrderItem } from '@/types/dto/TermsDto';

const WorkerAppTermsPage = () => {
  const [pagination, setPagination] = useState({ pageIndex: 1, pageSize: 10 });
  const [sorting, setSorting] = useState<SortingState>([]);
  const { data, loading, refetch } = useGetWorkerTermsList();
  const [updateTermsOrder] = useUpdateTermsOrder();
  const [localData, setLocalData] = useState(data.workerAppTerms);

  const [showModal, setShowModal] = useState(false);
  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(false);

  const renderTopToolbar = () => <HeaderActions openModal={openModal} />;

  useEffect(() => {
    if (data && data.workerAppTerms) {
      const ordered = data.workerAppTerms.sort((a, b) => a.sort_order - b.sort_order);
      setLocalData(ordered);
    }
  }, [data]);

  return (
    <>
      <Table
        mrtProps={{
          data: localData || [],
          columns: columns() as any,
          enableRowDragging: true,
          enableRowOrdering: true,
          muiRowDragHandleProps: ({ table }) => ({
            onDragEnd: async () => {
              const { draggingRow, hoveredRow } = table.getState();
              if (hoveredRow && draggingRow) {
                localData.splice(
                  (hoveredRow as MRT_Row<WorkerAppTerm>).index,
                  0,
                  localData.splice(draggingRow.index, 1)[0]
                );
                setLocalData([...localData]);
                const newOrder = localData.map((item, index) => {
                  return {
                    worker_app_term_id: item.worker_app_term_id,
                    sort_order: index + 1,
                  } as UpdateWorkerTermsOrderItem;
                });
                await updateTermsOrder({ termsOrder: newOrder });
              }
            },
          }),
          enableRowActions: true,
          renderRowActions: ({ row }) => <RenderRowActions rowData={row.original} refetchTerms={refetch} />,
          displayColumnDefOptions: {
            'mrt-row-drag': {
              header: 'Order',
            },
            'mrt-row-actions': {
              header: 'Actions',
              size: 280,
            },
          },
          state: {
            sorting,
            pagination,
            isLoading: loading,
          },
          onPaginationChange: setPagination,
          onSortingChange: setSorting,
          manualPagination: true,
          renderTopToolbar,
        }}
        rowCount={data?.workerAppTerms?.length || 0}
      />
      <CreateTermModal showModal={showModal} closeModal={closeModal} afterSubmission={refetch} />
    </>
  );
};

export default WorkerAppTermsPage;
