import { MRT_ColumnDef, MRT_Row } from 'material-react-table';
import { WorkerAppTerm } from '@/types/dto/WorkerAppTerm';

export const columns = (): MRT_ColumnDef<WorkerAppTerm>[] => [
  {
    accessorKey: 'id',
    header: '',
    enableSorting: false,
    size: 5,
    Cell: ({ row }: { row: MRT_Row<WorkerAppTerm> }) => <div style={{ marginLeft: -15 }}>{row.index + 1}</div>,
  },
  {
    accessorKey: 'worker_app_term_label',
    header: 'Title',
    Cell: ({ row }: { row: MRT_Row<WorkerAppTerm> }) => <>{row.original.worker_app_term_label}</>,
  },
  {
    accessorKey: 'modified_at',
    header: 'Last update',
    size: 50,
    Cell: ({ row }: { row: MRT_Row<WorkerAppTerm> }) => <>{formatDate(row.original.modified_at)}</>,
  },
  {
    accessorKey: 'in_use_branches',
    header: 'Branches using this',
    size: 250,
    Cell: ({ row }: { row: MRT_Row<WorkerAppTerm> }) => (
      <>
        {row.original.in_use_branches &&
          row.original.in_use_branches.map((branchInUse: any) => (
            <span key={branchInUse.branch_id}>{branchInUse.branch_name}</span>
          ))}
      </>
    ),
  },
];

const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  const formattedDate = `${day}/${month}/${year}`;
  return formattedDate;
};
