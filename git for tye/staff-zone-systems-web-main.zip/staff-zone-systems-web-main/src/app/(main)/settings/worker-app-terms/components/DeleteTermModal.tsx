'use client';
import { Backdrop, Box, Button, Fade, Modal, Typography, Stack } from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import { useSnackbar } from '@/context/SnackbarContext';
import { useDeleteWorkerTerm } from '@/requests/api/workerTermsApi/workerTermsApi';

type Props = {
  showModal?: boolean;
  closeModal?: () => void;
  afterSubmission?: () => void;
  termId: string;
};

export default function DeleteTermModal({ termId, showModal, closeModal, afterSubmission }: Props) {
  const [deleteWorkerTerm, { loading: updating }] = useDeleteWorkerTerm();
  const { setSuccessMessage, setErrorMessage } = useSnackbar();

  const submit = async () => {
    try {
      await deleteWorkerTerm(termId);
      if (closeModal) {
        closeModal();
        if (afterSubmission) {
          afterSubmission();
        }
        setSuccessMessage('Item deleted');
      }
    } catch (error) {
      setErrorMessage('Error deleting the file');
    }
  };

  return (
    <Modal
      aria-labelledby="transition-modal-title"
      aria-describedby="transition-modal-description"
      open={showModal ? showModal : false}
      onClose={closeModal}
      closeAfterTransition
      slots={{ backdrop: Backdrop }}
      slotProps={{
        backdrop: {
          timeout: 500,
        },
      }}>
      <Fade in={showModal}>
        <Box sx={styles.modal}>
          <Typography variant="h6" gutterBottom>
            Delete item
          </Typography>
          <Typography variant="body1" gutterBottom>
            Are you sure you want to delete this item? This legal statement will dissapear from the list of terms and
            conditions on the client application screen.
          </Typography>

          <Stack spacing={2} direction="row" sx={{ display: 'flex', justifyContent: 'flex-end' }} mt={2}>
            <Button variant="text" onClick={closeModal}>
              CANCEL
            </Button>
            <LoadingButton
              variant="contained"
              loading={updating}
              loadingPosition="start"
              color="error"
              onClick={submit}>
              DELETE ITEM
            </LoadingButton>
          </Stack>
        </Box>
      </Fade>
    </Modal>
  );
}

const styles = {
  modal: {
    position: 'absolute' as const,
    top: '40%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 700,
    bgcolor: 'background.paper',
    boxShadow: 24,
    p: 2,
  },
};
