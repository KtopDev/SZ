'use client';
import { useState } from 'react';
import { Backdrop, Box, Button, Fade, Modal, Typography, Stack } from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import TextField from '@mui/material/TextField';
import { Dropzone, ExtFile, FileMosaic } from '@dropzone-ui/react';
import FormControlLabel from '@mui/material/FormControlLabel';
import Switch from '@mui/material/Switch';
import { useSnackbar } from '@/context/SnackbarContext';
import { WorkerTermDto } from '@/types/dto/WorkerAppTerm';
import { useCreateWorkerTerm } from '@/requests/api/workerTermsApi/workerTermsApi';

type Props = {
  showModal?: boolean;
  closeModal?: () => void;
  afterSubmission?: () => void;
};

export default function ConfirmationModal({ showModal, closeModal, afterSubmission }: Props) {
  const [createWorkerTerm] = useCreateWorkerTerm();
  const { setSuccessMessage, setErrorMessage } = useSnackbar();
  const [title, setTitle] = useState('');
  const [enFile, setENFile] = useState<ExtFile[]>([]);
  const [esFile, setESFile] = useState<ExtFile[]>([]);

  const clearForm = () => {
    setTitle('');
    setENFile([]);
    setESFile([]);
  };

  const updateENFile = (incommingFiles: ExtFile[]) => {
    setENFile(incommingFiles);
  };

  const updateESFile = (incommingFiles: ExtFile[]) => {
    setESFile(incommingFiles);
  };

  const handleFormData = (fileDto: WorkerTermDto) => {
    const formData = new FormData();
    formData.append('fileName', fileDto.fileName);
    formData.append('document', fileDto.document);
    formData.append('spanishDocument', fileDto.spanishDocument);
    return formData;
  };

  const submit = async () => {
    const termDto = {
      fileName: title,
      document: enFile[0].file,
      spanishDocument: esFile[0].file,
    } as any;
    const formData = await handleFormData(termDto);
    try {
      await createWorkerTerm(formData);
      if (closeModal) {
        closeModal();
        clearForm();
        if (afterSubmission) {
          afterSubmission();
        }
        setSuccessMessage('Term added successfully');
      }
    } catch (error) {
      setErrorMessage('Error during file upload');
    }
  };

  return (
    <Modal
      aria-labelledby="transition-modal-title"
      aria-describedby="transition-modal-description"
      open={showModal ? showModal : false}
      onClose={closeModal}
      closeAfterTransition
      slots={{ backdrop: Backdrop }}
      slotProps={{
        backdrop: {
          timeout: 500,
        },
      }}>
      <Fade in={showModal}>
        <Box sx={styles.modal}>
          <Typography variant="h6" gutterBottom>
            Add item
          </Typography>

          <Typography variant="body2" gutterBottom>
            All fields are required
          </Typography>

          <Typography variant="caption" display="block" gutterBottom>
            This document must be mobile-friendly since it will be displayed on the Worker app. There must be no margins
            or padding on the document borders. A single column must contain all content.
          </Typography>

          <TextField
            required
            id="outlined-required"
            label="Title"
            value={title}
            onChange={(e) => {
              setTitle(e.target.value);
            }}
            fullWidth
            sx={{ marginBottom: 2 }}
          />

          <Typography variant="h6" display="block" gutterBottom>
            English version
          </Typography>

          <Dropzone
            onChange={updateENFile}
            value={enFile}
            maxFiles={1}
            maxFileSize={41943040}
            accept=".txt,.pdf,image/*">
            {enFile.map((file) => (
              <FileMosaic key={file.id} {...file} info />
            ))}
          </Dropzone>

          <br />

          <Typography variant="h6" display="block" gutterBottom>
            Spanish version
          </Typography>

          <Dropzone
            onChange={updateESFile}
            value={esFile}
            maxFiles={1}
            maxFileSize={41943040}
            accept=".txt,.pdf,image/*">
            {esFile.map((file) => (
              <FileMosaic key={file.id} {...file} info />
            ))}
          </Dropzone>

          <FormControlLabel control={<Switch defaultChecked />} label="Ask users to agree to this version" />

          <Stack spacing={2} direction="row" sx={{ display: 'flex', justifyContent: 'flex-end' }} mt={2}>
            <Button variant="text" onClick={closeModal}>
              CANCEL
            </Button>
            <LoadingButton
              variant="contained"
              disabled={!title || esFile.length === 0 || enFile.length === 0}
              loading={false}
              loadingPosition="start"
              color="primary"
              onClick={submit}>
              ADD ITEMS
            </LoadingButton>
          </Stack>
        </Box>
      </Fade>
    </Modal>
  );
}

const styles = {
  modal: {
    position: 'absolute' as const,
    top: '45%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 700,
    bgcolor: 'background.paper',
    boxShadow: 24,
    p: 2,
  },
};
