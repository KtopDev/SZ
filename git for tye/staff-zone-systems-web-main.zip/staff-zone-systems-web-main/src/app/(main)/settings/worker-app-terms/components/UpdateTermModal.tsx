'use client';
import { useEffect, useState } from 'react';
import { Backdrop, Box, Button, Fade, Modal, Typography, Stack } from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import TextField from '@mui/material/TextField';
import { ExtFile } from '@dropzone-ui/react';
import { useSnackbar } from '@/context/SnackbarContext';
import { useUpdateWorkerTerm } from '@/requests/api/workerTermsApi/workerTermsApi';
import { loadSampleFile } from '../functions';
import { WorkerAppTerm, WorkerTermDto } from '@/types/dto/WorkerAppTerm';
import DropzoneBlock from './DropzoneBlock';

type Props = {
  showModal?: boolean;
  closeModal?: () => void;
  afterSubmission?: () => void;
  term: WorkerAppTerm;
};

export default function UpdateTermModal({ term, showModal, closeModal, afterSubmission }: Props) {
  const [updateWorkerTerm, { loading: updating }] = useUpdateWorkerTerm();
  const { setSuccessMessage, setErrorMessage } = useSnackbar();
  const [sampleEnFile, setSampleEnFile] = useState({});
  const [sampleEsFile, setSampleEsFile] = useState({});
  const [title, setTitle] = useState(term.worker_app_term_label);
  const [enFile, setEnFile] = useState<ExtFile[]>([]);
  const [esFile, setEsFile] = useState<ExtFile[]>([]);

  const [showEnDropzone, setShowEnDropzone] = useState(false);
  const [showEsDropzone, setShowEsDropzone] = useState(false);
  const [showEnMosaic, setShowEnMosaic] = useState(true);
  const [showEsMosaic, setShowEsMosaic] = useState(true);
  const disableSubmission = !title || (enFile.length === 0 && !showEnMosaic) || (esFile.length === 0 && !showEsMosaic);

  const clearForm = () => {
    setTitle('');
    setEnFile([]);
    setEsFile([]);
  };

  const updateEnFile = (incommingFiles: ExtFile[]) => {
    setEnFile(incommingFiles);
  };

  const updateEsFile = (incommingFiles: ExtFile[]) => {
    setEsFile(incommingFiles);
  };

  const handleFormData = (fileDto: WorkerTermDto) => {
    const formData = new FormData();
    formData.append('fileName', fileDto.fileName);
    if (fileDto.document) {
      formData.append('document', fileDto.document);
    }
    if (fileDto.spanishDocument) {
      formData.append('spanishDocument', fileDto.spanishDocument);
    }
    return formData;
  };

  const toggleEnDropzone = () => {
    setShowEnDropzone(true);
    setShowEnMosaic(false);
  };

  const toggleEsDropzone = () => {
    setShowEsDropzone(true);
    setShowEsMosaic(false);
  };

  const submit = async () => {
    const termDto = {
      fileName: title,
      document: showEnMosaic ? null : enFile[0].file,
      spanishDocument: showEsMosaic ? null : esFile[0].file,
    } as WorkerTermDto;
    const formData = await handleFormData(termDto);
    try {
      await updateWorkerTerm({ termId: term.worker_app_term_id, data: formData });
      if (closeModal) {
        closeModal();
        clearForm();
        if (afterSubmission) {
          afterSubmission();
        }
        setSuccessMessage('Term updated successfully');
      }
    } catch (error) {
      setErrorMessage('Error during file upload');
    }
  };

  useEffect(() => {
    if (term.worker_app_term_file_uri && term.worker_app_term_es_file_uri && showModal) {
      setSampleEnFile(loadSampleFile(term.worker_app_term_file_uri));
      setSampleEsFile(loadSampleFile(term.worker_app_term_es_file_uri));
    }
    if (term.worker_app_term_label) {
      setTitle(term.worker_app_term_label);
    }
  }, [showModal, term.worker_app_term_es_file_uri, term.worker_app_term_file_uri, term.worker_app_term_label]);

  return (
    <Modal
      aria-labelledby="transition-modal-title"
      aria-describedby="transition-modal-description"
      open={showModal ? showModal : false}
      onClose={closeModal}
      closeAfterTransition
      slots={{ backdrop: Backdrop }}
      slotProps={{
        backdrop: {
          timeout: 500,
        },
      }}>
      <Fade in={showModal}>
        <Box sx={styles.modal}>
          <Typography variant="h6" gutterBottom>
            Edit item
          </Typography>
          <Typography variant="body2" gutterBottom>
            All fields are required
          </Typography>
          <TextField
            required
            id="outlined-required"
            label="Title"
            value={title}
            onChange={(e) => {
              setTitle(e.target.value);
            }}
            fullWidth
            sx={{ marginBottom: 2 }}
          />
          <Typography variant="caption" display="block" gutterBottom>
            This document must be mobile-friendly since it will be displayed on the Worker app. There must be no margins
            or padding on the document borders. A single column must contain all content.
          </Typography>

          <DropzoneBlock
            title="English version"
            showMosaic={showEnMosaic}
            showDropzone={showEnDropzone}
            toggleDropzone={toggleEnDropzone}
            files={enFile}
            updateFiles={updateEnFile}
            sampleFile={sampleEnFile}
          />

          <br />

          <DropzoneBlock
            title="Spanish version"
            showMosaic={showEsMosaic}
            showDropzone={showEsDropzone}
            toggleDropzone={toggleEsDropzone}
            files={esFile}
            updateFiles={updateEsFile}
            sampleFile={sampleEsFile}
          />

          <Stack spacing={2} direction="row" sx={{ display: 'flex', justifyContent: 'flex-end' }} mt={2}>
            <Button variant="text" onClick={closeModal}>
              CANCEL
            </Button>
            <LoadingButton
              variant="contained"
              disabled={disableSubmission}
              loading={updating}
              loadingPosition="start"
              color="primary"
              onClick={submit}>
              SAVE CHANGES
            </LoadingButton>
          </Stack>
        </Box>
      </Fade>
    </Modal>
  );
}

const styles = {
  modal: {
    position: 'absolute' as const,
    top: '40%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 700,
    bgcolor: 'background.paper',
    boxShadow: 24,
    p: 2,
  },
};
