'use client';

import { Typography } from '@mui/material';
import { Dropzone, ExtFile, FileMosaic } from '@dropzone-ui/react';
import stylesModule from '../client-app-terms.module.css';

type Props = {
  title: string;
  showMosaic: boolean;
  showDropzone: boolean;
  toggleDropzone: () => void;
  files: ExtFile[];
  updateFiles: (incommingFiles: ExtFile[]) => void;
  sampleFile: any;
};

const DropzoneBlock = ({ title, sampleFile, showMosaic, showDropzone, toggleDropzone, files, updateFiles }: Props) => {
  return (
    <>
      <Typography variant="h6" gutterBottom>
        {title}
      </Typography>

      {showMosaic && (
        <div className={stylesModule.mosaic}>
          <FileMosaic id={0} {...sampleFile} onDelete={toggleDropzone} />
        </div>
      )}

      {showDropzone && (
        <Dropzone
          fakeUpload={true}
          onChange={updateFiles}
          value={files}
          maxFiles={1}
          maxFileSize={41943040}
          accept=".txt,.pdf,image/*">
          {files.map((file) => (
            <FileMosaic key={file.id} {...file} info />
          ))}
        </Dropzone>
      )}
    </>
  );
};

export default DropzoneBlock;
