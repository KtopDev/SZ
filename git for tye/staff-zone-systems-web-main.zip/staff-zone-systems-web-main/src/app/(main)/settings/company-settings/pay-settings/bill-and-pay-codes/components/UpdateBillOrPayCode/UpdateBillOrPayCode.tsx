import BillOrPayCodeBaseForm from '../BillOrPayCodeBaseForm';
import { useSnackbar } from '@/context/SnackbarContext';
import { useUpdatePayCode } from '@/requests/api/payCodeApi/payCodeApi';
import { useUpdateBillCode } from '@/requests/api/billCodeApi/billCodeApi';

const UpdateBillOrPayCode = ({ open, handleClose, billCodeData, activeTab, refresh }: any) => {
  const [updatePayCode, { loading: loadingUpdatePayCode }] = useUpdatePayCode();
  const [updateBillCode, { loading: loadingUpdateBillCode }] = useUpdateBillCode();
  const { setMessage } = useSnackbar();
  const handleUpdateBillCode = async (formValues: any, setError: any, reset: any) => {
    try {
      const mutationCall = activeTab === 0 ? updateBillCode : updatePayCode;
      const payload =
        activeTab === 0
          ? {
            id: formValues.id,
            billCodeName: formValues.name,
            billCodeDescription: formValues.description,
          }
          : {
            payCodeName: formValues.name,
            payCodeDescription: formValues.description,
            id: formValues.id,
          };
      await mutationCall(payload);
      handleClose();
      refresh();
      reset();
      setMessage('Changes saved');
    } catch (e: any) {
      if (e.response.status === 400) {
        setError('name', { message: e.response.data?.details[0]?.message });
      }
    }
  };

  return (
    <BillOrPayCodeBaseForm
      open={open}
      handleClose={handleClose}
      loading={loadingUpdatePayCode || loadingUpdateBillCode}
      isCreate={false}
      activeTab={activeTab}
      billCodeData={billCodeData}
      onSubmit={handleUpdateBillCode}
    />
  );
};

export default UpdateBillOrPayCode;
