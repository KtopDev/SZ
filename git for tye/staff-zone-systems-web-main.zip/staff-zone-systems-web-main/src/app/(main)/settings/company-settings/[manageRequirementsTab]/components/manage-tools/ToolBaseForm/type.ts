export type ToolForm = {
  id?: string;
  toolName: string;
  toolAbbreviation: string;
  toolDescription: string;
  branch: {
    id: string;
    name: string;
  };
};
