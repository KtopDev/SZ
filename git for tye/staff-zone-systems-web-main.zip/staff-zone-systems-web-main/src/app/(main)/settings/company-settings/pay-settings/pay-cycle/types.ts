export type IPayCycleListFilter = {
  name: string;
};
