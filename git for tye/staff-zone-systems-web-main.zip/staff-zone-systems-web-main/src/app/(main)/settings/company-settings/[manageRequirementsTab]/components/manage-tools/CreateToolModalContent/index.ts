import CreateToolModalContent from '@/app/(main)/settings/company-settings/[manageRequirementsTab]/components/manage-tools/CreateToolModalContent/CreateToolModalContent';

export default CreateToolModalContent;
