import React from 'react';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Unstable_Grid2';
import { MRT_TablePagination } from 'material-react-table';
import SearchIcon from '@mui/icons-material/Search';
import { TextField } from '@mui/material';

interface Props {
  table: any;
  handleNameInputChange: any;
}

const TopToolbar = ({ table, handleNameInputChange }: Props) => {
  return (
    <Box
      py={1}
      sx={{
        backgroundColor: 'common.white',
        justifyContent: 'space-between',
      }}>
      <Grid pl={3} container alignItems="end" spacing={2} columns={100}>
        <Grid xs={85}>
          <Box>
            <TextField
              InputProps={{
                startAdornment: <SearchIcon />,
              }}
              fullWidth
              label="Search By Name"
              margin="none"
              onChange={handleNameInputChange}
            />
          </Box>
        </Grid>
        <Box ml="auto" pr={3}>
          <MRT_TablePagination table={table} />
        </Box>
      </Grid>
    </Box>
  );
};

export default TopToolbar;
