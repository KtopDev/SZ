import React, { useState } from 'react';
import { Box, Button } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import PPEFormModal from './ppe/PPEFormModal';
import CreateTool from '@/app/(main)/settings/company-settings/[manageRequirementsTab]/components/tools/CreateTool/CreateTool';
import SiteRequirementsFormModal from './manage-site-requirements/SiteRequirementsFormModal';
import CreateCertificationBadge from '@/app/(main)/settings/company-settings/[manageRequirementsTab]/components/manage-certification-badge/CreateCertificationBadge/CreateCertificationBadge';

interface Props {
  tabName: string;
  refetch: () => void;
}

const RenderCreateButton = ({ tabName, refetch }: Props) => {
  const [showPPEModal, setShowPPEModal] = useState(false);
  const [showToolModal, setShowToolModal] = useState(false);
  const [showSiteRequirementsModal, setShowSiteRequirementsModal] = useState(false);
  const [showCertificatesModal, setShowCertificatesModal] = useState(false);
  // prettier-ignore
  const renderButtonText = () => {
    switch (tabName) {
    case 'manage-ppe':
      return 'CREATE PPE';
    case 'manage-site-requirements':
      return 'CREATE SITE REQUIREMENT';
    default:
      return 'CREATE';
    }
  };
  // prettier-ignore
  const handleModal = () => {
    switch (tabName) {
    case 'manage-ppe':
      setShowPPEModal(true);
      return;
    case 'manage-tools':
      setShowToolModal(true);
      return;
    case 'manage-site-requirements':
      setShowSiteRequirementsModal(true);
      return;
    case 'certifications-badge':
      setShowCertificatesModal(true);
      break;
    default:
      return;
    }
  };

  return (
    <>
      <Box paddingY="5px">
        <Button variant="contained" startIcon={<AddIcon />} onClick={handleModal}>
          {renderButtonText()}
        </Button>
      </Box>

      {showPPEModal && (
        <PPEFormModal showModal={showPPEModal} closeModal={() => setShowPPEModal(false)} refetch={refetch} />
      )}
      <CreateTool open={showToolModal} handleClose={() => setShowToolModal(false)} refetch={refetch} />
      <CreateCertificationBadge
        open={showCertificatesModal}
        handleClose={() => setShowCertificatesModal(false)}
        refetch={refetch}
      />
      {showSiteRequirementsModal && (
        <SiteRequirementsFormModal
          showModal={showSiteRequirementsModal}
          closeModal={() => setShowSiteRequirementsModal(false)}
        />
      )}
    </>
  );
};

export default RenderCreateButton;
