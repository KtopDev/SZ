export interface IFutaSutaSdiFilter {
  nameCode: string;
  state: string;
  status: string;
  startDate: string;
  endDate: string;
  isRowActive: boolean;
}
