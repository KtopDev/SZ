import { PayCycleForm } from '@/app/(main)/settings/company-settings/pay-settings/pay-cycle/components/PayCycleBaseForm/types';
import { useSnackbar } from '@/context/SnackbarContext';
import ToolBaseForm from '@/app/(main)/settings/company-settings/[manageRequirementsTab]/components/manage-tools/ToolBaseForm/ToolBaseForm';

const CreateToolModalContent = ({ open, handleClose, refetch }: any) => {
  //const [createTool, { loading }] = useCreateTool();
  const { setMessage } = useSnackbar();

  const createTool = async (props: any) => props;
  const loading = false;

  const onSubmit = async (formValues: PayCycleForm, setError: any) => {
    try {
      await createTool({
        payCycleName: formValues.name,
        startIsoDayOfWeek: formValues.startDay,
      });
      refetch();
      handleClose();
      setMessage('Item created successfully');
    } catch (e: any) {
      if (e.response.status === 400) {
        setError('name', { message: e.response.data?.details[0]?.message });
      }
    }
  };

  return <ToolBaseForm open={open} handleClose={handleClose} isCreate onSubmit={onSubmit} isLoading={loading} />;
};

export default CreateToolModalContent;
