import { MRT_ColumnDef, MRT_Row } from 'material-react-table';
import dayjs from 'dayjs';
import Typography from '@mui/material/Typography';
import Tooltip from '@mui/material/Tooltip';
import { SiteRequirementDto } from '@/types/dto/SiteRequirementDto';

export const columns = (): MRT_ColumnDef<SiteRequirementDto>[] => [
  {
    accessorKey: 'ppeName',
    header: 'Name',
    Cell: ({ row }: { row: MRT_Row<SiteRequirementDto> }) => (
      <Typography fontWeight="500">{row.original.site_requirement_name}</Typography>
    ),
  },
  {
    header: 'Branch',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<SiteRequirementDto> }) => (
      <Typography fontWeight="500">{row.original.branch_name}</Typography>
    ),
  },
  {
    accessorKey: 'ppeDescription',
    header: 'Description',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<SiteRequirementDto> }) => (
      <Tooltip
        title={<Typography sx={{ fontSize: '16px' }}>{row.original.site_requirement_description}</Typography>}
        arrow>
        <Typography
          fontWeight="500"
          style={{
            maxWidth: '150px',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
          }}>
          {row.original.site_requirement_description}
        </Typography>
      </Tooltip>
    ),
  },
  {
    accessorKey: 'ppeOccurrences',
    header: 'Occurrences',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<SiteRequirementDto> }) => (
      <Typography fontWeight="500">{row.original.ocurrences}</Typography>
    ),
  },
  {
    accessorKey: 'modifiedAt',
    header: 'Last updated',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<SiteRequirementDto> }) => (
      <span>{`${dayjs(row.original.modified_at).format('MM/DD/YYYY')}`}</span>
    ),
  },
];
