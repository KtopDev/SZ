import UpdateCompCodeModalContent from './UpdateCompCodeModalContent';

export default UpdateCompCodeModalContent;
