import RHTextField from '@/components/shared/Form/RHTextField';
import { useForm } from 'react-hook-form';
import { Backdrop, Button, Card, CardContent, FormControl, Stack } from '@mui/material';
import { commonModalStyle } from '@/theme/constants';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Unstable_Grid2';
import LoadingButton from '@mui/lab/LoadingButton';
import React, { useEffect } from 'react';
import { ToolForm } from '@/app/(main)/settings/company-settings/[manageRequirementsTab]/components/manage-tools/ToolBaseForm/type';
import FormLabel from '@mui/material/FormLabel';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Radio from '@mui/material/Radio';
import Modal from '@mui/material/Modal';

const ToolBaseForm = ({ open, isCreate, toolData, handleClose, isLoading, onSubmit }: any) => {
  const {
    control,
    formState: { errors, isValid },
    handleSubmit,
    reset,
    setError,
  } = useForm<ToolForm>({
    mode: 'onBlur',
    defaultValues: isCreate ? ({} as ToolForm) : toolData,
  });

  useEffect(() => {
    reset(toolData);
  }, [toolData, reset]);

  return (
    <Modal
      open={open}
      onClose={handleClose}
      closeAfterTransition
      slots={{ backdrop: Backdrop }}
      slotProps={{
        backdrop: {
          timeout: 500,
        },
      }}>
      <Card sx={commonModalStyle}>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            {isCreate ? 'Create tool' : 'Edit tool'}
          </Typography>
          <Typography variant="subtitle2" gutterBottom mb={1} mt={2}>
            All fields are required
          </Typography>
          <Grid container spacing={2}>
            <Grid xs={12} sm={12} md={12} lg={12} mb={-2}>
              <RHTextField<ToolForm> label="Name" propName="toolName" rhProps={{ errors, control }} />
              <RHTextField<ToolForm> label="Abbreviation" propName="toolAbbreviation" rhProps={{ errors, control }} />
              <FormControl>
                <FormLabel id="demo-radio-buttons-group-label">Level</FormLabel>
                <RadioGroup
                  aria-labelledby="demo-radio-buttons-group-label"
                  defaultValue="1"
                  name="radio-buttons-group">
                  <FormControlLabel value="1" control={<Radio />} label="Create only for this branch" />
                  <FormControlLabel value="2" control={<Radio />} label="Create globally" />
                </RadioGroup>
              </FormControl>
              <RHTextField<ToolForm>
                label="Description"
                fullWidth
                propName="toolDescription"
                multiline
                rows={4}
                rhProps={{ errors, control }}
              />
              <Stack spacing={2} direction="row" sx={{ display: 'flex', justifyContent: 'flex-end' }} mt={2}>
                <Button variant="text" onClick={handleClose}>
                  CANCEL
                </Button>
                <LoadingButton
                  variant="contained"
                  color="primary"
                  disabled={!isValid}
                  loading={isLoading}
                  onClick={handleSubmit((formValues) => onSubmit(formValues, setError, reset))}>
                  {isCreate ? 'CREATE TOOL' : 'SAVE CHANGES'}
                </LoadingButton>
              </Stack>
            </Grid>
          </Grid>
        </CardContent>
      </Card>
    </Modal>
  );
};

export default ToolBaseForm;
