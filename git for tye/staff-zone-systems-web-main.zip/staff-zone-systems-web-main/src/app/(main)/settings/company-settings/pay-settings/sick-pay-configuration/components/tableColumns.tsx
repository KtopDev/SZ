import { MRT_ColumnDef, MRT_Row } from 'material-react-table';
import dayjs from 'dayjs';
import Typography from '@mui/material/Typography';
import { displayAnniversaryOpt } from '@/types/Dropdown';
import { SickPayDto } from '@/types/dto/SickPayDto';

export const columns = (): MRT_ColumnDef<SickPayDto>[] => [
  {
    accessorKey: 'state',
    header: 'Jurisdiction',
    Cell: ({ row }: { row: MRT_Row<SickPayDto> }) => <Typography fontWeight="500">{row.original.state}</Typography>,
  },
  {
    accessorKey: 'effectiveDate',
    header: 'Effective Date',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<SickPayDto> }) => (
      <span>{`${dayjs(row.original.efective_date).format('MM/DD/YYYY')}`}</span>
    ),
  },
  {
    accessorKey: 'aniversaryMethod',
    header: 'Aniversary Method',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<SickPayDto> }) => (
      <Typography fontWeight="500">{displayAnniversaryOpt(row.original.anniversary_method_label)}</Typography>
    ),
  },
  {
    accessorKey: 'vestingDays',
    header: 'Vesting Period (days)',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<SickPayDto> }) => (
      <Typography fontWeight="500">{row.original.vesting_days}</Typography>
    ),
  },
  {
    accessorKey: 'suspendedDays',
    header: 'Suspended Period (days)',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<SickPayDto> }) => (
      <Typography fontWeight="500">{row.original.suspended_days}</Typography>
    ),
  },
  {
    accessorKey: 'loseAfterDays',
    header: 'Losee After (days)',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<SickPayDto> }) => (
      <Typography fontWeight="500">{row.original.lose_after_days}</Typography>
    ),
  },
  {
    accessorKey: 'accrualHours',
    header: 'Accrual hours',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<SickPayDto> }) => (
      <Typography fontWeight="500">{row.original.accrual_hours}</Typography>
    ),
  },
  {
    accessorKey: 'workedHours',
    header: 'Hours worked',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<SickPayDto> }) => (
      <Typography fontWeight="500">{row.original.worked_hours}</Typography>
    ),
  },
  {
    accessorKey: 'maxCarryForwardHours',
    header: 'Max carry forward',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<SickPayDto> }) => (
      <Typography fontWeight="500">{row.original.max_carry_forward_hours}</Typography>
    ),
  },
  {
    header: 'Max unused hours',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<SickPayDto> }) => (
      <Typography fontWeight="500">{row.original.max_unused_hours}</Typography>
    ),
  },
  {
    accessorKey: 'maxPerYearHours',
    header: 'Max Per Year Usable',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<SickPayDto> }) => (
      <Typography fontWeight="500">{row.original.max_per_year_hours}</Typography>
    ),
  },
  {
    accessorKey: 'minConsumableHours',
    header: 'Max Consumable Hours',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<SickPayDto> }) => (
      <Typography fontWeight="500">{row.original.min_consumable_hours}</Typography>
    ),
  },
];
