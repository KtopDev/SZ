import { MRT_ColumnDef, MRT_Row } from 'material-react-table';
import { daysOfTheWeek } from '@/constants/contants';

export const columns: MRT_ColumnDef<any>[] = [
  {
    accessorKey: 'pay_cycle_name',
    header: 'Name',
  },
  {
    header: 'Start day',
    accessorKey: 'start_iso_day_of_week',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<any> }) => <div>{daysOfTheWeek[row.original.start_iso_day_of_week - 1]}</div>,
  },
  {
    header: 'End day',
    accessorKey: 'end_iso_day_of_week',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<any> }) => <div>{daysOfTheWeek[row.original.end_iso_day_of_week - 1]}</div>,
  },
];
