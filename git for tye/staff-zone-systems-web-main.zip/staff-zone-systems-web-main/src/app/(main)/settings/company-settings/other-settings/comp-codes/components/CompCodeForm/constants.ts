import { CompCodeFormType } from './types';

export const createCompCode: CompCodeFormType = {
  id: undefined,
  compCode: undefined,
  description: undefined,
  billingInformation: undefined,
  state: undefined,
  burdenPerHour: undefined,
  costPerHundred: undefined,
  billRatePerHundred: undefined,
  effectiveDate: undefined,
};
