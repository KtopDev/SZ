import ToolBaseForm from '@/app/(main)/settings/company-settings/[manageRequirementsTab]/components/manage-tools/ToolBaseForm/ToolBaseForm';

export default ToolBaseForm;
