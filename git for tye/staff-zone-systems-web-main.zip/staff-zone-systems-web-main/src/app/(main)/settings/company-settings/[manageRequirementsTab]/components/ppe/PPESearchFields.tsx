import React from 'react';
import Box from '@mui/material/Box';
import { TextField } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import Grid from '@mui/material/Unstable_Grid2';
import Typography from '@mui/material/Typography';
import RHSelect from '@/components/shared/Form/RHSelect';
import RHDatePicker from '@/components/shared/Form/RHDatePicker';
import { Control, FieldErrors, UseFormSetValue } from 'react-hook-form';
import { debounce } from 'lodash';
import { useGetDropdownBranchList } from '@/requests/api/branchesApi/branchesApi';

type Props = {
  setValue: UseFormSetValue<any>;
  errors: FieldErrors<any>;
  control: Control<any, any, any>;
};

const PPESearchFields = ({ setValue, errors, control }: Props) => {
  const { data: branchList, loading: isBranchListLoading } = useGetDropdownBranchList();
  const debouncedSetValue = debounce(setValue, 1000);

  const handleNameInputChange = (e: any) => {
    debouncedSetValue('ppeName', e.target.value);
  };

  return (
    <Box paddingY="8px" paddingX="24px" bgcolor="common.white" border="none">
      <Box sx={{ flexGrow: 1 }}>
        <Grid container alignItems="end" spacing={2} columns={16}>
          <Grid xs={6}>
            <TextField
              fullWidth
              InputProps={{
                startAdornment: <SearchIcon />,
              }}
              placeholder=" Search by name, abbreviation or description"
              id="outlined-basic"
              variant="outlined"
              name="ppeName"
              onChange={handleNameInputChange}
            />
          </Grid>
          <Grid xs={4} py="0px">
            <RHSelect<IPPEListFilter>
              label="Branch"
              propName="branch"
              options={branchList}
              isLoading={isBranchListLoading}
              rhProps={{ errors, control, required: false }}
            />
          </Grid>
          <Grid xs={2}>
            <TextField
              fullWidth
              placeholder="Occurrences"
              id="outlined-basic"
              variant="outlined"
              onChange={handleNameInputChange}
            />
          </Grid>
          <Grid xs={2}>
            <Typography fontSize={14} paddingBottom="8px">
              Last update
            </Typography>
            <RHDatePicker<IPPEListFilter>
              label="Start date"
              propName="startDate"
              rhProps={{ errors, control, required: false }}
            />
          </Grid>
          <Grid xs={2}>
            <RHDatePicker<IPPEListFilter>
              label="End date"
              propName="endDate"
              rhProps={{ errors, control, required: false }}
            />
          </Grid>
        </Grid>
      </Box>
    </Box>
  );
};

export default PPESearchFields;

export interface IPPEListFilter {
  ppeName: string;
  branch: string;
  status: string;
  startDate: string;
  endDate: string;
}
