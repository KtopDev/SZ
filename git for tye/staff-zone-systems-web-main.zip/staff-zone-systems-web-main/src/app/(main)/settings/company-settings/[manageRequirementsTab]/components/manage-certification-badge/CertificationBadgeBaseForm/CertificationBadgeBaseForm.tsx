import RHTextField from '@/components/shared/Form/RHTextField';
import { useForm } from 'react-hook-form';
import { Backdrop, Button, Card, CardContent, Stack } from '@mui/material';
import { commonModalStyle } from '@/theme/constants';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Unstable_Grid2';
import LoadingButton from '@mui/lab/LoadingButton';
import React, { useEffect } from 'react';
import Modal from '@mui/material/Modal';
import { CertificationBadgeForm } from '@/app/(main)/settings/company-settings/[manageRequirementsTab]/components/manage-certification-badge/CertificationBadgeBaseForm/types';
import RHNumberInput from '@/components/shared/Form/NumberInput';
import RHSwitchGroup from '@/components/shared/Form/RHSwitchGroup';

const CertificationBadgeBaseForm = ({
  open,
  isCreate,
  certificationBadgeData,
  handleClose,
  isLoading,
  onSubmit,
}: any) => {
  const {
    control,
    formState: { errors, isValid },
    handleSubmit,
    reset,
    setError,
    setValue,
  } = useForm<CertificationBadgeForm>({
    mode: 'onBlur',
    defaultValues: isCreate ? ({} as CertificationBadgeForm) : certificationBadgeData,
  });

  useEffect(() => {
    reset(certificationBadgeData);
  }, [certificationBadgeData, reset]);

  return (
    <Modal
      open={open}
      onClose={handleClose}
      closeAfterTransition
      slots={{ backdrop: Backdrop }}
      slotProps={{
        backdrop: {
          timeout: 500,
        },
      }}>
      <Card sx={commonModalStyle}>
        <CardContent>
          <Typography variant="h6" gutterBottom>
            {isCreate ? 'Create certification/badge' : 'Edit certification/badge'}
          </Typography>
          <Typography variant="subtitle2" gutterBottom mb={1} mt={2}>
            All fields are required
          </Typography>
          <Grid container spacing={2}>
            <Grid xs={12} sm={12} md={12} lg={12} mb={-2}>
              <RHTextField<CertificationBadgeForm> label="Name" propName="name" rhProps={{ errors, control }} />
              <RHTextField<CertificationBadgeForm>
                label="Abbreviation"
                propName="abbreviation"
                rhProps={{ errors, control }}
              />
              <RHNumberInput<CertificationBadgeForm>
                label="Days from hire requirement"
                propName="daysFromHireRequirement"
                onlyInteger={true}
                rhProps={{ errors, setValue, control, required: false }}
                helperText="(optional)"
              />
              <RHNumberInput<CertificationBadgeForm>
                label="Days from first placement on project"
                propName="daysFromFirstPlacement"
                onlyInteger={true}
                rhProps={{ errors, setValue, control, required: false }}
                helperText="(optional)"
              />
              <RHTextField<CertificationBadgeForm>
                label="Description"
                fullWidth
                propName="description"
                multiline
                rows={4}
                rhProps={{ errors, control }}
              />
              <RHSwitchGroup<CertificationBadgeForm>
                labels={["Can't dispatch without this requirement"]}
                propNames={['prop']}
                rhProps={{ errors, control, required: false }}
                helperTexts={["If enabled, workers without this requirement can't be dispatched"]}
              />
              <Stack spacing={2} direction="row" sx={{ display: 'flex', justifyContent: 'flex-end' }} mt={2}>
                <Button variant="text" onClick={handleClose}>
                  CANCEL
                </Button>
                <LoadingButton
                  variant="contained"
                  color="primary"
                  disabled={!isValid}
                  loading={isLoading}
                  onClick={handleSubmit((formValues) => onSubmit(formValues, setError, reset))}>
                  {isCreate ? 'CREATE' : 'SAVE CHANGES'}
                </LoadingButton>
              </Stack>
            </Grid>
          </Grid>
        </CardContent>
      </Card>
    </Modal>
  );
};

export default CertificationBadgeBaseForm;
