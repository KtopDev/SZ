import BillOrPayCodeBaseForm from '@/app/(main)/settings/company-settings/pay-settings/bill-and-pay-codes/components/BillOrPayCodeBaseForm/BillOrPayCodeBaseForm';

export default BillOrPayCodeBaseForm;
