'use client';
import Grid from '@mui/material/Unstable_Grid2';
import { Backdrop, Box, Button, Fade, Modal, Typography, Stack } from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import { SubmitHandler, useForm } from 'react-hook-form';
import { useSnackbar } from '@/context/SnackbarContext';
import RHSelect from '@/components/shared/Form/RHSelect';
import { useGetDropdownState } from '@/requests/api/statesApi/statesApi';
import { useCreateSickPay, useUpdateSickPay } from '@/requests/api/sickPayApi/sickPayApi';
import { SickPayDto } from '@/types/dto/SickPayDto';
import RHDatePicker from '@/components/shared/Form/RHDatePicker';
import { TypeProps } from '@/types/TypeProps';
import { anniversaryOptions } from '@/types/Dropdown';
import RHNumberInput from '@/components/shared/Form/NumberInput';
import { handleApiError } from '@/utils/general/general';
import { transformSickPayDtoToRequest } from '@/types/forms/SickPay';

type Props = {
  showModal?: boolean;
  closeModal?: () => void;
  refetch?: () => void;
  sickPay?: SickPayDto;
};

export default function SickPayFormModal({ sickPay, showModal, closeModal, refetch }: Props) {
  const { data: stateList, loading: isStateListLoading } = useGetDropdownState();
  const [createSickPay, { loading: isSaving }] = useCreateSickPay();
  const [updateSickPay, { loading: isUpdating }] = useUpdateSickPay();
  const { setMessage } = useSnackbar();
  const {
    control,
    formState: { errors, isValid },
    handleSubmit,
    getValues,
    setValue,
    reset,
  } = useForm<SickPayDto>({ defaultValues: sickPay ? sickPay : ({} as SickPayDto), mode: 'onChange' });

  const onSubmit: SubmitHandler<SickPayDto> = async (formData) => {
    const payload = transformSickPayDtoToRequest(formData);
    try {
      if (!sickPay) {
        await createSickPay(payload);
        setMessage('Item created successfully');
        reset();
        if (closeModal) {
          closeModal();
          if (refetch) {
            refetch();
          }
        }
      } else {
        await updateSickPay({ id: sickPay.sick_pay_jurisdiction_id, payload });
        setMessage('Changes saved');
        reset();
        if (closeModal) {
          closeModal();
          if (refetch) {
            refetch();
          }
        }
      }
    } catch (e: any) {
      handleApiError(e, setMessage, 'Error creating sick pay rule');
    }
  };

  const renderNumberField = (label: string, fieldName: TypeProps<SickPayDto>, onlyInteger: boolean) => {
    const customMessages = fieldName === 'worked_hours' ? { min: 'Please enter a value larger than 0' } : undefined;
    const min = customMessages ? 0.1 : 0;
    return (
      <RHNumberInput<SickPayDto>
        label={label}
        propName={fieldName}
        onlyInteger={onlyInteger}
        rhProps={{ errors, setValue, control, min, customMessages }}
      />
    );
  };

  const renderButtonText = () => {
    return isSaving || isUpdating ? '' : !sickPay ? 'CREATE SICK PAY' : 'SAVE CHANGES';
  };

  const callSubmit = () => {
    const submitHandler = handleSubmit(onSubmit);
    submitHandler();
  };

  return (
    <Modal
      aria-labelledby="transition-modal-title"
      aria-describedby="transition-modal-description"
      open={showModal ? showModal : false}
      onClose={closeModal}
      closeAfterTransition
      slots={{ backdrop: Backdrop }}
      slotProps={{
        backdrop: {
          timeout: 500,
        },
      }}>
      <Fade in={showModal}>
        <Box sx={styles.modal}>
          <Typography variant="h6" gutterBottom>
            {!sickPay ? 'Create sick pay' : 'Edit sick pay'}
          </Typography>
          <Grid container spacing={2}>
            <Grid xs={12} sm={12} md={12} lg={12} mb={-2}>
              <RHSelect<SickPayDto>
                label="Jurisdiction"
                propName="state"
                options={stateList}
                isLoading={isStateListLoading}
                rhProps={{ errors, control, getValues }}
              />
              <div style={{ marginBottom: 5, marginTop: 5 }}>
                <RHDatePicker<SickPayDto>
                  fullWidth={true}
                  label="Effective date"
                  propName="efective_date"
                  rhProps={{ errors, control, required: false }}
                />
              </div>
              <RHSelect<SickPayDto>
                label="Anniversary method"
                propName="anniversary_method"
                options={anniversaryOptions}
                rhProps={{ errors, control, getValues }}
              />
              {renderNumberField('Vesting period (days)', 'vesting_days', true)}
              {renderNumberField('Suspended period (days)', 'suspended_days', true)}
              {renderNumberField('Lose After (days)', 'lose_after_days', true)}
              {renderNumberField('Accrural Hours', 'accrual_hours', false)}
              {renderNumberField('Hours Worked', 'worked_hours', false)}
              {renderNumberField('Max carry forward', 'max_carry_forward_hours', false)}
              {renderNumberField('Max unused hours', 'max_unused_hours', false)}
              {renderNumberField('Max Per Year Usable', 'max_per_year_hours', false)}
              {renderNumberField('Min Consumable Hours', 'min_consumable_hours', false)}
              <Stack spacing={2} direction="row" sx={{ display: 'flex', justifyContent: 'flex-end' }} mt={2}>
                <Button variant="text" onClick={closeModal}>
                  CANCEL
                </Button>
                <LoadingButton
                  variant="contained"
                  disabled={!isValid}
                  color="primary"
                  loading={isSaving || isUpdating}
                  onClick={() => {
                    if (callSubmit) {
                      callSubmit();
                    }
                  }}>
                  {renderButtonText()}
                </LoadingButton>
              </Stack>
            </Grid>
          </Grid>
        </Box>
      </Fade>
    </Modal>
  );
}

const styles = {
  modal: {
    position: 'absolute' as const,
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 500,
    bgcolor: 'background.paper',
    boxShadow: 24,
    p: 4,
    paddingTop: 2,
  },
};
