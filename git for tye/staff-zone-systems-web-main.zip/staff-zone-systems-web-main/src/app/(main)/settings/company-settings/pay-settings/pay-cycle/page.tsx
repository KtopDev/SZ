'use client';

import * as React from 'react';
import { useMemo, useState } from 'react';
import Box from '@mui/material/Box';
import { Backdrop, Button } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import Grid from '@mui/material/Unstable_Grid2';
import EditIcon from '@mui/icons-material/Edit';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import DeleteIcon from '@mui/icons-material/Delete';
import Table from '@/components/shared/Table/Table';
import { SortingState } from '@tanstack/table-core';
import Modal from '@mui/material/Modal';
import { debounce } from 'lodash';
import { useDeletePayCycle, useGetPayCycleList } from '@/requests/api/payCycleApi/payCycleApi';
import ConfirmationModal from '@/components/shared/Modal/ConfirmationModal';
import TableTopToolbar from '@/app/(main)/settings/company-settings/pay-settings/pay-cycle/components/TableTopToolbar';
import CreatePayCycleModalContent from '@/app/(main)/settings/company-settings/pay-settings/pay-cycle/components/CreatePayCycleModalContent';
import UpdatePayCycleModalContent from '@/app/(main)/settings/company-settings/pay-settings/pay-cycle/components/UpdatePayCycleModalContent/UpdatePayCycleModalContent';
import { columns } from '@/app/(main)/settings/company-settings/pay-settings/pay-cycle/constants/tableColumns';
import { useSnackbar } from '@/context/SnackbarContext';

const PayCyclePage = () => {
  const [pagination, setPagination] = useState({ pageIndex: 1, pageSize: 10 });
  const [sorting, setSorting] = useState<SortingState>([]);
  const [selectedPayCycle, setSelectedPayCycle] = useState<any>({});
  const [shouldShowCreatePayCycleModal, setShouldShowCreatePayCycleModal] = useState(false);
  const [shouldShowUpdatePayCycleModal, setShouldShowUpdatePayCycleModal] = useState(false);
  const [shouldShowConfirmDeletePayCycleModal, setShouldShowConfirmDeletePayCycleModal] = useState(false);
  const [searchName, setSearchName] = useState('');
  const { setMessage } = useSnackbar();

  const filter = useMemo(
    () => ({
      size: pagination.pageSize,
      page: pagination.pageIndex + 1,
      sort: sorting[0] ? `pay_cycle_name,${sorting[0].desc ? 'desc' : 'asc'}` : 'pay_cycle_name,asc',
      pay_cycle_name: searchName,
    }),
    [searchName, sorting, pagination]
  );

  const { data: payCycleList, loading, refetch } = useGetPayCycleList(filter);
  const [deletePayCycle, { loading: deletePayCycleLoading }] = useDeletePayCycle();

  const debouncedSetValue = debounce(setSearchName, 1000);

  const handleNameInputChange = (e: any) => {
    debouncedSetValue(e.target.value);
  };

  const showCreateModal = () => {
    setShouldShowCreatePayCycleModal(true);
  };

  const handleDeletePayCycle = async () => {
    try {
      await deletePayCycle(selectedPayCycle.id);
      refetch();
      setMessage('Item deleted');
    } catch (e) {
      // handle error
    }
  };

  const renderTopToolbar = ({ table }: any) => (
    <TableTopToolbar table={table} handleNameInputChange={handleNameInputChange} />
  );

  const handleSetItem = ({ original }: any) => {
    setSelectedPayCycle({
      id: original.pay_cycle_id,
      name: original.pay_cycle_name,
      startDay: Number(original.start_iso_day_of_week),
    });
  };

  const onClickUpdateButton = (item: any) => {
    handleSetItem(item);
    setShouldShowUpdatePayCycleModal(true);
  };

  const onClickDeleteButton = (item: any) => {
    handleSetItem(item);
    setShouldShowConfirmDeletePayCycleModal(true);
  };

  const renderRowActions = ({ row }: any) => (
    <Box>
      <IconButton onClick={() => onClickUpdateButton(row)}>
        <EditIcon color="secondary" />
      </IconButton>
      <IconButton onClick={() => onClickDeleteButton(row)}>
        <DeleteIcon color="error" />
      </IconButton>
    </Box>
  );

  return (
    <>
      <Box paddingY="8px" paddingX="24px" bgcolor="common.white" border="none">
        <Grid container direction="row" pt={2} justifyContent="space-between">
          <Typography paddingY="4px" fontWeight="regular" fontSize={24}>
            Pay cycles
          </Typography>
          <Box paddingY="5px">
            <Button variant="contained" startIcon={<AddIcon />} onClick={showCreateModal}>
              CREATE
            </Button>
          </Box>
        </Grid>
      </Box>
      <Table
        mrtProps={{
          data: payCycleList.content || [],
          columns,
          renderTopToolbar,
          renderRowActions,
          state: {
            sorting,
            pagination,
            isLoading: loading || deletePayCycleLoading,
          },
          onPaginationChange: setPagination,
          onSortingChange: setSorting,
          manualPagination: true,
        }}
        rowCount={payCycleList.totalSize || 0}
      />

      <Modal
        open={shouldShowCreatePayCycleModal}
        onClose={() => setShouldShowCreatePayCycleModal(false)}
        closeAfterTransition
        slots={{ backdrop: Backdrop }}
        slotProps={{
          backdrop: {
            timeout: 500,
          },
        }}>
        <CreatePayCycleModalContent handleClose={() => setShouldShowCreatePayCycleModal(false)} refetch={refetch} />
      </Modal>

      <Modal
        open={shouldShowUpdatePayCycleModal}
        onClose={() => setShouldShowUpdatePayCycleModal(false)}
        closeAfterTransition
        slots={{ backdrop: Backdrop }}
        slotProps={{
          backdrop: {
            timeout: 500,
          },
        }}>
        <UpdatePayCycleModalContent
          handleClose={() => setShouldShowUpdatePayCycleModal(false)}
          payCycleData={selectedPayCycle}
          refetch={refetch}
        />
      </Modal>

      <Modal
        open={shouldShowConfirmDeletePayCycleModal}
        onClose={() => setShouldShowConfirmDeletePayCycleModal(false)}
        closeAfterTransition
        slots={{ backdrop: Backdrop }}
        slotProps={{
          backdrop: {
            timeout: 500,
          },
        }}>
        <ConfirmationModal
          title="Delete pay cycle"
          description="Are you sure you want to delete this pay cycle?"
          confirmationButtonText="DELETE PAY CYCLE"
          confirmationButtonColor="error"
          showModal={shouldShowConfirmDeletePayCycleModal}
          closeModal={() => setShouldShowConfirmDeletePayCycleModal(false)}
          isLoading={false}
          callSubmit={handleDeletePayCycle}
        />
      </Modal>
    </>
  );
};

export default PayCyclePage;
