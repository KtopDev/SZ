import CompCodeForm from './CompCodeForm';

export default CompCodeForm;
