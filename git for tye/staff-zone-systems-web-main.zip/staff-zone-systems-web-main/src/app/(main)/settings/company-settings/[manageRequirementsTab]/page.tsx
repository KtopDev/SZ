'use client';

import * as React from 'react';
import { useMemo, useState } from 'react';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Unstable_Grid2';
import Typography from '@mui/material/Typography';
import Table from '@/components/shared/Table/Table';
import { columns } from '@/app/(main)/settings/company-settings/[manageRequirementsTab]/components/ppe/tableColumns';
import { columns as siteColumns } from '@/app/(main)/settings/company-settings/[manageRequirementsTab]/components/manage-site-requirements/tableColumns';
import { columns as toolsColumns } from '@/app/(main)/settings/company-settings/[manageRequirementsTab]/components/manage-tools/tableColumns';
import { useForm, useWatch } from 'react-hook-form';
import { SortingState } from '@tanstack/table-core';
import { useGetPPEList } from '@/requests/api/ppeApi/ppeApi';
import { useGetToolsList } from '@/requests/api/toolsApi/toolsApi';
import { RowActions as PPERowActions } from './components/ppe/RowActions';
import { RowActions as SiteReqRowActions } from './components/manage-site-requirements/RowActions';
import { RowActions as ToolsRowActions } from './components/manage-tools/RowActions';
import ManageRequirementTabs from './components/ManageRequirementTabs';
import PPETopToolbar from './components/ppe/PPETopToolbar';
import RenderCreateButton from './components/RenderCreateButton';
import RenderDescription from './components/RenderDescription';
import SiteReqTopToolbar from './components/manage-site-requirements/SiteReqTopToolbar';
import PPESearchFields from './components/ppe/PPESearchFields';
import SiteReqSearchFields from './components/manage-site-requirements/SiteReqSearchFields';

type PageParams = {
  params: {
    manageRequirementsTab: string;
  };
};

const ManagePPEPage = ({ params }: PageParams) => {
  const {
    formState: { errors },
    setValue,
    control,
  } = useForm<any>({
    defaultValues: {
      ppeName: '',
      branch: '',
      status: 'ACTIVE',
      isRowActive: true,
      startDate: '',
      endDate: '',
    },
  });

  // prettier-ignore
  const handleActiveTab = () => {
    switch (params.manageRequirementsTab) {
    case 'manage-tools':
      return 0;
    case 'certifications-badge':
      return 1;
    case 'manage-skills':
      return 2;
    case 'manage-site-requirements':
      return 3;
    case 'manage-ppe':
      return 4;
    default:
      return 0;
    }
  };
  const searchBy = useWatch({ control: control, name: 'ppeName' });
  const branch = useWatch({ control: control, name: 'branch' });
  const startDate = useWatch({ control: control, name: 'startDate' });
  const endDate = useWatch({ control: control, name: 'endDate' });
  const status = useWatch({ control: control, name: 'status' });
  const isRowActive = useWatch({ control: control, name: 'isRowActive' });

  const [pagination, setPagination] = useState({ pageIndex: 1, pageSize: 10 });
  const [sorting, setSorting] = useState<SortingState>([]);
  const [activeTab, setActiveTab] = useState(handleActiveTab());

  const renderTopToolbar = ({ table }: any) => (
    <PPETopToolbar table={table} control={control} errors={errors} setValue={setValue} />
  );

  // TODO: extract filters logic to external files: ppeFilters, toolsFilter and so on
  const filter = useMemo(
    () => ({
      size: pagination.pageSize,
      page: pagination.pageIndex + 1,
      sort: sorting[0] ? `${sorting[0].id},${sorting[0].desc ? 'desc' : 'asc'}` : 'ppeName,asc',
      searchBy,
      branch,
      status,
      startDate,
      endDate,
      isRowActive,
    }),
    //eslint-disable-next-line react-hooks/exhaustive-deps
    [endDate, searchBy, startDate, branch, status, sorting, pagination.pageIndex]
  );

  const toolsFilter = useMemo(
    () => ({
      size: pagination.pageSize,
      page: pagination.pageIndex + 1,
      sort: sorting[0] ? `${sorting[0].id},${sorting[0].desc ? 'desc' : 'asc'}` : 'toolName,asc',
      searchBy,
      branch,
      status,
      startDate,
      endDate,
      isRowActive,
    }),
    //eslint-disable-next-line react-hooks/exhaustive-deps
    [endDate, searchBy, startDate, branch, status, sorting, pagination.pageIndex]
  );

  const { data: ppeList, loading, refetch } = useGetPPEList(filter);
  const { data: toolsList, loading: toolsLoading } = useGetToolsList(toolsFilter);

  const handleTabChange = (_: any, newValue: number) => {
    setActiveTab(newValue);
  };

  const renderSiteReqTopToolbar = ({ table }: any) => (
    <SiteReqTopToolbar table={table} control={control} errors={errors} setValue={setValue} />
  );

  return (
    <>
      <Box paddingY="8px" paddingX="24px" bgcolor="common.white" border="none">
        <Typography paddingY="4px" fontWeight="regular" fontSize={24}>
          Manage requirements
        </Typography>

        <Grid container direction="row" justifyContent="space-between" mb={2}>
          <ManageRequirementTabs activeTab={activeTab} handleTabChange={handleTabChange} />

          <RenderCreateButton tabName={params.manageRequirementsTab} refetch={refetch} />
        </Grid>
        <RenderDescription tabName={params.manageRequirementsTab} />
      </Box>
      {params.manageRequirementsTab === 'manage-ppe' && (
        <>
          <PPESearchFields setValue={setValue} errors={errors} control={control} />
          <Table
            mrtProps={{
              data: ppeList.content || [],
              columns: columns() as any,
              renderTopToolbar,
              renderRowActions: ({ row }) => <PPERowActions rowData={row.original} refetch={refetch} />,
              state: {
                sorting,
                pagination,
                isLoading: loading,
              },
              onPaginationChange: setPagination,
              onSortingChange: setSorting,
              manualPagination: true,
            }}
            rowCount={ppeList.totalSize || 0}
          />
        </>
      )}
      {params.manageRequirementsTab === 'manage-site-requirements' && (
        <>
          <SiteReqSearchFields setValue={setValue} errors={errors} control={control} />
          <Table
            mrtProps={{
              data: ppeList.content || [],
              columns: siteColumns() as any,
              renderTopToolbar: renderSiteReqTopToolbar,
              renderRowActions: ({ row }) => <SiteReqRowActions rowData={row.original} refetch={refetch} />,
              state: {
                sorting,
                pagination,
                isLoading: loading,
              },
              onPaginationChange: setPagination,
              onSortingChange: setSorting,
              manualPagination: true,
            }}
            rowCount={ppeList.totalSize || 0}
          />
        </>
      )}
      {params.manageRequirementsTab === 'manage-tools' && (
        <>
          <PPESearchFields setValue={setValue} errors={errors} control={control} />
          <Table
            mrtProps={{
              data: toolsList.content || [],
              columns: toolsColumns() as any,
              renderTopToolbar,
              renderRowActions: ({ row }) => <ToolsRowActions rowData={row.original} refetch={refetch} />,
              state: {
                sorting,
                pagination,
                isLoading: toolsLoading,
              },
              onPaginationChange: setPagination,
              onSortingChange: setSorting,
              manualPagination: true,
            }}
            rowCount={toolsList.totalSize || 0}
          />
        </>
      )}
    </>
  );
};

export default ManagePPEPage;
