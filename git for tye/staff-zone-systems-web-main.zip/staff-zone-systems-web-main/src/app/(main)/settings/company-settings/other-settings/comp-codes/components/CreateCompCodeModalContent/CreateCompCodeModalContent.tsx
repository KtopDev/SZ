import CompCodeForm from '@/app/(main)/settings/company-settings/other-settings/comp-codes/components/CompCodeForm';
import { CompCodeFormType } from '@/app/(main)/settings/company-settings/other-settings/comp-codes/components/CompCodeForm/types';
import { useCreateCompCode } from '@/requests/api/compCodesApi/compCodesApi';

const CreateCompCodeModalContent = ({ handleClose, stateList, refresh, setErrorMessage }: any) => {
  const [createCompCode, { loading }] = useCreateCompCode();
  const onSubmit = async (formValues: CompCodeFormType) => {
    try {
      await createCompCode(formValues);
      refresh();
      handleClose();
    } catch (e: any) {
      if (e.response.status === 400) {
        setErrorMessage(e.response.data.message);
      }
    }
  };

  return (
    <CompCodeForm stateList={stateList} handleClose={handleClose} isCreate onSubmit={onSubmit} isLoading={loading} />
  );
};

export default CreateCompCodeModalContent;
