import React from 'react';
import Typography from '@mui/material/Typography';

interface Props {
  tabName: string;
}

const RenderDescription = ({ tabName }: Props) => {
  const renderDescriptionText = () => {
    switch (tabName) {
    case 'manage-ppe':
      return 'Manage the PPE or equivalent that Workers are required in order to be dispatched to a Project containing this.';
    case 'manage-site-requirements':
      return 'Manage the Site requirements or equivalent that Workers are required in order to be dispatched to a Project containing this.';
    default:
      return '';
    }
  };

  return (
    <Typography fontSize={14} color="secondary.dark">
      {renderDescriptionText()}
    </Typography>
  );
};

export default RenderDescription;
