export interface IBillAndPayCodesFilters {
  nameOrDescription: string;
  startDate: string;
  endDate: string;
}

export interface BillCodeForm {
  name: string;
  description: string;
}
