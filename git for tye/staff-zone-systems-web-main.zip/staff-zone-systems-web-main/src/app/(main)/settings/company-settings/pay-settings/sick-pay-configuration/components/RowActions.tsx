import React, { useState } from 'react';
import Box from '@mui/material/Box';
import EditIcon from '@mui/icons-material/Edit';
import IconButton from '@mui/material/IconButton';
import DeleteIcon from '@mui/icons-material/Delete';
import SickPayFormModal from './SickPayFormModal';
import DeleteSickPayFormModal from './DeleteSickPayFormModal';
import { SickPayDto } from '@/types/dto/SickPayDto';

type Props = {
  rowData: SickPayDto;
  refetch: () => void;
};

const RowActions = ({ rowData, refetch }: Props) => {
  const [showEditModal, setShowEditModal] = useState(false);
  const openEditModal = () => setShowEditModal(true);
  const closeEditModal = () => setShowEditModal(false);

  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const openDeleteModal = () => setShowDeleteModal(true);
  const closeDeleteModal = () => setShowDeleteModal(false);

  return (
    <>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
        <IconButton>
          <EditIcon onClick={openEditModal} />
        </IconButton>
        <IconButton color="error" onClick={openDeleteModal}>
          <DeleteIcon />
        </IconButton>
      </Box>

      {showEditModal && (
        <SickPayFormModal sickPay={rowData} showModal={showEditModal} closeModal={closeEditModal} refetch={refetch} />
      )}

      {showDeleteModal && (
        <DeleteSickPayFormModal
          sickPayId={rowData.sick_pay_jurisdiction_id}
          showModal={showDeleteModal}
          closeModal={closeDeleteModal}
          refetch={refetch}
        />
      )}
    </>
  );
};

export default RowActions;
