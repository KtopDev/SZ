import CertificationBadgeBaseForm from '@/app/(main)/settings/company-settings/[manageRequirementsTab]/components/manage-certification-badge/CertificationBadgeBaseForm/CertificationBadgeBaseForm';

export default CertificationBadgeBaseForm;
