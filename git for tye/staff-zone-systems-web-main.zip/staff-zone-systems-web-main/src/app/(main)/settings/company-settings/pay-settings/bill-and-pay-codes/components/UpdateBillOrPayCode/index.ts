import UpdateBillOrPayCode from '@/app/(main)/settings/company-settings/pay-settings/bill-and-pay-codes/components/UpdateBillOrPayCode/UpdateBillOrPayCode';

export default UpdateBillOrPayCode;
