'use client';

import * as React from 'react';
import { useMemo, useState } from 'react';
import Table from '@/components/shared/Table/Table';
import { columns } from '@/app/(main)/settings/company-settings/pay-settings/sick-pay-configuration/components/tableColumns';
import { useForm, useWatch } from 'react-hook-form';
import { SortingState } from '@tanstack/table-core';
import RowActions from './components/RowActions';
import SickPayTopToolbar from './components/SickPayTopToolbar';
import SickPayPageHeader from './components/SickPayPageHeader';
import { useGetSickPayList } from '@/requests/api/sickPayApi/sickPayApi';

const SickPayPage = () => {
  const {
    control,
    formState: { errors },
  } = useForm<any>({
    defaultValues: {
      id: '',
      state: '',
      status: '',
      startDate: '',
      endDate: '',
    },
  });

  const [pagination, setPagination] = useState({ pageIndex: 1, pageSize: 10 });
  const [sorting, setSorting] = useState<SortingState>([]);

  const renderTopToolbar = ({ table }: any) => <SickPayTopToolbar table={table} control={control} errors={errors} />;

  const state = useWatch({ control: control, name: 'state' });
  const nameCode = useWatch({ control: control, name: 'nameCode' });
  const startDate = useWatch({ control: control, name: 'startDate' });
  const endDate = useWatch({ control: control, name: 'endDate' });
  const status = useWatch({ control: control, name: 'status' });
  const isRowActive = useWatch({ control: control, name: 'isRowActive' });

  const filter = useMemo(
    () => ({
      size: pagination.pageSize,
      page: pagination.pageIndex + 1,
      sort: sorting[0] ? `${sorting[0].id},${sorting[0].desc ? 'desc' : 'asc'}` : 'effectiveDate,asc',
      nameCode,
      state,
      status: status,
      startDate,
      endDate,
      isRowActive,
    }),
    //eslint-disable-next-line react-hooks/exhaustive-deps
    [endDate, nameCode, startDate, state, status, isRowActive, sorting, pagination.pageIndex]
  );

  const { data: sickPayList, loading, refetch } = useGetSickPayList(filter);

  return (
    <>
      <SickPayPageHeader refetch={refetch} />

      <Table
        mrtProps={{
          data: sickPayList.content || [],
          columns: columns() as any,
          renderTopToolbar,
          renderRowActions: ({ row }) => <RowActions rowData={row.original} refetch={refetch} />,
          state: {
            sorting,
            pagination,
            isLoading: loading,
          },
          onPaginationChange: setPagination,
          onSortingChange: setSorting,
          manualPagination: true,
        }}
        rowCount={sickPayList.totalSize || 0}
      />
    </>
  );
};

export default SickPayPage;
