import CreateBillCode from '@/app/(main)/settings/company-settings/pay-settings/bill-and-pay-codes/components/CreateBillOrPayCode/CreateBillOrPayCode';

export default CreateBillCode;
