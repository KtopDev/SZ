'use client';
import Grid from '@mui/material/Unstable_Grid2';
import { Backdrop, Box, Button, Fade, Modal, Typography, Stack } from '@mui/material';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import LoadingButton from '@mui/lab/LoadingButton';
import { SubmitHandler, useForm } from 'react-hook-form';
import { useSnackbar } from '@/context/SnackbarContext';
import RHTextField from '@/components/shared/Form/RHTextField';
// import { useCreateSiteRequirement, useUpdateSiteRequirement } from '@/requests/api/siteRequirementApi/siteRequirementApi';
import { SiteRequirementRequest } from '@/types/forms/SiteRequirement';
import { SiteRequirementDto, convertDtoToRequest } from '@/types/dto/SiteRequirementDto';

type Props = {
  showModal?: boolean;
  closeModal?: () => void;
  refetch?: () => void;
  siteRequirement?: SiteRequirementDto;
};

export default function SiteRequirementsFormModal({ siteRequirement, showModal, closeModal, refetch }: Props) {
  // const [createSiteRequirement, { loading: isSavingSiteRequirement }] = useCreateSiteRequirement();
  // const [updateSiteRequirement, { loading: isUpdatingSiteRequirement }] = useUpdateSiteRequirement();
  const { setMessage } = useSnackbar();
  const {
    control,
    formState: { errors },
    handleSubmit,
    reset,
  } = useForm<SiteRequirementRequest>({
    defaultValues: siteRequirement ? convertDtoToRequest(siteRequirement) : ({} as SiteRequirementRequest),
    mode: 'onBlur',
  });

  /* eslint-disable */
  const onSubmit: SubmitHandler<SiteRequirementRequest> = async (formData) => {
    try {
      if (!siteRequirement) {
        // await createSiteRequirement(formData);
        setMessage('Item created');
        reset();
        if (closeModal) {
          closeModal();
          if (refetch) {
            refetch();
          }
        }
      } else {
        // await updateSiteRequirement({ id: siteRequirement.id, payload: formData });
        setMessage('Changes saved');
        reset();
        if (closeModal) {
          closeModal();
          if (refetch) {
            refetch();
          }
        }
      }
    } catch (e: any) {
      if (e?.response?.data?.message) {
        setMessage(e.response.data.message);
      } else {
        setMessage('Error creating the site requirement');
      }
    }
  };

  const renderButtonText = () => {
    // return isSavingSiteRequirement || isUpdatingSiteRequirement ? '' : !siteRequirement ? 'CREATE SITE REQUIREMENT' : 'SAVE CHANGES';
    return !siteRequirement ? 'CREATE SITE REQUIREMENT' : 'SAVE CHANGES';
  };

  const callSubmit = () => {
    const submitHandler = handleSubmit(onSubmit);
    submitHandler();
  };

  return (
    <Modal
      aria-labelledby="transition-modal-title"
      aria-describedby="transition-modal-description"
      open={showModal ? showModal : false}
      onClose={closeModal}
      closeAfterTransition
      slots={{ backdrop: Backdrop }}
      slotProps={{
        backdrop: {
          timeout: 500,
        },
      }}>
      <Fade in={showModal}>
        <Box sx={styles.modal}>
          <Typography variant="h6" gutterBottom>
            {!siteRequirement ? 'Create site requirement' : 'Edit site requirement'}
          </Typography>
          <Typography variant="subtitle2" gutterBottom mb={1} mt={2}>
            All fields are required
          </Typography>
          <Grid container spacing={2}>
            <Grid xs={12} sm={12} md={12} lg={12} mb={-2}>
              <RHTextField<SiteRequirementRequest>
                label="Name"
                propName="siteRequirementName"
                rhProps={{ errors, control }}
              />
              <FormControl>
                <FormLabel id="demo-radio-buttons-group-label">Level</FormLabel>
                <RadioGroup
                  aria-labelledby="demo-radio-buttons-group-label"
                  defaultValue="1"
                  name="radio-buttons-group">
                  <FormControlLabel value="1" control={<Radio />} label="Create only for this branch" />
                  <FormControlLabel value="2" control={<Radio />} label="Create globally" />
                </RadioGroup>
              </FormControl>
              <RHTextField<SiteRequirementRequest>
                label="Description"
                fullWidth
                propName="siteRequirementDescription"
                multiline
                rows={4}
                rhProps={{ errors, control }}
              />
              <Stack spacing={2} direction="row" sx={{ display: 'flex', justifyContent: 'flex-end' }} mt={2}>
                <Button variant="text" onClick={closeModal}>
                  CANCEL
                </Button>
                <LoadingButton
                  variant="contained"
                  color="primary"
                  loading={false}
                  onClick={() => {
                    if (callSubmit) {
                      callSubmit();
                    }
                  }}>
                  {renderButtonText()}
                </LoadingButton>
              </Stack>
            </Grid>
          </Grid>
        </Box>
      </Fade>
    </Modal>
  );
}

const styles = {
  modal: {
    position: 'absolute' as const,
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 500,
    bgcolor: 'background.paper',
    boxShadow: 24,
    p: 4,
    paddingTop: 2,
  },
};
