import React from 'react';
import { Box, Tab, Tabs } from '@mui/material';
import { useRouter } from 'next/navigation';

interface Props {
  activeTab: number;
  handleTabChange: (_: any, newValue: number) => void;
}

const ManageRequirementTabs = ({ activeTab, handleTabChange }: Props) => {
  const router = useRouter();

  return (
    <Box>
      <Box>
        <Tabs value={activeTab} onChange={handleTabChange} aria-label="basic tabs example">
          <Tab label="TOOLS" id="TOOLS" onClick={() => router.push('/settings/company-settings/manage-tools')} />
          <Tab
            label="CERTIFICATION/BADGE"
            id="CERTIFICATION/BADGE"
            onClick={() => router.push('/settings/company-settings/certifications-badge')}
          />
          <Tab label="SKILLS" id="SKILLS" onClick={() => router.push('/settings/company-settings/manage-skills')} />
          <Tab
            label="SITE REQUIREMENTS"
            id="SITE REQUIREMENTS"
            onClick={() => router.push('/settings/company-settings/manage-site-requirements')}
          />
          <Tab label="PPE" id="PPE" onClick={() => router.push('/settings/company-settings/manage-ppe')} />
        </Tabs>
      </Box>
    </Box>
  );
};

export default ManageRequirementTabs;
