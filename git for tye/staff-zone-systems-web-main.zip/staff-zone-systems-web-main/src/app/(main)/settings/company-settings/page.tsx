import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import Link from '@/components/shared/Link';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import Divider from '@mui/material/Divider';
import List from '@mui/material/List';

const CompanySettingsPage = () => {
  return (
    <Box paddingY="18px" paddingX="24px" bgcolor="common.white">
      <Typography paddingY="4px" fontWeight="regular" fontSize={24}>
        Company settings
      </Typography>
      <Typography fontWeight="500" fontSize={14} color="secondary.dark">
        Manage the application formats, components and settings
      </Typography>

      <Typography pt={5} fontWeight="regular" fontSize={14} color="secondary.dark">
        Manage requirements
      </Typography>

      <List title="title" component="nav">
        <Link href={'/settings/company-settings/manage-tools'}>
          <ListItemButton>
            <ListItemText primary="Manage tools" />
          </ListItemButton>
        </Link>

        <Divider component="li" />

        <Link href={'/settings/company-settings/certification-badges'}>
          <ListItemButton>
            <ListItemText primary="Manage certification/badges" />
          </ListItemButton>
        </Link>

        <Divider component="li" />

        <Link href={'/settings/company-settings/skills'}>
          <ListItemButton>
            <ListItemText primary="Manage skills" />
          </ListItemButton>
        </Link>

        <Divider component="li" />

        <Link href={'/settings/company-settings/manage-site-requirements'}>
          <ListItemButton>
            <ListItemText primary="Manage site requirements" />
          </ListItemButton>
        </Link>

        <Divider component="li" />

        <Link href={'/settings/company-settings/manage-ppe'}>
          <ListItemButton>
            <ListItemText primary="Manage personal protective equipment (PPE)" />
          </ListItemButton>
        </Link>

        <Divider component="li" />
      </List>

      <Typography pt={5} fontWeight="regular" fontSize={14} color="secondary.dark">
        Pay settings
      </Typography>

      <List title="title" component="nav">
        <Link href={'/settings/company-settings/pay-settings/pay-cycle'}>
          <ListItemButton>
            <ListItemText primary="Pay cycle" />
          </ListItemButton>
        </Link>

        <Divider component="li" />

        <Link href={'/settings/company-settings/pay-settings/bill-and-pay-codes'}>
          <ListItemButton>
            <ListItemText primary="Bill and pay codes" />
          </ListItemButton>
        </Link>

        <Divider component="li" />

        <Link href={'/settings/company-settings/pay-settings/sick-pay-configuration'}>
          <ListItemButton>
            <ListItemText primary="Sick pay configuration" />
          </ListItemButton>
        </Link>

        <Divider component="li" />
      </List>

      <Typography pt={3} fontWeight="regular" fontSize={14} color="secondary.dark">
        Other settings
      </Typography>

      <List title="title" component="nav">
        <Link href={'/settings/company-settings/other-settings/comp-codes'}>
          <ListItemButton>
            <ListItemText primary="Comp codes" />
          </ListItemButton>
        </Link>

        <Divider component="li" />

        <Link href={'/settings/company-settings/other-settings/futa-suta-sdi'}>
          <ListItemButton>
            <ListItemText primary="FUTA, SUTA and SDI settings" />
          </ListItemButton>
        </Link>
        <Divider component="li" />
      </List>
    </Box>
  );
};

export default CompanySettingsPage;
