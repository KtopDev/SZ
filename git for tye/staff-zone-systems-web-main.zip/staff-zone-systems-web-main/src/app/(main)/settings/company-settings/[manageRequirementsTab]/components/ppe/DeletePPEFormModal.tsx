'use client';
import { Backdrop, Box, Button, Fade, Modal, Typography, Stack } from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import { useSnackbar } from '@/context/SnackbarContext';
import { useDeletePPE } from '@/requests/api/ppeApi/ppeApi';

type Props = {
  showModal?: boolean;
  closeModal?: () => void;
  refetch?: () => void;
  taxId: string;
};

export default function DeletePPEModal({ taxId, showModal, closeModal, refetch }: Props) {
  const [deletePPE, { loading }] = useDeletePPE();
  const { setSuccessMessage, setErrorMessage } = useSnackbar();

  const renderButtonText = () => {
    return loading ? '' : 'DELETE FUTA CONFIGURATION';
  };

  const submit = async () => {
    try {
      await deletePPE(taxId);
      if (closeModal) {
        closeModal();
        if (refetch) {
          refetch();
        }
        setSuccessMessage('Item deleted');
      }
    } catch (error) {
      setErrorMessage('Error deleting PPE');
    }
  };

  return (
    <Modal
      aria-labelledby="transition-modal-title"
      aria-describedby="transition-modal-description"
      open={showModal ? showModal : false}
      onClose={closeModal}
      closeAfterTransition
      slots={{ backdrop: Backdrop }}
      slotProps={{
        backdrop: {
          timeout: 500,
        },
      }}>
      <Fade in={showModal}>
        <Box sx={styles.modal}>
          <Typography variant="h6" gutterBottom>
            Delete PPE
          </Typography>
          <Typography variant="body1" gutterBottom mt={2} mb={3}>
            Are you sure you want to delete this item?
          </Typography>

          <Stack spacing={2} direction="row" sx={{ display: 'flex', justifyContent: 'flex-end' }} mt={2}>
            <Button variant="text" onClick={closeModal}>
              CANCEL
            </Button>
            <LoadingButton variant="contained" loading={loading} loadingPosition="start" color="error" onClick={submit}>
              {renderButtonText()}
            </LoadingButton>
          </Stack>
        </Box>
      </Fade>
    </Modal>
  );
}

const styles = {
  modal: {
    position: 'absolute' as const,
    top: '40%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    boxShadow: 24,
    p: 2,
  },
};
