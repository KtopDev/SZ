import React, { useState } from 'react';
import Box from '@mui/material/Box';
import EditIcon from '@mui/icons-material/Edit';
import IconButton from '@mui/material/IconButton';
import DeleteIcon from '@mui/icons-material/Delete';
import SiteRequirementsFormModal from './SiteRequirementsFormModal';
import DeleteItemModal from '../shared/DeleteItemModal';
import { useDeleteSiteRequirement } from '@/requests/api/siteRequirementApi/siteRequirementApi';

type Props = {
  rowData: any;
  refetch: () => void;
};

export const RowActions = ({ rowData, refetch }: Props) => {
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);

  const [deleteSiteRequirement, { loading }] = useDeleteSiteRequirement();

  return (
    <>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
        {rowData.status !== 'ARCHIVED' && (
          <IconButton onClick={() => setShowUpdateModal(true)}>
            <EditIcon />
          </IconButton>
        )}
        <IconButton color="error" onClick={() => setShowDeleteModal(true)}>
          <DeleteIcon />
        </IconButton>
      </Box>

      {showUpdateModal && (
        <SiteRequirementsFormModal
          siteRequirement={rowData}
          showModal={showUpdateModal}
          closeModal={() => setShowUpdateModal(false)}
          refetch={refetch}
        />
      )}

      {showDeleteModal && (
        <DeleteItemModal
          id={rowData.id}
          deleteFunction={deleteSiteRequirement}
          isDeleting={loading}
          showModal={showDeleteModal}
          closeModal={() => setShowDeleteModal(false)}
          refetch={refetch}
        />
      )}
    </>
  );
};
