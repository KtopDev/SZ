'use client';
import { Backdrop, Box, Button, Fade, Modal, Typography, Stack } from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import { useSnackbar } from '@/context/SnackbarContext';

type Props = {
  showModal?: boolean;
  closeModal?: () => void;
  refetch?: () => void;
  id: string;
  deleteFunction: (id: string) => Promise<void>;
  isDeleting: boolean;
};

export default function DeleteItemModal({ id, deleteFunction, isDeleting, showModal, closeModal, refetch }: Props) {
  const { setSuccessMessage, setErrorMessage } = useSnackbar();

  const renderButtonText = () => {
    return isDeleting ? '' : 'DELETE ITEM';
  };

  const submit = async () => {
    try {
      await deleteFunction(id);
      if (closeModal) {
        closeModal();
        if (refetch) {
          refetch();
        }
        setSuccessMessage('Item deleted');
      }
    } catch (error) {
      setErrorMessage('Error deleting this item');
    }
  };

  return (
    <Modal
      aria-labelledby="transition-modal-title"
      aria-describedby="transition-modal-description"
      open={showModal ? showModal : false}
      onClose={closeModal}
      closeAfterTransition
      slots={{ backdrop: Backdrop }}
      slotProps={{
        backdrop: {
          timeout: 500,
        },
      }}>
      <Fade in={showModal}>
        <Box sx={styles.modal}>
          <Typography variant="h6" gutterBottom>
            Delete item
          </Typography>
          <Typography variant="body1" gutterBottom mt={2} mb={3}>
            Are you sure you want to delete this item?
          </Typography>

          <Stack spacing={2} direction="row" sx={{ display: 'flex', justifyContent: 'flex-end' }} mt={2}>
            <Button variant="text" onClick={closeModal}>
              CANCEL
            </Button>
            <LoadingButton
              variant="contained"
              loading={isDeleting}
              loadingPosition="start"
              color="error"
              onClick={submit}>
              {renderButtonText()}
            </LoadingButton>
          </Stack>
        </Box>
      </Fade>
    </Modal>
  );
}

const styles = {
  modal: {
    position: 'absolute' as const,
    top: '40%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    boxShadow: 24,
    p: 2,
  },
};
