import { MRT_ColumnDef, MRT_Row } from 'material-react-table';
import Typography from '@mui/material/Typography';
import dayjs from 'dayjs';

export const getColumns = (activeTab: number) => (activeTab === 0 ? billCodeColumns : payCodeColumns);

export const billCodeColumns: MRT_ColumnDef<any>[] = [
  {
    accessorKey: 'bill_code_name',
    header: 'Name',
  },
  {
    header: 'Description',
    accessorKey: 'bill_code_description',
    enableSorting: false,
  },
  {
    header: 'Creation Date',
    accessorKey: 'created_at',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<any> }) => (
      <Typography>{dayjs(row.original.created_at).format('DD/MM/YYYY')}</Typography>
    ),
  },
];

export const payCodeColumns: MRT_ColumnDef<any>[] = [
  {
    accessorKey: 'pay_code_name',
    header: 'Name',
  },
  {
    header: 'Description',
    accessorKey: 'pay_code_description',
    enableSorting: false,
  },
  {
    header: 'Creation Date',
    accessorKey: 'created_at',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<any> }) => (
      <Typography>{dayjs(row.original.created_at).format('DD/MM/YYYY')}</Typography>
    ),
  },
];
