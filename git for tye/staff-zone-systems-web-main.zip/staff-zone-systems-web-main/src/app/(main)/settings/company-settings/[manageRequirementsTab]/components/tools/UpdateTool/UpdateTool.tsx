import { PayCycleForm } from '@/app/(main)/settings/company-settings/pay-settings/pay-cycle/components/PayCycleBaseForm/types';
import { useSnackbar } from '@/context/SnackbarContext';
import ToolBaseForm from '@/app/(main)/settings/company-settings/[manageRequirementsTab]/components/manage-tools/ToolBaseForm';

const UpdateTool = ({ open, handleClose, refetch, toolData }: any) => {
  //const [createTool, { loading }] = useCreateTool();
  const { setMessage } = useSnackbar();
  const updateTool = async (props: any) => props;
  const loading = false;

  const onSubmit = async (formValues: PayCycleForm, setError: any, reset: any) => {
    try {
      await updateTool({
        name: formValues.name,
        description: formValues.startDay,
      });
      refetch();
      reset();
      handleClose();
      setMessage('Changes saved');
    } catch (e: any) {
      if (e.response.status === 400) {
        setError('name', { message: e.response.data?.details[0]?.message });
      }
    }
  };

  return (
    <ToolBaseForm
      toolData={toolData}
      open={open}
      handleClose={handleClose}
      isCreate={false}
      onSubmit={onSubmit}
      isLoading={loading}
    />
  );
};

export default UpdateTool;
