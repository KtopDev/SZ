import RHTextField from '@/components/shared/Form/RHTextField';
import { useForm, useWatch } from 'react-hook-form';
import { Box, Button, Card, CardContent, FormControl, InputLabel, MenuItem, Select } from '@mui/material';
import { commonModalStyle } from '@/theme/constants';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Unstable_Grid2';
import LoadingButton from '@mui/lab/LoadingButton';
import React, { useEffect, useState } from 'react';
import { defaultPayCycle } from './constants';
import RHSelect from '@/components/shared/Form/RHSelect';
import { daysOfTheWeekOptions } from '@/constants/contants';
import { PayCycleForm } from '@/app/(main)/settings/company-settings/pay-settings/pay-cycle/components/PayCycleBaseForm/types';
import { SelectOption } from '@/types/Dropdown';

const PayCycleBaseForm = ({ isCreate, payCycleData, handleClose, isLoading, onSubmit }: any) => {
  const {
    control,
    formState: { errors, isValid },
    handleSubmit,
    getValues,
    reset,
    setError,
    setValue,
  } = useForm<PayCycleForm>({
    mode: 'onBlur',
    defaultValues: isCreate ? defaultPayCycle : payCycleData,
  });

  const startDay = useWatch({ control, name: 'startDay' });
  const [endDay, setEndDay] = useState<any>('');

  useEffect(() => {
    reset(payCycleData);
  }, [payCycleData, reset]);

  useEffect(() => {
    if (startDay) {
      setEndDay(startDay === 1 ? 7 : startDay - 1);
    }
  }, [startDay]);

  return (
    <Card sx={commonModalStyle}>
      <CardContent>
        <Typography pb={2} fontWeight={500}>
          {isCreate ? 'Create' : 'Update'} pay cycle
        </Typography>

        <Typography py={2}>All fields are required</Typography>

        <Grid container direction="column">
          <RHTextField<PayCycleForm> label="Name" propName="name" rhProps={{ errors, control, getValues }} />
          <RHSelect<PayCycleForm>
            label="Start day"
            propName="startDay"
            options={daysOfTheWeekOptions}
            rhProps={{ errors, control, getValues, setValue }}
          />
          <Box py={1}>
            <FormControl fullWidth>
              <InputLabel id="demo-simple-select-label">End day</InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={endDay}
                disabled
                label="End Day">
                <MenuItem value={''}></MenuItem>
                {daysOfTheWeekOptions.dropdown.map((dayInfo: SelectOption) => (
                  <MenuItem value={dayInfo.id} key={dayInfo.id}>
                    {dayInfo.displayName}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Box>
        </Grid>

        <Box pt={2} display="flex" justifyContent="flex-end">
          <Button variant="outlined" onClick={handleClose}>
            CANCEL
          </Button>
          <LoadingButton
            disabled={!isValid}
            startIcon={null}
            loading={isLoading}
            variant="contained"
            color="primary"
            sx={{ marginLeft: 1 }}
            onClick={handleSubmit((formValues: PayCycleForm) => onSubmit(formValues, setError))}>
            {isCreate ? 'CREATE PAY CYCLE' : 'SAVE CHANGES'}
          </LoadingButton>
        </Box>
      </CardContent>
    </Card>
  );
};

export default PayCycleBaseForm;
