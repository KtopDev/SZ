'use client';
import Grid from '@mui/material/Unstable_Grid2';
import { Backdrop, Box, Button, Fade, Modal, Typography, Stack } from '@mui/material';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import LoadingButton from '@mui/lab/LoadingButton';
import { SubmitHandler, useForm } from 'react-hook-form';
import { useSnackbar } from '@/context/SnackbarContext';
import RHTextField from '@/components/shared/Form/RHTextField';
import { useCreatePPE, useUpdatePPE } from '@/requests/api/ppeApi/ppeApi';
import { PPERequest } from '@/types/forms/PPE';
import { PPEDto, convertPPEDtoToPPERequest } from '@/types/dto/PPEDto';
import { handleApiError } from '@/utils/general/general';
import { useSidebar } from '@/context/SidebarContext';
import RHRadioGroup from '@/components/shared/Form/RHRadioGroup';

type Props = {
  showModal?: boolean;
  closeModal?: () => void;
  refetch: () => void;
  ppe?: PPEDto;
};

export default function PPEFormModal({ ppe, showModal, closeModal, refetch }: Props) {
  const { selectedBranchId } = useSidebar();
  const [createPPE, { loading: isSavingPPE }] = useCreatePPE();
  const [updatePPE, { loading: isUpdatingPPE }] = useUpdatePPE();
  const { setMessage } = useSnackbar();

  const renderInitialValue = (ppe: PPEDto | undefined) => {
    if (ppe) {
      const transformedDto = convertPPEDtoToPPERequest(ppe);
      transformedDto.branchId = selectedBranchId;
      return transformedDto;
    } else {
      return { branchId: selectedBranchId } as PPERequest;
    }
  };

  const {
    control,
    formState: { errors },
    handleSubmit,
    reset,
  } = useForm<PPERequest>({
    defaultValues: renderInitialValue(ppe),
    mode: 'onBlur',
  });

  /* eslint-disable */
  const onSubmit: SubmitHandler<PPERequest> = async (formData) => {
    try {
      if (formData.branchId === '0') {
        formData.branchId = null;
      }
      if (!ppe) {
        await createPPE(formData);
        setMessage('Item created');
        reset();
        if (closeModal) {
          closeModal();
          refetch();
        }
      } else {
        await updatePPE({ id: ppe.ppe_id, payload: formData });
        setMessage('Changes saved');
        reset();
        if (closeModal) {
          closeModal();
          refetch();
        }
      }
    } catch (e: any) {
      handleApiError(e, setMessage, 'Error creating the PPE');
    }
  };

  const renderButtonText = () => {
    return isSavingPPE || isUpdatingPPE ? '' : !ppe ? 'CREATE PPE' : 'SAVE CHANGES';
  };

  const callSubmit = () => {
    const submitHandler = handleSubmit(onSubmit);
    submitHandler();
  };

  return (
    <Modal
      aria-labelledby="transition-modal-title"
      aria-describedby="transition-modal-description"
      open={showModal ? showModal : false}
      onClose={closeModal}
      closeAfterTransition
      slots={{ backdrop: Backdrop }}
      slotProps={{
        backdrop: {
          timeout: 500,
        },
      }}>
      <Fade in={showModal}>
        <Box sx={styles.modal}>
          <Typography variant="h6" gutterBottom>
            {!ppe ? 'Create PPE' : 'Edit PPE'}
          </Typography>
          <Typography variant="subtitle2" gutterBottom mb={1} mt={2}>
            All fields are required
          </Typography>
          <Grid container spacing={2}>
            <Grid xs={12} sm={12} md={12} lg={12} mb={-2}>
              <RHTextField<PPERequest> label="Name" propName="ppeName" rhProps={{ errors, control }} />
              <RHTextField<PPERequest> label="Abbreviation" propName="ppeAbbreviation" rhProps={{ errors, control }} />
              <FormControl>
                <FormLabel id="demo-radio-buttons-group-label">Level</FormLabel>
                <RHRadioGroup
                  labels={['Create only for this branch', 'Create globally']}
                  values={[selectedBranchId, '0']}
                  propName="branchId"
                  rhProps={{ errors, control }}
                />
              </FormControl>
              <RHTextField<PPERequest>
                label="Description"
                fullWidth
                propName="ppeDescription"
                multiline
                rows={4}
                rhProps={{ errors, control }}
              />
              <Stack spacing={2} direction="row" sx={{ display: 'flex', justifyContent: 'flex-end' }} mt={2}>
                <Button variant="text" onClick={closeModal}>
                  CANCEL
                </Button>
                <LoadingButton
                  variant="contained"
                  color="primary"
                  loading={isSavingPPE || isUpdatingPPE}
                  onClick={() => {
                    if (callSubmit) {
                      callSubmit();
                    }
                  }}>
                  {renderButtonText()}
                </LoadingButton>
              </Stack>
            </Grid>
          </Grid>
        </Box>
      </Fade>
    </Modal>
  );
}

const styles = {
  modal: {
    position: 'absolute' as const,
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 500,
    bgcolor: 'background.paper',
    boxShadow: 24,
    p: 4,
    paddingTop: 2,
  },
};
