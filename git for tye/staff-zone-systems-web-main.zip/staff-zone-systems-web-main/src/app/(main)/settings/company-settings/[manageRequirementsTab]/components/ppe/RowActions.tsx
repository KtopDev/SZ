import React, { useState } from 'react';
import Box from '@mui/material/Box';
import EditIcon from '@mui/icons-material/Edit';
import IconButton from '@mui/material/IconButton';
import DeleteIcon from '@mui/icons-material/Delete';
import PPEFormModal from './PPEFormModal';
import DeletePPEModal from './DeletePPEFormModal';
import { PPEDto } from '@/types/dto/PPEDto';

type Props = {
  rowData: PPEDto;
  refetch: () => void;
};

export const RowActions = ({ rowData, refetch }: Props) => {
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);

  return (
    <>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
        <IconButton onClick={() => setShowUpdateModal(true)}>
          <EditIcon />
        </IconButton>
        <IconButton color="error" onClick={() => setShowDeleteModal(true)}>
          <DeleteIcon />
        </IconButton>
      </Box>

      {showUpdateModal && (
        <PPEFormModal
          ppe={rowData}
          showModal={showUpdateModal}
          closeModal={() => setShowUpdateModal(false)}
          refetch={refetch}
        />
      )}

      {showDeleteModal && (
        <DeletePPEModal
          taxId={rowData.ppe_id}
          showModal={showDeleteModal}
          closeModal={() => setShowDeleteModal(false)}
          refetch={refetch}
        />
      )}
    </>
  );
};
