import CreateCompCodeModalContent from './CreateCompCodeModalContent';

export default CreateCompCodeModalContent;
