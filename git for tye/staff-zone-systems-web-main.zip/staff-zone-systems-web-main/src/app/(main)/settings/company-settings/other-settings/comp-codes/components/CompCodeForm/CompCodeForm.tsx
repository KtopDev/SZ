import Grid from '@mui/material/Unstable_Grid2';
import { useForm } from 'react-hook-form';
import { CompCodeFormType } from '@/app/(main)/settings/company-settings/other-settings/comp-codes/components/CompCodeForm/types';
import RHTextField from '@/components/shared/Form/RHTextField';
import React, { useEffect } from 'react';
import RHSelect from '@/components/shared/Form/RHSelect';
import { createCompCode } from '@/app/(main)/settings/company-settings/other-settings/comp-codes/components/CompCodeForm/constants';
import { Box, Button, Card, CardContent } from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import Typography from '@mui/material/Typography';
import RHDatePicker from '@/components/shared/Form/RHDatePicker';
import RHCurrency from '@/components/shared/Form/RHCurrency';

const CompCodeForm = ({ onSubmit, isLoading, compCodeData, isCreate, handleClose, stateList }: any) => {
  const {
    control,
    formState: { errors, isValid },
    handleSubmit,
    getValues,
    reset,
    setValue,
  } = useForm<CompCodeFormType>({
    mode: 'onBlur',
    defaultValues: isCreate ? createCompCode : compCodeData,
  });

  useEffect(() => {
    reset(compCodeData);
  }, [compCodeData, reset]);

  return (
    <Card sx={modalStyle}>
      <CardContent>
        <Typography pb={2} fontWeight={500}>
          {isCreate ? 'Create' : 'Update'} Comp Code
        </Typography>

        <Typography py={2}>All fields are required</Typography>

        <Grid container direction="column">
          <RHTextField<CompCodeFormType>
            label="Comp Code"
            propName="compCode"
            rhProps={{ errors, control, getValues, maxLength: 4 }}
          />
          <RHTextField<CompCodeFormType>
            label="Description"
            propName="description"
            rhProps={{ errors, control, getValues }}
          />
          <RHTextField<CompCodeFormType>
            label="Billing Description"
            propName="billingInformation"
            rhProps={{ errors, control, getValues }}
          />
          <RHSelect<CompCodeFormType>
            label="State"
            propName="state"
            options={stateList}
            rhProps={{ errors, control, setValue, getValues }}
          />
          <RHCurrency<CompCodeFormType>
            label="Burden per Hour"
            propName="burdenPerHour"
            rhProps={{ errors, control, getValues }}
          />
          <RHCurrency<CompCodeFormType>
            label="Cost per Hundred"
            propName="costPerHundred"
            rhProps={{ errors, control, getValues }}
          />
          <RHCurrency<CompCodeFormType>
            label="Bill rate per Hundred"
            propName="billRatePerHundred"
            rhProps={{ errors, control, getValues }}
          />
          <RHDatePicker<CompCodeFormType>
            label="Effective Date"
            propName="effectiveDate"
            rhProps={{ errors, control, getValues }}
          />
        </Grid>
        <Box pt={2} display="flex" justifyContent="flex-end">
          <Button variant="outlined" onClick={handleClose}>
            CANCEL
          </Button>
          <LoadingButton
            disabled={!isValid}
            startIcon={null}
            loading={isLoading}
            variant="contained"
            color="primary"
            sx={{ marginLeft: 1 }}
            onClick={handleSubmit(onSubmit)}>
            {isCreate ? 'CREATE COMP CODE' : 'SAVE CHANGES'}
          </LoadingButton>
        </Box>
      </CardContent>
    </Card>
  );
};

const modalStyle = {
  position: 'absolute' as const,
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 550,
  textDecoration: 'none',
  p: 1,
};

export default CompCodeForm;
