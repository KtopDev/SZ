import { MRT_ColumnDef, MRT_Row } from 'material-react-table';
import dayjs from 'dayjs';
import Typography from '@mui/material/Typography';
import Tooltip from '@mui/material/Tooltip';
import { ToolDto } from '@/types/dto/ToolDto';

export const columns = (): MRT_ColumnDef<ToolDto>[] => [
  {
    accessorKey: 'ppeName',
    header: 'Name',
    Cell: ({ row }: { row: MRT_Row<ToolDto> }) => (
      <Tooltip title={<Typography sx={{ fontSize: '16px' }}>{row.original.tool_name}</Typography>} arrow>
        <Typography
          fontWeight="500"
          style={{
            maxWidth: '250px',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
          }}>
          {row.original.tool_name}
        </Typography>
      </Tooltip>
    ),
  },
  {
    accessorKey: 'ppeAbbreviation',
    header: 'Abbreviation',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<ToolDto> }) => (
      <Tooltip title={<Typography sx={{ fontSize: '16px' }}>{row.original.tool_abreviation}</Typography>} arrow>
        <Typography
          fontWeight="500"
          style={{
            maxWidth: '100px',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
          }}>
          {row.original.tool_abreviation}
        </Typography>
      </Tooltip>
    ),
  },
  {
    header: 'Branch',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<ToolDto> }) => <Typography fontWeight="500">{row.original.branch_name}</Typography>,
  },
  {
    accessorKey: 'ppeDescription',
    header: 'Description',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<ToolDto> }) => (
      <Tooltip title={<Typography sx={{ fontSize: '16px' }}>{row.original.tool_description}</Typography>} arrow>
        <Typography
          fontWeight="500"
          style={{
            maxWidth: '150px',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
          }}>
          {row.original.tool_description}
        </Typography>
      </Tooltip>
    ),
  },
  {
    accessorKey: 'ppeOccurrences',
    header: 'Occurrences',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<ToolDto> }) => <Typography fontWeight="500">{row.original.ocurrences}</Typography>,
  },
  {
    accessorKey: 'modifiedAt',
    header: 'Last updated',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<ToolDto> }) => (
      <span>{`${dayjs(row.original.modified_at).format('MM/DD/YYYY')}`}</span>
    ),
  },
];
