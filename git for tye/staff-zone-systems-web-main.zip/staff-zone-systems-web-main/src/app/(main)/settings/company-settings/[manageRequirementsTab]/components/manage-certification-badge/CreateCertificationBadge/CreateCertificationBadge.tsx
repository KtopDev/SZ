import { PayCycleForm } from '@/app/(main)/settings/company-settings/pay-settings/pay-cycle/components/PayCycleBaseForm/types';
import { useSnackbar } from '@/context/SnackbarContext';
import CertificationBadgeBaseForm from '@/app/(main)/settings/company-settings/[manageRequirementsTab]/components/manage-certification-badge/CertificationBadgeBaseForm';

const CreateCertificationBadge = ({ open, handleClose, refetch }: any) => {
  const { setMessage } = useSnackbar();

  const createCertificationBadge = async (props: any) => props;
  const loading = false;

  const onSubmit = async (formValues: PayCycleForm, setError: any, reset: any) => {
    try {
      await createCertificationBadge({
        formValues,
      });
      refetch();
      reset();
      handleClose();
      setMessage('Item created successfully');
    } catch (e: any) {
      if (e.response.status === 400) {
        //TODO: missing other validations for abbreviation
        setError('name', { message: e.response.data?.details[0]?.message });
      }
    }
  };

  return (
    <CertificationBadgeBaseForm
      isCreate
      open={open}
      onSubmit={onSubmit}
      isLoading={loading}
      handleClose={handleClose}
    />
  );
};

export default CreateCertificationBadge;
