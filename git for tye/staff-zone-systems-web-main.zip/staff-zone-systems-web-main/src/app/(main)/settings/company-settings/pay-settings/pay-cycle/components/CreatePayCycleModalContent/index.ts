import CreatePayCycleModalContent from '@/app/(main)/settings/company-settings/pay-settings/pay-cycle/components/CreatePayCycleModalContent/CreatePayCycleModalContent';

export default CreatePayCycleModalContent;
