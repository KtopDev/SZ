import UpdateTool from '@/app/(main)/settings/company-settings/[manageRequirementsTab]/components/tools/UpdateTool/UpdateTool';

export default UpdateTool;
