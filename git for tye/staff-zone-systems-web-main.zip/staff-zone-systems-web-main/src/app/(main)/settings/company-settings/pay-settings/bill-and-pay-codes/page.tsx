'use client';

import { useForm, useWatch } from 'react-hook-form';
import { IBillAndPayCodesFilters } from '@/app/(main)/settings/company-settings/pay-settings/bill-and-pay-codes/types';
import * as React from 'react';
import { useEffect, useMemo, useState } from 'react';
import { Box, CircularProgress, Tab, Tabs } from '@mui/material';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Unstable_Grid2';
import Button from '@mui/material/Button';
import AddIcon from '@mui/icons-material/Add';
import Table from '@/components/shared/Table/Table';
import { SortingState } from '@tanstack/table-core';
import IconButton from '@mui/material/IconButton';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import TopToolbar from '@/app/(main)/settings/company-settings/pay-settings/bill-and-pay-codes/components/TableTopToolbar';
import { debounce } from 'lodash';
import ConfirmationModal from '@/components/shared/Modal/ConfirmationModal';
import { useDeletePayCode, useGetPayCodeList } from '@/requests/api/payCodeApi/payCodeApi';
import { useDeleteBillCode, useGetBillCodeList } from '@/requests/api/billCodeApi/billCodeApi';
import { getColumns } from '@/app/(main)/settings/company-settings/pay-settings/bill-and-pay-codes/constants/tableColumns';
import CreateBillOrPayCode from '@/app/(main)/settings/company-settings/pay-settings/bill-and-pay-codes/components/CreateBillOrPayCode';
import UpdateBillOrPayCode from '@/app/(main)/settings/company-settings/pay-settings/bill-and-pay-codes/components/UpdateBillOrPayCode';
import Backdrop from '@mui/material/Backdrop';
import { useSnackbar } from '@/context/SnackbarContext';

const BillAndPayCodesPage = () => {
  const {
    control,
    formState: { errors },
    reset,
  } = useForm<IBillAndPayCodesFilters>({
    defaultValues: {
      nameOrDescription: '',
      startDate: '',
      endDate: '',
    },
  });

  const startDate = useWatch({ control: control, name: 'startDate' });
  const endDate = useWatch({ control: control, name: 'endDate' });

  const [pagination, setPagination] = useState({ pageIndex: 1, pageSize: 10 });
  const [sorting, setSorting] = useState<SortingState>([]);
  const [activeTab, setActiveTab] = useState(0);
  const [searchName, setSearchName] = useState('');

  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<any>({});

  const payCodeFilter = useMemo(
    () => ({
      size: pagination.pageSize,
      page: pagination.pageIndex + 1,
      sort: sorting[0] ? `payCodeName,${sorting[0].desc ? 'desc' : 'asc'}` : 'payCodeName,asc',
      searchBy: searchName,
      startDate,
      endDate,
    }),
    //eslint-disable-next-line react-hooks/exhaustive-deps
    [searchName, endDate, startDate, sorting, pagination.pageIndex]
  );

  const billCodeFilter = useMemo(
    () => ({
      size: pagination.pageSize,
      page: pagination.pageIndex + 1,
      sort: sorting[0] ? `billCodeName,${sorting[0].desc ? 'desc' : 'asc'}` : 'billCodeName,asc',
      searchBy: searchName,
      startDate,
      endDate,
    }),
    //eslint-disable-next-line react-hooks/exhaustive-deps
    [searchName, endDate, startDate, sorting, pagination.pageIndex]
  );

  useEffect(() => {
    reset();
    setSearchName('');
  }, [activeTab, reset]);

  const { setMessage } = useSnackbar();
  const { data: billCodes, loading: billCodesLoading, refetch: refetchBillCodes } = useGetBillCodeList(billCodeFilter);
  const { data: payCodes, loading: payCodesLoading, refetch: refetchPayCodes } = useGetPayCodeList(payCodeFilter);
  const [deletePayCode, { loading: deletePayCodeLoading }] = useDeletePayCode();
  const [deleteBillCode, { loading: deleteBillCodeLoading }] = useDeleteBillCode();

  const refreshLists = () => {
    refetchBillCodes();
    refetchPayCodes();
  };

  const debouncedSetValue = debounce(setSearchName, 1000);

  const handleNameInputChange = (e: any) => {
    debouncedSetValue(e.target.value);
  };

  const renderTopToolbar = ({ table }: any) => (
    <TopToolbar handleNameInputChange={handleNameInputChange} table={table} errors={errors} control={control} />
  );

  const handleDeletePayCode = async () => {
    try {
      const mutationCall = activeTab === 0 ? deleteBillCode : deletePayCode;
      await mutationCall(selectedItem.id);
      refreshLists();
      setMessage('Item deleted');
    } catch (e: any) {
      // if (e.response.status === 400) {
      //   setError('name', { message: e.response.data?.details[0]?.message });
      // }
    }
  };

  const handleTabChange = (_: any, newValue: number) => {
    setActiveTab(newValue);
  };

  const handleSetItem = ({ original }: any) => {
    setSelectedItem({
      id: original[activeTab === 0 ? 'bill_code_id' : 'pay_code_id'],
      name: original[activeTab === 0 ? 'bill_code_name' : 'pay_code_name'],
      description: original[activeTab === 0 ? 'bill_code_description' : 'pay_code_description'],
    });
  };

  const onClickUpdateButton = (item: any) => {
    handleSetItem(item);
    setIsUpdateModalOpen(true);
  };

  const onClickDeleteButton = (item: any) => {
    handleSetItem(item);
    setIsDeleteModalOpen(true);
  };

  const renderRowActions = ({ row }: any) => (
    <Box>
      <IconButton onClick={() => onClickUpdateButton(row)}>
        <EditIcon color="secondary" />
      </IconButton>
      <IconButton onClick={() => onClickDeleteButton(row)}>
        <DeleteIcon color="error" />
      </IconButton>
    </Box>
  );

  return (
    <>
      <Backdrop sx={{ color: '#fff' }} open={deleteBillCodeLoading || deletePayCodeLoading}>
        <CircularProgress color="inherit" />
      </Backdrop>
      <Box paddingY="8px" paddingX="24px" bgcolor="common.white" border="none">
        <Typography paddingY="4px" fontWeight="regular" fontSize={24}>
          Bill and pay codes
        </Typography>
        <Grid container direction="row" pt={2} justifyContent="space-between">
          <Box>
            <Box>
              <Tabs value={activeTab} onChange={handleTabChange} aria-label="basic tabs example">
                <Tab label="BILL CODES" id="BILL_CODES" />
                <Tab label="PAY CODES" id="PAY_CODES" />
              </Tabs>
            </Box>
          </Box>
          <Box paddingY="5px">
            <Button variant="contained" startIcon={<AddIcon />} onClick={() => setIsCreateModalOpen(true)}>
              CREATE
            </Button>
          </Box>
        </Grid>
      </Box>

      <Table
        key={activeTab}
        mrtProps={{
          data: activeTab === 0 ? billCodes.content || [] : payCodes.content || [],
          columns: getColumns(activeTab),
          renderTopToolbar,
          renderRowActions,
          state: {
            sorting,
            pagination,
            isLoading: billCodesLoading || payCodesLoading,
          },
          onPaginationChange: setPagination,
          onSortingChange: setSorting,
          manualPagination: true,
        }}
        rowCount={activeTab === 0 ? billCodes.totalSize || 0 : payCodes.totalSize || 0}
      />

      <CreateBillOrPayCode
        refresh={refreshLists}
        activeTab={activeTab}
        open={isCreateModalOpen}
        handleClose={() => setIsCreateModalOpen(false)}
      />
      <UpdateBillOrPayCode
        refresh={refreshLists}
        activeTab={activeTab}
        open={isUpdateModalOpen}
        billCodeData={selectedItem}
        handleClose={() => setIsUpdateModalOpen(false)}
      />
      <ConfirmationModal
        title={`Delete ${activeTab === 0 ? 'bill code' : 'pay code'}`}
        description={`Are you sure you want to remove the ${activeTab === 0 ? 'bill code' : 'pay code'} "${selectedItem.name}" ?`}
        confirmationButtonText={`DELETE ${activeTab === 0 ? 'BILL CODE' : 'PAY CODE'}`}
        confirmationButtonColor="error"
        showModal={isDeleteModalOpen}
        closeModal={() => setIsDeleteModalOpen(false)}
        isLoading={false}
        callSubmit={handleDeletePayCode}
      />
    </>
  );
};

export default BillAndPayCodesPage;
