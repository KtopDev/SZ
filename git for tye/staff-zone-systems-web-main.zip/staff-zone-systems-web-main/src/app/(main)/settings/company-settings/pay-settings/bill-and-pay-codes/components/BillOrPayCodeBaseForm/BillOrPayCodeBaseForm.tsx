import { Button, Dialog, DialogActions, DialogContent, DialogTitle } from '@mui/material';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Unstable_Grid2';
import RHTextField from '@/components/shared/Form/RHTextField';
import RHTextareaAutosize from '@/components/shared/Form/RHTextarea';
import LoadingButton from '@mui/lab/LoadingButton';
import * as React from 'react';
import { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { BillCodeForm } from '@/app/(main)/settings/company-settings/pay-settings/bill-and-pay-codes/types';

const BillOrPayCodeBaseForm = ({ open, handleClose, loading, isCreate, billCodeData, onSubmit, activeTab }: any) => {
  const {
    control,
    formState: { errors, isValid },
    handleSubmit,
    reset,
    setError,
  } = useForm<BillCodeForm>({
    defaultValues: isCreate
      ? {
        name: '',
        description: '',
      }
      : billCodeData,
    mode: 'onBlur',
  });

  useEffect(() => {
    reset(billCodeData);
  }, [billCodeData, reset]);

  return (
    <>
      <Dialog open={open} onClose={handleClose} fullWidth>
        <DialogTitle>
          {isCreate ? 'Create' : 'Edit'} {activeTab === 0 ? 'bill code' : 'pay code'}
        </DialogTitle>
        <DialogContent>
          <Box py={2}>
            <Grid>
              <RHTextField<BillCodeForm> label="Title" propName="name" margin="none" rhProps={{ errors, control }} />
              <RHTextareaAutosize<BillCodeForm>
                minRows={8}
                label="Description"
                propName="description"
                rhProps={{ errors, control, maxLength: 300 }}
              />
            </Grid>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>CANCEL</Button>
          <LoadingButton
            disabled={!isValid}
            loading={loading}
            variant="contained"
            onClick={handleSubmit((formValues) => onSubmit(formValues, setError, reset))}>
            {isCreate ? `CREATE ${activeTab === 0 ? 'BILL CODE' : 'PAY CODE'}` : 'SAVE CHANGES'}
          </LoadingButton>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default BillOrPayCodeBaseForm;
