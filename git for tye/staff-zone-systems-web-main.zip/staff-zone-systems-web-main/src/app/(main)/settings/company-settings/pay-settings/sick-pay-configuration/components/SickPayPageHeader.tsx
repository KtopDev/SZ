import React, { useState } from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import { Box, Button, Typography } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import SickPayFormModal from './SickPayFormModal';

type Props = {
  refetch: () => void;
};

const SickPayPageHeader = ({ refetch }: Props) => {
  const [showModal, setShowModal] = useState(false);
  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(false);

  return (
    <>
      <Box paddingY="8px" paddingX="24px" bgcolor="common.white" border="none" justifyContent="space-between">
        <Grid container direction="row" justifyContent="space-between" mb={2}>
          <Typography paddingY="4px" fontWeight="regular" fontSize={24}>
            Sick pay configuration
          </Typography>
          <Box paddingY="5px">
            <Button variant="contained" startIcon={<AddIcon />} onClick={openModal}>
              CREATE
            </Button>
          </Box>
        </Grid>
      </Box>

      {showModal && <SickPayFormModal showModal={showModal} closeModal={closeModal} refetch={refetch} />}
    </>
  );
};

export default SickPayPageHeader;
