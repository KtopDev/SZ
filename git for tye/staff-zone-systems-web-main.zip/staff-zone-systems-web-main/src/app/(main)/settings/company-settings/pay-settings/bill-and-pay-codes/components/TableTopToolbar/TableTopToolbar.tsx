import React from 'react';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Unstable_Grid2';
import { MRT_TablePagination } from 'material-react-table';
import SearchIcon from '@mui/icons-material/Search';
import { TextField } from '@mui/material';
import Typography from '@mui/material/Typography';
import RHDatePicker from '@/components/shared/Form/RHDatePicker';

interface Props {
  table: any;
  handleNameInputChange: any;
  errors: any;
  control: any;
}

const TopToolbar = ({ table, handleNameInputChange, errors, control }: Props) => {
  return (
    <Box
      pb={2}
      sx={{
        backgroundColor: 'common.white',
        justifyContent: 'space-between',
      }}>
      <Grid pl={3} container alignItems="end" spacing={2} columns={100}>
        <Grid xs={55}>
          <TextField
            InputProps={{
              startAdornment: <SearchIcon />,
            }}
            fullWidth
            label="Search By Name"
            margin="none"
            onChange={handleNameInputChange}
          />
        </Grid>
        <Grid xs={15}>
          <Typography fontSize={14} paddingBottom="8px">
            Creation date
          </Typography>
          <RHDatePicker label="Start date" propName="startDate" rhProps={{ errors, control, required: false }} />
        </Grid>
        <Grid xs={15}>
          <RHDatePicker label="End date" propName="endDate" rhProps={{ errors, control, required: false }} />
        </Grid>
        <Box ml="auto" pr={3}>
          <MRT_TablePagination table={table} />
        </Box>
      </Grid>
    </Box>
  );
};

export default TopToolbar;
