export type PayCycleForm = {
  id: string;
  name: string;
  startDay: any;
};
