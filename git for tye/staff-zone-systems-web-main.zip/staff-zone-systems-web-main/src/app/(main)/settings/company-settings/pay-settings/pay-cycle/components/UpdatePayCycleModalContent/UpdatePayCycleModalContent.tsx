import PayCycleBaseForm from '@/app/(main)/settings/company-settings/pay-settings/pay-cycle/components/PayCycleBaseForm';
import { PayCycleForm } from '@/app/(main)/settings/company-settings/pay-settings/pay-cycle/components/PayCycleBaseForm/types';
import { useUpdatePayCycle } from '@/requests/api/payCycleApi/payCycleApi';
import { useSnackbar } from '@/context/SnackbarContext';

const UpdateCompCodeModalContent = ({ handleClose, payCycleData, refetch }: any) => {
  const [updatePayCycle, { loading }] = useUpdatePayCycle();
  const { setMessage } = useSnackbar();
  const onSubmit = async (formValues: PayCycleForm, setError: any) => {
    try {
      await updatePayCycle({
        id: formValues.id,
        payCycleName: formValues.name,
        startIsoDayOfWeek: formValues.startDay,
      });
      refetch();
      handleClose();
      setMessage('Changes saved');
    } catch (e: any) {
      if (e.response.status === 400) {
        setError('name', { message: e.response.data?.details[0]?.message });
      }
    }
  };

  return (
    <PayCycleBaseForm
      handleClose={handleClose}
      loading={loading}
      payCycleData={payCycleData}
      isCreate={false}
      onSubmit={onSubmit}
    />
  );
};

export default UpdateCompCodeModalContent;
