import React from 'react';
import { Control, FieldErrors, UseFormSetValue } from 'react-hook-form';
import { MRT_TableInstance, MRT_TablePagination } from 'material-react-table';

type Props = {
  table: MRT_TableInstance<any>;
  setValue: UseFormSetValue<any>;
  errors: FieldErrors<any>;
  control: Control<any, any, any>;
};

const PPETopToolbar = ({ table }: Props) => {
  return (
    <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
      <MRT_TablePagination table={table} />
    </div>
  );
};

export default PPETopToolbar;

export interface IPPEListFilter {
  name: string;
  branch: string;
  status: string;
  startDate: string;
  endDate: string;
}
