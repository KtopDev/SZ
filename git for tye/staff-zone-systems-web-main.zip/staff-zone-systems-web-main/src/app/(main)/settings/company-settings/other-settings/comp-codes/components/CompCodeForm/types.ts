export type CompCodeFormType = {
  id: number | undefined;
  compCode: string | undefined;
  description: string | undefined;
  billingInformation: string | undefined;
  state: string | undefined;
  burdenPerHour: number | undefined;
  costPerHundred: number | undefined;
  billRatePerHundred: number | undefined;
  effectiveDate: string | undefined;
};
