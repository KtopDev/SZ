import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Unstable_Grid2';
import { Box } from '@mui/material';
import RHSelect from '@/components/shared/Form/RHSelect';
import RHDatePicker from '@/components/shared/Form/RHDatePicker';
import { useGetDropdownState } from '@/requests/api/statesApi/statesApi';
import { Control, FieldErrors } from 'react-hook-form';
import { MRT_TableInstance, MRT_TablePagination } from 'material-react-table';

type Props = {
  table: MRT_TableInstance<any>;
  errors: FieldErrors<any>;
  control: Control<any, any, any>;
};

const SickPayTopToolbar = ({ table, errors, control }: Props) => {
  const { data: stateList, loading: isStateListLoading } = useGetDropdownState();
  return (
    <>
      <Box paddingY="8px" paddingX="24px" bgcolor="common.white" border="none">
        <Box sx={{ flexGrow: 1 }}>
          <Grid container alignItems="end" spacing={2} columns={16}>
            <Grid xs={12} py="0px">
              <RHSelect<any>
                label="Jurisdiction"
                propName="state"
                options={stateList}
                isLoading={isStateListLoading}
                rhProps={{ errors, control, required: false }}
              />
            </Grid>
            <Grid xs={2}>
              <Typography fontSize={14} paddingBottom="8px">
                Effective date
              </Typography>
              <RHDatePicker<any>
                label="Start date"
                propName="startDate"
                rhProps={{ errors, control, required: false }}
              />
            </Grid>
            <Grid xs={2}>
              <RHDatePicker<any> label="End date" propName="endDate" rhProps={{ errors, control, required: false }} />
            </Grid>
          </Grid>
        </Box>
      </Box>
      <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
        <MRT_TablePagination table={table} />
      </div>
    </>
  );
};

export default SickPayTopToolbar;
