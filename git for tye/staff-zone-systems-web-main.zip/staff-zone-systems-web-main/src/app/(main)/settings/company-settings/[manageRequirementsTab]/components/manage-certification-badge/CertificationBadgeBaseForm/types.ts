export type CertificationBadgeForm = {
  name: string;
  abbreviation: string;
  isMutable: boolean;
  daysFromHireRequirement?: string;
  daysFromFirstPlacement?: string;
  description: string;
  prop: boolean;
};
