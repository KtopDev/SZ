import { MRT_ColumnDef, MRT_Row } from 'material-react-table';
import dayjs from 'dayjs';
import Typography from '@mui/material/Typography';
import { currencyFormatter } from '@/utils/general/general';

export const columns = (): MRT_ColumnDef<any>[] => [
  {
    accessorKey: 'lkStates',
    header: 'Jurisdiction',
    Cell: ({ row }: { row: MRT_Row<any> }) => (
      <Typography fontWeight="500">{row.original.lkStates.stateName}</Typography>
    ),
  },
  {
    accessorKey: 'minWage',
    header: 'Min Wage',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<any> }) => (
      <Typography fontWeight="500">{currencyFormatter.format(row.original.minWage)}</Typography>
    ),
  },
  {
    accessorKey: 'maxWage',
    header: 'Max Wage',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<any> }) => (
      <Typography fontWeight="500">{currencyFormatter.format(row.original.maxWage)}</Typography>
    ),
  },
  { accessorKey: 'rate', header: 'Rate', enableSorting: false },
  { accessorKey: 'federalCreditRate', header: 'Federal Credit Rate', enableSorting: false },
  { accessorKey: 'employeeRate', header: 'Employee Rate', enableSorting: false },
  { accessorKey: 'companyRate', header: 'Company Rate', enableSorting: false },
  {
    accessorKey: 'modifiedAt',
    header: 'Last updated',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<any> }) => <span>{`${dayjs(row.original.modifiedAt).format('MM/DD/YYYY')}`}</span>,
  },
];
