export interface ICompCodeListFilter {
  nameCode: string;
  state: string;
  status: string;
  startDate: string;
  endDate: string;
  isRowActive: boolean;
}
