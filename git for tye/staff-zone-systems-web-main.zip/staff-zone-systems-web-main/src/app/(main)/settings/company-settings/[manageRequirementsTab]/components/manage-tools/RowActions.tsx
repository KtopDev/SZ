import React, { useMemo, useState } from 'react';
import Box from '@mui/material/Box';
import EditIcon from '@mui/icons-material/Edit';
import IconButton from '@mui/material/IconButton';
import DeleteIcon from '@mui/icons-material/Delete';
import UpdateTool from '@/app/(main)/settings/company-settings/[manageRequirementsTab]/components/tools/UpdateTool';
import DeleteItemModal from '@/app/(main)/settings/company-settings/[manageRequirementsTab]/components/shared/DeleteItemModal';

type Props = {
  rowData: any;
  refetch: () => void;
};

export const RowActions = ({ rowData, refetch }: Props) => {
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);

  const formData = useMemo(
    () => ({
      id: rowData.tool_id,
      toolName: rowData.tool_name,
      toolDescription: rowData.tool_description,
      toolAbbreviation: rowData.tool_abreviation,
    }),
    [rowData]
  );

  return (
    <>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
        <IconButton>
          <EditIcon onClick={() => setShowUpdateModal(true)} />
        </IconButton>
        <IconButton color="error">
          <DeleteIcon onClick={() => setShowDeleteModal(true)} />
        </IconButton>
      </Box>

      <UpdateTool
        toolData={formData}
        open={showUpdateModal}
        handleClose={() => setShowUpdateModal(false)}
        refetch={refetch}
      />

      {showDeleteModal && (
        <DeleteItemModal
          id={rowData.id}
          deleteFunction={async () => {}}
          isDeleting={false}
          showModal={showDeleteModal}
          closeModal={() => setShowDeleteModal(false)}
          refetch={refetch}
        />
      )}
    </>
  );
};
