export const defaultPayCycle = {
  name: '',
  startDay: null,
  endDate: null,
};
