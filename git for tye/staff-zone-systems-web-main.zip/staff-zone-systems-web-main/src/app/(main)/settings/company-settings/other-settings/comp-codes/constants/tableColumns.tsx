import { currencyFormatter } from '@/utils/general/general';
import { MRT_Row } from 'material-react-table';
import dayjs from 'dayjs';

export const columns = [
  { accessorKey: 'comp_code', header: 'Comp code' },
  { accessorKey: 'comp_code_description', header: 'Description', enableSorting: false },
  { accessorKey: 'comp_code_billing_description', header: 'Billing description', enableSorting: false },
  { accessorKey: 'state', header: 'State', enableSorting: false },
  {
    accessorKey: 'burden_per_hour',
    header: 'Burden per Hour',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<any> }) => {
      return currencyFormatter.format(row.original.burden_per_hour);
    },
  },
  {
    accessorKey: 'cost_per_hundred',
    header: 'Cost Per Hundred',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<any> }) => {
      return currencyFormatter.format(row.original.cost_per_hundred);
    },
  },
  {
    accessorKey: 'bill_rate_per_hundred',
    header: 'Bill rate per Hundred',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<any> }) => {
      return currencyFormatter.format(row.original.bill_rate_per_hundred);
    },
  },
  {
    accessorKey: 'efective_date',
    header: 'Effective Date',
    enableSorting: false,
    Cell: ({ row }: { row: MRT_Row<any> }) => {
      return dayjs(row.original.efective_date).format('MM/DD/YYYY');
    },
  },
];
