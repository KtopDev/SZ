import UpdateCompCodeModalContent from '@/app/(main)/settings/company-settings/pay-settings/pay-cycle/components/UpdatePayCycleModalContent/UpdatePayCycleModalContent';

export default UpdateCompCodeModalContent;
