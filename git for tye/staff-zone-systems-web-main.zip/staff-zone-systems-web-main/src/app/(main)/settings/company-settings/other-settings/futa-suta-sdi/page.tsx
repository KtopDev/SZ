'use client';

import * as React from 'react';
import { useMemo, useState } from 'react';
import Box from '@mui/material/Box';
import AddIcon from '@mui/icons-material/Add';
import Grid from '@mui/material/Unstable_Grid2';
import Typography from '@mui/material/Typography';
import Table from '@/components/shared/Table/Table';
import { columns } from '@/app/(main)/settings/company-settings/other-settings/futa-suta-sdi/components/tableColumns';
import { Button, Tab, Tabs } from '@mui/material';
import { useGetDropdownState } from '@/requests/api/statesApi/statesApi';
import { useForm, useWatch } from 'react-hook-form';
import { SortingState } from '@tanstack/table-core';
import { useGetTaxesList } from '@/requests/api/taxesApi/taxesApi';
import FutaSutaFormModal from '@/app/(main)/settings/company-settings/other-settings/futa-suta-sdi/components/FutaSutaFormModal';
import TopToolbar from './components/TopToolbar';
import RowActions from './components/RowActions';
import { IFutaSutaSdiFilter } from '@/app/(main)/settings/company-settings/other-settings/futa-suta-sdi/types';

const FutaSutaSdiPage = () => {
  const {
    control,
    setValue,
    formState: { errors },
  } = useForm<IFutaSutaSdiFilter>({
    defaultValues: {
      nameCode: '',
      state: '',
      status: 'ACTIVE',
      isRowActive: true,
      startDate: '',
      endDate: '',
    },
  });

  const [showModal, setShowModal] = useState(false);
  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(false);

  const nameCode = useWatch({ control: control, name: 'nameCode' });
  const state = useWatch({ control: control, name: 'state' });
  const startDate = useWatch({ control: control, name: 'startDate' });
  const endDate = useWatch({ control: control, name: 'endDate' });
  const status = useWatch({ control: control, name: 'status' });
  const isRowActive = useWatch({ control: control, name: 'isRowActive' });

  const { data: stateList, loading: isStateListLoading } = useGetDropdownState();
  const [pagination, setPagination] = useState({ pageIndex: 1, pageSize: 10 });
  const [sorting, setSorting] = useState<SortingState>([]);
  const [activeTab, setActiveTab] = useState(0);

  const filter = useMemo(
    () => ({
      size: pagination.pageSize,
      page: pagination.pageIndex + 1,
      sort: sorting[0] ? `${sorting[0].id},${sorting[0].desc ? 'desc' : 'asc'}` : 'lkStates,asc',
      nameCode,
      state,
      status,
      startDate,
      endDate,
      isRowActive,
    }),
    //eslint-disable-next-line react-hooks/exhaustive-deps
    [endDate, nameCode, startDate, state, status, sorting, pagination.pageIndex]
  );

  const { data: taxesList, loading, refetch } = useGetTaxesList(filter);

  const renderTopToolbar = ({ table }: any) => (
    <TopToolbar
      table={table}
      stateList={stateList}
      isStateListLoading={isStateListLoading}
      errors={errors}
      control={control}
    />
  );

  const handleTabChange = (_: any, newValue: number) => {
    setActiveTab(newValue);
  };

  return (
    <>
      <Box paddingY="8px" paddingX="24px" bgcolor="common.white" border="none">
        <Typography paddingY="4px" fontWeight="regular" fontSize={24}>
          FUTA, SUTA and SDI configurations
        </Typography>
        <Typography fontSize={14} color="secondary.dark">
          Federal Unemployment Tax (FUTA), State Unemployment Tax (SUTA), and State Disability Insurance (SDI) settings{' '}
        </Typography>
        <Grid container direction="row" pt={2} justifyContent="space-between">
          <Box>
            <Box>
              <Tabs value={activeTab} onChange={handleTabChange} aria-label="basic tabs example">
                <Tab label="ACTIVE CONFIGURATIONS" id="ACTIVE" onClick={() => setValue('status', 'ACTIVE')} />
                <Tab label="ARCHIVED" id="ARCHIVE" onClick={() => setValue('status', 'ARCHIVED')} />
              </Tabs>
            </Box>
          </Box>
          <Box paddingY="5px">
            <Button variant="contained" startIcon={<AddIcon />} onClick={openModal}>
              CREATE
            </Button>
          </Box>
        </Grid>
      </Box>
      <Table
        mrtProps={{
          data: taxesList.content || [],
          columns: columns(),
          renderTopToolbar,
          renderRowActions: ({ row }) => <RowActions rowData={row.original} refetch={refetch} />,
          state: {
            sorting,
            pagination,
            isLoading: loading,
          },
          onPaginationChange: setPagination,
          onSortingChange: setSorting,
          manualPagination: true,
        }}
        rowCount={taxesList.totalSize || 0}
      />

      <FutaSutaFormModal showModal={showModal} closeModal={closeModal} refetch={refetch} />
    </>
  );
};

export default FutaSutaSdiPage;
