import CreateTool from '@/app/(main)/settings/company-settings/[manageRequirementsTab]/components/tools/CreateTool/CreateTool';

export default CreateTool;
