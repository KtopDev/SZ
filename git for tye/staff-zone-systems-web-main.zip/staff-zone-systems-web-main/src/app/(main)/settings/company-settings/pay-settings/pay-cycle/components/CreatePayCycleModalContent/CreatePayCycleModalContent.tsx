import { PayCycleForm } from '@/app/(main)/settings/company-settings/pay-settings/pay-cycle/components/PayCycleBaseForm/types';
import PayCycleBaseForm from '@/app/(main)/settings/company-settings/pay-settings/pay-cycle/components/PayCycleBaseForm';
import { useCreatePayCycle } from '@/requests/api/payCycleApi/payCycleApi';
import { useSnackbar } from '@/context/SnackbarContext';

const CreatePayCycleModalContent = ({ handleClose, refetch }: any) => {
  const [createPayCycle, { loading }] = useCreatePayCycle();
  const { setMessage } = useSnackbar();

  const onSubmit = async (formValues: PayCycleForm, setError: any) => {
    try {
      await createPayCycle({
        payCycleName: formValues.name,
        startIsoDayOfWeek: formValues.startDay,
      });
      refetch();
      handleClose();
      setMessage('Item created successfully');
    } catch (e: any) {
      if (e.response.status === 400) {
        setError('name', { message: e.response.data?.details[0]?.message });
      }
    }
  };

  return <PayCycleBaseForm handleClose={handleClose} isCreate onSubmit={onSubmit} isLoading={loading} />;
};

export default CreatePayCycleModalContent;
