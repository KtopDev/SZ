import BillOrPayCodeBaseForm from '../BillOrPayCodeBaseForm';
import { useCreatePayCode } from '@/requests/api/payCodeApi/payCodeApi';
import { useCreateBillCode } from '@/requests/api/billCodeApi/billCodeApi';
import { useSnackbar } from '@/context/SnackbarContext';

const CreateBillOrPayCode = ({ open, handleClose, activeTab, refresh }: any) => {
  const [createPayCode, { loading: loadingCreatePayCode }] = useCreatePayCode();
  const [createBillCode, { loading: loadingCreateBillCode }] = useCreateBillCode();
  const { setMessage } = useSnackbar();
  const handleCreateBillCode = async (formValues: any, setError: any, reset: any) => {
    try {
      const mutationCall = activeTab === 0 ? createBillCode : createPayCode;
      const payload =
        activeTab === 0
          ? {
            billCodeName: formValues.name,
            billCodeDescription: formValues.description,
          }
          : { payCodeName: formValues.name, payCodeDescription: formValues.description };
      await mutationCall(payload);
      handleClose();
      refresh();
      reset();
      setMessage('Item created successfully');
    } catch (e: any) {
      if (e.response.status === 400) {
        setError('name', { message: e.response.data?.details[0]?.message });
      }
    }
  };

  return (
    <BillOrPayCodeBaseForm
      open={open}
      loading={loadingCreateBillCode || loadingCreatePayCode}
      isCreate={true}
      BillCodeData={null}
      activeTab={activeTab}
      handleClose={handleClose}
      onSubmit={handleCreateBillCode}
    />
  );
};

export default CreateBillOrPayCode;
