import { CompCodeFormType } from '@/app/(main)/settings/company-settings/other-settings/comp-codes/components/CompCodeForm/types';
import { useEditCompCode } from '@/requests/api/compCodesApi/compCodesApi';
import CompCodeForm from '@/app/(main)/settings/company-settings/other-settings/comp-codes/components/CompCodeForm';
import dayjs from 'dayjs';

const UpdateCompCodeModalContent = ({ handleClose, compCodeData, stateList, refresh, setErrorMessage }: any) => {
  const [updateCompCode, { loading }] = useEditCompCode();
  const onSubmit = async (formValues: CompCodeFormType) => {
    try {
      formValues.effectiveDate = dayjs(formValues.effectiveDate).format('YYYY-MM-DD');
      await updateCompCode(formValues);
      refresh();
      handleClose();
    } catch (e: any) {
      if (e.response.status === 400) {
        setErrorMessage(e.response.data.message);
      }
    }
  };

  return (
    <CompCodeForm
      handleClose={handleClose}
      loading={loading}
      compCodeData={compCodeData}
      isCreate={false}
      onSubmit={onSubmit}
      stateList={stateList}
    />
  );
};

export default UpdateCompCodeModalContent;
