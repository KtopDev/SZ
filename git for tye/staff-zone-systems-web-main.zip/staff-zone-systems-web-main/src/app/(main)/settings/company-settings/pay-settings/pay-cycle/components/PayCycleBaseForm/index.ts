import PayCycleBaseForm from './PayCycleBaseForm';

export default PayCycleBaseForm;
