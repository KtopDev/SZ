'use client';

import * as React from 'react';
import { useMemo, useState } from 'react';
import Box from '@mui/material/Box';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import Grid from '@mui/material/Unstable_Grid2';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import Table from '@/components/shared/Table/Table';
import { MRT_TablePagination } from 'material-react-table';
import { Backdrop, Button, Card, CardContent, Stack, TextField } from '@mui/material';
import { useGetDropdownState } from '@/requests/api/statesApi/statesApi';
import RHDatePicker from '@/components/shared/Form/RHDatePicker';
import RHSelect from '@/components/shared/Form/RHSelect';
import { useForm, useWatch } from 'react-hook-form';
import RHChipGroup from '@/components/shared/Form/RHChipGroup';
import { SortingState } from '@tanstack/table-core';
import { debounce } from 'lodash';
import SearchIcon from '@mui/icons-material/Search';
import DeleteIcon from '@mui/icons-material/Delete';
import { useDeleteCompCode, useGetCompCodeList } from '@/requests/api/compCodesApi/compCodesApi';
import { ICompCodeListFilter } from '@/app/(main)/settings/company-settings/other-settings/comp-codes/types';
import Modal from '@mui/material/Modal';
import CreateCompCodeModalContent from './components/CreateCompCodeModalContent';
import UpdateCompCodeModalContent from '@/app/(main)/settings/company-settings/other-settings/comp-codes/components/UpdateCompCodeModalContent';
import { columns } from '@/app/(main)/settings/company-settings/other-settings/comp-codes/constants/tableColumns';
import LoadingButton from '@mui/lab/LoadingButton';
import { useSnackbar } from '@/context/SnackbarContext';
import dayjs from 'dayjs';
import { commonModalStyle } from '@/theme/constants';

const CompCodeListPage = () => {
  const {
    control,
    formState: { errors },
    setValue,
  } = useForm<ICompCodeListFilter>({
    defaultValues: {
      nameCode: '',
      state: '',
      status: 'ACTIVE',
      startDate: '',
      endDate: '',
    },
  });

  const startDate = useWatch({ control: control, name: 'startDate' });
  const endDate = useWatch({ control: control, name: 'endDate' });
  const state = useWatch({ control: control, name: 'state' });
  const searchBy = useWatch({ control: control, name: 'nameCode' });
  const status = useWatch({ control: control, name: 'status' });

  const [pagination, setPagination] = useState({ pageIndex: 1, pageSize: 10 });
  const [sorting, setSorting] = useState<SortingState>([]);

  const filter = useMemo(
    () => ({
      size: pagination.pageSize,
      page: pagination.pageIndex + 1,
      sort: sorting[0] ? `${sorting[0].id},${sorting[0].desc ? 'desc' : 'asc'}` : 'compCode,asc',
      searchBy,
      state,
      status,
      startDate,
      endDate,
    }),
    //eslint-disable-next-line react-hooks/exhaustive-deps
    [endDate, searchBy, startDate, state, status, sorting, pagination.pageIndex]
  );

  const { setErrorMessage } = useSnackbar();

  const [shouldShowCreateCompCodeModal, setShouldShowCreateCompCodeModal] = useState(false);
  const [shouldShowUpdateCompCodeModal, setShouldShowUpdateCompCodeModal] = useState(false);
  const [shouldShowConfirmDeleteCompCodeModal, setShouldShowConfirmDeleteCompCodeModal] = useState(false);
  const [selectedCompCode, setSelectedCompCode] = useState<any>({});

  const { data: compCodeList, loading, refetch } = useGetCompCodeList(filter);
  const { data: stateList, loading: isStateListLoading } = useGetDropdownState();

  const [deleteCompCode, { loading: deleteCompCodeLoading }] = useDeleteCompCode();

  const handleDeleteCompCode = async () => {
    try {
      await deleteCompCode(selectedCompCode.id);
      setShouldShowConfirmDeleteCompCodeModal(false);
      refetch();
    } catch (e: any) {
      if (e.response.status === 400) {
        setErrorMessage('This comp code is in use');
      }
    }
  };

  const handleSetItem = ({ original }: any) => {
    setSelectedCompCode({
      id: original.comp_code_id,
      compCode: original.comp_code,
      description: original.comp_code_description,
      billingInformation: original.comp_code_billing_description,
      state: original.state,
      burdenPerHour: original.burden_per_hour,
      costPerHundred: original.cost_per_hundred,
      billRatePerHundred: original.bill_rate_per_hundred,
      effectiveDate: dayjs(original.efective_date),
    });
  };

  const onClickUpdateButton = (item: any) => {
    handleSetItem(item);
    setShouldShowUpdateCompCodeModal(true);
  };

  const onClickDeleteButton = (item: any) => {
    handleSetItem(item);
    setShouldShowConfirmDeleteCompCodeModal(true);
  };

  const renderRowActions = ({ row }: any) => (
    <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
      <IconButton onClick={() => onClickUpdateButton(row)}>
        <EditIcon color="secondary" />
      </IconButton>
      <IconButton onClick={() => onClickDeleteButton(row)}>
        <DeleteIcon color="error" />
      </IconButton>
    </Box>
  );

  const renderTopToolbar = ({ table }: any) => (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        backgroundColor: 'common.white',
        justifyContent: 'space-between',
      }}>
      <Box sx={{ paddingLeft: '24px', paddingBottom: '16px' }}>
        <Typography fontSize="14px">Status</Typography>
        <RHChipGroup
          chips={[
            { label: 'Active', color: 'success', value: 'ACTIVE' },
            { label: 'Inactive', color: 'default', value: 'ARCHIVED' },
          ]}
          propName="status"
          rhProps={{ errors, control, required: false }}
        />
      </Box>
      <MRT_TablePagination table={table} />
    </Box>
  );

  const debouncedSetValue = debounce(setValue, 1000);

  const handleCodeNameInputChange = (e: any) => {
    debouncedSetValue('nameCode', e.target.value);
  };

  const closeCreateModal = () => {
    setShouldShowCreateCompCodeModal(false);
  };

  const closeUpdateModal = () => {
    setShouldShowUpdateCompCodeModal(false);
  };

  return (
    <>
      <Box paddingY="8px" paddingX="24px" bgcolor="common.white" border="none">
        <Grid container direction="row" justifyContent="space-between">
          <Typography paddingY="4px" fontWeight="regular" fontSize={24}>
            Comp Codes
          </Typography>
          <Box paddingY="5px">
            <Button variant="contained" startIcon={<AddIcon />} onClick={() => setShouldShowCreateCompCodeModal(true)}>
              CREATE
            </Button>
          </Box>
        </Grid>
        <Box sx={{ flexGrow: 1 }}>
          <Grid container alignItems="end" spacing={2} columns={12}>
            <Grid xs={4}>
              <TextField
                InputProps={{
                  startAdornment: <SearchIcon />,
                }}
                fullWidth
                label="Search by code or description"
                margin="none"
                onChange={handleCodeNameInputChange}
              />
            </Grid>
            <Grid xs={4} py="0px">
              <RHSelect<ICompCodeListFilter>
                label="State"
                propName="state"
                options={stateList}
                isLoading={isStateListLoading}
                rhProps={{ errors, control, required: false }}
              />
            </Grid>
            <Grid xs={2}>
              <Typography fontSize={14} paddingBottom="8px">
                Last update
              </Typography>
              <RHDatePicker<ICompCodeListFilter>
                label="Start date"
                propName="startDate"
                rhProps={{ errors, control, required: false }}
              />
            </Grid>
            <Grid xs={2}>
              <RHDatePicker<ICompCodeListFilter>
                label="End date"
                propName="endDate"
                rhProps={{ errors, control, required: false }}
              />
            </Grid>
          </Grid>
        </Box>
      </Box>
      <Table
        mrtProps={{
          data: compCodeList.content || [],
          columns: columns,
          renderTopToolbar,
          renderRowActions,
          state: {
            sorting,
            pagination,
            isLoading: loading,
          },
          onPaginationChange: setPagination,
          onSortingChange: setSorting,
          manualPagination: true,
        }}
        rowCount={compCodeList.totalSize || 0}
      />

      <Modal
        open={shouldShowCreateCompCodeModal}
        onClose={closeCreateModal}
        closeAfterTransition
        slots={{ backdrop: Backdrop }}
        slotProps={{
          backdrop: {
            timeout: 500,
          },
        }}>
        <CreateCompCodeModalContent
          setErrorMessage={setErrorMessage}
          refresh={refetch}
          stateList={stateList}
          handleClose={closeCreateModal}
        />
      </Modal>

      <Modal
        open={shouldShowUpdateCompCodeModal}
        onClose={closeUpdateModal}
        closeAfterTransition
        slots={{ backdrop: Backdrop }}
        slotProps={{
          backdrop: {
            timeout: 500,
          },
        }}>
        <UpdateCompCodeModalContent
          refresh={refetch}
          stateList={stateList}
          setErrorMessage={setErrorMessage}
          compCodeData={selectedCompCode}
          handleClose={closeUpdateModal}
        />
      </Modal>

      <Modal
        open={shouldShowConfirmDeleteCompCodeModal}
        onClose={() => setShouldShowConfirmDeleteCompCodeModal(false)}
        closeAfterTransition
        slots={{ backdrop: Backdrop }}
        slotProps={{
          backdrop: {
            timeout: 500,
          },
        }}>
        <Box sx={commonModalStyle}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Delete comp code
              </Typography>
              <Typography fontWeight={500} variant="body1" gutterBottom>
                Are you sure you want to delete this item?
              </Typography>

              <Stack spacing={2} direction="row" sx={{ display: 'flex', justifyContent: 'flex-end' }} mt={2}>
                <Button variant="text" onClick={() => setShouldShowConfirmDeleteCompCodeModal(false)}>
                  CANCEL
                </Button>
                <LoadingButton
                  variant="contained"
                  loading={deleteCompCodeLoading}
                  loadingPosition="start"
                  color="error"
                  onClick={() => handleDeleteCompCode()}>
                  DELETE COMP CODE
                </LoadingButton>
              </Stack>
            </CardContent>
          </Card>
        </Box>
      </Modal>
    </>
  );
};

export default CompCodeListPage;
