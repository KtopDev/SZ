export default function Home() {
  return <div>Task Master</div>;
}
