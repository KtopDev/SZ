export default function Home() {
  return <div>Dispatcher</div>;
}
