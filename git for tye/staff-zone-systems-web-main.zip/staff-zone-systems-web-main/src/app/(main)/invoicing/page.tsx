export default function Home() {
  return <div>Invoicing</div>;
}
