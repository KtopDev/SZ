export default function Home() {
  return <div>Projects</div>;
}
