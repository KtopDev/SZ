export default function Home() {
  return <div>Ticket Editor</div>;
}
