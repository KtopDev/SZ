/* eslint-disable @next/next/no-page-custom-font */
'use client';

import { ReactNode } from 'react';
import theme from '@/theme/theme';
import { GlobalStyles, ThemeProvider } from '@mui/material';
import { AppRouterCacheProvider } from '@mui/material-nextjs/v13-appRouter';
import { SnackBarProvider } from '@/context/SnackbarContext';
import SnackBar from '@/components/Layout/components/SnackBar/SnackBar';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers';
import { SidebarProvider } from '@/context/SidebarContext';

interface RootLayoutProps {
  children: ReactNode;
}

const globalSvgRotation = {
  'svg[data-testid="MoreHorizIcon"]': {
    transform: 'rotate(90deg)',
  },
};

export default function RootLayout({ children }: RootLayoutProps) {
  return (
    <html lang="en">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body style={{ margin: 0, padding: 0, display: 'flex' }}>
        <GlobalStyles styles={globalSvgRotation} />
        <AppRouterCacheProvider>
          <ThemeProvider theme={theme}>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <SidebarProvider>
                <SnackBarProvider>
                  <SnackBar />
                  {children}
                </SnackBarProvider>
              </SidebarProvider>
            </LocalizationProvider>
          </ThemeProvider>
        </AppRouterCacheProvider>
      </body>
    </html>
  );
}
