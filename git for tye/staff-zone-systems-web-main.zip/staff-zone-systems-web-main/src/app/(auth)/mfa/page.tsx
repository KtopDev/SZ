'use client';
import React from 'react';
import { Grid } from '@mui/material';
import MFARegistration from './components/MFARegistration';
import VerificationCodeForm from '@/components/shared/pages/Authentication/VerificationCodeForm';
import UserClosure from '@/utils/UserClosure';

export default function MFAPage() {
  const mfaTokenDto = UserClosure.getMfaTokenDto();
  return (
    <Grid item xs={6} lg={6} md={6} sm={12} sx={{ width: '100%', height: '90%' }}>
      {UserClosure.getMfaPreference() === 'AUTH_APP' && !mfaTokenDto?.registered ? (
        <MFARegistration />
      ) : (
        <VerificationCodeForm />
      )}
    </Grid>
  );
}
