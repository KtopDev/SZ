'use client';
import React, { useState } from 'react';
import { Typography, Box, Button } from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import Image from 'next/image';
import AppLinks from './AppLinks';
import { SubmitHandler, useForm } from 'react-hook-form';
import { useRouter } from 'next/navigation';
import { useVerifyMfaOtpCode } from '@/requests/api/authApi/authApi';
import UserClosure from '@/utils/UserClosure';
import { LoginMFAVerifyDto } from '@/types/dto/LoginDto';
import AuthenticationMethodModal from '@/components/shared/pages/Authentication/AuthenticationMethodModal';
import RHMaskedInput from '@/components/shared/Form/RHMaskedInput';

export default function MFARegistration() {
  const [showModal, setShowModal] = useState(false);
  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(false);
  const [verifyMfaOtpCode, { loading }] = useVerifyMfaOtpCode();
  const router = useRouter();
  const {
    control,
    setError,
    getValues,
    formState: { errors },
    handleSubmit,
  } = useForm<LoginMFAVerifyDto>({
    defaultValues: { code: '' },
    mode: 'onChange',
  });

  const onSubmit: SubmitHandler<LoginMFAVerifyDto> = async (data) => {
    const username = UserClosure.getUsername() ?? '';
    const response = await verifyMfaOtpCode({
      authProcessId: UserClosure.getAuthProcessId() ?? '',
      username,
      code: data.code,
      userType: 'EMPLOYEE',
    });
    if (response && response.data) {
      router.push('dispatcher');
    } else {
      setError('code', { type: 'manual', message: 'Wrong verification code' });
    }
  };

  return (
    <>
      <Box sx={styles.container}>
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            width: '90%',
          }}>
          <Typography variant="subtitle1" gutterBottom textAlign="left" fontWeight="bold">
            Setup authenticator app
          </Typography>

          <Typography variant="subtitle1" gutterBottom textAlign="left">
            Your account is not linked to any authenticator app. Please follow the instructions bellow to link your
            account to your authenticator app.
          </Typography>

          <Typography variant="body1">
            <ol>
              <li>
                If you don’t have one already, download and install an authenticator app. <br />
                Below are our recommended authenticators:
              </li>
            </ol>
          </Typography>

          <AppLinks />

          <Typography variant="body1">
            <ol>
              <li value="2">Use your authenticator app to scan this QR code</li>
            </ol>
          </Typography>

          <Image src={UserClosure.getMfaTokenDto()?.qrCode || '/#'} alt="QR Code" width={200} height={200} />

          <Typography variant="body1">
            If you can’t scan this QR code, input the code below in your authenticator app setup setting
          </Typography>
          <Typography
            variant="body1"
            sx={{
              my: 1,
              fontWeight: 'bold',
              width: 500,
            }}>
            <span
              style={{
                fontWeight: 'bold',
                backgroundColor: '#DED7E5',
                borderRadius: 1,
                padding: 5,
                wordWrap: 'break-word',
              }}>
              {UserClosure.getMfaTokenDto()?.mfaCode}
            </span>
          </Typography>
          <Typography variant="body1">
            3. Test if everything works. Insert the code you see in your app for Staff Zone System here:
          </Typography>

          <RHMaskedInput<LoginMFAVerifyDto>
            label="6-digit verification code"
            propName="code"
            mask="999999"
            rhProps={{
              errors,
              control,
              required: true,
              minLength: 6,
              maxLength: 6,
            }}
          />

          <Typography variant="body1" sx={{ mb: 2 }}>
            4. If the verification fails, restart from the beginning.
          </Typography>

          <LoadingButton
            fullWidth
            color="primary"
            loading={loading}
            loadingPosition="start"
            variant="contained"
            sx={{ marginBottom: 3 }}
            onClick={handleSubmit(onSubmit)}
            disabled={!!errors.code || !getValues('code')}>
            VALIDATE
          </LoadingButton>

          <Button
            variant="outlined"
            color="primary"
            fullWidth
            sx={{ marginBottom: 1 }}
            onClick={() => {
              openModal();
            }}>
            CHANGE AUTHENTICATION METHOD
          </Button>

          <div
            style={{
              display: 'flex',
              justifyContent: 'flex-end',
            }}>
            <Button
              fullWidth
              variant="text"
              color="primary"
              onClick={() => {
                router.push('/login');
              }}>
              CLOSE
            </Button>
          </div>
        </div>
      </Box>

      <AuthenticationMethodModal showModal={showModal} closeModal={closeModal} />
    </>
  );
}

const styles = {
  container: {
    display: 'flex',
    height: '98vh',
    alignItems: 'center',
    justifyContent: 'flex-start',
    width: '100%',
    flexDirection: 'column',
  },
  leftBoxStyle: {
    width: '100%',
    display: 'flex',
    justifyContent: 'flex-start',
    flexDirection: 'column',
    alignItems: 'center',
    borderRadius: 2,
    padding: 4,
  },
};
