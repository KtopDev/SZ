'use client';
import { ReactNode } from 'react';
import { Box } from '@mui/material';
import Grid from '@mui/material/Unstable_Grid2';
import { styled } from '@mui/material/styles';
import styles from '@/../public/css/login/login.module.css';

interface AuthLayoutProps {
  children: ReactNode;
}

function RightImage() {
  return (
    <Box sx={imageStyles.container}>
      <div style={imageStyles.imagesContainer}></div>
    </Box>
  );
}

export default function AuthLayout({ children }: AuthLayoutProps) {
  const MainContainer = styled('main')(({ theme }) => ({
    flexGrow: 1,
    display: 'flex',
    flexDirection: 'column',
    backgroundColor: theme.palette.background.default,
  }));

  return (
    <MainContainer>
      <Grid container className={styles.loginPageContent}>
        <Grid container xs={12} lg={6} md={6} sm={12} alignItems="center" justifyContent="center">
          {children}
        </Grid>
        <Grid xs={-1} sm={-1} md={6} lg={6}>
          <RightImage />
        </Grid>
      </Grid>
    </MainContainer>
  );
}

const imageStyles = {
  container: {
    height: '96vh',
    paddingTop: '20px',
    justifyContent: 'center',
    flexDirection: 'column',
    alignItems: 'center',
    display: 'flex',
  },
  imagesContainer: {
    display: 'flex',
    justifyContent: 'center',
    width: '98%',
    height: '98%',
    borderRadius: 10,
    backgroundImage: 'url("/images/login/workers-banner.png")',
    backgroundSize: 'contain',
    backgroundRepeat: 'no-repeat',
    backgroundPosition: 'center',
  },
};
