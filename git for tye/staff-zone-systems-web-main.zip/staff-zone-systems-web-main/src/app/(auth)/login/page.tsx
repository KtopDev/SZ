/* eslint-disable @next/next/no-img-element */
'use client';
import React, { useState } from 'react';
import { Box, Button, Typography } from '@mui/material';
import { SubmitHandler, useForm } from 'react-hook-form';
import RHTextField from '@/components/shared/Form/RHTextField';
import { useLogin } from '@/requests/api/authApi/authApi';
import { useRouter } from 'next/navigation';
import LoadingButton from '@mui/lab/LoadingButton';
import UserClosure from '@/utils/UserClosure';
import { RHPasswordInput } from '@/components/shared/Form/RHPasswordInput';
import { Login } from '@/types/forms/LoginFormTypes';

export default function LoginPage() {
  const {
    control,
    formState: { errors },
    handleSubmit,
    setError,
  } = useForm<Login>({
    mode: 'onBlur',
  });
  const router = useRouter();
  const [login, { loading }] = useLogin();
  const [shouldShowIncorrectCredentialsError, setShouldShowIncorrectCredentialsError] = useState(false);

  const onSubmit: SubmitHandler<Login> = async (data) => {
    try {
      const response = await login(data);
      if (response.data.token) {
        UserClosure.handleLogin(response.data.token);
        router.push('/dispatcher');
      } else if (response.data.status === 'MFA') {
        UserClosure.setAuthProcessId(response.data.authProcessId);
        UserClosure.setMfaPreference(response.data.mfaPreference);
        if (response.data.mfaTokenDto) {
          UserClosure.setMfaTokenDto(response.data.mfaTokenDto);
          UserClosure.setUsername(data.username);
        }
        router.push('/mfa');
      }
    } catch (e: any) {
      if (e.response.status === 400) {
        setShouldShowIncorrectCredentialsError(true);
        setError('username', {});
        setError('password', {});
      }
    }
  };

  return (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        flexDirection: 'column',
        padding: 5,
      }}>
      <img src="/images/login/logo-with-title.png" alt="Picture of the author" />

      <Typography variant="h4" component="h4" gutterBottom pt={4}>
        Welcome back!
      </Typography>
      <Typography variant="caption" gutterBottom sx={{ alignSelf: 'flex-start' }}>
        Please enter your login information to access the application
      </Typography>

      {shouldShowIncorrectCredentialsError && (
        <Typography py={2} color="error" variant="caption" gutterBottom sx={{ alignSelf: 'flex-start' }}>
          Email address and/or Password incorrect
        </Typography>
      )}

      <RHTextField<Login>
        label="Email address"
        propName="username"
        type="text"
        rhProps={{
          errors,
          control,
          isEmail: true,
          minLength: 3,
        }}
      />

      <RHPasswordInput<Login>
        label="Password"
        propName="password"
        shouldValidatePassword={false}
        rhProps={{
          errors,
          control,
        }}
      />
      <Button
        onClick={() => router.push('/reset-password')}
        variant="text"
        color="primary"
        sx={{ alignSelf: 'flex-end', marginBottom: 1, marginY: '20px' }}>
        I FORGOT MY PASSWORD
      </Button>
      <LoadingButton
        loading={loading}
        variant="contained"
        color="primary"
        fullWidth
        sx={{ marginBottom: 1 }}
        onClick={handleSubmit(onSubmit)}>
        LOG IN
      </LoadingButton>
    </Box>
  );
}
