'use client';
import Image from 'next/image';
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Unstable_Grid2';
import { Box, Button, CircularProgress, Typography } from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import React, { useEffect, useState } from 'react';
import { useForm, useWatch } from 'react-hook-form';
import { NewPassword } from '@/app/(auth)/reset-password/setup-password/type';
import { useRouter } from 'next/navigation';
import { useSaveNewPassword, useVerifyTokenToResetPassword } from '@/requests/api/usersApi/usersApi';
import Backdrop from '@mui/material/Backdrop';
import { RHPasswordInput } from '@/components/shared/Form/RHPasswordInput';
import { RHConfirmPasswordInput } from '@/components/shared/Form/RHConfirmPassword';

const MainContainer = styled('main')(({ theme }) => ({
  flexGrow: 1,
  display: 'flex',
  height: '100vh',
  flexDirection: 'column',
  justifyContent: 'center',
  alignItems: 'center',
  backgroundColor: theme.palette.background.default,
}));

const ResetPasswordPage = ({ searchParams }: any) => {
  const {
    control,
    formState: { errors, isValid },
    handleSubmit,
  } = useForm<NewPassword>({
    mode: 'onBlur',
  });
  const router = useRouter();
  const password = useWatch({ control, name: 'password' });
  const [verifyToken, { loading: verifyTokenLoading }] = useVerifyTokenToResetPassword();
  const [updatePassword, { loading: updatePasswordLoading }] = useSaveNewPassword();
  const [userData, setUserData] = useState<any>();

  useEffect(() => {
    const verify = async () => {
      try {
        const { data } = await verifyToken(searchParams.token);
        setUserData({ id: data.id, email: data.email });
      } catch (e) {
        router.push('/reset-password');
      }
    };

    if (searchParams.token) {
      verify();
    }
  }, [router, searchParams.token, verifyToken]);

  const onSubmit = async (formValues: any) => {
    try {
      await updatePassword({
        token: searchParams.token,
        id: userData?.id,
        email: userData?.email,
        ...formValues,
      });
      router.push('/reset-password/password-set');
    } catch (e) {
      // handle error
    }
  };

  return (
    <MainContainer>
      <Backdrop sx={{ color: '#fff' }} open={verifyTokenLoading || updatePasswordLoading}>
        <CircularProgress color="inherit" />
      </Backdrop>
      <Grid container xs={12} lg={4} md={4} sm={12} alignItems="center" justifyContent="center">
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            flexDirection: 'column',
            padding: 5,
          }}>
          <Image src="/images/login/logo-with-title.png" alt="Picture of the author" width={360} height={80} />
          <Typography variant="h5" component="h5" gutterBottom pt={4}>
            Setup your new password
          </Typography>
          <Typography fontSize={14} py={2} variant="caption" textAlign="center">
            Please enter your new password
          </Typography>

          <RHPasswordInput<NewPassword>
            label="Password"
            propName="password"
            rhProps={{
              errors,
              control,
            }}
          />

          <div style={{ paddingLeft: 4, marginRight: 'auto' }}>
            <Typography fontSize={12}>Your password must follow these rules:</Typography>

            <ul style={{ marginTop: 2, paddingLeft: 25 }}>
              <li>
                <Typography fontSize={12}>Contain at least 8 characters</Typography>
              </li>
              <li>
                <Typography fontSize={12}>Contain at least 1 upper case letter</Typography>
              </li>
              <li>
                <Typography fontSize={12}>Contain at least 1 lower case letter</Typography>
              </li>
              <li>
                <Typography fontSize={12}>Contain at least 1 number</Typography>
              </li>
            </ul>
          </div>

          <RHConfirmPasswordInput<NewPassword>
            label="Password"
            propName="confirmPassword"
            originalPassword={password}
            rhProps={{
              errors,
              control,
            }}
          />

          <LoadingButton
            loading={updatePasswordLoading}
            variant="contained"
            disabled={!isValid}
            color="primary"
            fullWidth
            sx={{ marginBottom: 1 }}
            onClick={handleSubmit(onSubmit)}>
            CONTINUE
          </LoadingButton>
          <Button onClick={() => router.push('/login')} variant="text">
            RETURN TO LOG IN
          </Button>
        </Box>
      </Grid>
    </MainContainer>
  );
};

export default ResetPasswordPage;
