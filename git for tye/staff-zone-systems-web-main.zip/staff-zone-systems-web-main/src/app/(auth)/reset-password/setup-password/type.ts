export type NewPassword = {
  password: string;
  confirmPassword: string;
};
