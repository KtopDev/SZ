export type ResetPassword = {
  email: string;
};
