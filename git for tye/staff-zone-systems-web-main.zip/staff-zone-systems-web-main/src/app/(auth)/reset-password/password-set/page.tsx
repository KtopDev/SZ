'use client';
import Image from 'next/image';
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Unstable_Grid2';
import { Box, Button, Typography } from '@mui/material';
import React from 'react';
import { useRouter } from 'next/navigation';

const MainContainer = styled('main')(({ theme }) => ({
  flexGrow: 1,
  height: '100vh',
  display: 'flex',
  alignItems: 'center',
  flexDirection: 'column',
  justifyContent: 'center',
  backgroundColor: theme.palette.background.default,
}));

const PasswordSet = () => {
  const router = useRouter();

  return (
    <MainContainer>
      <Grid container xs={12} lg={6} md={6} sm={12} alignItems="center" justifyContent="center">
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            flexDirection: 'column',
            padding: 5,
          }}>
          <Image src="/images/common/success.png" alt="Picture of the author" width={136} height={136} />
          <Typography variant="h6" component="h6" gutterBottom>
            Password changed successfully
          </Typography>
          <Typography fontSize={14} py={2} variant="caption" textAlign="center">
            Your password has been updated, you can now access your account
          </Typography>

          <Button onClick={() => router.push('/login')} fullWidth variant="contained">
            GO TO THE LOGIN PAGE
          </Button>
        </Box>
      </Grid>
    </MainContainer>
  );
};

export default PasswordSet;
