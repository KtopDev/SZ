'use client';
import Image from 'next/image';
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Unstable_Grid2';
import { Box, Button, CircularProgress, Typography } from '@mui/material';
import RHTextField from '@/components/shared/Form/RHTextField';
import LoadingButton from '@mui/lab/LoadingButton';
import React from 'react';
import { useForm } from 'react-hook-form';
import { ResetPassword } from '@/app/(auth)/reset-password/types';
import { useRequestResetPassword } from '@/requests/api/usersApi/usersApi';
import Backdrop from '@mui/material/Backdrop';
import { useRouter } from 'next/navigation';

const MainContainer = styled('main')(({ theme }) => ({
  flexGrow: 1,
  display: 'flex',
  height: '100vh',
  flexDirection: 'column',
  justifyContent: 'center',
  alignItems: 'center',
  backgroundColor: theme.palette.background.default,
}));

const ResetPasswordPage = () => {
  const {
    control,
    formState: { errors },
    handleSubmit,
  } = useForm<ResetPassword>({
    mode: 'onBlur',
  });
  const router = useRouter();
  const [requestResetPassword, { loading }] = useRequestResetPassword();

  const onSubmit = async (formvalues: any) => {
    try {
      await requestResetPassword(formvalues);
      router.push(`/reset-password/email-sent?email=${formvalues.email}`);
    } catch (e) {
      // handle error
    }
  };

  return (
    <MainContainer>
      <Backdrop sx={{ color: '#fff' }} open={loading}>
        <CircularProgress color="inherit" />
      </Backdrop>
      <Grid container xs={12} lg={4} md={4} sm={12} alignItems="center" justifyContent="center">
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            flexDirection: 'column',
            padding: 5,
          }}>
          <Image src="/images/login/logo-with-title.png" alt="Picture of the author" width={360} height={80} />
          <Typography variant="h5" component="h5" gutterBottom pt={4}>
            Reset your password
          </Typography>
          <Typography fontSize={14} py={2} variant="caption" textAlign="center">
            Enter your email address and we’ll send you a link to
            <br /> reset your password
          </Typography>

          <RHTextField<ResetPassword>
            label="Email address"
            propName="email"
            type="text"
            rhProps={{
              errors,
              control,
              isEmail: true,
              minLength: 3,
              errorMessage: 'Please check the email format. Example: mail@example.com',
            }}
          />

          <LoadingButton
            loading={false}
            variant="contained"
            color="primary"
            fullWidth
            sx={{ marginBottom: 1, marginTop: 2 }}
            onClick={handleSubmit(onSubmit)}>
            CONTINUE
          </LoadingButton>
          <Button onClick={() => router.push('/login')} variant="text">
            RETURN TO LOG IN
          </Button>
        </Box>
      </Grid>
    </MainContainer>
  );
};

export default ResetPasswordPage;
