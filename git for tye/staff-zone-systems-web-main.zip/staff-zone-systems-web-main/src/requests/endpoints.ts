export const CHECK_FORMATS = 'check-formats/dropdown';
export const COMP_CODES = 'comp-codes/dropdown';
export const DEPOSIT_ADVICE_FORMAT = 'deposit-advice-format/dropdown';
export const FUTA_SUTA = 'futa-suta-sdi/dropdown';
export const PAY_CHECK_FORMAT = 'pay-check-formats/dropdown';
export const PAY_CYCLE = 'pay-cycles/dropdown';
export const TAXES = 'taxes/dropdown';
export const BRANCH_LIST = '/api/v1/branches';
export const STATES = 'states/dropdown';
export const PAY_RULES = 'pay-rules/dropdown';

export const CREATE_BRANCH = 'branches';
export const GET_BRANCH = (branchId: string) => `branches/${branchId}`;
export const PUT_BRANCH = (branchId: string) => `branches/${branchId}`;
export const ACTIVATE_BRANCH = (branchId: string) => `branches/${branchId}/activate`;
export const DEACTIVATE_BRANCH = (branchId: string) => `branches/${branchId}/deactivate`;

export const TAXES_LIST = '/api/v1/settings/taxes';
export const PPE_LIST = '/api/v1/settings/ppe';
