export interface GetTaxesListPayload {
  size: number;
  page: number;
  sort: string;
  // state: string;
  status: string;
  startDate: string;
  endDate: string;
}
