import { createApi } from '@/utils/createApi/createApi';
import { HttpMethod, PaginatedListResponse } from '@/utils/createApi/types';
import { TAXES_LIST } from '@/requests/endpoints';
import { buildUrl } from '@/utils/buildUrl/buildUrl';
import { GetTaxesListPayload } from './types';
import { FutaSutaRequest } from '@/types/forms/FutaSuta';

const queryApis = {
  getTaxesList: {
    query: (payload: GetTaxesListPayload) => ({
      url: buildUrl(TAXES_LIST, payload),
    }),
    errorMessage: 'Failed to fetch branch list',
  },
};

const mutationApis = {
  createFutaSuta: {
    query: (data: any) => ({
      url: '/api/v1/settings/taxes',
      data,
      method: HttpMethod.POST,
    }),
    errorMessage: 'Failed to create tax',
  },
  updateFutaSuta: {
    query: (data: UpdateFutaSutaRequest) => ({
      url: `/api/v1/settings/taxes/${data.id}`,
      data: data.payload,
      method: HttpMethod.PUT,
    }),
    errorMessage: 'Failed to update tax',
  },
  deleteFutaSuta: {
    query: (id: string) => ({
      url: `/api/v1/settings/taxes/${id}`,
      method: HttpMethod.DELETE,
    }),
    errorMessage: 'Failed to delete FUTA SUTA tax',
  },
};

const api = createApi({ queryApis, mutationApis });
export const { useGetTaxesList, useCreateFutaSuta, useUpdateFutaSuta, useDeleteFutaSuta } = api as {
  useGetTaxesList: (payload: GetTaxesListPayload) => {
    data: PaginatedListResponse<any>;
    loading: boolean;
    refetch: () => void;
  };
  useCreateFutaSuta: () => [createFutaSuta: (data: FutaSutaRequest) => any, props: any];
  useUpdateFutaSuta: () => [updateFutaSuta: (data: UpdateFutaSutaRequest) => any, props: any];
  useDeleteFutaSuta: () => [deleteFutaSuta: (id: string) => any, props: any];
};

export type UpdateFutaSutaRequest = { id: string; payload: FutaSutaRequest };
