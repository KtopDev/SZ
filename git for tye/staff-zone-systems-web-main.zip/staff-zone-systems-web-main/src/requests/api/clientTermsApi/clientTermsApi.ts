import { ClientAppTerm, ClientTermResponse } from '@/types/dto/ClientAppTerm';
import { UpdateClientTermsOrderDto } from '@/types/dto/TermsDto';
import { createApi } from '@/utils/createApi/createApi';
import { HttpMethod } from '@/utils/createApi/types';

const queryApis = {
  getClientTermsList: {
    query: () => ({
      url: '/api/v1/client-app-terms',
    }),
    errorMessage: 'Failed to fetch client app terms',
  },
  getClientTerm: {
    query: (termId: string) => ({
      url: `api/v1/client-app-terms/term/${termId}`,
    }),
    errorMessage: 'Failed to find the client term',
  },
};

const mutationApis = {
  createClientTerm: {
    query: (data: FormData) => ({
      url: '/api/v1/client-app-terms',
      data,
      method: HttpMethod.POST,
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    }),
    errorMessage: 'Failed to upload the file',
  },
  updateClientTerm: {
    query: ({ termId, data }: { termId: string; data: FormData }) => ({
      url: `/api/v1/client-app-terms/term/${termId}`,
      data,
      method: HttpMethod.POST,
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    }),
    errorMessage: 'Failed to upload the file',
  },
  deleteClientTerm: {
    query: (termId: string) => ({
      url: `/api/v1/client-app-terms/term/${termId}`,
      method: HttpMethod.DELETE,
    }),
    errorMessage: 'Failed to delete the file',
  },
  updateTermsOrder: {
    query: (data: UpdateClientTermsOrderDto) => ({
      url: '/api/v1/client-app-terms/update-order',
      data,
      method: HttpMethod.PUT,
    }),
    errorMessage: 'Failed to update the client terms order',
  },
  getClientTerm: {
    query: (termId: string) => ({
      url: `api/v1/client-app-terms/term/${termId}`,
      method: HttpMethod.GET,
    }),
    errorMessage: 'Failed to find the client term',
  },
};

const api = createApi({ queryApis, mutationApis });
export const {
  useGetClientTermsList,
  useGetClientTerm,
  useCreateClientTerm,
  useUpdateClientTerm,
  useDeleteClientTerm,
  useUpdateTermsOrder,
} = api as {
  useGetClientTermsList: () => { data: ClientTermResponse; loading: boolean; refetch: () => void };
  useCreateClientTerm: () => [createClientTerm: (data: FormData) => any, props: any];
  useUpdateTermsOrder: () => [updateTermsOrder: (data: UpdateClientTermsOrderDto) => any, props: any];
  useUpdateClientTerm: () => [
    updateClientTerm: ({ termId, data }: { termId: string; data: FormData }) => any,
    props: any,
  ];
  useDeleteClientTerm: () => [deleteClientTerm: (termId: string) => ClientAppTerm, props: any];
  useGetClientTerm: () => [getClientTerm: (termId: string) => ClientAppTerm, props: any];
};
