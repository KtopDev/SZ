import { createApi } from '@/utils/createApi/createApi';
import { Dropdown } from '@/types/Dropdown';

const queryApis = {
  getDropdownInvoiceMethod: {
    query: () => ({
      url: '/api/v1/invoice-methods/dropdown',
    }),
    errorMessage: 'Failed to fetch dropdown invoice method list',
  },
  getDropdownInvoiceFormat: {
    query: () => ({
      url: '/api/v1/invoice-formats/dropdown',
    }),
    errorMessage: 'Failed to fetch dropdown invoice method list',
  },
};

const api = createApi({ queryApis });
export const { useGetDropdownInvoiceMethod, useGetDropdownInvoiceFormat } = api as {
  useGetDropdownInvoiceMethod: () => { data: Dropdown; loading: boolean };
  useGetDropdownInvoiceFormat: () => { data: Dropdown; loading: boolean };
};
