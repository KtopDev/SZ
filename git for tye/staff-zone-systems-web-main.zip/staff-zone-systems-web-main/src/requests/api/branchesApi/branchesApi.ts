import { createApi } from '@/utils/createApi/createApi';
import { PaginatedListResponse } from '@/utils/createApi/types';
import { BRANCH_LIST } from '@/requests/endpoints';
import { Dropdown } from '@/types/Dropdown';
import { buildUrl } from '@/utils/buildUrl/buildUrl';
import { GetBranchListPayload } from '@/requests/api/branchesApi/types';
import { Branch } from '@/app/(main)/settings/branches/types';
import { BranchDTO } from '@/types/dto/Branch';

const queryApis = {
  getBranchList: {
    query: (payload: GetBranchListPayload) => ({
      url: buildUrl(BRANCH_LIST, payload),
    }),
    errorMessage: 'Failed to fetch branch list',
  },
  getBranchDetails: {
    query: (branchId: string) => ({
      url: `/api/v1/branches/${branchId}`,
    }),
    defaultValue: {},
    errorMessage: 'Failed to fetch branch details',
  },
  getDropdownBranchList: {
    query: () => ({
      url: '/api/v1/branches-dropdown',
    }),
    errorMessage: 'Failed to fetch dropdown branch list',
  },
};

const api = createApi({ queryApis });
export const { useGetBranchList, useGetBranchDetails, useGetDropdownBranchList } = api as {
  useGetBranchList: (payload: GetBranchListPayload) => { data: PaginatedListResponse<Branch>; loading: boolean };
  useGetBranchDetails: (branchId: string) => { data: BranchDTO; loading: boolean };
  useGetDropdownBranchList: () => { data: Dropdown; loading: boolean };
};
