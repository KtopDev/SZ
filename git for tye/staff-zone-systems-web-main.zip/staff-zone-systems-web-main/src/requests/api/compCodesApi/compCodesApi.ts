import { createApi } from '@/utils/createApi/createApi';
import { COMP_CODES } from '@/requests/endpoints';
import { Dropdown } from '@/types/Dropdown';
import { buildUrl } from '@/utils/buildUrl/buildUrl';
import { CompCodeFormType } from '@/app/(main)/settings/company-settings/other-settings/comp-codes/components/CompCodeForm/types';
import { HttpMethod, PaginatedListResponse } from '@/utils/createApi/types';

const queryApis = {
  getDropdownCompCodes: {
    query: (state: string) => ({
      url: buildUrl(`api/v1/${COMP_CODES}`, { state }),
    }),
    errorMessage: 'Failed to fetch branch list',
  },
  getCompCodeList: {
    query: (payload: any) => ({
      url: buildUrl('/api/v1/settings/comp-codes', payload),
    }),
    errorMessage: 'Failed to fetch comp code list',
  },
};

const mutationApis = {
  createCompCode: {
    query: (payload: CompCodeFormType) => ({
      url: '/api/v1/settings/comp-codes',
      data: payload,
    }),
    errorMessage: 'Failed to create comp code',
  },
  editCompCode: {
    query: (payload: CompCodeFormType) => ({
      url: `/api/v1/settings/comp-codes/${payload.id}`,
      data: payload,
      method: HttpMethod.PUT,
    }),
    errorMessage: 'Failed to update comp code',
  },
  deleteCompCode: {
    query: (id: string) => ({
      url: `/api/v1/settings/comp-codes/${id}`,
      method: HttpMethod.DELETE,
    }),
    errorMessage: 'Failed to delete comp code',
  },
};

const api = createApi({ queryApis, mutationApis });
export const { useGetDropdownCompCodes, useCreateCompCode, useGetCompCodeList, useEditCompCode, useDeleteCompCode } =
  api as {
    useGetDropdownCompCodes: (state?: string) => { data: Dropdown; loading: boolean };
    useGetCompCodeList: (payload: any) => { data: PaginatedListResponse<any>; loading: boolean; refetch: any };
    useCreateCompCode: () => [createCompCode: (data: CompCodeFormType) => any, props: any];
    useEditCompCode: () => [editCompCode: (data: CompCodeFormType) => any, props: any];
    useDeleteCompCode: () => [deleteCompCode: (id: string) => any, props: any];
  };
