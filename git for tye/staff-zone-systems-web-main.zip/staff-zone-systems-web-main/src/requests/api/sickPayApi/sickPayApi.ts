import { createApi } from '@/utils/createApi/createApi';
import { HttpMethod, PaginatedListResponse } from '@/utils/createApi/types';
import { buildUrl } from '@/utils/buildUrl/buildUrl';
import { SickPayDto } from '@/types/dto/SickPayDto';
import { SickPayRequest } from '@/types/forms/SickPay';

const queryApis = {
  getSickPayList: {
    query: (payload: GetSickPayListPayload) => ({
      url: buildUrl('/api/v1/settings/sick-pay', payload),
    }),
    errorMessage: 'Failed to fetch sick pay rules list',
  },
};

const mutationApis = {
  createSickPay: {
    query: (data: SickPayDto) => ({
      url: '/api/v1/settings/sick-pay',
      data,
      method: HttpMethod.POST,
    }),
    errorMessage: 'Failed to create sick pay rule',
  },
  updateSickPay: {
    query: (data: UpdateSickPayRequest) => ({
      url: `/api/v1/settings/sick-pay/${data.id}`,
      data: data.payload,
      method: HttpMethod.PUT,
    }),
    errorMessage: 'Failed to update sick pay rule',
  },
  deleteSickPay: {
    query: (id: string) => ({
      url: `/api/v1/settings/sick-pay/${id}`,
      method: HttpMethod.DELETE,
    }),
    errorMessage: 'Failed to delete sick pay rule',
  },
};

const api = createApi({ queryApis, mutationApis });
export const { useGetSickPayList, useCreateSickPay, useUpdateSickPay, useDeleteSickPay } = api as {
  useGetSickPayList: (payload: GetSickPayListPayload) => {
    data: PaginatedListResponse<SickPayDto>;
    loading: boolean;
    refetch: () => void;
  };
  useCreateSickPay: () => [createSickPay: (data: SickPayRequest) => any, props: any];
  useUpdateSickPay: () => [updateSickPay: (data: UpdateSickPayRequest) => any, props: any];
  useDeleteSickPay: () => [deleteSickPay: (id: string) => any, props: any];
};

export type UpdateSickPayRequest = { id: string; payload: SickPayRequest };

export interface GetSickPayListPayload {
  size: number;
  page: number;
  sort: string;
  // state: string;
  status: string;
  startDate: string;
  endDate: string;
}
