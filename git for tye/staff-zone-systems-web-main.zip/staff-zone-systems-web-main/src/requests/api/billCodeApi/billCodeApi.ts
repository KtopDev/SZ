import { createApi } from '@/utils/createApi/createApi';
import { HttpMethod } from '@/utils/createApi/types';
import { buildUrl } from '@/utils/buildUrl/buildUrl';

const queryApis = {
  getBillCodeList: {
    query: (payload: any) => ({
      url: buildUrl('/api/v1/settings/bill-codes', payload),
    }),
    errorMessage: 'Failed to fetch bill codes',
  },
};

const mutationApis = {
  createBillCode: {
    query: (data: any) => ({
      url: '/api/v1/settings/bill-codes',
      data,
      method: HttpMethod.POST,
    }),
    errorMessage: 'Failed to create bill codes',
  },
  updateBillCode: {
    query: (data: any) => ({
      url: `/api/v1/settings/bill-codes/${data.id}`,
      data,
      method: HttpMethod.PUT,
    }),
    errorMessage: 'Failed to update bill codes',
  },
  deleteBillCode: {
    query: (id: any) => ({
      url: `/api/v1/settings/bill-codes/${id}`,
      method: HttpMethod.DELETE,
    }),
    errorMessage: 'Failed to delete bill codes',
  },
};

const api = createApi({ queryApis, mutationApis });

export const { useGetBillCodeList, useCreateBillCode, useUpdateBillCode, useDeleteBillCode } = api as {
  useGetBillCodeList: (payload: any) => { data: any; loading: boolean; refetch: any };
  useCreateBillCode: () => [createBillCode: (data: any) => Promise<any>, props: any];
  useUpdateBillCode: () => [updateBillCode: (data: any) => Promise<any>, props: any];
  useDeleteBillCode: () => [deleteBillCode: (data: any) => Promise<any>, props: any];
};
