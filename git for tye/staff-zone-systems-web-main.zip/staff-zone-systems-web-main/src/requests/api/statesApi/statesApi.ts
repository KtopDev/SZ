import { createApi } from '@/utils/createApi/createApi';
import { Dropdown } from '@/types/Dropdown';

const queryApis = {
  getDropdownState: {
    query: () => ({
      url: '/api/v1/states/dropdown',
    }),
    errorMessage: 'Failed to fetch dropdown state',
  },
};

const api = createApi({ queryApis });
export const { useGetDropdownState } = api as {
  useGetDropdownState: () => { data: Dropdown; loading: boolean };
};
