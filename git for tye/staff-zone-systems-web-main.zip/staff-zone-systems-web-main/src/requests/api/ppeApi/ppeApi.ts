import { createApi } from '@/utils/createApi/createApi';
import { HttpMethod, PaginatedListResponse } from '@/utils/createApi/types';
import { buildUrl } from '@/utils/buildUrl/buildUrl';
import { PPERequest } from '@/types/forms/PPE';

const queryApis = {
  getPPEList: {
    query: (payload: GetPPEListPayload) => ({
      url: buildUrl('/api/v1/settings/ppe', payload),
    }),
  },
};

const mutationApis = {
  createPPE: {
    query: (data: PPERequest) => ({
      url: '/api/v1/settings/ppe',
      data,
      method: HttpMethod.POST,
    }),
    errorMessage: 'Failed to create PPE',
  },
  updatePPE: {
    query: (data: UpdatePPERequest) => ({
      url: `/api/v1/settings/ppe/${data.id}`,
      data: data.payload,
      method: HttpMethod.PUT,
    }),
    errorMessage: 'Failed to update PPE',
  },
  deletePPE: {
    query: (id: string) => ({
      url: `/api/v1/settings/ppe/${id}`,
      method: HttpMethod.DELETE,
    }),
    errorMessage: 'Failed to delete PPE',
  },
};

const api = createApi({ queryApis, mutationApis });
export const { useGetPPEList, useCreatePPE, useUpdatePPE, useDeletePPE } = api as {
  useGetPPEList: (payload: GetPPEListPayload) => {
    data: PaginatedListResponse<any>;
    loading: boolean;
    refetch: () => void;
  };
  useCreatePPE: () => [createPPE: (data: PPERequest) => any, props: any];
  useUpdatePPE: () => [updatePPE: (data: UpdatePPERequest) => any, props: any];
  useDeletePPE: () => [deletePPE: (id: string) => any, props: any];
};

export type UpdatePPERequest = { id: string; payload: PPERequest };

export interface GetPPEListPayload {
  size: number;
  page: number;
  sort: string;
  status: string;
  startDate: string;
  endDate: string;
}
