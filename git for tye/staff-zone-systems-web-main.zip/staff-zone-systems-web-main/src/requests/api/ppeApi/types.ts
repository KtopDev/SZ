export interface GetPPEListPayload {
  size: number;
  page: number;
  sort: string;
  startDate: string;
  endDate: string;
}
