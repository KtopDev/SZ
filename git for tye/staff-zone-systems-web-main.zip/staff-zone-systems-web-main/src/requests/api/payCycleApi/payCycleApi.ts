import { createApi } from '@/utils/createApi/createApi';
import { HttpMethod } from '@/utils/createApi/types';
import { buildUrl } from '@/utils/buildUrl/buildUrl';

const queryApis = {
  getPayCycleList: {
    query: (payload: any) => ({
      url: buildUrl('/api/v1/settings/pay-cycles', payload),
    }),
    errorMessage: 'Failed to fetch pay cycles',
  },
};

const mutationApis = {
  createPayCycle: {
    query: (data: any) => ({
      url: '/api/v1/settings/pay-cycles',
      data,
      method: HttpMethod.POST,
    }),
    errorMessage: 'Failed to create pay cycle',
  },
  updatePayCycle: {
    query: (data: any) => ({
      url: `/api/v1/settings/pay-cycles/${data.id}`,
      data,
      method: HttpMethod.PUT,
    }),
    errorMessage: 'Failed to update pay cycle',
  },
  deletePayCycle: {
    query: (id: any) => ({
      url: `/api/v1/settings/pay-cycles/${id}`,
      method: HttpMethod.DELETE,
    }),
    errorMessage: 'Failed to delete pay cycle',
  },
};

const api = createApi({ queryApis, mutationApis });

export const { useGetPayCycleList, useCreatePayCycle, useUpdatePayCycle, useDeletePayCycle } = api as {
  useGetPayCycleList: (payload: any) => { data: any; loading: boolean; refetch: any };
  useCreatePayCycle: () => [createPayCycle: (data: any) => Promise<any>, props: any];
  useUpdatePayCycle: () => [updatePayCycle: (data: any) => Promise<any>, props: any];
  useDeletePayCycle: () => [deletePayCycle: (data: any) => Promise<any>, props: any];
};
