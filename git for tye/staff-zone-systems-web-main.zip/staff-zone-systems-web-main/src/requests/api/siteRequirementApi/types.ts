export interface GetSiteRequirementListPayload {
  size: number;
  page: number;
  sort: string;
  startDate: string;
  endDate: string;
}
