import { createApi } from '@/utils/createApi/createApi';
import { HttpMethod, PaginatedListResponse } from '@/utils/createApi/types';
import { TAXES_LIST } from '@/requests/endpoints';
import { buildUrl } from '@/utils/buildUrl/buildUrl';
import { SiteRequirementRequest } from '@/types/forms/SiteRequirement';

const queryApis = {
  getSiteRequirementList: {
    query: (payload: GetSiteRequirementListPayload) => ({
      url: buildUrl(TAXES_LIST, payload),
    }),
  },
};

const mutationApis = {
  createSiteRequirement: {
    query: (data: SiteRequirementRequest) => ({
      url: '/api/v1/settings/site-requirement',
      data,
      method: HttpMethod.POST,
    }),
    errorMessage: 'Failed to create sick pay rule',
  },
  updateSiteRequirement: {
    query: (data: UpdateSiteRequirementRequest) => ({
      url: `/api/v1/settings/site-requirement/${data.id}`,
      data: data.payload,
      method: HttpMethod.PUT,
    }),
    errorMessage: 'Failed to update sick pay rule',
  },
  deleteSiteRequirement: {
    query: (id: string) => ({
      url: `/api/v1/settings/site-requirement/${id}`,
      method: HttpMethod.DELETE,
    }),
    errorMessage: 'Failed to delete sick pay rule',
  },
};

const api = createApi({ queryApis, mutationApis });
export const {
  useGetSiteRequirementList,
  useCreateSiteRequirement,
  useUpdateSiteRequirement,
  useDeleteSiteRequirement,
} = api as {
  useGetSiteRequirementList: (payload: GetSiteRequirementListPayload) => {
    data: PaginatedListResponse<any>;
    loading: boolean;
    refetch: () => void;
  };
  useCreateSiteRequirement: () => [createSiteRequirement: (data: SiteRequirementRequest) => any, props: any];
  useUpdateSiteRequirement: () => [updateSiteRequirement: (data: UpdateSiteRequirementRequest) => any, props: any];
  useDeleteSiteRequirement: () => [deleteSiteRequirement: (id: string) => any, props: any];
};

export type UpdateSiteRequirementRequest = { id: string; payload: SiteRequirementRequest };

export interface GetSiteRequirementListPayload {
  size: number;
  page: number;
  sort: string;
  status: string;
  startDate: string;
  endDate: string;
}
