import { WorkerAppTerm, WorkerTermResponse } from '@/types/dto/WorkerAppTerm';
import { UpdateWorkerTermsOrderDto } from '@/types/dto/TermsDto';
import { createApi } from '@/utils/createApi/createApi';
import { HttpMethod } from '@/utils/createApi/types';

const queryApis = {
  getWorkerTermsList: {
    query: () => ({
      url: '/api/v1/worker-app-terms',
    }),
    errorMessage: 'Failed to fetch worker app terms',
  },
};

const mutationApis = {
  createWorkerTerm: {
    query: (data: any) => ({
      url: '/api/v1/worker-app-terms',
      data,
      method: HttpMethod.POST,
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    }),
    errorMessage: 'Failed to upload the file(s)',
  },
  updateWorkerTerm: {
    query: ({ termId, data }: { termId: string; data: FormData }) => ({
      url: `/api/v1/worker-app-terms/${termId}/update`,
      data,
      method: HttpMethod.POST,
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    }),
    errorMessage: 'Failed to update the file',
  },
  deleteWorkerTerm: {
    query: (termId: string) => ({
      url: `/api/v1/worker-app-terms/${termId}/delete`,
      method: HttpMethod.DELETE,
    }),
    errorMessage: 'Failed to delete the file',
  },
  updateTermsOrder: {
    query: (data: UpdateWorkerTermsOrderDto) => ({
      url: '/api/v1/worker-app-terms/update-order',
      data,
      method: HttpMethod.PUT,
    }),
    errorMessage: 'Failed to update the worker terms order',
  },
};

const api = createApi({ queryApis, mutationApis });
export const {
  useGetWorkerTermsList,
  useCreateWorkerTerm,
  useUpdateWorkerTerm,
  useDeleteWorkerTerm,
  useUpdateTermsOrder,
} = api as {
  useGetWorkerTermsList: () => { data: WorkerTermResponse; loading: boolean; refetch: () => void };
  useCreateWorkerTerm: () => [createWorkerTerm: (data: FormData) => any, props: any];
  useUpdateWorkerTerm: () => [
    updateWorkerTerm: ({ termId, data }: { termId: string; data: FormData }) => any,
    props: any,
  ];
  useDeleteWorkerTerm: () => [deleteWorkerTerm: (termId: string) => WorkerAppTerm, props: any];
  useUpdateTermsOrder: () => [updateTermsOrder: (data: UpdateWorkerTermsOrderDto) => any, props: any];
};
