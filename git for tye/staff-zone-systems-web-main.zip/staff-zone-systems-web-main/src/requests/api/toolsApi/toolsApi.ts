import { createApi } from '@/utils/createApi/createApi';
import { HttpMethod, PaginatedListResponse } from '@/utils/createApi/types';
import { buildUrl } from '@/utils/buildUrl/buildUrl';
import { ToolRequest } from '@/types/forms/Tools';

const queryApis = {
  getToolsList: {
    query: (payload: GetToolListPayload) => ({
      url: buildUrl('/api/v1/settings/tools', payload),
    }),
  },
};

const mutationApis = {
  createTool: {
    query: (data: ToolRequest) => ({
      url: '/api/v1/settings/tools',
      data,
      method: HttpMethod.POST,
    }),
    errorMessage: 'Failed to create tool',
  },
  updateTool: {
    query: (data: UpdateToolRequest) => ({
      url: `/api/v1/settings/tools/${data.id}`,
      data: data.payload,
      method: HttpMethod.PUT,
    }),
    errorMessage: 'Failed to update PPE',
  },
  deleteTool: {
    query: (id: string) => ({
      url: `/api/v1/settings/tools/${id}`,
      method: HttpMethod.DELETE,
    }),
    errorMessage: 'Failed to delete PPE',
  },
};

const api = createApi({ queryApis, mutationApis });
export const { useGetToolsList, useCreateTool, useUpdateTool, useDeleteTool } = api as {
  useGetToolsList: (payload: GetToolListPayload) => {
    data: PaginatedListResponse<any>;
    loading: boolean;
    refetch: () => void;
  };
  useCreateTool: () => [createTool: (data: ToolRequest) => any, props: any];
  useUpdateTool: () => [updateTool: (data: UpdateToolRequest) => any, props: any];
  useDeleteTool: () => [deleteTool: (id: string) => any, props: any];
};

export type UpdateToolRequest = { id: string; payload: ToolRequest };

export interface GetToolListPayload {
  size: number;
  page: number;
  sort: string;
  status: string;
  startDate: string;
  endDate: string;
}
