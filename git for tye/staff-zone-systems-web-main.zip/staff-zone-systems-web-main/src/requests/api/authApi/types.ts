export interface ILoginPayload {
  username: string;
  password: string;
  userType: string;
}

export interface LogoutPayload {
  clientId: string;
  userType: UserType;
}

export type LoginResponse = {
  authProcessId: string;
  expiresIn: number;
  mfaPreference: MfaPreference;
  status: string;
  token: string;
  mfaTokenDto: MfaTokenDto;
};

export type MfaTokenDto = {
  qrCode?: string;
  mfaCode?: string;
  registered: boolean;
};

export type VerificationCodeDto = {
  verificationCode: string;
};

export type MfaPreference = 'SMS' | 'EMAIL' | 'AUTH_APP' | 'NONE';

export type VerifyMfaOTPRequest = { authProcessId: string; username: string; code: string; userType: UserType };

type UserType = 'EMPLOYEE' | 'CLIENT' | 'WORKER';
