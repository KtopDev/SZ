import { createApi } from '@/utils/createApi/createApi';
import { ILoginPayload, LoginResponse, LogoutPayload, VerifyMfaOTPRequest } from '@/requests/api/authApi/types';
import { MeDto } from '@/types/dto/MeDto';
import { HttpMethod } from '@/utils/createApi/types';

const queryApis = {
  getClientLegalTerms: {
    query: ({ clientId }: { clientId: string }) => ({
      url: `/api/v1/clients/${clientId}/legal-terms`,
    }),
    errorMessage: 'Failed to fetch client legal terms',
  },
  getMe: {
    query: () => ({
      url: '/api/v1/users/me',
    }),
    errorMessage: 'Failed to fetch authenticated user',
  },
};

const mutationApis = {
  login: {
    query: (data: ILoginPayload) => ({
      url: '/api/v1/login',
      data: { ...data, userType: 'EMPLOYEE' },
      errorMessage: 'Error on login',
    }),
  },
  sendMfaPhoneCode: {
    query: (payload: { phone: string }) => ({
      url: '/api/v1/login/phone/send-code',
      data: payload,
      errorMessage: 'Error on send code',
    }),
  },
  verifyMfaPhoneCode: {
    query: (payload: { authProcessId: string; code: string }) => ({
      url: '/api/v1/login/mfa/verify-code',
      data: { ...payload, userType: 'EMPLOYEE' },
      errorMessage: 'Error on verify code',
    }),
  },
  verifyMfaOtpCode: {
    query: (payload: VerifyMfaOTPRequest) => ({
      url: '/api/v1/login/mfa/verify-otp',
      data: { ...payload, userType: 'EMPLOYEE' },
      errorMessage: 'Error on verify code',
    }),
  },
  logout: {
    query: (data: LogoutPayload) => ({
      url: '/api/v1/logout',
      data,
      errorMessage: 'Error on logout',
    }),
  },
  postPoneResetPassword: {
    query: ({ daysToExtend }: any) => ({
      url: '/api/v1/users/password/postpone-expire',
      method: HttpMethod.POST,
      data: { daysToExtend },
    }),
    errorMessage: 'Failed to pone reset password',
  },
};

const api = createApi({ mutationApis, queryApis });

export const {
  useLogin,
  useLogout,
  useGetMe,
  useSendMfaPhoneCode,
  useVerifyMfaPhoneCode,
  useVerifyMfaOtpCode,
  usePostPoneResetPassword,
} = api as {
  useLogin: () => [(data: ILoginPayload) => Promise<{ data: LoginResponse }>, { loading: boolean }];
  useLogout: () => [(data: LogoutPayload) => Promise<any>, { loading: boolean }];
  useGetMe: () => { data: MeDto; loading: boolean };
  useGetClientLegalTerms: (clientId: string) => { data: any; loading: boolean };
  useSendMfaPhoneCode: () => [(payload: { phone: string }) => Promise<any>, { loading: false }];
  useVerifyMfaOtpCode: () => [(payload: VerifyMfaOTPRequest) => Promise<any>, { loading: boolean }];
  useVerifyMfaPhoneCode: () => [(payload: { authProcessId: string; code: string }) => Promise<any>, { loading: false }];
  usePostPoneResetPassword: () => [(data?: any) => Promise<void>, { loading: boolean }];
};
