import { createApi } from '@/utils/createApi/createApi';
import { HttpMethod } from '@/utils/createApi/types';
import { buildUrl } from '@/utils/buildUrl/buildUrl';

const queryApis = {
  getPayCodeList: {
    query: (payload: any) => ({
      url: buildUrl('/api/v1/settings/pay-codes', payload),
    }),
    errorMessage: 'Failed to fetch pay codes',
  },
};

const mutationApis = {
  createPayCode: {
    query: (data: any) => ({
      url: '/api/v1/settings/pay-codes',
      data,
      method: HttpMethod.POST,
    }),
    errorMessage: 'Failed to create pay codes',
  },
  updatePayCode: {
    query: (data: any) => ({
      url: `/api/v1/settings/pay-codes/${data.id}`,
      data,
      method: HttpMethod.PUT,
    }),
    errorMessage: 'Failed to update pay codes',
  },
  deletePayCode: {
    query: (id: any) => ({
      url: `/api/v1/settings/pay-codes/${id}`,
      method: HttpMethod.DELETE,
    }),
    errorMessage: 'Failed to delete pay codes',
  },
};

const api = createApi({ queryApis, mutationApis });

export const { useGetPayCodeList, useCreatePayCode, useUpdatePayCode, useDeletePayCode } = api as {
  useGetPayCodeList: (payload: any) => { data: any; loading: boolean; refetch: any };
  useCreatePayCode: () => [createPayCode: (data: any) => Promise<any>, props: any];
  useUpdatePayCode: () => [updatePayCode: (data: any) => Promise<any>, props: any];
  useDeletePayCode: () => [deletePayCode: (data: any) => Promise<any>, props: any];
};
