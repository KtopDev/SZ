import { createApi } from '@/utils/createApi/createApi';
import { HttpMethod, PaginatedListResponse } from '@/utils/createApi/types';
import { buildUrl } from '@/utils/buildUrl/buildUrl';
import { GetUserListPayload } from '@/requests/api/usersApi/types';
import { Dropdown } from '@/types/Dropdown';

const queryApis = {
  getEmployeesList: {
    query: (filters: GetUserListPayload) => ({
      url: buildUrl('/api/v1/users', filters),
    }),
    errorMessage: 'Failed to fetch employees list',
  },
  getJobTitleDropdown: {
    query: () => ({
      url: '/api/v1/job-titles/dropdown',
    }),
    errorMessage: 'Failed to fetch job title dropdown',
  },
  getSecurityRoleDropdown: {
    query: () => ({
      url: '/api/v1/dropdown/securityRoles',
    }),
    errorMessage: 'Failed to fetch security role dropdown',
  },
  getUserDetails: {
    query: (userId: string) => ({
      url: `/api/v1/users/${userId}`,
    }),
    transformResponse: (response: any) => ({
      ...response,
      jobTitle: response.lkJobTitle.jobTitle,
      preferredMultiFactor: response.multiFactorAuthenticationPreference,
      multiFactorAuthenticationTtlDays: response.multiFactorAuthenticationTtlDays.toString(),
    }),
    errorMessage: 'Failed to fetch user details',
  },
};

const mutationApis = {
  createUser: {
    query: (data: any) => ({
      url: '/api/v1/users',
      method: HttpMethod.POST,
      data,
    }),
  },
  updateUser: {
    query: (data: any) => ({
      url: `/api/v1/users/${data.appUserId}`,
      method: HttpMethod.PUT,
      data,
    }),
    errorMessage: 'Failed to update user',
  },
  requestResetPassword: {
    query: (payload: { email: string }) => ({
      url: '/api/v1/authentication/password/reset',
      method: HttpMethod.POST,
      data: { ...payload, userType: 'EMPLOYEE' },
    }),
    errorMessage: 'Failed to request reset password',
  },
  verifyTokenToResetPassword: {
    query: (token: string) => ({
      url: `/api/v1/authentication/password/verify/${token}`,
      method: HttpMethod.PUT,
    }),
  },
  saveNewPassword: {
    query: (payload: any) => ({
      url: `/api/v1/authentication/password/save/${payload.token}`,
      method: HttpMethod.PUT,
      data: { ...payload, userType: 'EMPLOYEE' },
    }),
    errorMessage: 'Failed to save new password',
  },
};

const api = createApi({ queryApis, mutationApis });

export const {
  useGetEmployeesList,
  useGetJobTitleDropdown,
  useGetSecurityRoleDropdown,
  useCreateUser,
  useGetUserDetails,
  useUpdateUser,
  useRequestResetPassword,
  useVerifyTokenToResetPassword,
  useSaveNewPassword,
} = api as {
  useGetEmployeesList: (filters: GetUserListPayload) => { data: PaginatedListResponse<any>; loading: boolean };
  useGetJobTitleDropdown: () => { data: Dropdown; loading: boolean };
  useGetSecurityRoleDropdown: () => { data: Dropdown; loading: boolean };
  useCreateUser: () => [createUser: (data: any) => any, props: { loading: boolean }];
  useGetUserDetails: (userId: string) => { data: any; loading: boolean };
  useUpdateUser: () => [createUser: (data: any) => Promise<void>, props: { loading: boolean }];
  useRequestResetPassword: () => [requestResetPassword: (data: any) => Promise<any>, props: { loading: boolean }];
  useVerifyTokenToResetPassword: () => [
    verifyTokenToResetPassword: (token: any) => Promise<any>,
    props: {
      loading: boolean;
    },
  ];
  useSaveNewPassword: () => [saveNewPassword: (data: any) => Promise<any>, props: { loading: boolean }];
};
