export interface GetUserListPayload {
  size: number;
  page: number;
  sort: string;
  nameOrCode: string;
  status: string;
  branchName: string;
  jobTitle: string;
  // securityRole: string;
}
