import { Client, ClientDTO, mapClientDTO } from '@/app/(main)/clients/types';
import { ClientDTO as ClientRawDTO } from '@/types/dto/Client';
import { createApi } from '@/utils/createApi/createApi';
import { HttpMethod, PaginatedListResponse } from '@/utils/createApi/types';
import { Dropdown } from '@/types/Dropdown';
import { ICreateClient, IUpdateClient } from '@/app/(main)/clients/create-client/types';
import { buildUrl } from '@/utils/buildUrl/buildUrl';
import {
  GetClientListPayload,
  ICreateOrUpdateClientNote,
  IDeleteNote,
  IGetClientNotes,
} from '@/requests/api/clientsApi/types';
import { Note } from '@/app/(main)/clients/[clientId]/notes/types';

const queryApis = {
  getClientsList: {
    query: (payload: GetClientListPayload) => ({
      url: buildUrl('/api/v1/clients', payload),
    }),
    errorMessage: 'Failed to fetch client list',
  },
  getClientDetails: {
    query: (clientId: string) => ({
      url: `/api/v1/clients/${clientId}`,
    }),
    defaultValue: {},
    transformResponse: mapClientDTO,
    errorMessage: 'Failed to fetch client details',
  },
  getRawClientDetails: {
    query: (clientId: string) => ({
      url: `/api/v1/clients/${clientId}`,
    }),
    defaultValue: {},
    errorMessage: 'Failed to fetch client details',
  },
  getDropdownPaymentMethods: {
    query: () => ({
      url: '/api/v1/payment-terms/dropdown',
    }),
    errorMessage: 'Failed to fetch dropdown payment methods dropdown',
  },
  getClientNotes: {
    query: ({ payload, clientId }: IGetClientNotes) => ({
      url: buildUrl(`/api/v1/clients/${clientId}/notes`, payload),
    }),
    errorMessage: 'Failed to fetch client notes',
  },
};

const mutationApis = {
  createClient: {
    query: (data: ICreateClient) => ({
      url: '/api/v1/clients',
      data,
    }),
  },
  updateClient: {
    query: (data: IUpdateClient) => ({
      url: `/api/v1/clients/${data.client_id}`,
      data,
      method: HttpMethod.PUT,
    }),
    errorMessage: 'Failed to update client',
  },
  patchClient: {
    query: (data: IUpdateClient) => ({
      url: `/api/v1/clients/${data.client_id}`,
      data,
      method: HttpMethod.PATCH,
    }),
    errorMessage: 'Failed to update client',
  },
  createNote: {
    query: ({ clientId, payload }: ICreateOrUpdateClientNote) => ({
      url: `/api/v1/clients/${clientId}/notes`,
      data: payload,
    }),
    errorMessage: 'Failed to create client note',
  },
  updateNote: {
    query: ({ clientId, noteId, payload }: ICreateOrUpdateClientNote) => ({
      url: `/api/v1/clients/${clientId}/notes/${noteId}`,
      data: payload,
      method: HttpMethod.PUT,
    }),
    errorMessage: 'Failed to edit client note',
  },
  deleteNote: {
    query: ({ clientId, noteId }: IDeleteNote) => ({
      url: `/api/v1/clients/${clientId}/notes/${noteId}`,
      method: HttpMethod.DELETE,
    }),
    errorMessage: 'Failed to delete client note',
  },
};

const api = createApi({ queryApis, mutationApis });
export const {
  useGetClientsList,
  useGetClientDetails,
  useGetRawClientDetails,
  useGetDropdownPaymentMethods,
  useCreateClient,
  useUpdateClient,
  usePatchClient,
  useGetClientNotes,
  useCreateNote,
  useUpdateNote,
  useDeleteNote,
} = api as {
  useGetClientsList: (payload: GetClientListPayload) => { data: PaginatedListResponse<Client>; loading: boolean };
  useGetClientDetails: (clientId: string) => { data: ClientDTO; loading: boolean };
  useGetRawClientDetails: (clientId: string) => { data: ClientRawDTO; loading: boolean };
  useGetDropdownPaymentMethods: () => { data: Dropdown; loading: boolean };
  useCreateClient: () => [createAccount: (data: ICreateClient) => any, props: any];
  useUpdateClient: () => [createAccount: (data: IUpdateClient) => any, props: any];
  usePatchClient: () => [updateClient: (data: IUpdateClient) => any, props: any];
  useGetClientNotes: (props: IGetClientNotes) => { data: PaginatedListResponse<Note>; loading: boolean };
  useCreateNote: () => [createNote: (data: ICreateOrUpdateClientNote) => any, props: any];
  useUpdateNote: () => [updateNote: (data: ICreateOrUpdateClientNote) => any, props: any];
  useDeleteNote: () => [deleteNote: (data: IDeleteNote) => any, props: any];
};
