export interface GetClientListPayload {
  size: number;
  page: number;
  sort: string;
  name: string;
  branch: string;
  status: string;
  startDate: string;
  endDate: string;
}

export interface IGetClientNotesListPayload {
  size: number;
  page: number;
  title?: string;
  noteType?: string;
  startDate?: string;
  endDate?: string;
}

export interface IGetClientNotes {
  payload: IGetClientNotesListPayload;
  clientId: string;
}

export interface ICreateOrUpdateNote {
  title: string | undefined;
  noteType: string | undefined;
  note: string | undefined;
}

export interface ICreateOrUpdateClientNote {
  payload: ICreateOrUpdateNote;
  clientId: string;
  noteId?: string;
}

export interface IDeleteNote {
  clientId: string;
  noteId: string;
}
