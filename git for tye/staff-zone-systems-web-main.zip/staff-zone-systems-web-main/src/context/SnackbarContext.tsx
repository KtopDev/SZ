'use client';
import { AlertColor } from '@mui/lab';
import React, { createContext, Dispatch, ReactNode, SetStateAction, useContext, useState } from 'react';

interface SnackbarContextType {
  showMessage: boolean;
  message: string;
  setMessage: (message: string) => void;
  clearMessage: () => void;
  severity: AlertColor;
  setSeverity: Dispatch<SetStateAction<AlertColor>>;
  setSuccessMessage: (message: string) => void;
  setErrorMessage: (message: string) => void;
  customStyles: React.CSSProperties;
  setCustomStyles: Dispatch<SetStateAction<React.CSSProperties>>;
}

const SnackbarContext = createContext<SnackbarContextType | undefined>(undefined);

export const SnackBarProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [showMessage, setShowMessage] = useState(false);
  const [messageInternal, setMessageInternal] = useState('');
  const [severity, setSeverity] = useState<AlertColor>('info');
  const [customStyles, setCustomStyles] = useState<React.CSSProperties>({});

  const setMessage = (message: string) => {
    setMessageInternal(message);
    setShowMessage(true);
  };

  const setSuccessMessage = (message: string) => {
    setSeverity('success');
    setMessage(message);
  };

  const setErrorMessage = (message: string) => {
    setSeverity('error');
    setMessage(message);
  };

  const clearMessage = () => setShowMessage(false);

  return (
    <SnackbarContext.Provider
      value={{
        showMessage,
        message: messageInternal,
        setMessage,
        setSuccessMessage,
        setErrorMessage,
        clearMessage,
        severity,
        setSeverity,
        customStyles,
        setCustomStyles,
      }}
    >
      {children}
    </SnackbarContext.Provider>
  );
};

export const useSnackbar = () => {
  const context = useContext(SnackbarContext);
  if (context === undefined) {
    throw new Error('useSnackbar must be used within an SnackBarProvider');
  }
  return context;
};
