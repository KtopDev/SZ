import React from 'react';
import Box from '@mui/material/Box';
import { Chip, Typography } from '@mui/material';

type Props = {
  label: string;
  values: string[] | null;
};

export default function DisplayValues({ label, values }: Props) {
  return (
    <Box component="div" sx={styles.box}>
      <Typography variant="caption" color="gray" component="label">
        {label}
      </Typography>
      <Box sx={styles.chipsContainer}>
        {values &&
          values.map((value) => <Chip key={value} label={value} variant="outlined" size="small" sx={styles.chip} />)}
      </Box>
    </Box>
  );
}

const styles = {
  box: {
    display: 'inline-flex',
    flexDirection: 'column',
    alignItems: 'flex-start',
    marginRight: 3,
  },
  chipsContainer: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    gap: '4px',
    marginTop: '4px',
  },
  chip: {},
};
