import React from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';

type Props = {
  label: string;
  value: string | number | null;
  formatType?: 'currency' | 'phone' | null;
};

export default function NonEditableTextField({ label, value, formatType = null }: Props) {
  let formattedValue = value;

  if (formatType === 'currency') {
    formattedValue = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(Number(value) || 0);
  } else if (formatType === 'phone') {
    const phoneNumber = String(value || '');
    const cleaned = ('' + phoneNumber).replace(/\D/g, '');
    const match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
    if (match) {
      formattedValue = '(' + match[1] + ') ' + match[2] + ' ' + match[3];
    }
  }
  return (
    <Box component="div" sx={styles.box}>
      <Typography variant="caption" color="gray" component="label">
        {label}
      </Typography>
      <Typography component="span">{formattedValue}</Typography>
    </Box>
  );
}

const styles = {
  box: { display: 'inline-flex', flexDirection: 'column', alignItems: 'flex-start', marginRight: 3 },
};
