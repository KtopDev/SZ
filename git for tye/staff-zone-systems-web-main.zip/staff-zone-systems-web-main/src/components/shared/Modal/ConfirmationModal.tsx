import { Backdrop, Box, Button, Fade, Modal, Typography, Stack } from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';

type Props = {
  title: string;
  description: string;
  confirmationButtonText: string;
  confirmationButtonColor?: 'success' | 'info' | 'warning' | 'error' | 'inherit' | 'secondary' | 'primary';
  showModal?: boolean;
  closeModal?: () => void;
  isLoading?: boolean;
  callSubmit?: () => void;
};

export default function ConfirmationModal({
  title,
  description,
  confirmationButtonText,
  confirmationButtonColor = 'primary',
  showModal,
  closeModal,
  isLoading,
  callSubmit,
}: Props) {
  return (
    <Modal
      aria-labelledby="transition-modal-title"
      aria-describedby="transition-modal-description"
      open={showModal ? showModal : false}
      onClose={closeModal}
      closeAfterTransition
      slots={{ backdrop: Backdrop }}
      slotProps={{
        backdrop: {
          timeout: 500,
        },
      }}>
      <Fade in={showModal}>
        <Box sx={styles.modal}>
          <Typography id="transition-modal-title" variant="subtitle1" component="h1">
            <b>{title}</b>
          </Typography>
          <Typography id="transition-modal-description" sx={{ mt: 2 }}>
            {description}
          </Typography>

          <Stack
            spacing={2}
            direction="row"
            sx={{ display: 'flex', justifyContent: 'flex-end' }}
            mb={-2}
            mr={-2}
            mt={2}>
            <Button variant="text" onClick={closeModal}>
              CANCEL
            </Button>
            <LoadingButton
              variant="contained"
              loading={isLoading}
              loadingPosition="start"
              color={confirmationButtonColor}
              onClick={() => {
                if (callSubmit) {
                  callSubmit();
                  if (closeModal) {
                    closeModal();
                  }
                }
              }}>
              {confirmationButtonText}
            </LoadingButton>
          </Stack>
        </Box>
      </Fade>
    </Modal>
  );
}

const styles = {
  modal: {
    position: 'absolute' as const,
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 500,
    bgcolor: 'background.paper',
    boxShadow: 24,
    p: 4,
    paddingTop: 2,
  },
};
