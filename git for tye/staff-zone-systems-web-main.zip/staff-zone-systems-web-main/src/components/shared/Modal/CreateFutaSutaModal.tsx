'use client';
import Grid from '@mui/material/Unstable_Grid2';
import { Backdrop, Box, Button, Fade, Modal, Typography, Stack } from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import { SubmitHandler, useForm } from 'react-hook-form';
import { useSnackbar } from '@/context/SnackbarContext';
import RHTextField from '@/components/shared/Form/RHTextField';
import RHCurrency from '@/components/shared/Form/RHCurrency';
import RHSelect from '@/components/shared/Form/RHSelect';
import { useGetDropdownState } from '@/requests/api/statesApi/statesApi';
import { useCreateFutaSuta } from '@/requests/api/taxesApi/taxesApi';
import { useEffect } from 'react';

type Props = {
  showModal?: boolean;
  closeModal?: () => void;
  refetch: () => void;
};

export default function CreateFutaSutaModal({ showModal, closeModal, refetch }: Props) {
  const { data: stateList, loading: isStateListLoading } = useGetDropdownState();
  const [createFutaSuta, { loading: isSavingTax }] = useCreateFutaSuta();
  const {
    control,
    formState: { errors },
    handleSubmit,
    getValues,
    reset,
    setError,
    watch,
  } = useForm<any>({ defaultValues: {} as any, mode: 'onBlur' });
  const { setMessage } = useSnackbar();

  const onSubmit: SubmitHandler<any> = async (formData) => {
    try {
      await createFutaSuta(formData);
      setMessage('Item created');
      reset();
      if (closeModal) {
        closeModal();
        refetch();
      }
    } catch (e: any) {
      if (e?.response?.data?.message) {
        setMessage(e.response.data.message);
      } else {
        setMessage('Error creating the tax');
      }
    }
  };

  const callSubmit = () => {
    const submitHandler = handleSubmit(onSubmit);
    submitHandler();
  };

  useEffect(() => {
    const subscription = watch((value, { name }) => {
      if ((name === 'minWage' && getValues('minWage')) || (name === 'maxWage' && getValues('maxWage'))) {
        if (getValues('minWage') > getValues('maxWage')) {
          setError('minWage', { type: 'manual', message: "Min wage amount can't be greater than Max wage amount" });
          setError('maxWage', { type: 'manual', message: "Max wage amount can't be smaller than Min wage amount" });
        }
      }
      return () => subscription.unsubscribe();
    });
  }, [getValues, setError, watch]);

  return (
    <Modal
      aria-labelledby="transition-modal-title"
      aria-describedby="transition-modal-description"
      open={showModal ? showModal : false}
      onClose={closeModal}
      closeAfterTransition
      slots={{ backdrop: Backdrop }}
      slotProps={{
        backdrop: {
          timeout: 500,
        },
      }}>
      <Fade in={showModal}>
        <Box sx={styles.modal}>
          <Typography variant="h6" gutterBottom>
            Create FUTA configuration
          </Typography>
          <Typography variant="subtitle2" gutterBottom mb={1} mt={2}>
            All fields are required
          </Typography>
          <Grid container spacing={2}>
            <Grid xs={12} sm={12} md={12} lg={12} mb={-2}>
              <RHSelect<any>
                label="Jurisdiction"
                propName="jurisdiction"
                options={stateList}
                isLoading={isStateListLoading}
                rhProps={{ errors, control, getValues }}
              />
              <RHCurrency<any> label="Min wage" propName="minWage" rhProps={{ errors, control }} />
              <RHCurrency<any> label="Max wage" propName="maxWage" rhProps={{ errors, control }} />
              <RHTextField<any> label="Rate" propName="rate" type="number" rhProps={{ errors, control }} />
              <RHTextField<any>
                label="Federal Credit Rate"
                propName="federalCreditRate"
                type="number"
                rhProps={{ errors, control }}
              />
              <RHTextField<any>
                label="Employee rate"
                propName="employeeRate"
                type="number"
                rhProps={{ errors, control }}
              />
              <RHTextField<any> label="Company rate" propName="companyRate" rhProps={{ errors, control }} />
              <Stack spacing={2} direction="row" sx={{ display: 'flex', justifyContent: 'flex-end' }} mt={2}>
                <Button variant="text" onClick={closeModal}>
                  CANCEL
                </Button>
                <LoadingButton
                  variant="contained"
                  color="primary"
                  loading={isSavingTax}
                  onClick={() => {
                    if (callSubmit) {
                      callSubmit();
                    }
                  }}>
                  CREATE FUTA CONFIGURATION
                </LoadingButton>
              </Stack>
            </Grid>
          </Grid>
        </Box>
      </Fade>
    </Modal>
  );
}

const styles = {
  modal: {
    position: 'absolute' as const,
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 500,
    bgcolor: 'background.paper',
    boxShadow: 24,
    p: 4,
    paddingTop: 2,
  },
};
