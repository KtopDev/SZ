'use client';
import React, { useEffect, useState } from 'react';
import { Button, Typography } from '@mui/material';
import Image from 'next/image';
import { SubmitHandler, useForm } from 'react-hook-form';
import RHMaskedInput from '@/components/shared/Form/RHMaskedInput';
import AuthenticationMethodModal from '@/components/shared/pages/Authentication/AuthenticationMethodModal';
import { VerificationCodeDto } from '@/requests/api/authApi/types';
import styles from '@/../public/css/login/login.module.css';
import UserClosure from '@/utils/UserClosure';
import { useVerifyMfaOtpCode, useVerifyMfaPhoneCode } from '@/requests/api/authApi/authApi';
import LoadingButton from '@mui/lab/LoadingButton';
import { useRouter } from 'next/navigation';

export default function VerificationCodeForm() {
  const router = useRouter();
  const [verifyMfaOtpCode, { loading }] = useVerifyMfaOtpCode();
  const [verifyMfaPhoneCode, { loading: smsLoading }] = useVerifyMfaPhoneCode();
  const [showModal, setShowModal] = useState(false);
  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(false);
  const mfaPreference = UserClosure.getMfaPreference();

  const {
    getValues,
    setValue,
    control,
    setError,
    formState: { errors },
    handleSubmit,
    watch,
  } = useForm<VerificationCodeDto>({
    defaultValues: {} as VerificationCodeDto,
    mode: 'onChange',
  });
  const verificationCodeValue = watch('verificationCode');

  // prettier-ignore
  const renderDescription = () => {
    switch (mfaPreference) {
    case 'AUTH_APP':
      return 'Insert the code you see in your app for Staff Zone System here:';
    case 'EMAIL':
      return "We've sent you a 6-digit code by EMAIL. Insert that code below to proceed.";
    case 'SMS':
      return "We've sent you a 6-digit code by SMS. Insert that code below to proceed.";
    default:
      return '';
    }
  };

  const onSubmit: SubmitHandler<VerificationCodeDto> = async (formData) => {
    if (UserClosure.getMfaPreference() === 'AUTH_APP') {
      const response = await verifyMfaOtpCode({
        authProcessId: UserClosure.getAuthProcessId() ?? '',
        username: UserClosure.getUsername() ?? '',
        code: formData.verificationCode,
        userType: 'EMPLOYEE',
      });
      if (response.data.token) {
        UserClosure.handleLogin(response.data.token);
        router.push('dispatcher');
      } else {
        setError('verificationCode', { type: 'manual', message: 'Wrong verification code' });
      }
    } else {
      try {
        const res = await verifyMfaPhoneCode({
          code: formData.verificationCode,
          authProcessId: UserClosure.getAuthProcessId() || '',
        });
        if (res.data.token) {
          UserClosure.handleLogin(res.data.token);
          router.push('/dispatcher');
        }
      } catch (e: any) {
        if (e.response.status) {
          setError('verificationCode', {
            message: 'Wrong verification code',
          });
        }
      }
    }
  };

  useEffect(() => {
    if (verificationCodeValue) {
      setValue('verificationCode', verificationCodeValue);
    }
  }, [setValue, verificationCodeValue]);

  return (
    <div className={styles.centralize}>
      <div>
        <div className={styles.centralize}>
          <Image src="/images/login/logo-with-title.png" alt="Picture of the author" width={360} height={80} />
          <Typography variant="h4" component="h4" gutterBottom pt={4}>
            Authentication Code
          </Typography>
        </div>
        <Typography variant="caption" display="block" gutterBottom textAlign="center">
          {renderDescription()}
        </Typography>
        <RHMaskedInput<VerificationCodeDto>
          label="6-digit verification code"
          propName="verificationCode"
          mask="999999"
          rhProps={{
            errors,
            control,
            required: true,
            minLength: 6,
            maxLength: 6,
          }}
        />

        <Button variant="text" color="primary" fullWidth sx={{ marginBottom: -1 }} onClick={() => {}}>
          RESEND AUTHENTICATION CODE
        </Button>
        <Typography variant="caption" display="block" textAlign="center" sx={{ marginTop: 1, marginBottom: 3 }}>
          3 attepmts left
        </Typography>
        <LoadingButton
          fullWidth
          color="primary"
          loading={loading || smsLoading}
          loadingPosition="start"
          variant="contained"
          sx={{ marginBottom: 3 }}
          onClick={handleSubmit(onSubmit)}
          disabled={!!errors.verificationCode || !getValues('verificationCode')}>
          LOG IN
        </LoadingButton>
        <Button
          variant="outlined"
          color="primary"
          fullWidth
          sx={{ marginBottom: 1 }}
          onClick={() => {
            openModal();
          }}>
          CHANGE AUTHENTICATION METHOD
        </Button>
        <AuthenticationMethodModal showModal={showModal} closeModal={closeModal} />
      </div>
    </div>
  );
}
