import * as React from 'react';
import { Chip, FormHelperText, Stack } from '@mui/material';
import { Controller, FieldValues, Path } from 'react-hook-form';
import { ReactHookProps } from '@/types/forms/RHProps';
import { generateRules } from './utils';

type ChipData = {
  label: string;
  color?: 'error' | 'default' | 'primary' | 'secondary' | 'info' | 'success' | 'warning';
  value: string;
};

type Props<T extends FieldValues> = {
  chips: ChipData[];
  propName: Path<T>;
  helperText?: string;
  rhProps: ReactHookProps<T>;
};

export default function RHChipGroup<T extends FieldValues>({ chips, propName, helperText = '', rhProps }: Props<T>) {
  return (
    <Controller
      name={propName}
      control={rhProps.control}
      rules={generateRules(rhProps)}
      render={({ field, fieldState }) => (
        <>
          <Stack direction="row" spacing={1}>
            {chips.map(({ label, color, value }) => (
              <Chip
                key={label}
                label={label}
                variant={field.value === value ? 'filled' : 'outlined'}
                color={color || 'primary'}
                size="small"
                onClick={() => field.onChange(value)}
              />
            ))}
          </Stack>
          <FormHelperText error={!!fieldState.error}>
            {fieldState.error ? fieldState.error.message : helperText}
          </FormHelperText>
        </>
      )}
    />
  );
}
