import { ReactHookProps } from '@/types/forms/RHProps';
import { FieldValues } from 'react-hook-form';

export const generateRules = <T extends FieldValues>({
  required = true,
  errorMessage,
  customMessages = {},
  ...rhProps
}: ReactHookProps<T>): any => {
  const rules: any = {};

  const getErrorMessage = (defaultMessage: string) => {
    if (errorMessage) {
      return errorMessage;
    }

    return defaultMessage;
  };

  if (required !== undefined && required) {
    rules.required = 'This field must not be empty';
  }

  if (rhProps.minLength && rhProps.minLength > 0) {
    rules.minLength = {
      value: rhProps.minLength,
      message: getErrorMessage(`This field must be at least ${rhProps.minLength} characters`),
    };
  }

  if (rhProps.maxLength && rhProps.maxLength > 0) {
    rules.maxLength = {
      value: rhProps.maxLength,
      message: getErrorMessage(`This field must not exceed ${rhProps.maxLength} characters`),
    };
  }

  if (rhProps.min !== undefined && rhProps.min !== null) {
    rules.min = {
      value: rhProps.min,
      message: customMessages.min || `Please enter a value equal or larger than ${rhProps.min}`,
    };
  }

  if (rhProps.max !== undefined && rhProps.max !== null) {
    rules.max = {
      value: rhProps.max,
      message: getErrorMessage(`Please enter a value equal or less than ${rhProps.max}`),
    };
  }

  if (rhProps.isIp) {
    const pattern =
      /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    rules.pattern = {
      value: pattern,
      message: getErrorMessage('Please enter a valid IP address'),
    };
  }

  if (rhProps.isLatLong) {
    const pattern = /^-?\d+(\.\d+)?,\s*-?\d+(\.\d+)?$/;
    rules.pattern = {
      value: pattern,
      message: getErrorMessage('Enter a valid coordinate format: latitude,longitude'),
    };
  }

  if (rhProps.isEmail) {
    const pattern = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
    rules.pattern = {
      value: pattern,
      message: getErrorMessage('Please enter a valid email address'),
    };
  }

  return rules;
};
