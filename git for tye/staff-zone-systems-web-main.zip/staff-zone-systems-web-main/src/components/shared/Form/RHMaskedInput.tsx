import * as React from 'react';
import { FormHelperText, TextField } from '@mui/material';
import { Controller, FieldValues, Path, PathValue } from 'react-hook-form';
import InputMask from 'react-input-mask';
import { ReactHookProps } from '@/types/forms/RHProps';
import { generateRules } from './utils';

type Props<T extends FieldValues> = {
  label: string;
  propName: Path<T>;
  helperText?: string;
  mask: string;
  maskPlaceholder?: string;
  rhProps: ReactHookProps<T>;
};

export default function RHMaskedInput<T extends FieldValues>({
  label,
  propName,
  helperText = '',
  mask,
  maskPlaceholder = '',
  rhProps,
}: Props<T>) {
  return (
    <Controller
      name={propName}
      control={rhProps.control}
      rules={generateRules(rhProps)}
      render={({ field, fieldState }) => (
        <>
          <InputMask
            mask={mask}
            value={field.value}
            maskPlaceholder={maskPlaceholder}
            onChange={(event: { target: { value: string } }) => {
              const unmaskedValue = event.target.value.replace(/\D+/g, '');
              if (rhProps.setValue) {
                rhProps.setValue(propName, unmaskedValue as PathValue<T, Path<T>>);
              }
              field.onChange(unmaskedValue);
            }}
            onBlur={() => {
              field.onBlur();
              if (rhProps.trigger) {
                rhProps.trigger(propName);
              }
            }}>
            <TextField
              fullWidth
              label={label.toString()}
              variant="outlined"
              margin="dense"
              size="small"
              error={!!fieldState.error}
            />
          </InputMask>
          <FormHelperText error={!!fieldState.error}>
            {fieldState.error ? fieldState.error.message : helperText}
          </FormHelperText>
        </>
      )}
    />
  );
}
