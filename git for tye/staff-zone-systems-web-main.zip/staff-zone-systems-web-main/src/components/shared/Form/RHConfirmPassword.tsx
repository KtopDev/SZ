import { ReactHookProps } from '@/types/forms/RHProps';
import { Controller, FieldValues, Path } from 'react-hook-form';
import { FormHelperText, InputAdornment, TextField } from '@mui/material';
import IconButton from '@mui/material/IconButton';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import { useState } from 'react';

type ConfirmProps<T extends FieldValues> = {
  label: string;
  propName: keyof T;
  helperText?: string;
  margin?: 'dense' | 'none' | 'normal';
  disabled?: boolean;
  pattern?: RegExp;
  rhProps: ReactHookProps<T>;
  inputProps?: any;
  originalPassword: string;
};

export function RHConfirmPasswordInput<T extends FieldValues>({
  label,
  propName,
  margin = 'dense',
  helperText = '',
  disabled = false,
  pattern = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)[A-Za-z\d]{8,}$/,
  rhProps,
  inputProps,
  originalPassword,
}: ConfirmProps<T>) {
  const [showPassword, setShowPassword] = useState(false);

  return (
    <Controller
      name={propName as Path<T>}
      control={rhProps.control}
      render={({ field, fieldState }) => (
        <>
          <TextField
            {...field}
            InputLabelProps={{
              shrink: true,
            }}
            fullWidth
            type={showPassword ? 'text' : 'password'}
            label={label}
            variant="outlined"
            value={field.value}
            disabled={disabled}
            margin={margin}
            size="small"
            onChange={field.onChange}
            error={!!fieldState.error}
            {...inputProps}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton onClick={() => setShowPassword(!showPassword)} edge="end">
                    {showPassword ? <VisibilityOff /> : <Visibility />}
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
          <FormHelperText error={!!fieldState.error}>
            {fieldState.error ? fieldState.error.message : helperText}
          </FormHelperText>
        </>
      )}
      rules={{
        pattern: { value: pattern, message: 'Password is not valid' },
        validate: (value) => {
          if (value !== originalPassword) {
            return 'Passwords do not match';
          }
          return true;
        },
      }}
    />
  );
}
