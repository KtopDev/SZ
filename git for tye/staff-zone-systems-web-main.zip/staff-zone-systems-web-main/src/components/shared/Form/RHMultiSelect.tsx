import * as React from 'react';
import {
  Checkbox,
  Chip,
  FormControl,
  FormHelperText,
  InputLabel,
  ListItemText,
  MenuItem,
  OutlinedInput,
  Select,
} from '@mui/material';
import { Controller, ControllerRenderProps, FieldValues, Path } from 'react-hook-form';
import { ReactHookProps } from '@/types/forms/RHProps';
import { Dropdown } from '@/types/Dropdown';
import { generateRules } from './utils';
import CancelIcon from '@mui/icons-material/Cancel';

type Props<T extends FieldValues> = {
  label: string;
  propName: keyof T;
  helperText?: string;
  isLoading?: boolean;
  options: Dropdown;
  rhProps: ReactHookProps<T>;
};

export default function RHMultiSelect<T extends FieldValues>({
  label,
  propName,
  helperText = '',
  options,
  rhProps,
  isLoading,
}: Props<T>) {
  const [selectedOptions, setSelectedOptions] = React.useState<string[]>([]);
  const ITEM_HEIGHT = 48;
  const ITEM_PADDING_TOP = 8;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
        width: 250,
      },
    },
  };

  React.useEffect(() => {
    if (rhProps.getValues) {
      const currentValues = rhProps.getValues(propName as Path<T>);
      if (currentValues && Array.isArray(currentValues)) {
        setSelectedOptions(currentValues);
      }
    }
  }, [propName, rhProps]);

  const handleDeleteChip = (
    field: ControllerRenderProps<T, Path<T>>,
    selectedItems: string[],
    clickedValue: string
  ) => {
    const updatedSelectedItems = selectedItems.filter((item) => item !== clickedValue);
    field.onChange(updatedSelectedItems);
    setSelectedOptions(updatedSelectedItems);
  };
  const getOptionById = (optionId: string) => options.dropdown?.find((option) => option.id === optionId);

  return (
    <FormControl fullWidth>
      <InputLabel id={`${String(propName)}-label`} error={!!rhProps.errors[propName]} size="small">
        {isLoading ? 'loading' : label}
      </InputLabel>
      <Controller
        name={propName as Path<T>}
        control={rhProps.control}
        rules={generateRules(rhProps)}
        render={({ field, fieldState }) => (
          <>
            <Select
              {...field}
              size="small"
              multiple
              labelId={`${String(propName)}-label`}
              id={`${String(propName)}-select`}
              error={!!rhProps.errors[propName]}
              input={<OutlinedInput label={label} />}
              renderValue={(selected) => (
                <div>
                  {(selected as string[]).map((value) => (
                    <Chip
                      key={value}
                      label={getOptionById(value)?.displayName}
                      clickable
                      variant="outlined"
                      sx={{ mx: '4px' }}
                      deleteIcon={<CancelIcon onMouseDown={(event) => event.stopPropagation()} />}
                      onDelete={() => handleDeleteChip(field, selected, value)}
                    />
                  ))}
                </div>
              )}
              MenuProps={MenuProps}
              onChange={(event) => {
                const { value } = event.target;
                const newSelectedOptions = typeof value === 'string' ? [value] : value;
                field.onChange(newSelectedOptions);
                setSelectedOptions(newSelectedOptions); // Update state to reflect the new selection
              }}
              value={selectedOptions}>
              {options.dropdown?.map((option) => (
                <MenuItem key={option.id} value={option.id}>
                  <Checkbox
                    checked={
                      rhProps.getValues && rhProps.getValues(propName as Path<T>)
                        ? rhProps.getValues(propName as Path<T>).includes(option.id)
                        : false
                    }
                    size="small"
                  />
                  <ListItemText primary={option.displayName} />
                </MenuItem>
              ))}
            </Select>
            <FormHelperText error={!!fieldState.error}>
              {fieldState.error ? fieldState.error.message : helperText}
            </FormHelperText>
          </>
        )}
      />
    </FormControl>
  );
}
