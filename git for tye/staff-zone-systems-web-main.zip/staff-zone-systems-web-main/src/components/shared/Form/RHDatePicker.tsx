import * as React from 'react';
import { Controller, FieldValues, Path } from 'react-hook-form';
import { DatePicker } from '@mui/x-date-pickers';
import { ReactHookProps } from '@/types/forms/RHProps';
import dayjs, { Dayjs } from 'dayjs';

type Props<T extends FieldValues> = {
  label: string;
  propName: keyof T;
  rhProps: ReactHookProps<T>;
  fullWidth?: boolean;
};

export default function RHDatePicker<T extends FieldValues>({ label, propName, rhProps, fullWidth = false }: Props<T>) {
  return (
    <Controller
      name={propName as Path<T>}
      control={rhProps.control}
      render={({ field }) => (
        <DatePicker
          slotProps={{
            textField: { fullWidth },
            actionBar: {
              actions: ['clear'],
            },
          }}
          label={label}
          value={field.value ? dayjs(field.value) : null}
          onChange={(date: Dayjs | null) => {
            if (date) {
              field.onChange(date.format('YYYY-MM-DD'));
            } else {
              field.onChange('');
            }
          }}
        />
      )}
    />
  );
}
