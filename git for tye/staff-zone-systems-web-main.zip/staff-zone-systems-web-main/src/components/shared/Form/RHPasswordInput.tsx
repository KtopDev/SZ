import { FormHelperText, IconButton, InputAdornment, TextField } from '@mui/material';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import { Controller, FieldValues, Path } from 'react-hook-form';
import { ReactHookProps } from '@/types/forms/RHProps';
import { useState } from 'react';

type Props<T extends FieldValues> = {
  label: string;
  propName: keyof T;
  helperText?: string;
  margin?: 'dense' | 'none' | 'normal';
  disabled?: boolean;
  pattern?: RegExp;
  shouldValidatePassword?: boolean;
  rhProps: ReactHookProps<T>;
  inputProps?: any;
};

export function RHPasswordInput<T extends FieldValues>({
  label,
  propName,
  margin = 'dense',
  helperText = '',
  disabled = false,
  pattern = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)[A-Za-z\d]{8,}$/,
  rhProps,
  inputProps,
  shouldValidatePassword = true,
}: Props<T>) {
  const [showPassword, setShowPassword] = useState(false);

  return (
    <Controller
      name={propName as Path<T>}
      control={rhProps.control}
      render={({ field, fieldState }) => (
        <>
          <TextField
            {...field}
            InputLabelProps={{
              shrink: true,
            }}
            fullWidth
            type={showPassword ? 'text' : 'password'}
            label={label}
            variant="outlined"
            value={field.value}
            disabled={disabled}
            margin={margin}
            size="small"
            onChange={field.onChange}
            error={!!fieldState.error}
            {...inputProps}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton onClick={() => setShowPassword(!showPassword)} edge="end">
                    {showPassword ? <VisibilityOff /> : <Visibility />}
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
          <FormHelperText error={!!fieldState.error}>
            {fieldState.error ? fieldState.error.message : helperText}
          </FormHelperText>
        </>
      )}
      rules={{
        ...(shouldValidatePassword && { pattern: { value: pattern, message: 'Password is not valid' } }),
      }}
    />
  );
}
