'use client';
import { FormHelperText, TextField } from '@mui/material';
import * as React from 'react';
import { Controller, FieldValues, Path } from 'react-hook-form';
import { ReactHookProps } from '@/types/forms/RHProps';
import { generateRules } from './utils';

type Props<T extends FieldValues> = {
  label: string;
  propName: keyof T;
  helperText?: string;
  margin?: 'dense' | 'none' | 'normal';
  type?: string;
  disabled?: boolean;
  fullWidth?: boolean;
  multiline?: boolean;
  rows?: number;
  rhProps: ReactHookProps<T>;
  inputProps?: any;
};

export default function RHTextField<T extends FieldValues>({
  label,
  propName,
  margin = 'dense',
  fullWidth = true,
  helperText = '',
  type = 'text',
  disabled = false,
  multiline = false,
  rows = 0,
  rhProps,
  inputProps,
}: Props<T>) {
  return (
    <Controller
      name={propName as Path<T>}
      control={rhProps.control}
      rules={generateRules(rhProps)}
      render={({ field, fieldState }) => (
        <>
          <TextField
            {...field}
            InputLabelProps={{
              shrink: true,
            }}
            multiline={multiline}
            rows={rows}
            fullWidth={fullWidth}
            type={type}
            label={label}
            variant="outlined"
            value={field.value}
            disabled={disabled}
            margin={margin}
            ref={field.ref}
            size="small"
            onChange={(e) => {
              const value = e.target.value;
              field.onChange(value);
            }}
            error={!!fieldState.error}
            {...inputProps}
          />
          <FormHelperText error={!!fieldState.error}>
            {fieldState.error ? fieldState.error.message : helperText}
          </FormHelperText>
        </>
      )}
    />
  );
}
