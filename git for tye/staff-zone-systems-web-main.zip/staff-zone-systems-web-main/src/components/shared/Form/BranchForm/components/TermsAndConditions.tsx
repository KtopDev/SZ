'use client';
import * as React from 'react';
import { Typography } from '@mui/material';
import ClientAppTable from '@/components/shared/Table/ClientAppTable';
import WorkerAppTable from '@/components/shared/Table/WorkerAppTable';
import { FieldValues } from 'react-hook-form';
import { ReactHookProps } from '@/types/forms/RHProps';
import { ICreateBranch } from '@/types/forms/CreateBranch';
import { BranchDTO } from '@/types/dto/Branch';

type Props<T extends FieldValues> = {
  branch?: BranchDTO;
  rhProps?: ReactHookProps<T>;
};

export default function Taxes({ branch, rhProps = {} as ReactHookProps<ICreateBranch> }: Props<ICreateBranch>) {
  return (
    <>
      <Typography variant="h6" gutterBottom>
        Apps terms and conditions
      </Typography>
      <Typography variant="subtitle2" gutterBottom mb={2}>
        The following terms and conditions apply to users of Worker and Client apps in this branch
      </Typography>

      <ClientAppTable branch={branch} rhProps={rhProps} />
      <br />
      <WorkerAppTable branch={branch} rhProps={rhProps} />
    </>
  );
}
