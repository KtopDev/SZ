'use client';
import * as React from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import { Typography } from '@mui/material';
import { ReactHookProps } from '@/types/forms/RHProps';
import { ICreateBranch } from '@/types/forms/CreateBranch';
import RHTextField from '@/components/shared/Form/RHTextField';
import { FieldValues } from 'react-hook-form';

type Props<T extends FieldValues> = {
  rhProps: ReactHookProps<T>;
};

export default function Printer({ rhProps }: Props<ICreateBranch>) {
  const { control, errors } = rhProps;
  return (
    <>
      <Typography variant="h6" gutterBottom mt={2}>
        Printer IP configuration
      </Typography>
      <Typography variant="subtitle2" gutterBottom mb={2}>
        IP addresses of the default printers for this branch
      </Typography>
      <Grid container spacing={2} mb={4}>
        <Grid xs={12} sm={12} lg={4} mb={-2}>
          <RHTextField<ICreateBranch>
            label="Scaner IP"
            propName="scannerIp"
            rhProps={{ errors, control, isIp: true }}
          />
        </Grid>
        <Grid xs={12} sm={12} lg={4} mb={-2}>
          <RHTextField<ICreateBranch>
            label="Check printer IP"
            propName="checkPrinterIp"
            rhProps={{ errors, control, isIp: true }}
          />
        </Grid>
        <Grid xs={12} sm={12} lg={4} mb={-2}>
          <RHTextField<ICreateBranch>
            label="Report printer IP"
            propName="reportPrinterIp"
            rhProps={{ errors, control, isIp: true }}
          />
        </Grid>
      </Grid>
    </>
  );
}
