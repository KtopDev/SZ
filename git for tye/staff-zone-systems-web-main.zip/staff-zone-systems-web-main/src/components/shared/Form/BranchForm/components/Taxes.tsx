import React from 'react';
import { Typography } from '@mui/material';
import Grid from '@mui/material/Unstable_Grid2';
import { FUTA_SUTA, TAXES, PAY_RULES } from '@/requests/endpoints';
import type { Dropdown } from '@/types/Dropdown';
import useGet from '@/hooks/useGet';
import { ReactHookProps } from '@/types/forms/RHProps';
import { ICreateBranch } from '@/types/forms/CreateBranch';
import RHMultiSelect from '@/components/shared/Form/RHMultiSelect';
import { FieldValues } from 'react-hook-form';

type Props<T extends FieldValues> = {
  rhProps: ReactHookProps<T>;
};

export default function Taxes({ rhProps }: Props<ICreateBranch>) {
  const { control, getValues, errors } = rhProps;
  const { getData: defaultTaxes } = useGet<Dropdown>(TAXES);
  const { getData: futaSutaSdis } = useGet<Dropdown>(FUTA_SUTA);
  const { getData: payRules } = useGet<Dropdown>(PAY_RULES);

  return (
    <>
      <Typography variant="h6" gutterBottom mt={2}>
        Taxes
      </Typography>
      <Typography variant="subtitle2" gutterBottom mb={2}>
        Default taxes to be used for this project
      </Typography>
      <Grid container spacing={2}>
        <Grid xs={12} sm={12} lg={6} mb={-1}>
          <RHMultiSelect<ICreateBranch>
            label="Default taxes"
            propName="taxJurisdictions"
            options={defaultTaxes}
            rhProps={{ errors, control, getValues }}
          />
        </Grid>
        <Grid xs={12} sm={12} lg={6} mb={-1}>
          <RHMultiSelect<ICreateBranch>
            label="FUTA, SUTA and SDI configurations"
            propName="futaSutaSdi"
            options={futaSutaSdis}
            rhProps={{ errors, control, getValues }}
          />
        </Grid>
        <Grid xs={12}>
          <RHMultiSelect<ICreateBranch>
            label="Sick pay rules"
            propName="sickPayJurisdictions"
            helperText="Optional"
            options={payRules}
            rhProps={{ errors, control, getValues, required: false }}
          />
        </Grid>
      </Grid>
    </>
  );
}
