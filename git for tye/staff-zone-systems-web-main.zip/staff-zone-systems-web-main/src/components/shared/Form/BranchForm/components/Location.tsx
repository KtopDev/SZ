'use client';
import * as React from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import { Typography } from '@mui/material';
import MapAlert from './MapAlert';
import { ReactHookProps } from '@/types/forms/RHProps';
import { ICreateBranch } from '@/types/forms/CreateBranch';
import RHTextField from '@/components/shared/Form/RHTextField';
import { STATES } from '@/requests/endpoints';
import type { Dropdown } from '@/types/Dropdown';
import useGet from '@/hooks/useGet';
import RHSelect from '@/components/shared/Form/RHSelect';
import RHMaskedInput from '@/components/shared/Form/RHMaskedInput';
import { FieldValues } from 'react-hook-form';

type Props<T extends FieldValues> = {
  rhProps: ReactHookProps<T>;
};

export default function Location({ rhProps }: Props<ICreateBranch>) {
  const { control, errors, getValues } = rhProps;
  const { getData: states } = useGet<Dropdown>(STATES);
  return (
    <>
      <Typography variant="h6" gutterBottom mt={2}>
        Location
      </Typography>
      <Typography variant="subtitle2" gutterBottom mb={2}>
        Address of the branch main building
      </Typography>
      <Grid container spacing={2}>
        <Grid xs={12} sm={12} md={12} lg={12} mb={-1}>
          <RHTextField<ICreateBranch>
            label="Street address"
            propName="address"
            margin="none"
            rhProps={{ errors, control }}
          />
        </Grid>
        <Grid xs={12} sm={12} md={6} lg={6} mb={-2}>
          <RHTextField<ICreateBranch>
            label="Street address line 2"
            propName="addressLine2"
            helperText="Optional"
            rhProps={{ errors, control, required: false }}
          />
        </Grid>
        <Grid xs={12} sm={12} md={6} lg={6} mb={-2}>
          <RHSelect<ICreateBranch>
            label="State"
            propName="state"
            options={states}
            rhProps={{ errors, control, getValues }}
          />
        </Grid>

        <Grid xs={12} sm={12} md={6} lg={6} mb={-2}>
          <RHTextField<ICreateBranch> label="City" propName="city" rhProps={{ errors, control }} />
        </Grid>

        <Grid xs={12} sm={12} md={6} lg={6} mb={-2}>
          <RHMaskedInput<ICreateBranch>
            label="Zip code"
            propName="postalCode"
            mask="99999"
            rhProps={{ errors, control, minLength: 5, maxLength: 5 }}
          />
        </Grid>
        <Grid xs={12} sm={12} md={6} lg={6}>
          <RHTextField<ICreateBranch>
            label="Coordinates"
            propName="geoLocation"
            rhProps={{ errors, control, isLatLong: true }}
          />
        </Grid>
        <Grid xs={12} sm={12} md={12} lg={12} mb={2}>
          <MapAlert />
        </Grid>
      </Grid>
    </>
  );
}
