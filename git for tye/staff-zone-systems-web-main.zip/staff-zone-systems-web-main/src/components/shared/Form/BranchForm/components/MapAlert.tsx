'use client';
import Alert from '@mui/material/Alert';
import Button from '@mui/material/Button';
import { mapsInfoStyle } from '../styles';

export default function MapAlert() {
  const handleOpenMaps = () => {
    const url = 'https://www.google.com/maps';
    window.open(url, '_blank');
  };

  return (
    <Alert
      variant="filled"
      severity="info"
      sx={{
        bgcolor: '#ECF3FA',
        color: '#1B3852',
        width: '100%',
      }}
      action={
        <Button
          onClick={handleOpenMaps}
          variant="text"
          sx={{
            'color': '#1B3852',
            '&:hover': {
              color: 'primary.secondary',
            },
          }}>
          OPEN GOOGLE MAPS
        </Button>
      }>
      <span>Get the coordinates to a place</span>
      <ol style={mapsInfoStyle}>
        <li>
          Open
          <a href="https://maps.google.com/" target="blank">
            Google Maps
          </a>
        </li>
        <li>
          Right-click the place or area on the map
          <ul style={mapsInfoStyle}>
            <li>
              a. This will open a pop-up window. You can find your latitude and longitude in decimal format at the top.
            </li>
            <li>b. To copy the coordinates automatically, left click on the latitude and longitude.</li>
          </ul>
        </li>
      </ol>
    </Alert>
  );
}
