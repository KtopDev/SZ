'use client';
import React, { useState } from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import { FormControlLabel, Switch, Typography } from '@mui/material';
import { CHECK_FORMATS, DEPOSIT_ADVICE_FORMAT, PAY_CHECK_FORMAT } from '@/requests/endpoints';
import type { Dropdown, SelectOption } from '@/types/Dropdown';
import useGet from '@/hooks/useGet';
import { ReactHookProps } from '@/types/forms/RHProps';
import { ICreateBranch } from '@/types/forms/CreateBranch';
import RHSelect from '@/components/shared/Form/RHSelect';
import { useGetDropdownCompCodes } from '@/requests/api/compCodesApi/compCodesApi';
import { FieldValues, useWatch } from 'react-hook-form';

type Props<T extends FieldValues> = {
  rhProps: ReactHookProps<T>;
};

export default function Other({ rhProps }: Props<ICreateBranch>) {
  const { control, errors, getValues } = rhProps;
  const state = useWatch({ control: control, name: 'state' });
  const { getData: checkFormat } = useGet<Dropdown>(CHECK_FORMATS);
  const { getData: payCheckFormat } = useGet<Dropdown>(PAY_CHECK_FORMAT);
  const { getData: depositAdviceFormat } = useGet<Dropdown>(DEPOSIT_ADVICE_FORMAT);
  const { data: compCodes, loading: isCompCodeLoading } = useGetDropdownCompCodes(state);

  const [checked, setChecked] = useState(false);

  const handleChangeSwitch = (event: any) => {
    setChecked(event.target.checked);
  };

  return (
    <>
      <Typography variant="h6" gutterBottom mt={2}>
        Other settings
      </Typography>
      <Grid container spacing={2} mb={2}>
        <Grid xs={12} sm={12} lg={4} mb={-2}>
          <RHSelect<ICreateBranch>
            label="Default check format"
            propName="defaultCheckPrintingFormatId"
            options={checkFormat}
            rhProps={{ errors, control, getValues }}
          />
        </Grid>
        <Grid xs={12} sm={12} lg={4} mb={-2}>
          <RHSelect<ICreateBranch>
            label="Sick pay check format"
            propName="sickCheckPrintingFormatId"
            options={payCheckFormat}
            rhProps={{ errors, control, getValues }}
          />
        </Grid>
        <Grid xs={12} sm={12} lg={4} mb={-2}>
          <RHSelect<ICreateBranch>
            label="Deposit advice format"
            propName="depositPrintingFormatId"
            options={depositAdviceFormat}
            rhProps={{ errors, control, getValues }}
          />
        </Grid>
        <Grid xs={12} sm={12} lg={12}>
          <RHSelect<ICreateBranch>
            label="Comp code for this branch"
            propName="compCodeId"
            options={compCodes}
            getOptionLabel={(option: SelectOption) => `${option.displayName}`}
            renderOption={(props, option: SelectOption) => <li {...props}>{`${option.displayName}`}</li>}
            isLoading={isCompCodeLoading}
            rhProps={{ errors, control, getValues }}
          />
        </Grid>
        <Grid xs={12} sm={12} lg={12}>
          <div>
            <FormControlLabel
              control={
                <Switch
                  checked={checked}
                  onChange={handleChangeSwitch}
                  name="isVoluntaryDeductionApproveRequired"
                  color="primary"
                />
              }
              label="Workers from this branch must approve voluntary deductions"
            />
          </div>
        </Grid>
      </Grid>
    </>
  );
}
