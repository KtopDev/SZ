'use client';
import React from 'react';
import Grid from '@mui/material/Unstable_Grid2';
import { Typography } from '@mui/material';
import { PAY_CYCLE } from '@/requests/endpoints';
import type { Dropdown } from '@/types/Dropdown';
import useGet from '@/hooks/useGet';
import { ReactHookProps } from '@/types/forms/RHProps';
import { ICreateBranch } from '@/types/forms/CreateBranch';
import RHTextField from '@/components/shared/Form/RHTextField';
import RHMaskedInput from '@/components/shared/Form/RHMaskedInput';
import RHCurrency from '@/components/shared/Form/RHCurrency';
import RHSelect from '@/components/shared/Form/RHSelect';
import { FieldValues } from 'react-hook-form';
import { BranchDTO } from '@/types/dto/Branch';

type Props<T extends FieldValues> = {
  branch?: BranchDTO;
  rhProps: ReactHookProps<T>;
};

export default function BasicInformation({ branch, rhProps }: Props<ICreateBranch>) {
  const { control, getValues, errors, setValue } = rhProps;
  const { getData: payCycles } = useGet<Dropdown>(PAY_CYCLE);

  return (
    <>
      <Typography variant="h6" gutterBottom mt={2}>
        Basic information
      </Typography>
      <Typography variant="subtitle2" gutterBottom mb={2}>
        Enter a name to identify the new branch and contact numbers
      </Typography>
      <Grid container spacing={2}>
        <Grid xs={12} sm={12} md={6} lg={6} mb={-2}>
          <RHTextField<ICreateBranch>
            label="Branch name"
            propName="branchName"
            rhProps={{ errors, getValues, control, minLength: 3 }}
          />
        </Grid>
        <Grid xs={12} sm={12} md={6} lg={6} mb={-2}>
          <RHTextField<ICreateBranch>
            label="Branch code location number"
            propName="branchCode"
            disabled={!!branch?.branchCode}
            type="number"
            rhProps={{ errors, control, minLength: 3, maxLength: 3 }}
          />
        </Grid>
        <Grid xs={12} sm={12} md={6} lg={6} mb={-2}>
          <RHMaskedInput<ICreateBranch>
            label="Phone number"
            propName="phone"
            mask="(999) 999 9999"
            rhProps={{ errors, control, setValue, minLength: 9 }}
          />
        </Grid>
        <Grid xs={12} sm={12} md={6} lg={6} mb={-2}>
          <RHMaskedInput<ICreateBranch>
            label="Fax number"
            propName="fax"
            mask="(999) 999 9999"
            rhProps={{ errors, control, setValue, minLength: 9 }}
          />
        </Grid>
        <Grid xs={12} sm={12} md={6} lg={6} mb={-2}>
          <RHCurrency<ICreateBranch>
            label="Daily pay limit"
            propName="payLimitDaily"
            helperText="Max amount a worker can get paid daily before needing an approval from a General Manager or Admin"
            rhProps={{ errors, control }}
          />
        </Grid>

        <Grid xs={12} sm={12} md={6} lg={6} mb={-2}>
          <RHCurrency<ICreateBranch>
            label="Weekly pay limit"
            propName="payLimitWeekly"
            helperText="Max amount a worker can get paid weekly before needing an approval from a General Manager or Admin"
            rhProps={{ errors, control }}
          />
        </Grid>
        <Grid xs={12} sm={12} md={6} lg={6} mb={2}>
          <RHSelect<ICreateBranch>
            label="Default pay cycle"
            propName="payCycle"
            options={payCycles}
            rhProps={{ errors, control, getValues }}
          />
        </Grid>
      </Grid>
    </>
  );
}
