'use client';
import { FormControl, FormHelperText, InputLabel, OutlinedInput } from '@mui/material';
import { Controller, FieldValues, Path } from 'react-hook-form';
import { ReactHookProps } from '@/types/forms/RHProps';
import { generateRules } from './utils';

type Props<T extends FieldValues> = {
  label: string;
  propName: keyof T;
  helperText?: string;
  onlyInteger?: boolean;
  rhProps: ReactHookProps<T>;
};

export default function RHNumberInput<T extends FieldValues>({
  label,
  propName,
  helperText,
  onlyInteger = false,
  rhProps,
}: Props<T>) {
  const removeLeadingZeros = (value: string) => {
    if (value.startsWith('0') && value !== '0') {
      return value.replace(/^0(?=[1-9])/, '');
    }
    return value;
  };
  const validateDecimalPlaces = (value: string) => {
    value = value.replace(/[^0-9.]/g, '');

    const match = value.match(/^(\d+)\.?(\d{0,2})/);
    return match ? match[0] : '';
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!/[\d.]/.test(e.key) && e.key !== 'Backspace' && e.key !== 'Tab') {
      e.preventDefault();
    }
    if (onlyInteger && /[.]/.test(e.key)) {
      e.preventDefault();
    }
  };

  return (
    <FormControl fullWidth margin="dense" error={!!rhProps.errors.payLimitWeekly}>
      <InputLabel size="small" error={!!rhProps.errors[propName]}>
        {label}
      </InputLabel>
      <Controller
        name={propName as Path<T>}
        control={rhProps.control}
        rules={generateRules(rhProps)}
        render={({ field, fieldState }) => (
          <>
            <OutlinedInput
              {...field}
              type="text"
              label={label}
              value={field.value}
              size="small"
              inputProps={{
                min: 0,
                step: onlyInteger ? 1 : 'any',
              }}
              onKeyDown={handleKeyDown}
              onChange={(e) => {
                let value = e.target.value;

                value = removeLeadingZeros(value);
                if (!onlyInteger) {
                  value = validateDecimalPlaces(value);
                }
                field.onChange(value);
              }}
              onBlur={(e) => {
                const value = e.target.value;

                if (value === '.') {
                  field.onChange('');
                }
                if (value.endsWith('.')) {
                  field.onChange(value.replace('.', ''));
                }
              }}
              error={!!fieldState.error}
            />
            <FormHelperText error={!!fieldState.error}>
              {fieldState.error ? fieldState.error.message : helperText}
            </FormHelperText>
          </>
        )}
      />
    </FormControl>
  );
}
