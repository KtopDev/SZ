import { Button, Card, CardContent, Modal, Typography } from '@mui/material';
import Grid from '@mui/material/Unstable_Grid2';

type Props = {
  open: boolean;
  setOpen: (open: boolean) => void;
};

export default function MfaMethodModal({ open, setOpen }: Props) {
  return (
    <Modal open={open}>
      <Card sx={modalStyle}>
        <CardContent>
          <Typography gutterBottom marginBottom={4} fontWeight={500}>
            Change authentication method
          </Typography>

          <Typography fontWeight={500}>
            You’re currently using SMS. Choose another method to authenticate your login. The system will remember your
            choice in the future.
          </Typography>

          <Button sx={{ marginTop: 2 }} fullWidth variant="outlined">
            EMAIL
          </Button>
          <Button sx={{ marginTop: 2 }} fullWidth variant="outlined">
            AUTHENTICATION APP
          </Button>

          <Grid container>
            <Grid xs={9}>
              <Button sx={{ marginTop: 2, fontSize: 12, height: '50px' }} fullWidth color="warning" variant="contained">
                Click here to simulate a first time setup for auth app
              </Button>
            </Grid>
            <Grid xs={3}>
              <Button onClick={() => setOpen(false)} sx={{ marginLeft: 1, marginTop: 3 }} fullWidth variant="text">
                CANCEL
              </Button>
            </Grid>
          </Grid>
        </CardContent>
      </Card>
    </Modal>
  );
}

const modalStyle = {
  position: 'absolute' as const,
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 550,
  textDecoration: 'none',
  p: 1,
};
