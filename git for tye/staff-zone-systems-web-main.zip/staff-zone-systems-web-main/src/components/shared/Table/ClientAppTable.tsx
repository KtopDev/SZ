import React, { useEffect, useState } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Checkbox,
  Button,
  Typography,
  TablePagination,
  Link,
} from '@mui/material';
import DownloadIcon from '@mui/icons-material/Download';
import { useGetClientTermsList } from '@/requests/api/clientTermsApi/clientTermsApi';
import { FieldValues } from 'react-hook-form';
import { ReactHookProps } from '@/types/forms/RHProps';
import { ICreateBranch } from '@/types/forms/CreateBranch';
import { BranchDTO } from '@/types/dto/Branch';
import { formatDate } from '@/utils/general/general';
import { parseClientTerm } from '@/types/dto/ClientAppTerm';

type Props<T extends FieldValues> = {
  branch?: BranchDTO;
  rhProps: ReactHookProps<T>;
};

export default function ClientApp({ branch, rhProps }: Props<ICreateBranch>) {
  const { data } = useGetClientTermsList();
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [currentPage, setCurrentPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [preSelectedExistent, setPreselectedExistent] = useState(false);

  const handleToggle = (id: string) => {
    const currentIndex = selectedIds.indexOf(id);
    const newSelectedIds = [...selectedIds];

    if (currentIndex === -1) {
      newSelectedIds.push(id);
    } else {
      newSelectedIds.splice(currentIndex, 1);
    }

    setSelectedIds(newSelectedIds);
    if (rhProps.setValue) {
      rhProps.setValue('clientTerms', newSelectedIds);
    }
  };

  const handleToggleAll = () => {
    if (selectedIds.length === data.clientAppTerms.length) {
      setSelectedIds([]);
      if (rhProps.setValue) {
        rhProps.setValue('clientTerms', []);
      }
    } else {
      const allIds = data.clientAppTerms.map((term) => term.client_app_term_id);
      setSelectedIds(allIds);
      if (rhProps.setValue) {
        rhProps.setValue('clientTerms', allIds);
      }
    }
  };

  const hasRhProps = () => {
    return Object.keys(rhProps).length > 0;
  };

  const dataToRender = () => {
    const isEditing = hasRhProps() && branch;
    const isCreating = hasRhProps() && !branch;
    const isInDetails = !hasRhProps() && branch;
    if (isEditing || isCreating) {
      return currentTerms ? currentTerms : [];
    } else if (isInDetails) {
      return branch.clientAppTerms ? branch.clientAppTerms : [];
    } else {
      return [];
    }
  };

  useEffect(() => {
    if (branch && branch.clientAppTerms && !preSelectedExistent) {
      const branchTermIds = branch.clientAppTerms.map((term) => term.clientAppTermId);
      setSelectedIds(branchTermIds);
      setPreselectedExistent(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [branch, rhProps]);

  const indexOfLastTerm = (currentPage + 1) * rowsPerPage;
  const indexOfFirstTerm = indexOfLastTerm - rowsPerPage;
  const currentTerms = data.clientAppTerms?.slice(indexOfFirstTerm, indexOfLastTerm);

  return (
    <TableContainer component={Paper}>
      <Typography variant="h6" gutterBottom ml={1} mt={1}>
        Client app
      </Typography>
      {!branch && (
        <>
          <Table aria-label="customized table">
            <TableHead>
              <TableRow>
                <TableCell padding="checkbox">
                  <Checkbox
                    onChange={handleToggleAll}
                    checked={selectedIds.length === data.clientAppTerms?.length && data.clientAppTerms.length > 0}
                    indeterminate={
                      data.clientAppTerms && selectedIds.length > 0 && selectedIds.length < data.clientAppTerms.length
                    }
                  />
                </TableCell>
                <TableCell align="left">Title</TableCell>
                <TableCell>Last updated</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {currentTerms &&
                currentTerms.map((term) => (
                  <TableRow key={term.client_app_term_id}>
                    <TableCell padding="checkbox">
                      <Checkbox
                        checked={selectedIds.includes(term.client_app_term_id)}
                        onChange={() => handleToggle(term.client_app_term_id)}
                      />
                    </TableCell>
                    <TableCell component="th" scope="row">
                      {term.client_app_term_label}
                    </TableCell>
                    <TableCell>{formatDate(term.modified_at)}</TableCell>
                    <TableCell align="right">
                      <Button
                        startIcon={<DownloadIcon />}
                        onClick={() => {
                          /* handle download */
                        }}>
                        DOWNLOAD PDF
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
            </TableBody>
          </Table>
          <TablePagination
            component="div"
            count={data.clientAppTerms?.length}
            page={currentPage}
            onPageChange={(event, newPage) => setCurrentPage(newPage)}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={(event) => {
              setRowsPerPage(parseInt(event.target.value, 10));
              setCurrentPage(0);
            }}
          />
        </>
      )}
      {branch && (
        <>
          <Table aria-label="customized table">
            <TableHead>
              <TableRow>
                {hasRhProps() && (
                  <TableCell padding="checkbox">
                    <Checkbox
                      onChange={handleToggleAll}
                      checked={selectedIds.length === data.clientAppTerms?.length && data.clientAppTerms.length > 0}
                      indeterminate={
                        data.clientAppTerms && selectedIds.length > 0 && selectedIds.length < data.clientAppTerms.length
                      }
                    />
                  </TableCell>
                )}
                <TableCell align="left">Title</TableCell>
                <TableCell align="right">Last updated</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {dataToRender().map((term) => (
                <TableRow key={parseClientTerm(term).client_app_term_label}>
                  {hasRhProps() && (
                    <TableCell padding="checkbox">
                      <Checkbox
                        checked={selectedIds.includes(parseClientTerm(term).client_app_term_id)}
                        onChange={() => handleToggle(parseClientTerm(term).client_app_term_id)}
                      />
                    </TableCell>
                  )}
                  <TableCell component="th" scope="row">
                    {parseClientTerm(term).client_app_term_label}
                  </TableCell>
                  <TableCell component="th" align="right" scope="row">
                    {formatDate(parseClientTerm(term).modified_at)}
                  </TableCell>
                  <TableCell align="right">
                    <Button startIcon={<DownloadIcon />}>
                      <Link
                        href={parseClientTerm(term).client_app_term_file_uri}
                        download={parseClientTerm(term).client_app_term_file_uri || 'download'}
                        underline="none"
                        color="inherit">
                        DOWNLOAD PDF
                      </Link>
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {hasRhProps() && (
            <TablePagination
              component="div"
              count={data.clientAppTerms?.length}
              page={currentPage}
              onPageChange={(event, newPage) => setCurrentPage(newPage)}
              rowsPerPage={rowsPerPage}
              onRowsPerPageChange={(event) => {
                setRowsPerPage(parseInt(event.target.value, 10));
                setCurrentPage(0);
              }}
            />
          )}
        </>
      )}
    </TableContainer>
  );
}
