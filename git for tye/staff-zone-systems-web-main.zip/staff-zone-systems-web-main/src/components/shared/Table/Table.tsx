import * as React from 'react';
import Image from 'next/image';
import Box from '@mui/material/Box';
import { Theme } from '@mui/material/styles';
import Typography from '@mui/material/Typography';
import { MaterialReactTable, MRT_TableOptions, useMaterialReactTable } from 'material-react-table';

type TableProps = {
  mrtProps: MRT_TableOptions<any>;
  rowCount: number;
};

const Table = ({ mrtProps, rowCount }: TableProps) => {
  const table = useMaterialReactTable({
    enableColumnActions: false,
    enableColumnFilters: false,
    enableColumnOrdering: true,
    enableRowActions: true,
    enableColumnDragging: false,
    enableTableFooter: false,
    enableBottomToolbar: false,
    enableColumnPinning: true,
    manualSorting: true,
    positionPagination: 'top',
    positionActionsColumn: 'last',
    displayColumnDefOptions: {
      'mrt-row-actions': {
        size: 80,
      },
    },
    rowCount,
    renderEmptyRowsFallback: () => (
      <Box display="flex" flexDirection="column" justifyContent="center" alignItems="center" paddingTop={10}>
        <Image src={'/images/empty-table/staff-zone.svg'} alt="Logo" width={180} height={140} />
        <Typography>There is no data to show here yet</Typography>
      </Box>
    ),
    muiTablePaperProps: {
      elevation: 0,
    },
    muiTableContainerProps: {
      sx: {
        paddingLeft: '16px',
      },
    },
    muiPaginationProps: {
      showRowsPerPage: false,
    },
    muiTableBodyProps: {
      sx: {
        border: 'none',
      },
    },
    mrtTheme: (theme: Theme) => ({
      baseBackgroundColor: theme.palette.background.default,
    }),
    muiTableBodyCellProps: {
      sx: {
        border: 'none',
        paddingY: '5px',
      },
    },
    muiTableHeadCellProps: {
      sx: {
        border: 'none',
        paddingTop: '25px',
      },
    },
    muiTableHeadProps: {
      sx: {
        display: mrtProps.data.length ? undefined : 'none',
      },
    },
    ...mrtProps,
  });

  return <MaterialReactTable table={table} />;
};

export default Table;
