import * as React from 'react';
import { capitalize } from 'lodash';
import Link from 'next/link';
import { Breadcrumbs } from '@mui/material';
import Typography from '@mui/material/Typography';
import { usePathname } from 'next/navigation';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import { BASE_URL } from '@/requests/axios-conf';
import { useEffect, useState } from 'react';

const Breadcrumb = () => {
  const paths = usePathname();
  const [formattedBreadcrumb, setFormattedBreadcrumb] = useState('');
  const [rawPathNames, setRawPathNames] = useState(['']);

  const isValidUUID = (str: string) => {
    const regex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    return regex.test(str);
  };

  const fetchBreadcrumbs = async (rawPathNames: string[]) => {
    const isUUIDRoute = (rawPathNames: string[]) => {
      if (rawPathNames[0] && rawPathNames.length > 0) {
        return rawPathNames.filter((path) => isValidUUID(path)).length > 0;
      }
      return false;
    };

    if (isUUIDRoute(rawPathNames)) {
      if (rawPathNames.includes('branches')) {
        const response = await fetch(`${BASE_URL}/api/v1/branches/${rawPathNames[3]}`);
        const data = await response.json();
        setFormattedBreadcrumb(data.branchName);
      }
      if (rawPathNames.includes('clients')) {
        const response = await fetch(`${BASE_URL}/api/v1/clients/${rawPathNames[2]}`);
        const data = await response.json();
        setFormattedBreadcrumb(data.clientName);
      }
    }
  };

  const customCapitalize = (pathName: string) => {
    pathName = capitalize(pathName.replace(/-/g, ' '));
    if (pathName.includes('ppe')) {
      return pathName.replace('ppe', 'PPE');
    }
    return pathName;
  };

  useEffect(() => {
    const newRawPathNames = paths.split('/').filter((path: string) => path);
    setRawPathNames(newRawPathNames);
    fetchBreadcrumbs(newRawPathNames);
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [paths]);

  return (
    <Breadcrumbs separator={<ChevronRightIcon fontSize="small" />} aria-label="breadcrumb">
      {rawPathNames.map((pathName: string, index: number) => {
        const href =
          pathName === 'branch-details' && isValidUUID(rawPathNames[index + 1])
            ? `/${rawPathNames.slice(0, index).join('/')}`
            : `/${rawPathNames.slice(0, index + 1).join('/')}`;

        return (
          <Link key={`${pathName}${index}`} href={href} style={{ textDecoration: 'none', color: 'inherit' }}>
            <Typography fontWeight="500" fontSize="16px" color="common.black">
              {isValidUUID(pathName) ? formattedBreadcrumb : customCapitalize(pathName)}
            </Typography>
          </Link>
        );
      })}
    </Breadcrumbs>
  );
};

export default Breadcrumb;
