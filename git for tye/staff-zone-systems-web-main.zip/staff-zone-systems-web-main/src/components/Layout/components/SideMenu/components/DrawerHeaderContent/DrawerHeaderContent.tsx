import * as React from 'react';
import Image from 'next/image';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Unstable_Grid2';
import Typography from '@mui/material/Typography';
import ToggleMenuButton from '@/components/Layout/components/SideMenu/components/ToggleMenuButton';
import { Button, FormControl, InputLabel, MenuItem, Select } from '@mui/material';
import styles from './styles';
import { useGetDropdownBranchList } from '@/requests/api/branchesApi/branchesApi';
import { useSidebar } from '@/context/SidebarContext';

interface Props {
  open: boolean;
  isAnimationFinished: boolean;
  handleToggle: () => void;
}

const DrawerHeaderContent = ({ open, isAnimationFinished, handleToggle }: Props) => {
  const { selectedBranchId, setSelectedBranchId } = useSidebar();
  const { data: branchList } = useGetDropdownBranchList();
  return (
    <Box sx={{ flexGrow: 1 }}>
      <Box sx={open ? { padding: '12px' } : {}}>
        <Grid sx={styles.gridStyles(open)} container={open} direction="row" justifyContent="space-between">
          <Grid container alignItems="center" columnGap={2}>
            {open && isAnimationFinished && (
              <>
                <Image src={'/images/sidebar-icons/staff-zone-logo.svg'} alt="Logo" width={32} height={32} />

                <Typography component="span" fontWeight="bold" color="common.white">
                  Staff Zone
                </Typography>
              </>
            )}
          </Grid>
          <ToggleMenuButton handleToggle={handleToggle} open={open} />
        </Grid>
        {open && isAnimationFinished && (
          <Grid container direction="column" paddingTop={1} rowGap={1}>
            <FormControl variant="filled">
              <InputLabel sx={styles.inputLabelStyles}>Branch</InputLabel>
              <Select
                disableUnderline={true}
                sx={styles.selectBranchStyles}
                id="working-branch"
                value={selectedBranchId}
                label="Branch"
                onChange={(e) => {
                  setSelectedBranchId(e.target.value);
                }}>
                {branchList?.dropdown?.map((option) => (
                  <MenuItem key={option.id} value={option.id}>
                    {option.displayName}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <Grid columns={8}>
              <Button variant="text">
                <Typography fontSize={12} fontWeight={500} color="primary.light">
                  {' '}
                  Return to default branch
                </Typography>
              </Button>
            </Grid>
          </Grid>
        )}
      </Box>
    </Box>
  );
};

export default DrawerHeaderContent;
