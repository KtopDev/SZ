import DrawerHeaderContent from './DrawerHeaderContent';

export default DrawerHeaderContent;
