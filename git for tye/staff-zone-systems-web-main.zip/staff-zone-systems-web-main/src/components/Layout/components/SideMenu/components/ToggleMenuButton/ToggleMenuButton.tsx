'use client';

import * as React from 'react';
import { Avatar } from '@mui/material';
import { Theme } from '@mui/material/styles';
import IconButton from '@mui/material/IconButton';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';

interface Props {
    open: boolean;
    handleToggle: () => void;
}

const styles = {
  iconProps: (theme: Theme) => ({ color: theme.palette.primary.light }),
  avatar: {
    backgroundColor: 'transparent',
    border: (theme: Theme) => `1px solid ${theme.palette.primary.light}`,
    width: 30,
    height: 30,
  },
};

const ToggleMenuButton = ({ open, handleToggle }: Props) => {
  return (
    <IconButton
      onClick={handleToggle}
      sx={{
        padding: 0,
      }}>
      <Avatar sx={styles.avatar}>
        {open ? <ChevronLeftIcon sx={styles.iconProps} /> : <ChevronRightIcon sx={styles.iconProps} />}
      </Avatar>
    </IconButton>
  );
};

export default ToggleMenuButton;
