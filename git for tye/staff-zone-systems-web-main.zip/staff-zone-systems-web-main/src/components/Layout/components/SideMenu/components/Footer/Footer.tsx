import Divider from '@mui/material/Divider';
import { Grid } from '@mui/material';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import LogoutIcon from '@mui/icons-material/Logout';
import ConfirmationModal from '@/components/shared/Modal/ConfirmationModal';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import UserClosure from '@/utils/UserClosure';

// import { useLogout, useGetMe } from '@/requests/api/authApi/authApi';

interface Props {
  open: boolean;
}

const Footer = ({ open }: Props) => {
  const [showModal, setShowModal] = useState(false);
  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(false);
  // const [logout] = useLogout();
  // const { data: meData } = useGetMe();
  const router = useRouter();

  const callSubmit = async () => {
    UserClosure.handleLogout();
    // if (meData?.appUserId) {
    //   await logout({ clientId: meData.appUserId, userType: 'EMPLOYEE' });
    // }
    router.push('/login');
  };

  return (
    <>
      <Divider sx={{ backgroundColor: 'grey.800' }} />
      <Grid container justifyContent="space-around" sx={{ paddingY: 2 }}>
        {open && (
          <Grid item>
            <Typography color="common.white">Staff Zone</Typography>
            <Typography color="common.white" fontSize="12">
              Systems 2024 v0.0.2
            </Typography>
          </Grid>
        )}
        <Grid item>
          <IconButton onClick={openModal}>
            <LogoutIcon sx={{ color: 'grey.700' }} />
          </IconButton>
        </Grid>
      </Grid>

      <ConfirmationModal
        title="Log out"
        description="Are you sure you want to log out of the application?"
        confirmationButtonText="LOG OUT"
        confirmationButtonColor="error"
        showModal={showModal}
        closeModal={closeModal}
        isLoading={false}
        callSubmit={callSubmit}
      />
    </>
  );
};

export default Footer;
