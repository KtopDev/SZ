import { Theme } from '@mui/material/styles';

export const dividerStyle = { backgroundColor: 'grey.800' };
export const listItemStyle = { display: 'block' };
export const listItemButtonStyle = (open: boolean) => ({
  minHeight: 48,
  justifyContent: open ? 'initial' : 'center',
  px: 2.5,
});
export const listItemIconStyle = (open: boolean) => ({
  minWidth: 0,
  mr: open ? 3 : 'auto',
  justifyContent: 'center',
});
export const listItemTextStyle = (open: boolean) => ({
  opacity: open ? 1 : 0,
  color: (theme: Theme) => theme.palette.common.white,
});

export const badgeStyle = {
  'marginLeft': 4,
  '& .MuiBadge-badge': {
    fontSize: 11,
    color: 'white',
    backgroundColor: (theme: Theme) => theme.palette.grey['800'],
  },
};
