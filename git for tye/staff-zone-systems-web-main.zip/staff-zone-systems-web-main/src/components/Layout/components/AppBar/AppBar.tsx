import * as React from 'react';
import { capitalize } from 'lodash';
import Toolbar from '@mui/material/Toolbar';
import Breadcrumb from '@/components/Layout/components/Breadcrumb/Breadcrumb';
import { StyledAppBar } from './AppBar.styled';
import IconButton from '@mui/material/IconButton';
import { usePathname, useRouter } from 'next/navigation';
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import AddTaskIcon from '@mui/icons-material/AddTask';
import HelpIcon from '@mui/icons-material/Help';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';

interface Props {
  open?: boolean;
}

const AppBar = ({ open }: Props) => {
  const paths = usePathname();
  const router = useRouter();
  const pathNames = paths
    .split('/')
    .filter((path: string) => path)
    .map((path: string) => capitalize(path.replace('-', ' ')));

  return (
    <StyledAppBar open={open}>
      <Box paddingX={pathNames.length > 1 ? '14px' : '26px'}>
        <Toolbar disableGutters>
          {pathNames.length > 1 && (
            <Box paddingRight="12px">
              <IconButton onClick={router.back}>
                <KeyboardBackspaceIcon color="primary" />
              </IconButton>
            </Box>
          )}
          <Breadcrumb />
          <Box sx={{ flexGrow: 1 }} />
          <Box>
            <Button component="label" variant="text" tabIndex={-1} startIcon={<AddTaskIcon />}>
              NEW TASK
            </Button>
            <Button component="label" variant="text" tabIndex={-1} size="small">
              <HelpIcon color="secondary" />
              <ArrowDropDownIcon color="secondary" fontSize="small" />
            </Button>
          </Box>
        </Toolbar>
      </Box>
    </StyledAppBar>
  );
};

export default AppBar;
