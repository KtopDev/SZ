import { AppBarProps as MuiAppBarProps } from '@mui/material/AppBar/AppBar';
import { styled } from '@mui/material/styles';
import MuiAppBar from '@mui/material/AppBar';
import { closedDrawerWidth, openDrawerWidth } from '@/theme/constants';

interface AppBarProps extends MuiAppBarProps {
    open?: boolean;
}

export const StyledAppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== 'open',
})<AppBarProps>(({ theme, open }) => ({
  'boxShadow': 'none',
  'padding': 0,
  'width': `calc(100% - ${closedDrawerWidth}px)`,
  'backgroundColor': `${theme.palette.common.white}`,
  'borderBottom': `2px solid ${theme.palette.divider}`,
  'transition': theme.transitions.create(['width', 'margin'], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    marginLeft: openDrawerWidth,
    width: `calc(100% - ${openDrawerWidth}px)`,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
  '&.MuiPaper-root': {
    width: '100%',
    margin: 0,
    position: 'relative',
  },
}));
