'use client';
import * as React from 'react';
import { useEffect, useState } from 'react';
import { Card, CardActions, CardContent, CircularProgress, CssBaseline } from '@mui/material';
import { styled } from '@mui/material/styles';
import { useIdleTimer } from 'react-idle-timer';
import AppBar from '@/components/Layout/components/AppBar/AppBar';
import SideMenu from '@/components/Layout/components/SideMenu/SideMenu';
import Modal from '@mui/material/Modal';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import { useRouter } from 'next/navigation';
import UserClosure from '@/utils/UserClosure';
import { usePostPoneResetPassword } from '@/requests/api/authApi/authApi';
import Backdrop from '@mui/material/Backdrop';
import dayjs from 'dayjs';
import { useGetUserDetails } from '@/requests/api/usersApi/usersApi';

interface Props {
  children: React.ReactNode;
}

const DrawerContainer = styled('nav')({
  flexShrink: 0,
  height: '100vh',
});

const MainContainer = styled('main')(({ theme }) => ({
  flexGrow: 1,
  display: 'flex',
  height: '100vh',
  flexDirection: 'column',
  backgroundColor: theme.palette.background.default,
}));

const idleCardModalStyle = {
  position: 'absolute' as const,
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 500,
  textDecoration: 'none',
  p: 1,
};

const Layout = ({ children }: Props) => {
  const [open, setOpen] = useState(true);
  const [idleTimeModalVisible, setIdleTimeModalVisible] = useState(false);
  const [resetPasswordReminderModalVisible, setResetPasswordReminderModalVisible] = useState(false);
  const [resetPasswordIgnoreConfirmationModalVisible, setResetPasswordIgnoreConfirmationModalVisible] = useState(false);
  const [remaining, setRemaining] = useState<number>(100);
  const [modalCount, setModalCount] = useState(30);
  const router = useRouter();
  const [postponeResetPassword, { loading: postponePasswordLoading }] = usePostPoneResetPassword();
  const { data: userData, loading: userDataLoading } = useGetUserDetails(
    UserClosure.getUser()?.auth_user_details.user.app_user_id || ''
  );

  useEffect(() => {
    if (idleTimeModalVisible && modalCount > 0) {
      const timerId = setTimeout(() => setModalCount(modalCount - 1), 1000);
      return () => clearTimeout(timerId);
    } else if (modalCount === 0) {
      setIdleTimeModalVisible(false);
    }
  }, [modalCount, idleTimeModalVisible]);

  useEffect(() => {
    if (dayjs().isAfter(dayjs(userData.passwordExpireTs))) {
      setResetPasswordReminderModalVisible(true);
    }
  }, [userData]);

  const { getRemainingTime } = useIdleTimer({
    timeout: 270_000,
    throttle: 500,
  });

  //eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => {
    const interval = setInterval(() => {
      setRemaining(Math.ceil(getRemainingTime() / 1000));
    }, 500);

    if (remaining === 0) {
      setIdleTimeModalVisible(true);
    }

    return () => {
      clearInterval(interval);
    };
  });

  useEffect(() => {
    if (modalCount === 0) {
      setIdleTimeModalVisible(false);
      handleGoToLogin();
    }
    //eslint-disable-next-line react-hooks/exhaustive-deps
  }, [modalCount]);

  const handleGoToLogin = () => {
    // logout logic
    router.push('/login');
  };

  const renderIdleModal = () => {
    return (
      <Modal open={idleTimeModalVisible} aria-labelledby="modal-modal-title" aria-describedby="modal-modal-description">
        <Card sx={idleCardModalStyle}>
          <CardContent>
            <Typography gutterBottom fontWeight={500}>
              Session timeout
            </Typography>
            <Typography py={2} sx={{ fontSize: 50 }} textAlign="center">
              {modalCount}s
            </Typography>
            <Typography fontWeight={500}>
              Users of Staff Zone Systems are automatically logged out after 5 minutes of inactivity. If you want to
              stay connected, confirm you’re here before the timeout.
            </Typography>
          </CardContent>
          <CardActions sx={{ justifyContent: 'end' }}>
            <Button size="small" variant="contained" color="error" onClick={handleGoToLogin}>
              LOG OUT NOW
            </Button>
            <Button
              size="small"
              variant="contained"
              onClick={() => {
                setModalCount(30);
                setIdleTimeModalVisible(false);
              }}>
              STAY CONNECTED
            </Button>
          </CardActions>
        </Card>
      </Modal>
    );
  };

  const showIgnoreAlertConfirmationModal = () => {
    setResetPasswordReminderModalVisible(false);
    setResetPasswordIgnoreConfirmationModalVisible(true);
  };

  const handleIgnoreChangePasswordAlert = async () => {
    await postponeResetPassword({});
    setResetPasswordIgnoreConfirmationModalVisible(false);
  };

  const handleRemindMeTomorrow = async () => {
    try {
      await postponeResetPassword({ daysToExtend: 1 });
      setResetPasswordReminderModalVisible(false);
    } catch (err) {
      // handle error
    }
  };

  const goToResetPassword = () => {
    UserClosure.handleLogout();
    router.push('/reset-password');
  };

  const renderResetPasswordReminderModal = () => {
    return (
      <>
        <Backdrop sx={{ color: '#fff' }} open={postponePasswordLoading || userDataLoading}>
          <CircularProgress color="inherit" />
        </Backdrop>
        <Modal
          open={resetPasswordReminderModalVisible}
          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description">
          <Card sx={idleCardModalStyle}>
            <CardContent>
              <Typography gutterBottom fontWeight={500}>
                Outdated password
              </Typography>
              <Typography py={3} fontWeight={500}>
                You have used the same password for {UserClosure.getDaysSinceLastPasswordChange()} days without changing
                it. That is not considered a good practice for cyber security. Would you like to change your password
                now?
              </Typography>
              <Button fullWidth variant="outlined" onClick={showIgnoreAlertConfirmationModal}>
                IGNORE ALERT
              </Button>
              <Button sx={{ my: 2 }} fullWidth variant="outlined" onClick={handleRemindMeTomorrow}>
                REMIND ME AGAIN TOMORROW
              </Button>
              <Button fullWidth variant="contained" onClick={goToResetPassword}>
                CHANGE PASSWORD
              </Button>
            </CardContent>
          </Card>
        </Modal>
      </>
    );
  };

  const renderConfirmIgnoreAlert = () => {
    return (
      <>
        <Modal
          open={resetPasswordIgnoreConfirmationModalVisible}
          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description">
          <Card sx={idleCardModalStyle}>
            <CardContent>
              <Typography gutterBottom fontWeight={500}>
                Ignore alert for outdated password?
              </Typography>
              <Typography py={3} fontWeight={500}>
                Are you sure you want to ignore this alert? Your account may become vulnerable, specially if you don’t
                use a strong password. We’ll still remind you again to change your password in 90 days.
              </Typography>
              <Button fullWidth variant="outlined" onClick={handleIgnoreChangePasswordAlert}>
                I’M AWARE OF THE RISKS AND I’LL IGNORE THEM
              </Button>
              <Button sx={{ mt: 2 }} fullWidth variant="contained" onClick={goToResetPassword}>
                CHANGE PASSWORD
              </Button>
            </CardContent>
          </Card>
        </Modal>
      </>
    );
  };

  return (
    <>
      <CssBaseline />
      <DrawerContainer>
        <SideMenu setOpen={setOpen} open={open} />
      </DrawerContainer>
      <MainContainer>
        <AppBar open={open} />
        {renderIdleModal()}
        {renderResetPasswordReminderModal()}
        {renderConfirmIgnoreAlert()}
        <div>{children}</div>
      </MainContainer>
    </>
  );
};

export default Layout;
