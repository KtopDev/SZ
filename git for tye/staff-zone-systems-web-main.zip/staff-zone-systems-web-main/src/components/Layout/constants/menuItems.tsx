import { ReactNode } from 'react';
import PlayCircleIcon from '@mui/icons-material/PlayCircle';
import PaymentsIcon from '@mui/icons-material/Payments';
import ConfirmationNumberIcon from '@mui/icons-material/ConfirmationNumber';
import DescriptionIcon from '@mui/icons-material/Description';
import PendingActionsIcon from '@mui/icons-material/PendingActions';
import WorkIcon from '@mui/icons-material/Work';
import CollectionsBookmarkIcon from '@mui/icons-material/CollectionsBookmark';
import SupervisedUserCircleIcon from '@mui/icons-material/SupervisedUserCircle';
import SettingsIcon from '@mui/icons-material/Settings';
import { common } from '@mui/material/colors';

interface MenuItem {
  name: string;
  label: string;
  icon: ReactNode;
  href: string;
  notificationCount: number;
}

export const menuItems: MenuItem[] = [
  {
    name: 'dispatcher',
    label: 'Dispatcher',
    icon: <PlayCircleIcon sx={{ color: common.white }} />,
    href: '/dispatcher',
    notificationCount: 1,
  },
  {
    name: 'payroll',
    label: 'Payroll',
    icon: <PaymentsIcon sx={{ color: common.white }} />,
    href: '/payroll',
    notificationCount: 2,
  },
  {
    name: 'ticketEditor',
    label: 'Ticket Editor',
    icon: <ConfirmationNumberIcon sx={{ color: common.white }} />,
    href: '/ticket-editor',
    notificationCount: 3,
  },
  {
    name: 'invoicing',
    label: 'Invoicing',
    icon: <DescriptionIcon sx={{ color: common.white }} />,
    href: '/invoicing',
    notificationCount: 0,
  },
  {
    name: 'taskMaster',
    label: 'Task Master',
    icon: <PendingActionsIcon sx={{ color: common.white }} />,
    href: '/task-master',
    notificationCount: 0,
  },
  {
    name: 'clients',
    label: 'Clients',
    icon: <WorkIcon sx={{ color: common.white }} />,
    href: '/clients',
    notificationCount: 0,
  },
  {
    name: 'projects',
    label: 'Projects',
    icon: <CollectionsBookmarkIcon sx={{ color: common.white }} />,
    href: '/projects',
    notificationCount: 0,
  },
  {
    name: 'workers',
    label: 'Workers',
    icon: <SupervisedUserCircleIcon sx={{ color: common.white }} />,
    href: '/workers',
    notificationCount: 0,
  },
  {
    name: 'settings',
    label: 'Settings',
    icon: <SettingsIcon sx={{ color: common.white }} />,
    href: '/settings',
    notificationCount: 0,
  },
];
