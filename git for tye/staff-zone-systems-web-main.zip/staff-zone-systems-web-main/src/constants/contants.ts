import { Dropdown } from '@/types/Dropdown';

export const daysOfTheWeekOptions: Dropdown = {
  dropdown: [
    { displayName: 'Monday', id: 1 },
    {
      displayName: 'Tuesday',
      id: 2,
    },
    {
      displayName: 'Wednesday',
      id: 3,
    },
    {
      displayName: 'Thursday',
      id: 4,
    },
    {
      displayName: 'Friday',
      id: 5,
    },
    {
      displayName: 'Saturday',
      id: 6,
    },
    {
      displayName: 'Sunday',
      id: 7,
    },
  ],
};

export const daysOfTheWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
