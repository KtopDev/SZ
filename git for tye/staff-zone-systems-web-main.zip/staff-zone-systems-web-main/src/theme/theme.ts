'use client';
import { createTheme, Theme } from '@mui/material/styles';
import { backgroundGrey, error, grey, violet } from '@/theme/colors';

const theme: Theme = createTheme({
  typography: {
    fontFamily: "'Inter','serif'",
    fontSize: 14,
    fontWeightLight: 300,
    fontWeightRegular: 400,
    fontWeightMedium: 500,
  },
  palette: {
    primary: {
      main: violet['40'],
      light: violet['80'],
      dark: violet['10'],
      contrastText: violet['100'],
    },
    secondary: {
      main: grey['40'],
      light: grey['80'],
      dark: grey['10'],
      contrastText: grey['100'],
    },

    error: {
      main: error['40'],
      light: error['80'],
      dark: error['10'],
      contrastText: error['100'],
    },
    background: {
      default: backgroundGrey,
    },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: 'none',
        },
      },
    },
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          '& input::-webkit-outer-spin-button, & input::-webkit-inner-spin-button': {
            display: 'none',
          },
          '& input[type=number]': {
            MozAppearance: 'textfield',
          },
        },
      },
    },
    MuiTextField: {
      defaultProps: {
        size: 'small',
      },
      styleOverrides: {
        root: {
          '& input::-webkit-outer-spin-button, & input::-webkit-inner-spin-button': {
            display: 'none',
          },
          '& input[type=number]': {
            MozAppearance: 'textfield',
          },
        },
      },
    },
    MuiFormControl: {
      defaultProps: {
        size: 'small',
      },
    },
  },
});

export default theme;
