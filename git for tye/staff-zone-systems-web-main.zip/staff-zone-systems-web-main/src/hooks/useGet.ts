import { useEffect, useState, useCallback } from 'react';
import { axiosInstance as axios } from '@/requests/axios-conf';
import { handleError } from './utils';

function useGet<T = any>(endpoint: string) {
  const [getData, setGetData] = useState<T>({} as T);
  const [isLoading, setIsLoading] = useState(false);

  const fetchData = useCallback(async () => {
    setIsLoading(true);
    try {
      const response = await axios.get<T>(`/api/v1/${endpoint}`);
      setGetData(response.data);
    } catch (error) {
      handleError(error);
    } finally {
      setIsLoading(false);
    }
  }, [endpoint]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { getData, setGetData, isLoading, fetchData };
}

export default useGet;
