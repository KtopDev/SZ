import { AxiosError } from 'axios';

interface ValidationMessage {
  field: string;
  message: string;
}

export interface APIErrorResponse {
  code: string;
  message: string;
  details: ValidationMessage[];
}

export const isAxiosError = (error: unknown): error is AxiosError => {
  return (error as AxiosError).response !== undefined;
};

export const handleError = (error: unknown): string => {
  if (isAxiosError(error)) {
    const errorResponse = error.response?.data as APIErrorResponse;
    const formattedMessage = formatErrorMessages(errorResponse);
    return formattedMessage;
  } else if (error instanceof Error) {
    return error.message;
  } else {
    return 'An unexpected error occurred.';
  }
};

export const formatErrorMessages = (errorResponse: APIErrorResponse): string => {
  if (!errorResponse.details || errorResponse.details.length === 0) {
    return errorResponse.message;
  }
  const detailMessages = errorResponse.details.map((detail) => `${detail.message}`).join('\n');
  return `${detailMessages}`;
};
