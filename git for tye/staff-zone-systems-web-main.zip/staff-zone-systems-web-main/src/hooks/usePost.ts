import { useState } from 'react';
import { axiosInstance as axios } from '@/requests/axios-conf';
import { handleError } from './utils';

function usePost(endpoint: string) {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>();
  const [data, setData] = useState<any>(null);

  const postData = async (body: any) => {
    setIsLoading(true);
    try {
      const response = await axios.post(`/api/v1/${endpoint}`, body);
      if (response.status <= 200 || response.status >= 300) {
        throw new Error('Failed to submit data');
      }
      setData(response.data);
    } catch (error) {
      setError(handleError(error));
    } finally {
      setIsLoading(false);
    }
  };

  return { postData, isLoading, error, setError, data };
}

export default usePost;
