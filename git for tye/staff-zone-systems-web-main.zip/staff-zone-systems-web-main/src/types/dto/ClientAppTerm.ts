export interface ClientTermDto {
  sortOrder: number;
  fileName: string;
  document: File;
}

export interface ClientTermResponse {
  clientAppTerms: ClientAppTerm[];
}

export interface ClientAppTerm {
  sort_order: number;
  modified_at: string;
  in_use_branches: InUseBranch[];
  client_app_term_id: string;
  client_app_term_file_uri: string;
  client_app_term_label: string;
}

interface InUseBranch {
  branch_id: string;
  branch_code: string;
  branch_name: string;
}

export function parseClientTerm(term: any): ClientAppTerm {
  // if its of type from DTO: dto/Branch.ts -> WorkerAppTerm interface theres no need to parse
  if (term.client_app_term_id !== undefined) {
    return term;
  }
  return {
    sort_order: term.sortOrder,
    modified_at: term.approvalRequestTs,
    client_app_term_id: term.id,
    client_app_term_file_uri: term.clientAppTermFileUri,
    client_app_term_label: term.clientAppTermIdLabel,
  } as ClientAppTerm;
}
