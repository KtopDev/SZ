import { PPERequest } from '../forms/PPE';

export type PPEDto = {
  ppe_id: string;
  ppe_name: string;
  branch_id: string | null;
  ocurrences: string;
  total_rows: string;
  branch_name: string | null;
  modified_at: string;
  ppe_abreviation: string;
  ppe_description: string;
};

export const convertPPEDtoToPPERequest = (dto: PPEDto): PPERequest => {
  return {
    id: dto.ppe_id,
    ppeName: dto.ppe_name,
    ppeAbbreviation: dto.ppe_abreviation,
    ppeDescription: dto.ppe_description,
    branchId: dto.branch_id ?? '',
  };
};
