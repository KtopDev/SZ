export interface WorkerTermResponse {
  workerAppTerms: WorkerAppTerm[];
}

export interface WorkerAppTerm {
  sort_order: number;
  modified_at: string;
  in_use_branches: InUseBranch[];
  worker_app_term_id: string;
  worker_app_term_file_uri: string;
  worker_app_term_es_file_uri: string;
  worker_app_term_label: string;
}

export interface WorkerTermDto {
  fileName: string;
  document: File;
  spanishDocument: File;
}

interface InUseBranch {
  branch_id: string;
  branch_code: string;
  branch_name: string;
}

export function parseWorkerTerm(term: any): WorkerAppTerm {
  // if its of type from DTO: dto/Branch.ts -> WorkerAppTerm interface theres no need to parse
  if (term.worker_app_term_id !== undefined) {
    return term;
  }
  return {
    sort_order: term.sortOrder,
    modified_at: term.approvalRequestTs,
    worker_app_term_id: term.id,
    worker_app_term_file_uri: term.workerAppTermFileUri,
    worker_app_term_es_file_uri: term.workerAppTermEsFileUri,
    worker_app_term_label: term.workerAppTermIdLabel,
  } as WorkerAppTerm;
}
