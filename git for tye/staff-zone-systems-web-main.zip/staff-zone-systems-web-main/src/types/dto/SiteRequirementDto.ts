import { SiteRequirementRequest } from '../forms/SiteRequirement';

export type SiteRequirementDto = {
  site_requirement_id: string;
  site_requirement_name: string;
  branch_id: string | null;
  ocurrences: string;
  total_rows: string;
  branch_name: string | null;
  modified_at: string;
  site_requirement_description: string;
};

export const convertDtoToRequest = (dto: SiteRequirementDto): SiteRequirementRequest => {
  return {
    id: dto.site_requirement_id,
    siteRequirementName: dto.site_requirement_name,
    siteRequirementDescription: dto.site_requirement_description,
    branch: {
      id: dto.branch_id ?? '',
      name: dto.branch_name ?? '',
    },
  };
};

export const siteRequirementsList: SiteRequirementDto[] = [
  {
    site_requirement_id: '1',
    site_requirement_name: 'Safety Glasses',
    site_requirement_description: 'Protective eyewear to shield eyes from flying debris.',
    ocurrences: 'Frequent',
    modified_at: '2024-06-18T12:00:00Z',
    branch_name: 'Manufacturing Unit 1',
  } as SiteRequirementDto,
  {
    site_requirement_id: '2',
    site_requirement_name: 'Hard Hat',
    site_requirement_description: 'Helmet designed to protect from objects falling from above.',
    ocurrences: 'Rare',
    modified_at: '2024-06-15T08:45:00Z',
    branch_name: 'Construction Site 3',
  } as SiteRequirementDto,
  {
    site_requirement_id: '3',
    site_requirement_name: 'Ear Plugs',
    site_requirement_description: 'Small devices inserted in ear canal to protect from loud noises.',
    ocurrences: 'Always',
    modified_at: '2024-06-16T14:30:00Z',
    branch_name: 'Fabrication Workshop',
  } as SiteRequirementDto,
  {
    site_requirement_id: '4',
    site_requirement_name: 'Respirator',
    site_requirement_description: 'Mask to protect from inhaling hazardous substances.',
    ocurrences: 'Occasional',
    modified_at: '2024-06-17T17:00:00Z',
    branch_name: 'Chemical Lab 2',
  } as SiteRequirementDto,
];
