interface PaymentTerm {
  paymentTerm: string;
  isRowActive: boolean;
  label: string;
  sortOrder: number;
}

interface InvoiceMethod {
  invoiceMethod: string;
  label: string;
  sortOrder: number;
  isRowActive: boolean;
}

interface PrintingFormatType {
  printingFormatType: string;
  label: string;
  isRowActive: boolean;
}

interface InvoicePrintingFormat {
  printingFormatId: string;
  lkPrintingFormatType: PrintingFormatType;
  printingFormatName: string;
  printingFormatUri: string;
  isRowActive: boolean;
}

interface State {
  state: string;
  stateName: string;
  isRowActive: boolean;
}

interface CompCode {
  compCode: string;
  compCodeDescription: string;
  compCodeBillingDescription: string;
  lkState: State;
  burdenPerHour: number;
  costPerHundred: number;
  billRatePreHundred: number;
  date: string;
  isRowActive: boolean;
}

interface ContactId {
  clientId: string;
  contactId: string;
}

interface Contact {
  id: ContactId;
  isRowActive: boolean;
  name: string;
  lastName: string;
  phone: string;
  email: string;
  isPrimary: boolean;
  isAppAccessEnabled: boolean;
  canReceiveInvoices: boolean;
  canApproveHours: boolean;
  canRateWorkers: boolean;
  multiFactorAuthenticationPreference: string;
}

export interface ClientDTO {
  id: string;
  isRowActive: boolean;
  clientCode: string;
  clientName: string;
  status: string;
  statusTs: string;
  creditLimit: number;
  paymentTerm: PaymentTerm;
  invoiceMethod: InvoiceMethod;
  invoicePrintingFormat: InvoicePrintingFormat;
  phone: string;
  fax: string;
  address: string;
  addressLine2: string;
  state: State;
  city: string;
  postalCode: string;
  compCode: CompCode;
  lastOrderBranch: any;
  lastOrderDate: any;
  lastInvoiceDate: any;
  unpaidInvoices: any;
  createdAt: string;
  createdBy: string;
  modifiedAt: string;
  modifiedBy: string;
  branchesIds: string[];
  branchNames: string[];
  contact: Contact;
}
