export type MeDto = {
  appUserId: string;
  appUserCode: string;
  email: string;
  firstName: string;
  lastName: string;
  multiFactorAuthenticationPreference: 'SMS';
  passwordExpireTs: string;
  multiFactorAuthenticationTtlDays: number;
  password: string;
  phone: string;
  status: string;
  statusTs: string;
  lkJobTitle: {
    jobTitle: string;
    label: string;
    sortOrder: number;
    isRowActive: boolean;
  };
  appUsersBranches: {
    id: {
      appUserId: string;
      branchId: string;
    };
    isPrimary: boolean;
    appRole: {
      role: string;
      description: string;
      isRowActive: boolean;
    };
    appUser: string;
    branch: {
      branchId: string;
      branchName: string;
      branchCode: string;
      status: string;
      statusTs: string;
      phone: string;
      fax: string;
      address: string;
      addressLine2: string;
      state: {
        state: string;
        stateName: string;
        isRowActive: boolean;
      };
      city: string;
      postalCode: string;
      geoLocation: string;
      payLimitDaily: number;
      payLimitWeekly: number;
      payCycle: {
        payCycle: string;
        label: string;
        isRowActive: boolean;
      };
      isVoluntaryDeductionApproveRequired: boolean;
      scannerIp: string;
      checkPrinterIp: string;
      reportPrinterIp: string;
      defaultCheckPrintingFormat: {
        printingFormatId: string;
        lkPrintingFormatType: {
          printingFormatType: string;
          label: string;
          isRowActive: boolean;
        };
        printingFormatName: string;
        printingFormatUri: string;
        isRowActive: boolean;
      };
      sickCheckPrintingFormat: {
        printingFormatId: string;
        lkPrintingFormatType: {
          printingFormatType: string;
          label: string;
          isRowActive: boolean;
        };
        printingFormatName: string;
        printingFormatUri: string;
        isRowActive: boolean;
      };
      depositPrintingFormat: {
        printingFormatId: string;
        lkPrintingFormatType: {
          printingFormatType: string;
          label: string;
          isRowActive: boolean;
        };
        printingFormatName: string;
        printingFormatUri: string;
        isRowActive: boolean;
      };
      compCode: {
        compCode: string;
        compCodeDescription: string;
        compCodeBillingDescription: string;
        lkState: {
          state: string;
          stateName: string;
          isRowActive: boolean;
        };
        burdenPerHour: number;
        costPerHundred: number;
        billRatePreHundred: number;
        date: string;
        isRowActive: boolean;
      };
      taxJurisdictions: {
        id: string;
        name: string;
        type: string;
        isRowActive: boolean;
      }[];
      unemploymentJurisdictions: {
        id: string;
        lkStates: {
          state: string;
          stateName: string;
          isRowActive: boolean;
        };
        minWage: number;
        maxWage: number;
        rate: number;
        federalCreditRate: number;
        employeeRate: number;
        companyRate: number;
        status: string;
        statusTs: string;
        isRowActive: boolean;
      }[];
      sickPayJurisdictions: {
        id: string;
        state: string;
        effectiveDate: string;
        anniversaryMethod: {
          anniversaryMethod: string;
          label: string;
          isRowActive: boolean;
        };
        vestingDays: number;
        suspendedDays: number;
        loseAfterDays: number;
        accrualHours: number;
        workedHours: number;
        maxCarryForwardHours: number;
        maxPerYearHours: number;
        minConsumableHours: number;
        isRowActive: boolean;
      }[];
      rowActive: boolean;
      clientTerms: {
        id: {
          branchId: string;
          clientAppTermId: string;
        };
        branch: string;
        clientAppTerm: {
          clientAppTermId: string;
          isRowActive: boolean;
          clientAppTermIdLabel: string;
          clientAppTermFileUri: string;
          sortOrder: number;
          approvalRequestTs: string;
        };
        isRowActive: boolean;
      }[];
      workerTerms: {
        id: {
          branchId: string;
          workerAppTermId: string;
        };
        branch: string;
        workerAppTerm: {
          id: string;
          isRowActive: boolean;
          workerAppTermIdLabel: string;
          workerAppTermFileUri: string;
          workerAppTermEsFileUri: string;
          sortOrder: number;
          approvalRequestTs: string;
          branchWorkerAppTerms: string[];
        };
        isRowActive: boolean;
      }[];
      createdAt: string;
      createdBy: string;
      modifiedBy: string;
      modifiedAt: string;
      clientAppTerms: {
        clientAppTermId: string;
        isRowActive: boolean;
        clientAppTermIdLabel: string;
        clientAppTermFileUri: string;
        sortOrder: number;
        approvalRequestTs: string;
      }[];
      workerAppTerms: {
        id: string;
        isRowActive: boolean;
        workerAppTermIdLabel: string;
        workerAppTermFileUri: string;
        workerAppTermEsFileUri: string;
        sortOrder: number;
        approvalRequestTs: string;
        branchWorkerAppTerms: string[];
      }[];
    };
    isRowActive: boolean;
  }[];
  isRowActive: boolean;
  enabled: boolean;
  username: string;
  authorities: {
    authority: string;
  }[];
  accountNonExpired: boolean;
  accountNonLocked: boolean;
  credentialsNonExpired: boolean;
  roles: {
    role: string;
    description: string;
    isRowActive: boolean;
  }[];
};
