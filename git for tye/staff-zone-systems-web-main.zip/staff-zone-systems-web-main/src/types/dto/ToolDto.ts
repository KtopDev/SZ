import { ToolRequest } from '../forms/Tools';

export type ToolDto = {
  tool_id: string;
  branch_id: string;
  tool_name: string;
  ocurrences: string;
  total_rows: string;
  branch_name: string;
  modified_at: string;
  tool_abreviation: string;
  tool_description: string;
};

export const convertToolDtoToToolRequest = (dto: ToolDto): ToolRequest => {
  return {
    id: dto.tool_id,
    toolName: dto.tool_name,
    toolAbbreviation: dto.tool_abreviation,
    toolDescription: dto.tool_description,
    branchId: dto.branch_id ?? '',
  };
}
