export interface UpdateClientTermsOrderDto {
  termsOrder: UpdateClientTermsOrderItem[];
}

export interface UpdateClientTermsOrderItem {
  client_app_term_id: string;
  sort_order: number;
}

export interface UpdateWorkerTermsOrderDto {
  termsOrder: UpdateWorkerTermsOrderItem[];
}

export interface UpdateWorkerTermsOrderItem {
  worker_app_term_id: string;
  sort_order: number;
}
