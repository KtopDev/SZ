export type SickPayDto = {
  state: string;
  state_name: string;
  total_rows: string;
  vesting_days: number;
  worked_hours: number;
  accrual_hours: number;
  efective_date: string;
  suspended_days: number;
  lose_after_days: number;
  max_unused_hours: number;
  anniversary_method: string;
  max_per_year_hours: number;
  min_consumable_hours: number;
  max_carry_forward_hours: number;
  anniversary_method_label: string;
  sick_pay_jurisdiction_id: string;
};
