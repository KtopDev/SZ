export type TaxDto = {
  tax_id: string;
  tax_form_name: string;
  jurisdiction: string;
  tax_start_date: string;
  tax_last_updated: string;
};
