export type PPERequest = {
  id?: string;
  ppeName: string;
  ppeAbbreviation: string;
  ppeDescription: string;
  branchId: string | null;
};
