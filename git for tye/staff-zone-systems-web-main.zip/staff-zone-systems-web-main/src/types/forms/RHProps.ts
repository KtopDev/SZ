import {
  Control,
  FieldErrors,
  FieldValues,
  UseFormGetValues,
  UseFormRegister,
  UseFormSetValue,
  UseFormTrigger,
} from 'react-hook-form';

export interface ReactHookProps<T extends FieldValues> {
  register?: UseFormRegister<T>;
  control: Control<T>;
  errors: FieldErrors<T>;
  errorMessage?: string;
  getValues?: UseFormGetValues<T>;
  setValue?: UseFormSetValue<T>;
  required?: boolean;
  minLength?: number;
  maxLength?: number;
  min?: number;
  max?: number;
  trigger?: UseFormTrigger<T>;
  isIp?: boolean;
  isLatLong?: boolean;
  isEmail?: boolean;
  customMessages?: {
    min?: string;
    max?: string;
    minLength?: string;
    maxLength?: string;
    pattern?: string;
  };
}

export interface FormElementProps<T extends FieldValues> {
  label: string;
  propName: keyof T;
  rhProps: ReactHookProps<T>;
}
