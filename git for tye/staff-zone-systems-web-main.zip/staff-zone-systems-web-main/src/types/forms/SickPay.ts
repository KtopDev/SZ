import { SickPayDto } from '../dto/SickPayDto';

export type SickPayRequest = {
  state: string;
  effectiveDate: string;
  anniversaryMethod: string;
  vestingDays: number;
  suspendedDays: number;
  loseAfterDays: number;
  accrualHours: number;
  workedHours: number;
  maxCarryForwardHours: number;
  maxPerYearHours: number;
  maxUnusedHours: number;
  minConsumableHours: number;
};

export const transformSickPayDtoToRequest = (dto: SickPayDto): SickPayRequest => {
  return {
    state: dto.state,
    effectiveDate: dto.efective_date,
    anniversaryMethod: dto.anniversary_method,
    vestingDays: dto.vesting_days,
    suspendedDays: dto.suspended_days,
    loseAfterDays: dto.lose_after_days,
    accrualHours: dto.accrual_hours,
    workedHours: dto.worked_hours,
    maxCarryForwardHours: dto.max_carry_forward_hours,
    maxPerYearHours: dto.max_per_year_hours,
    maxUnusedHours: dto.max_unused_hours,
    minConsumableHours: dto.min_consumable_hours,
  };
};
