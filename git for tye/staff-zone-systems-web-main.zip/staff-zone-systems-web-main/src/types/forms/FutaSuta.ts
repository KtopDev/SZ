export type FutaSutaRequest = {
  jurisdiction: string;
  minWage: string;
  maxWage: string;
  rate: string;
  federalCreditRate: string;
  employeeRate: string;
  companyRate: string;
};

export type FutaSutaDto = {
  id: string;
  lkStates: {
    state: string;
    stateName: string;
    isRowActive: boolean;
  };
  minWage: number;
  maxWage: number;
  rate: number;
  federalCreditRate: number;
  employeeRate: number;
  companyRate: number;
  status: string;
  isRowActive: null | boolean;
  createdAt: null | string;
  createdBy: null | string;
  modifiedBy: null | string;
  modifiedAt: null | string;
};

export const convertToFutaSutaRequest = (dto: FutaSutaDto): FutaSutaRequest => {
  return {
    jurisdiction: dto.lkStates.state,
    minWage: dto.minWage?.toString() || '',
    maxWage: dto.maxWage?.toString() || '',
    rate: dto.rate?.toString() || '',
    federalCreditRate: dto.federalCreditRate?.toString() || '',
    employeeRate: dto.employeeRate?.toString() || '',
    companyRate: dto.companyRate?.toString() || '',
  };
};
