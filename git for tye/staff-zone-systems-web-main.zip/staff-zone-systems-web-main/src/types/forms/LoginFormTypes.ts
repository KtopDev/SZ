export type Login = {
  userType: string;
  username: string;
  password: string;
};

export type MFA = {
  code: string;
};
