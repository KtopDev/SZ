export type SiteRequirementRequest = {
  id?: string;
  siteRequirementName: string;
  siteRequirementDescription: string;
  branch: {
    id: string;
    name: string;
  };
};
