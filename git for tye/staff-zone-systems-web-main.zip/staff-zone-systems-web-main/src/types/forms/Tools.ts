export type ToolRequest = {
  id?: string;
  toolName: string;
  toolAbbreviation: string;
  toolDescription: string;
  branchId: string | null;
};
