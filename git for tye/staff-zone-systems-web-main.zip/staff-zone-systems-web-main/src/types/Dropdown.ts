export interface Dropdown {
  dropdown: SelectOption[];
}

export interface SelectOption {
  id: string | number;
  displayName: string | number;
}

export const anniversaryOptions = {
  dropdown: [
    { id: 'START_DATE', displayName: 'Start date' } as SelectOption,
    { id: 'LAST_SICK_LEAVE', displayName: 'Last sick leave date' } as SelectOption,
    { id: 'BEGINNING_OF_YEAR', displayName: 'Beginning of the year' } as SelectOption,
  ] as SelectOption[],
};
// prettier-ignore
export const displayAnniversaryOpt = (id: string) => {
  switch (id) {
  case '1':
    return 'Start date';
  case '2':
    return 'Last sick leave date';
  case '3':
    return 'Beginning of the year';
  default:
    return '';
  }
};
