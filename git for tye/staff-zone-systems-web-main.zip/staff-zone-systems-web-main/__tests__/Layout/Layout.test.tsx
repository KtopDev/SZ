import { render, screen } from '@testing-library/react';
import Layout from '@/components/Layout';

describe('Layout Component', () => {
  it('should render component correctly', () => {
    render(<Layout>content</Layout>);
    expect(screen.getByText('Staff Zone')).toBeInTheDocument();
  });
});
