import React from "react";

import "@testing-library/jest-native/";
import { render } from "@testing-library/react-native";

import { NavigationContainer } from "@react-navigation/native";
import { StackNavigator } from "navigation/stack-navigator";


test("Is the Profile screen being rendered", () => {
  const screen = render(
    <NavigationContainer>
      <StackNavigator />
    </NavigationContainer>
  );

  expect(screen.getByText("My Profile")).toBeOnTheScreen();
});
