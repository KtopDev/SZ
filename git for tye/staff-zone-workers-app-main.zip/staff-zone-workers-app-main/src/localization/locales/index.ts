export { default as en } from "./en.json";
export { default as es } from "./es.json";
