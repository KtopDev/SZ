import React from "react";

import { createNativeStackNavigator } from "@react-navigation/native-stack";

import { HomeScreen, ProfileScreen } from "screens";

import { RouteNames } from "./route-names";

export type AppStackParamList = {
  [RouteNames.home]: undefined;
  [RouteNames.profile]: undefined;
};

const Stack = createNativeStackNavigator<AppStackParamList>();

export const StackNavigator = () => (
  <Stack.Navigator screenOptions={{ headerShown: false }}>
    <Stack.Screen name={RouteNames.home} component={HomeScreen} />
    <Stack.Screen name={RouteNames.profile} component={ProfileScreen} />
  </Stack.Navigator>
);
