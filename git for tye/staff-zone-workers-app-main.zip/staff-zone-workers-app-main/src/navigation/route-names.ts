export enum RouteNames {
  home = "Home",
  profile = "Profile",
}
