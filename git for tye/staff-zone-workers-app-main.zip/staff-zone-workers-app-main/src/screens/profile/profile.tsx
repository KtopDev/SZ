import React from "react";

import styled from "styled-components/native";

export const ProfileScreen = () => (
  <Container>
    <Text>My Profile</Text>
  </Container>
);

const Text = styled.Text`
  font-size: 18px;
  color: black;
  font-weight: 500;
`;

const Container = styled.View`
  flex: 1;
  align-items: center;
  justify-content: center;
`;
