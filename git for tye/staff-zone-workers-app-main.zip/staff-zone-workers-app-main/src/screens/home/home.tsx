import React from "react";

import { useTranslation } from "react-i18next";
import styled from "styled-components/native";

export const HomeScreen = () => {
  const { t, i18n } = useTranslation();

  return (
    <Container>
      <Text>{t("screens.intro.text.introText")}</Text>
      <Button onPress={() => i18n.changeLanguage("en")}>
        <ButtonText>English</ButtonText>
      </Button>
      <Button onPress={() => i18n.changeLanguage("es")}>
        <ButtonText>Spanish</ButtonText>
      </Button>
    </Container>
  );
}

const Button = styled.TouchableOpacity`
  background-color: blue;
  padding: 16px;
  align-items: center;
  justify-content: center;
  width: 150px;
  margin: 12px 0px 12px 0px;
`;

const Text = styled.Text`
  font-size: 18px;
  color: black;
  font-weight: 500;
`;

const ButtonText = styled.Text`
  font-size: 14px;
  color: white;
  font-weight: 500;
`;

const Container = styled.View`
  flex: 1;
  align-items: center;
  justify-content: center;
`;