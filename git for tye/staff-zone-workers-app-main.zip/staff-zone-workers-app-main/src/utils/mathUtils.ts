export function addNumbers(x: number, y: number) {
  return x + y;
}
