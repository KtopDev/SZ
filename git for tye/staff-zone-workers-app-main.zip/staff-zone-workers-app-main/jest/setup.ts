import "react-native-gesture-handler/jestSetup";

// Import Jest Native matchers
// import '@testing-library/jest-native/extend-expect';

// Mock Async storage
import mockAsyncStorage from '@react-native-async-storage/async-storage/jest/async-storage-mock';
jest.mock('@react-native-async-storage/async-storage', () => mockAsyncStorage);