# staff-zone-systems-api

* Remember to add in your "/etc/hosts" file, the next: <br>
   - 127.0.0.1  &emsp;&emsp;&emsp;   local-db.szd.com
   - 127.0.0.1  &emsp;&emsp;&emsp;   local-wiremock.szd.com

* Install Docker on your local environment and execute the **docker-compose.yml** file
* Configure IDE checkstyle plugin with config/checkstyle/custom_checks.xml