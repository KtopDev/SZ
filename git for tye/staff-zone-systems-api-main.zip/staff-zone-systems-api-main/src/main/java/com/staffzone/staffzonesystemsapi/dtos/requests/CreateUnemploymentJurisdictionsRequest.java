package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.staffzone.staffzonesystemsapi.annotations.ValidWage;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;
import org.hibernate.validator.constraints.Length;

/**
 * Create Unemployment Jurisdictions Request DTO.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@ValidWage
public class CreateUnemploymentJurisdictionsRequest {
  @NotNull(message = "The jurisdiction cannot be empty.")
  @Length(min = 2, max = 2, message = "The jurisdiction must have 2 characters.")
  private String jurisdiction;
  @NotNull(message = "The minWage cannot be empty.")
  private BigDecimal minWage;
  @NotNull(message = "The maxWage cannot be empty.")
  private BigDecimal maxWage;
  @NotNull(message = "The rate cannot be empty.")
  private BigDecimal rate;
  @NotNull(message = "The federalCreditRate cannot be empty.")
  private BigDecimal federalCreditRate;
  @NotNull(message = "The employeeRate cannot be empty.")
  private BigDecimal employeeRate;
  @NotNull(message = "The companyRate cannot be empty.")
  private BigDecimal companyRate;


  @SneakyThrows
  @JsonIgnore
  public String toDBJson() {
    Map map = new HashMap<>();
    map.put("min_wage", getMinWage());
    map.put("max_wage", getMaxWage());
    map.put("state", getJurisdiction());
    map.put("rate", getRate());
    map.put("federal_credit_rate", getFederalCreditRate());
    map.put("employee_rate", getEmployeeRate());
    map.put("company_rate", getCompanyRate());
    ObjectMapper mapper = new ObjectMapper();
    return mapper.writeValueAsString(map);
  }
}
