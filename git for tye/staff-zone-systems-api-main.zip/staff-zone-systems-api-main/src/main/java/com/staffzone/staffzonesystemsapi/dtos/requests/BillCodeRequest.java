package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillCodeRequest {
  @NotBlank(message = "Bill Code Name cannot be blank")
  private String billCodeName;
  @NotBlank(message = "Bill Code Description cannot be blank")
  private String billCodeDescription;
}
