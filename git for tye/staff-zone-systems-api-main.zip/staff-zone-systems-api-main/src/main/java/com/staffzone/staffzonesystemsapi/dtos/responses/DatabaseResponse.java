package com.staffzone.staffzonesystemsapi.dtos.responses;

import lombok.Data;

@Data
public class DatabaseResponse<T> {
  private Boolean isProcessed;
  private String message;
  private T entity;
}
