package com.staffzone.staffzonesystemsapi.annotations;


import com.staffzone.staffzonesystemsapi.validators.WageConstraintValidator;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.*;

@Documented
@Constraint(validatedBy = WageConstraintValidator.class)
@Target({ ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidWage {
  String message() default "Max wage must be greater than or equal to min wage";
  Class<?>[] groups() default {};
  Class<? extends Payload>[] payload() default {};
}