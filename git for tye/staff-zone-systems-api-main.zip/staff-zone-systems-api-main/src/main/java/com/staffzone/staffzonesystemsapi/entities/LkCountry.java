package com.staffzone.staffzonesystemsapi.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.ColumnDefault;

/**
 * Entity mapped against "<strong>LkCountry</strong>" Table.
 */
@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Table(name = "lk_countries")
public class LkCountry extends Audit {
  @NotNull
  @ColumnDefault("true")
  @Column(name = "is_row_active", nullable = false)
  private Boolean isRowActive = false;

  @Id
  @Column(name = "country_code", length = 2, nullable = false)
  private String country;

  @Column(name = "country_name", nullable = false)
  private String countyName;

}
