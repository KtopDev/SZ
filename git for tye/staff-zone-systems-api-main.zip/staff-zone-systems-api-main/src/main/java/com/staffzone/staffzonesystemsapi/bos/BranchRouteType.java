package com.staffzone.staffzonesystemsapi.bos;

public enum BranchRouteType {
  PUBLIC_TRANSPORTATION, VAN, OTHER, COWORKER, UNASSIGNED
}
