package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.staffzone.staffzonesystemsapi.validators.Uuid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Project Certified Payroll Settings Request DTO.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProjectCertifiedPayrollSettingsRequest {
  @NotBlank(message = "Job Name cannot be blank")
  private String jobName;
  @Uuid
  @NotBlank(message = "Printing Format Id cannot be blank")
  private String printingFormatId;
  @Pattern(regexp = "^\\d{10}$",
          message = "Contact Phone must have at maximum 10 digits.")
  @Size(max = 10, message = "Contact Phone cannot exceed 10 chars")
  @NotBlank(message = "Contact Phone cannot be blank")
  private String contactPhone;
  @NotBlank(message = "Payroll Report cannot be blank")
  private String payrollReport;
  @NotBlank(message = "Payroll Number cannot be blank")
  private String payrollNumber;
  @NotBlank(message = "Wage Decision Number cannot be blank")
  private String wageDecisionNumber;
  @NotBlank(message = "Address cannot be blank")
  private String address;
  private String addressLine2;
  @NotBlank(message = "City cannot be blank")
  private String city;
  @NotBlank(message = "State cannot be blank")
  private String state;
  @NotBlank(message = "Postal code cannot be blank")
  private String postalCode;
  @Pattern(regexp = "^\\d{10}$",
          message = "Phone must have at maximum 10 digits.")
  @Size(max = 10, message = "Phone cannot exceed 10 chars")
  @NotBlank(message = "Phone cannot be blank")
  private String phone;
  @Pattern(regexp = "^\\d{10}$",
          message = "Fax must have at maximum 10 digits.")
  @Size(max = 10, message = "Fax cannot exceed 10 chars")
  private String fax;
}
