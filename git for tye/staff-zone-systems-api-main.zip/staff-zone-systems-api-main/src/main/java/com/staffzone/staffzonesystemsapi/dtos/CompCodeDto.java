package com.staffzone.staffzonesystemsapi.dtos;

import com.staffzone.staffzonesystemsapi.entities.CompCodes;
import com.staffzone.staffzonesystemsapi.entities.LkStates;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Comp Code DTO.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class CompCodeDto {
  private UUID compCodeId;
  private String compCode;
  private String description;
  private String billingInformation;
  private LkStates state;
  private BigDecimal burdenPerHour;
  private BigDecimal costPerHundred;
  private LocalDate effectiveDate;
  private Boolean status;

  /**
   * build.
   *
   * @param compCodes {@link CompCodes}
   * @return {@link CompCodeDto}
   */
  public static CompCodeDto build(CompCodes compCodes) {
    return CompCodeDto.builder()
            .compCodeId(compCodes.getCompCodeId())
            .compCode(compCodes.getCompCode())
            .description(compCodes.getCompCodeDescription())
            .billingInformation(compCodes.getCompCodeBillingDescription())
            .state(compCodes.getLkState())
            .burdenPerHour(compCodes.getBurdenPerHour())
            .costPerHundred(compCodes.getCostPerHundred())
            .effectiveDate(compCodes.getDate())
            .status(compCodes.getIsRowActive())
            .build();
  }
}
