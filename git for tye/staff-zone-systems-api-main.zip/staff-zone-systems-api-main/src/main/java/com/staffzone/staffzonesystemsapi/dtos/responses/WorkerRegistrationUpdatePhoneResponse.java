package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.*;

/**
 * Worker Update Phone response.
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class WorkerRegistrationUpdatePhoneResponse {

  private String status;
  private String verificationCode;
  private String message;

  @JsonIgnore
  public String getVerificationCode() {
        return verificationCode;
    }

  @JsonSetter("verification_code")
  public void setVerificationCode(String verificationCode) {
        this.verificationCode = verificationCode;
    }

  @JsonIgnore
  public String getMessage() {
    return message;
  }

  @JsonSetter("message")
  public void setMessage(String message) {
    this.message = message;
  }

  @JsonIgnore
  public String getStatus() {
    return status;
  }

  @JsonSetter("status")
  public void setStatus(String status) {
    this.status = status;
  }
}
