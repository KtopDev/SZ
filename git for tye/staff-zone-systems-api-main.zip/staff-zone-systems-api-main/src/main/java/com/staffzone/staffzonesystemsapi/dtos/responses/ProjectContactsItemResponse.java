package com.staffzone.staffzonesystemsapi.dtos.responses;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Project Contacts Item Response Dto.
 * <pre>{@code
 *    {
 *      "contact_id":                              "string"
 *      "name":                                    "string"
 *      "email":                                   "string"
 *      "phone":                                   "String"
 *      "last_name":                               "string"
 *      "active_projects":                          [... ]
 *      "can_receibe_invoices":                    "Boolean"
 *      "is_app_access_enabled":                   "Boolean"
 *      "multi_factor_authentication_ttl_days":    "Integer"
 *      "multi_factor_authentication_preference":  "string"
 *    }
 * }</pre>
 */
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class ProjectContactsItemResponse {
  private String name;
  private String email;
  private String phone;
  private String last_name;
  private String contact_id;
  private List<String> active_projects;
  private Boolean can_receibe_invoices;
  private Boolean is_app_access_enabled;
  private Integer multi_factor_authentication_ttl_days;
  private String multi_factor_authentication_preference;
}
