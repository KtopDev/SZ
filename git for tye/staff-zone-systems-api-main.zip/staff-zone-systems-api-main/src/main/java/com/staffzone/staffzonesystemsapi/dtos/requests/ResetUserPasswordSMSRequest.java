package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.staffzone.staffzonesystemsapi.bos.UserType;
import com.staffzone.staffzonesystemsapi.validators.ValueOfEnum;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Reset Password Request Data DTO.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ResetUserPasswordSMSRequest {
    @NotNull
    @ValueOfEnum(enumClass = UserType.class)
    private String userType;
    @NotBlank(message = "Phone cannot be blank")
    private String phone;

}
