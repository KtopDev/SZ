package com.staffzone.staffzonesystemsapi.bos;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Dropdown Options: <br/>
 * {@link #CHECK_FORMATS},<br/>
 * {@link #COMP_CODES},<br/>
 * {@link #DEPOSIT_ADVICE_FORMAT},<br/>
 * {@link #FUTA_SUTA_SDI},<br/>
 * {@link #PAY_CHECK_FORMATS},<br/>
 * {@link #INVOICE_FORMATS},<br/>
 * {@link #PAY_CYCLES},<br/>
 * {@link #PAY_RULES},<br/>
 * {@link #STATES},<br/>
 * {@link #TAX_JURISDICTIONS}<br/>
 * {@link #BRANCHES}<br/>
 * {@link #INVOICE_METHODS}<br/>
 * {@link #PAYMENT_TERMS}<br/>
 * {@link #JOB_TITLES}<br/>
 * {@link #APP_CLAIMS}<br/>
 * {@link #APP_ROLES}<br/>
 * {@link #SKILL_GROUPS}<br/>
 * {@link #CLIENT_CONTACTS}<br/>
 * {@link #PAY_CODES}<br/>
 * {@link #SITE_REQUIREMENTS}.
 *
 */
@Getter
@AllArgsConstructor
public enum DropdownType {
  CHECK_FORMATS("check-formats"),
  COMP_CODES("comp-codes"),
  DEPOSIT_ADVICE_FORMAT("deposit-advice-format"),
  FUTA_SUTA_SDI("futa-suta-sdi"),
  PAY_CHECK_FORMATS("pay-check-formats"),
  INVOICE_FORMATS("invoice-formats"),
  PAY_CYCLES("pay-cycles"),
  PAY_RULES("pay-rules"),
  STATES("states"),
  TAX_JURISDICTIONS("tax-jurisdictions"),
  BRANCHES("branches"),
  INVOICE_METHODS("invoice-methods"),
  PAYMENT_TERMS("payment-terms"),
  JOB_TITLES("job-titles"),
  APP_CLAIMS("claims"),
  APP_ROLES("roles"),
  SKILL_GROUPS("skill-groups"),
  PROJECT_CONTACTS("project-contacts"),
  CLIENT_CONTACTS("client-contacts"),
  SALES_CLOSERS("sales-closers"),
  PAY_CODES("pay-codes"),
  SITE_REQUIREMENTS("site-requirements"),
  CERTIFICATIONS("certifications"),
  SKILLS("skills"),
  PPES("ppes"),
  TOOLS("tools"),
  SKILL_TIERS("skill-tiers"),
  BILL_CODES("bill-codes"),
  SMS_MESSAGE_TEMPLATES("sms-message-templates"),
  PROJECT_DOCUMENT_TYPES("project-document-types"),
  RATE_AGREEMENT_TYPES("rate-agreement-types"),
  DISCIPLINARY_WARNING_TYPES("disciplinary-warning-types"),
  WORKER_DOCUMENT_TYPES("worker-document-types"),
  COUNTRIES("countries");

  private final String value;

  /**
   * Look up.
   *
   * @param name <strong>i.e:</strong> CHECK_FORMATS
   * @return <strong>i.e:</strong> check-formats <br><strong>It can return NULL</strong>
   */
  public static DropdownType of(String name) {
    for (DropdownType d : DropdownType.values()) {
      if (d.value.equals(name)) {
        return d;
      }
    }
    return null;
  }
}
