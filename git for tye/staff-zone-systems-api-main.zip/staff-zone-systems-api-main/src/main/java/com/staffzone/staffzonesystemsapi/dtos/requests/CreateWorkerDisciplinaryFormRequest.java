package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.staffzone.staffzonesystemsapi.validators.Uuid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Worker CreateWorkerDisciplinaryForm Request DTO.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class CreateWorkerDisciplinaryFormRequest {

  @Uuid
  @NotBlank(message = "Project Order Id cannot be blank")
  private String orderId;
  @Size(max = 50, message = "Warning type cannot exceed 50 chars")
  @NotNull(message = "Warning type cannot be null")
  private String warningType;
  @NotNull(message = "Form date cannot be null")
  private LocalDate formDate;
  @NotNull(message = "Infraction date cannot be null")
  @NotEmpty(message = "Infraction date cannot be empty")
  private String infraction;
  @NotNull(message = "Expected Behavior cannot be null")
  @NotEmpty(message = "Expected Behavior cannot be empty")
  private String expectedBehavior;

}
