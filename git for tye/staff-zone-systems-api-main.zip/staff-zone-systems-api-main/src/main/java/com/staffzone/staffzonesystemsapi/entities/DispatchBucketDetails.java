package com.staffzone.staffzonesystemsapi.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

/**
 * Entity mapped against "<strong>dispatch_bucket_details</strong>" Table.
 */
@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "dispatch_bucket_details")
public class DispatchBucketDetails extends Audit {
  @Id
  @Column(name = "dispatch_bucket_detail_id", nullable = false)
  private UUID dispatchBucketDetailId;

  @NotNull
  @Column(name = "dispatch_bucket_id", nullable = false)
  private UUID dispatchBucketId;

  @NotNull
  @Column(name = "project_id", nullable = false)
  private UUID projectId;

  @NotNull
  @Column(name = "order_id", nullable = false)
  private UUID orderId;

  @NotNull
  @Column(name = "project_worker_based_billing_id", nullable = false)
  private UUID projectWorkerBasedBillingId;

  @NotNull
  @Column(name = "slots")
  private Integer slots;

  @NotNull
  @Column(name = "additional_slots")
  private Integer additionalSlots;

  @Builder.Default
  @NotNull
  @Column(name = "is_row_active", nullable = false)
  private Boolean isRowActive = true;
}