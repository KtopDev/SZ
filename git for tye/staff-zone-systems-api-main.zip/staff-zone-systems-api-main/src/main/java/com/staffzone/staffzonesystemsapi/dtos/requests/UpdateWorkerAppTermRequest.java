package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotNull;
import com.staffzone.staffzonesystemsapi.validators.Pdf;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;
import org.springframework.web.multipart.MultipartFile;

/**
 * Update Worker App Terms Request DTO.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@FieldNameConstants
public class UpdateWorkerAppTermRequest {
  @NotNull(message = "File name cannot be null.")
  private String fileName;
  @Pdf(allowNull = true)
  private MultipartFile document;
  @Pdf(allowNull = true)
  private MultipartFile spanishDocument;
}
