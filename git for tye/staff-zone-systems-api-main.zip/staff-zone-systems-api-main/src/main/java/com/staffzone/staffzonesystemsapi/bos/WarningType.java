package com.staffzone.staffzonesystemsapi.bos;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * AuthStatusType: <br/>
 * {@link #NO_WARNINGS},<br/>
 * {@link #WARNINGS},<br/>
 * {@link #BLOCKED}.
 *
 */
@Getter
@AllArgsConstructor
public enum WarningType {
  NO_WARNINGS,
  WARNINGS,
  BLOCKED;
}
