package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Ledger Account Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchLedgerAccountItemResponse {
  @JsonAlias(value = "ledger_account")
  private String account;
  @JsonAlias(value = "ledger_account_name")
  private String accountName;
  @JsonAlias(value = "total_rows")
  private String totalRows;
  @JsonAlias(value = "modified_at")
  private String modifiedAt;
}
