package com.staffzone.staffzonesystemsapi.dtos.requests;

import static com.staffzone.staffzonesystemsapi.utils.StringUtils.toSnakeCase;
import static org.springframework.data.domain.Sort.Direction.ASC;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.staffzone.staffzonesystemsapi.bos.PayCardStatusType;
import com.staffzone.staffzonesystemsapi.exceptions.BusinessException;
import com.staffzone.staffzonesystemsapi.validators.SortOptions;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import net.minidev.json.JSONObject;

/**
 * Search Worker Pay History Request DTO.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class SearchWorkerPayHistoryRequest extends SearchAbstractRequest {
  private String status;
  private LocalDate dateStart;
  private LocalDate dateEnd;
  @SortOptions(anyOf = {"created_at", "status", "status_by_name"})
  private String sort;

  /**
   * Get sort as Json.
   *
   * @return String
   */
  @JsonIgnore
  public String getSortAsJson() {
    JSONObject jsonObject = new JSONObject();
    jsonObject.put("limit", super.getSize());

    var offset = (super.getPage() - 1) * super.getSize();
    jsonObject.put("offset", offset);

    if (sort == null || sort.isBlank()) {
      jsonObject.put("sort_column", "created_at");
      jsonObject.put("sort_direction", ASC.name());
    } else {
      String[] options = sort.split(",");
      jsonObject.put("sort_column", toSnakeCase(options[0]));
      jsonObject.put("sort_direction", options[1].toUpperCase());
    }
    return jsonObject.toJSONString();
  }

  public String[] getStatus() {
    if (status == null || status.isBlank()) {
      return null;
    }

    String[] statuses = status.split(",");
    List<String> validStatuses = new ArrayList<>();

    for (String s : statuses) {
      PayCardStatusType statusType = PayCardStatusType.of(s.trim());
      if (statusType == null) {
        throw new BusinessException(
                s, "Status must be either 'ACTIVE','ON-HOLD','INACTIVE','STOPPED','REPLACED'");
      }
      validStatuses.add(statusType.getValue());
    }

    return validStatuses.toArray(new String[0]);
  }

  public LocalDate getDateEnd() {
    if (dateEnd == null) {
      return null;
    }
    return dateEnd.plusDays(1);
  }
}
