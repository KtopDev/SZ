package com.staffzone.staffzonesystemsapi.bos;

/**
 * TaxFormQuestionType
 */
public enum TaxFormQuestionType {
  TEXT, NUMBER, DATE, SELECT, MULTI_SELECT
}
