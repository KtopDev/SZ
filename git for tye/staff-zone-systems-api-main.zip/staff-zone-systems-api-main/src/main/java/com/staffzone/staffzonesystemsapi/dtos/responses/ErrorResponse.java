package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.staffzone.staffzonesystemsapi.dtos.ErrorDetail;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Error Response.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ErrorResponse {
  private String code;
  private String message;
  private List<ErrorDetail> details = new ArrayList<>();

  public ErrorResponse(String code, String message) {
    this.code = code;
    this.message = message;
  }

  public void addDetail(String field, String message) {
    ErrorDetail errorDetail = new ErrorDetail(field, message);
    details.add(errorDetail);
  }

  public void addDetail(ErrorDetail errorDetail) {
    details.add(errorDetail);
  }

  public boolean hasErrors() {
    return details != null && !details.isEmpty();
  }
}