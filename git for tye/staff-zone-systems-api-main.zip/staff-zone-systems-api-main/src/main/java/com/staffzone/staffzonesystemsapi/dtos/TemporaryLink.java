
package com.staffzone.staffzonesystemsapi.dtos;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import net.minidev.json.annotate.JsonIgnore;

import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@Builder
@AllArgsConstructor
@EqualsAndHashCode
public class TemporaryLink {
  private UUID id;
  private String url;
  @JsonIgnore
  private String urlKey;
  private String email;
  private LocalDateTime expireDate;

  public boolean isExpired() {
    return expireDate!=null && LocalDateTime.now().isAfter(expireDate);
  }
}
