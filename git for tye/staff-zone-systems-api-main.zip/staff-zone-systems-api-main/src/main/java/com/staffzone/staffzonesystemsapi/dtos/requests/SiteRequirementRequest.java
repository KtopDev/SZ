package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotBlank;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SiteRequirementRequest {
  @NotBlank(message = "Site Requirement Name cannot be blank")
  private String siteRequirementName;
  @NotBlank(message = "Site Requirement Description cannot be blank")
  private String siteRequirementDescription;
  private UUID branchId;

}
