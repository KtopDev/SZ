package com.staffzone.staffzonesystemsapi.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.ColumnDefault;

/**
 * Entity mapped against "<strong>LkDisciplinaryWarningType</strong>" Table.
 */
@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Table(name = "lk_disciplinary_warning_types")
public class LkDisciplinaryWarningType extends Audit {
  @NotNull
  @ColumnDefault("true")
  @Column(name = "is_row_active", nullable = false)
  private Boolean isRowActive = false;

  @Id
  @Column(name = "warning_type")
  private String warningType;

  @Column(name = "warning_type_name")
  private String warningTypeName;
}
