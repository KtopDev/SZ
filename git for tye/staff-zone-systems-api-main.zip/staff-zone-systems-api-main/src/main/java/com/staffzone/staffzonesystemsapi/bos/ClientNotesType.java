package com.staffzone.staffzonesystemsapi.bos;

/**
 * ClientNotesType: <br/>
 * {@link #GENERAL_NOTE},<br/>
 * {@link #CREDIT_AND_COLLECTIONS},<br/>
 * {@link #HUMAN_RESOURCES},<br/>
 * {@link #SALES_SERVICE}.
 */
public enum ClientNotesType {
  GENERAL_NOTE, CREDIT_AND_COLLECTIONS, HUMAN_RESOURCES, SALES_SERVICE;

  public static ClientNotesType of(String str) {
    ClientNotesType result = null;
    if (str == null) {
      return result;
    }

    for (ClientNotesType type : values()) {
      if (str.toUpperCase().equals(type.name())) {
        result = type;
      }
    }

    return result;
  }
}
