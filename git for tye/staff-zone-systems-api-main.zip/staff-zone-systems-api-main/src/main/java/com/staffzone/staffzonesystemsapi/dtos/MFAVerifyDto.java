package com.staffzone.staffzonesystemsapi.dtos;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
@AllArgsConstructor
public class MFAVerifyDto {
    private String token;
    private String email;
}
