package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Compliant Request DTO.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class CompliantsRequest {
  @NotNull(message = "Complaint cannot be null")
  @NotEmpty(message = "Complaint cannot be blank")
  private String complaint;
}
