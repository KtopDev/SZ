package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.staffzone.staffzonesystemsapi.validators.Uuid;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Worker Check-In Request.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WorkerCheckInRequest {
  @Uuid
  private String branchId;
  private Boolean canDrive;
  @PositiveOrZero
  private Integer passengersCount;

  public Boolean getCanDrive() {
    return canDrive != null && canDrive;
  }

  public Integer getPassengersCount() {
    return  (canDrive == null || !canDrive) ? null : passengersCount;
  }
}
