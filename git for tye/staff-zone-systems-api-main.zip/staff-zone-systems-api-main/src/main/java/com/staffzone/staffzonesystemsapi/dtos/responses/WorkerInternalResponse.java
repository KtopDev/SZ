package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonSetter;
import java.util.List;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Workers complete registration response.
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class WorkerInternalResponse {
  private UUID workerId;
  private UUID branchId;
  private UUID lastBranchId;
  private String branchName;
  private String lastBranchName;
  private String payFrequency;
  private String profileImage;
  private String lastActiveTs;
  private String email;
  private String phone;
  private String status;
  private String statusTs;
  private String firstName;
  private String lastName;
  private String otherNames;
  private String workerCode;
  private String signatureTs;
  private String dateOfBirth;
  private String middleInitial;
  private String signaturePath;
  private String address;
  @JsonSetter("address_line_2")
  private String addressLine2;
  private String city;
  private String state;
  private String postalCode;
  private String legalStatus;
  private String alienRegistrationNumber;
  @JsonSetter("i_94_number")
  private String i94Number;
  @JsonSetter("i9_status")
  private String i9Status;
  private String ssnNumber;
  private String passportNumber;
  private String passportCountryCode;
  private String termsAcceptance;
  private String passwordHash;
  private String passwordExpireTs;
  private String ccMaskedSsnNumber;
  private String phoneVerificationTs;
  private String isWithholdingIrsLocked;
  private String lastWithholdingReviewTs;
  private String LastWithholdingRequestTs;
  private String warnings;
  private String cardNumber;
  private String cardHolderName;
  private String payCardId;
  private String accountNumber;
  private String defaultPaymentMethod;
  private String directDepositAccount;
  private String directDepositRouting;
  private List<WorkerSkillsResponse> skills;
  private List<WorkerCertificationResponse> certifications;
  private List<WorkerEmergencyContact> emergencyContacts;
  private List<String> workerClientRestrictions;


  @JsonGetter("i94Number")
  private String getI94Number() {
    return i94Number;
  }

  @JsonGetter("addressLine2")
  private String getAddressLine2() {
    return addressLine2;
  }
}
