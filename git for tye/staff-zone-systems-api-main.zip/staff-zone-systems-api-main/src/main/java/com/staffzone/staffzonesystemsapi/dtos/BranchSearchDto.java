package com.staffzone.staffzonesystemsapi.dtos;

import com.staffzone.staffzonesystemsapi.entities.Branch;
import java.time.LocalDate;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class BranchSearchDto {
  private UUID branchId;
  private String branchName;
  private String phone;
  private String fax;
  private String address;
  private LocalDate modifiedAt;
  private String status;

  /**
   * BranchSearchDto builder.
   *
   * @param branch {@link Branch}
   * @return {@link BranchSearchDto}
   */
  public static BranchSearchDto build(Branch branch) {
    return BranchSearchDto.builder()
            .branchId(branch.getBranchId())
            .branchName(branch.getBranchName())
            .address(branch.getAddress())
            .phone(branch.getPhone())
            .fax(branch.getFax())
            .status(branch.getStatus())
            .modifiedAt(branch.getModifiedAt())
            .build();
  }
}
