package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Compliments Request Dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ComplimentsRequest {
  @NotBlank(message = "Compliments cannot be blank")
  private String compliments;
}
