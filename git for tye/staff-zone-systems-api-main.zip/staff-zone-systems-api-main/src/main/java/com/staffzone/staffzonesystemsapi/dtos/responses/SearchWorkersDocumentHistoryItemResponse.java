package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Worker Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchWorkersDocumentHistoryItemResponse {

  @JsonSetter(value = "file_name")
  private String fileName;
  @JsonSetter(value = "file_path")
  private String filePath;
  @JsonSetter(value = "created_at")
  private String created_at;
  @JsonSetter(value = "country_name")
  private String countryName;
  @JsonSetter(value = "document_number")
  private String documentNumber;
  @JsonSetter(value = "expiration_date")
  private String expirationDate;
  @JsonSetter(value = "total_rows")
  private String totalRows;
  @JsonSetter(value = "worker_document_id")
  private String workerDocumentId;
  @JsonSetter(value = "projects")
  private List<ProjectIdNameItemResponse> projects;
}
