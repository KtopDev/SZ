package com.staffzone.staffzonesystemsapi.dtos.responses;

import java.util.UUID;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Skill Response from create and edit skill stored procedure.
 */
@Data
@NoArgsConstructor
public class SkillResponse {
  private UUID skillId;
  private String branchId;
  private String skillName;
  private String skillGroup;
  private String skillDescription;
}
