package com.staffzone.staffzonesystemsapi.dtos.responses;

import java.util.UUID;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Client Contact Details DTO.
 */
@Data
@NoArgsConstructor
public class ClientContactDetails {
  private UUID contactId;
  private String contactName;
  private String contactLastName;
  private String contactEmail;
  private String contactPhone;

  public void setName(String contactName) {
    this.contactName = contactName;
  }

  public void setLastName(String contactLastName) {
    this.contactLastName = contactLastName;
  }

  public void setEmail(String contactEmail) {
    this.contactEmail = contactEmail;
  }

  public void setPhone(String contactPhone) {
    this.contactPhone = contactPhone;
  }
}
