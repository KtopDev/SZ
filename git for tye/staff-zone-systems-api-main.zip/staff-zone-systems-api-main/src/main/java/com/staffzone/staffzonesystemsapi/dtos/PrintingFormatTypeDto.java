package com.staffzone.staffzonesystemsapi.dtos;

import com.staffzone.staffzonesystemsapi.entities.LkPrintingFormatTypes;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Printing Format Type DTO.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class PrintingFormatTypeDto {
  private String printingFormatType;
  private String label;

  /**
   * Printing Formats build from LkPrintingFormatTypes.
   *
   * @param printingFormatType {@link LkPrintingFormatTypes}
   * @return PrintingFormatTypeDto
   */
  public static PrintingFormatTypeDto build(LkPrintingFormatTypes printingFormatType) {
    if (printingFormatType == null) {
      return null;
    }

    return PrintingFormatTypeDto.builder()
            .printingFormatType(printingFormatType.getPrintingFormatType())
            .label(printingFormatType.getLabel())
            .build();
  }
}
