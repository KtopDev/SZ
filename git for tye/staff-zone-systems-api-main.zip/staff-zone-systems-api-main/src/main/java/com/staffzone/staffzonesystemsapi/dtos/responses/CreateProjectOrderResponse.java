package com.staffzone.staffzonesystemsapi.dtos.responses;

import java.util.List;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Project Order Response DTO.
 */
@Getter
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class CreateProjectOrderResponse {
  private UUID orderId;
  private Boolean isRowActive = true;
  private UUID projectId;
  private String orderNumber;
  private String status;
  private String orderStartTs;
  private String statusTs;
  private List<CreateProjectOrderDetailsResponse> projectOrderDetails;
}
