package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Projects WBB Rates Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchProjectWBBRatesItemResponse {
  @JsonSetter(value = "total_rows")
  private String totalRows;
  @JsonSetter(value = "project_id")
  private String projectId;
  @JsonSetter(value = "project_worker_based_billing_id")
  private String projectWorkerBasedBillingId;
  @JsonSetter(value = "skill_tier")
  private String skillTier;
  @JsonSetter(value = "comp_code_id")
  private String compCodeId;
  @JsonSetter(value = "comp_code")
  private String compCode;
  @JsonSetter(value = "pay_rate")
  private String payRate;
  @JsonSetter(value = "bill_rate")
  private String billRate;
  @JsonSetter(value = "overtime_bill_rate")
  private String overtimeBillRate;
  @JsonSetter(value = "worker_id")
  private String workerId;
  @JsonSetter(value = "first_name")
  private String firstName;
  @JsonSetter(value = "last_name")
  private String lastName;
  @JsonSetter(value = "worker_code")
  private String workerCode;
  @JsonSetter(value = "profile_image")
  private String profileImage;
  @JsonSetter(value = "cp_wages_in_lieu")
  private String cpWagesInLieu;
  @JsonSetter(value = "status")
  private String status;
  @JsonSetter(value = "description")
  private String description;
  @JsonSetter(value = "skills")
  private List<SkillWBBItemResponse> skills;
  @JsonSetter(value = "certifications")
  private List<CertificationWBBItemResponse> certifications;
}
