package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.staffzone.staffzonesystemsapi.entities.AppUser.Fields;
import com.staffzone.staffzonesystemsapi.validators.SortOptions;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class SearchAppUserRequest extends SearchAbstractRequest {

    public final static String JOB_TITLE = "jobTitle";
    public final static String NAME = "name";

    @SortOptions(anyOf = {NAME, Fields.status, JOB_TITLE})
    private String sort;
    private String nameOrCode;
    @Pattern(regexp = "^$|Active|Inactive|ACTIVE|INACTIVE",
            message = "Status must be either 'Active', 'Inactive'")
    private String status;
    private String jobTitle;
}
