package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Question Request Dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QuestionsRequest {
  @NotBlank(message = "You must add a message")
  private String question;
}
