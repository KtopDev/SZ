package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.staffzone.staffzonesystemsapi.validators.SortOptions;
import com.staffzone.staffzonesystemsapi.validators.Uuid;
import jakarta.validation.constraints.Pattern;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import net.minidev.json.JSONObject;

import java.time.LocalDate;
import org.apache.commons.lang3.StringUtils;

import static com.staffzone.staffzonesystemsapi.utils.StringUtils.toSnakeCase;
import static org.apache.commons.lang3.StringUtils.isNotBlank;
import static org.springframework.data.domain.Sort.Direction.ASC;

/**
 * Search Worker Disciplinary Forms Request DTO.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class SearchWorkerNotesRequest extends SearchAbstractRequest{
  private String searchBy;
  @Pattern(regexp = "^$|GENERAL|COMMENT|COMPLAINT|WARNING",
      message = "Type must be either 'GENERAL','COMMENT','COMPLAINT' or 'WARNING'")
  private String noteType;
  private LocalDate dateStart;
  private LocalDate dateEnd;
  @SortOptions(anyOf = {"noteTitle","noteType","note","createdAt"})
  private String sort;

  /**
   * Get sort as Json.
   *
   * @return String
   */
  @JsonIgnore
  public String getSortAsJson() {
    JSONObject jsonObject = new JSONObject();
    jsonObject.put("limit", super.getSize());

    var offset = (super.getPage() - 1) * super.getSize();
    jsonObject.put("offset", offset);

    if (sort == null || sort.isBlank()) {
      jsonObject.put("sort_column", "branch_name");
      jsonObject.put("sort_direction", ASC.name());
    } else {
      String[] options = sort.split(",");
      jsonObject.put("sort_column", toSnakeCase(options[0]));
      jsonObject.put("sort_direction", options[1].toUpperCase());
    }
    return jsonObject.toJSONString();
  }

  public String getNoteType(){
    return isNotBlank(noteType) ? noteType : null;
  }

}
