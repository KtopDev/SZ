package com.staffzone.staffzonesystemsapi.dtos;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.UUID;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class SearchClientContactFilterDto {
  private UUID contactId;
  private String name;
  private LocalDate startDate;
  private LocalDate endDate;
}
