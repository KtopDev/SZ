package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Create Garnishments Vendor Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class GarnishmentsVendorResponse {
  private String city ;
  private String state;
  @JsonSetter("address_1")
  private String address1;
  @JsonSetter("address_2")
  private String address2;
  private String vendorId;
  private String stateName;
  private String postalCode;
  private String contactName;
  private String vendorTpId;
  private String contactEmail;
  private String contactPhone;
  @JsonSetter("vendor_name_1")
  private String vendorName1;
  @JsonSetter("vendor_name_2")
  private String vendorName2;
}
