package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.staffzone.staffzonesystemsapi.validators.Uuid;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import java.time.LocalDate;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;

/**
 * Tax Forms Request DTO.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxFormsRequest {
  @NotBlank(message = "name cannot be blank")
  private String name;
  @NotBlank(message = "taxJurisdictionId cannot be blank")
  @Uuid
  private String taxJurisdictionId;
  @NotNull(message = "promptAfterInactivityDays cannot be blank")
  @PositiveOrZero
  private Integer promptAfterInactivityDays;
  @NotNull(message = "effectiveFrom cannot be null")
  private LocalDate effectiveFrom;
  @NotNull(message = "expiresAfter cannot be null")
  private LocalDate expiresAfter;
  @NotEmpty(message = "questions cannot be blank")
  private List<@Valid TaxFormQuestionsRequest> questions;

  /**
   * Build JSON.
   *
   * @return String
   */
  @SneakyThrows
  @JsonIgnore
  public String toDbJson() {
    ObjectMapper mapper = new ObjectMapper();
    ObjectNode jsonObject = mapper.createObjectNode();
    jsonObject.put("form_name", name);
    jsonObject.put("tax_jurisdiction_id", taxJurisdictionId);
    jsonObject.put("effective_from", effectiveFrom.toString());
    jsonObject.put("expires_after", expiresAfter.toString());
    jsonObject.put("prompt_after_inactivity_days", promptAfterInactivityDays);
    ArrayNode questionsArray = mapper.createArrayNode();
    for (TaxFormQuestionsRequest question : questions) {
      questionsArray.add(question.asJsonNode(mapper));
    }
    jsonObject.set("tax_form_questions", questionsArray);
    return mapper.writeValueAsString(jsonObject);
  }
}
