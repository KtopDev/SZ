package com.staffzone.staffzonesystemsapi.controllers;

import static org.springframework.http.HttpStatus.CREATED;

import com.staffzone.staffzonesystemsapi.dtos.requests.PostponePasswordExpireRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchAppUserRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.UserRequest;
import com.staffzone.staffzonesystemsapi.dtos.responses.PaginatedAppUsersResponse;
import com.staffzone.staffzonesystemsapi.entities.AppUser;
import com.staffzone.staffzonesystemsapi.exceptions.BusinessException;
import com.staffzone.staffzonesystemsapi.services.AppUserService;
import com.staffzone.staffzonesystemsapi.validators.UuidValidator;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * App User Controller.
 */
@RequestMapping("/api/v1/users")
@RestController
@AllArgsConstructor
public class UserController {
  private AppUserService userService;

  /**
   * Verify if is authenticated.
   *
   * @return ResponseEntity
   */
  @GetMapping("/me")
  @PreAuthorize("isAuthenticated()")
  public ResponseEntity<AppUser> authenticatedUser() {
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    AppUser currentUser = (AppUser) authentication.getPrincipal();
    return ResponseEntity.ok(currentUser);
  }

  @GetMapping("/{uuid}")
  @Operation(summary = "Retrieves AppUser info by uuid")
  public ResponseEntity<AppUser> findById(@PathVariable String uuid) {
    return ResponseEntity.ok(userService.findById(uuid));
  }

  @PostMapping
  @Operation(summary = "Creates a AppUser and returns newly created client guid")
  public ResponseEntity<AppUser> save(@RequestBody @Valid UserRequest createRequest) {
    AppUser appUser = userService.createUser(createRequest);
    return new ResponseEntity<>(userService.findById(appUser.getAppUserId()), CREATED);
  }

  @GetMapping
  @Operation(summary = "Returns paginated Users list")
  public ResponseEntity<PaginatedAppUsersResponse> search(@Valid SearchAppUserRequest request) {
    PaginatedAppUsersResponse paginatedAppUserResponse = userService.searchAppUsers(request);
    return ResponseEntity.ok(paginatedAppUserResponse);
  }

  /**
   * Update Employee.
   *
   * @param request AppUserRequest
   * @return ResponseEntity
   */
  @PutMapping("/{uuid}")
  @Operation(summary = "Retrieves AppUser info after update AppUser by uuid")
  public ResponseEntity<?> update(@PathVariable String uuid,
          @Valid
          @RequestBody UserRequest request) {
    UuidValidator.isValid(uuid);
    return ResponseEntity.ok(userService.updateUser(uuid, request));
  }

  @PostMapping("/password/postpone-expire")
  public ResponseEntity<String> postponePasswordExpire(
      @RequestBody @Valid PostponePasswordExpireRequest postponePasswordExpireRequest) {
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    Object user = authentication.getPrincipal();
    if (user instanceof AppUser) {
      userService.postponeExpire((AppUser)user, postponePasswordExpireRequest);
      return ResponseEntity.ok("Password expiration was postponed");
    } else {
      throw new BusinessException("", "Operation not supported for userType");
    }
  }
}
