package com.staffzone.staffzonesystemsapi.controllers;

import com.staffzone.staffzonesystemsapi.dtos.requests.CompliantsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.ComplimentsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.DiscriminationReportRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.QuestionsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.ReportBugRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.ReportHarassmentRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.ReportSafetyConcernRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchClientContactRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SuggestionRequest;
import com.staffzone.staffzonesystemsapi.dtos.responses.PaginatedClientContactResponse;
import com.staffzone.staffzonesystemsapi.services.ClientContactService;
import com.staffzone.staffzonesystemsapi.services.ContactService;
import com.staffzone.staffzonesystemsapi.services.JwtService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static org.springframework.http.MediaType.MULTIPART_FORM_DATA_VALUE;

/**
 * Controller for Contact Endpoints.
 */
@RequestMapping("/api/v1/contact")
@CrossOrigin("*")
@RestController
@AllArgsConstructor
public class ContactController {
  private ContactService contactService;
  private ClientContactService clientContactService;
  private JwtService jwtService;

  @GetMapping
  @Operation(summary = "Returns paginated Client contact information")
  public ResponseEntity<PaginatedClientContactResponse> search(@Valid SearchClientContactRequest request) {
    PaginatedClientContactResponse paginatedClientContactResponse = clientContactService.searchClientContacts(request);
    return ResponseEntity.ok(paginatedClientContactResponse);
  }

  @PostMapping("/report-bug")
  public ResponseEntity reportBug(@RequestBody @Valid ReportBugRequest request) {
    contactService.reportBug(request);
    return ResponseEntity.ok().build();
  }

  @PostMapping("/suggestion")
  public ResponseEntity suggestion(@RequestBody @Valid SuggestionRequest request) {
    contactService.suggestion(request);
    return ResponseEntity.ok().build();
  }

  @PostMapping("/compliments")
  public ResponseEntity compliments(@RequestBody @Valid ComplimentsRequest request) {
    contactService.compliments(request);
    return ResponseEntity.ok().build();
  }

  @PostMapping("/complaints")
  public ResponseEntity complaints(@RequestBody @Valid CompliantsRequest request) {
    contactService.complaints(request);
    return ResponseEntity.ok().build();
  }

  @PostMapping("/question")
  public ResponseEntity question(@RequestBody @Valid QuestionsRequest request) {
    contactService.questions(request);
    return ResponseEntity.ok().build();
  }

  @PostMapping(value = "/safety-concern", consumes = {MULTIPART_FORM_DATA_VALUE})
  public ResponseEntity safetyConcern(@ModelAttribute @Valid ReportSafetyConcernRequest request) {
    contactService.safetyConcern(request);
    return ResponseEntity.ok().build();
  }

  @PostMapping("/report-discrimination")
  public ResponseEntity reportDiscrimination(@NonNull HttpServletRequest httpServletRequest,
                                             @RequestBody @Valid DiscriminationReportRequest request) {
    String workerEmail = jwtService.extractUsername(httpServletRequest);
    contactService.reportDiscrimination(workerEmail, request);
    return ResponseEntity.ok().build();
  }

  @PostMapping("/report-harassment")
  public ResponseEntity reportHarassment(@RequestBody @Valid ReportHarassmentRequest request) {
    contactService.reportHarassment(request);
    return ResponseEntity.ok().build();
  }
}
