package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Projects Agreements Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchProjectAgreementsItemResponse {
  @JsonSetter(value = "file_name")
  private String fileName;
  @JsonSetter(value = "file_path")
  private String filePath;
  @JsonSetter(value = "created_at")
  private String createdAt;
  @JsonSetter(value = "project_id")
  private String projectId;
  @JsonSetter(value = "total_rows")
  private String totalRows;
  @JsonSetter(value = "agreement_id")
  private String agreementId;
  @JsonSetter(value = "agreement_type")
  private String agreementType;
  @JsonSetter(value = "agreement_type_name")
  private String agreementTypeName;
}
