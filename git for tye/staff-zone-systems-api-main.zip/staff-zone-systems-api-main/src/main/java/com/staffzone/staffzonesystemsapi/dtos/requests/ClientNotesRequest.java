package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.staffzone.staffzonesystemsapi.bos.ClientNotesType;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ClientNotesRequest {
  @Size(min = 1, max = 100, message = "Title must be between 1 and 100 characters")
  private String title;
  private ClientNotesType noteType;
  @Size(min = 1, max = 300, message = "Note must be between 1 and 300 characters")
  private String note;
  private UUID clientId;
  private UUID clientNoteId;
}
