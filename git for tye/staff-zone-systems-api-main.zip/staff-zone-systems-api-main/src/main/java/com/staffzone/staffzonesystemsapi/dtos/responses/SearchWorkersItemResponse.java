package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Worker Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchWorkersItemResponse {

  @JsonSetter(value = "status")
  private String status;
  @JsonSetter(value = "rating")
  private String rating;
  @JsonSetter(value = "warnings")
  private String warnings;
  @JsonSetter(value = "branch_id")
  private String branchId;
  @JsonSetter(value = "worker_id")
  private String workerId;
  @JsonSetter(value = "first_name")
  private String firstName;
  @JsonSetter(value = "last_name")
  private String lastName;
  @JsonSetter(value = "total_rows")
  private String totalRows;
  @JsonSetter(value = "branch_name")
  private String branchName;
  @JsonSetter(value = "other_names")
  private String otherNames;
  @JsonSetter(value = "worker_code")
  private String workerCode;
  @JsonSetter(value = "middle_initial")
  private String middleInitial;
  @JsonSetter(value = "last_day_worked")
  private String lastDayWorked;
  @JsonSetter(value = "is_previously_worked")
  private String previouslyWorked;
  @JsonSetter(value = "hours_worked_current_week")
  private String hoursWorkedCurrentWeek;
  @JsonSetter(value = "skills")
  private List<SkillDto> skills;
  @JsonSetter(value = "certifications")
  private List<CertificationDto> certifications;
  @JsonSetter(value = "row_order")
  private String rowOrder;
}
