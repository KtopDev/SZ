package com.staffzone.staffzonesystemsapi.dtos.requests;

import static com.staffzone.staffzonesystemsapi.utils.StringUtils.toSnakeCase;
import static java.util.UUID.fromString;
import static org.springframework.data.domain.Sort.Direction.ASC;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.staffzone.staffzonesystemsapi.validators.SortOptions;
import com.staffzone.staffzonesystemsapi.validators.Uuid;
import java.time.LocalDate;
import java.util.UUID;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import net.minidev.json.JSONObject;

/**
 * Search Certifications Request DTO.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class SearchCertificationsRequest extends SearchAbstractRequest {
  private String searchBy;
  private Integer daysFirstPlacement;
  private Integer daysHire;
  @Getter(AccessLevel.NONE)
  private String branch;
  private Integer occurrences;
  private LocalDate startDate;
  private LocalDate endDate;
  @SortOptions(anyOf = {"certificationName", "certificationAbreviation", "certificationDescription",
          "modifiedAt","daysFromHire","daysFromFirstPlacement","isOverridable","certificationDescription"})
  private String sort;

  /**
   * Get sort as Json.
   *
   * @return String
   */
  @JsonIgnore
  public String getSortAsJson() {
    JSONObject jsonObject = new JSONObject();
    jsonObject.put("limit", super.getSize());

    var offset = (super.getPage() - 1) * super.getSize();
    jsonObject.put("offset", offset);

    if (sort == null || sort.isBlank()) {
      jsonObject.put("sort_column", "certificationName");
      jsonObject.put("sort_direction", ASC.name());
    } else {
      String[] options = sort.split(",");
      jsonObject.put("sort_column", toSnakeCase(options[0]));
      jsonObject.put("sort_direction", options[1].toUpperCase());
    }
    return jsonObject.toJSONString();
  }

  public UUID getBranch() {
    return (branch == null || branch.isBlank()) ? null : fromString(branch);
  }
}
