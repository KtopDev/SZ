package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Site Requirements Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchSiteRequirementsItemResponse {
  @JsonSetter(value = "site_requirement_id")
  private String siteRequirementId;
  @JsonSetter(value = "site_requirement_name")
  private String siteRequirementName;
  @JsonSetter(value = "site_requirement_description")
  private String siteRequirementDescription;
  @JsonSetter(value = "branch_id")
  private String branchId;
  @JsonSetter(value = "branch_name")
  private String branchName;
  @JsonSetter(value = "modified_at")
  private String modifiedAt;
  @JsonSetter(value = "ocurrences")
  private String occurrences;
  @JsonSetter(value = "total_rows")
  private String totalRows;
}
