package com.staffzone.staffzonesystemsapi.dtos.requests;

import static com.staffzone.staffzonesystemsapi.utils.StringUtils.toSnakeCase;
import static org.springframework.data.domain.Sort.Direction.ASC;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.staffzone.staffzonesystemsapi.validators.SortOptions;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import net.minidev.json.JSONObject;

/**
 * Search Tax forms Request DTO.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class SearchPrintingFormatsWithoutFormatRequest extends SearchAbstractRequest {
  private String searchBy;
  private LocalDate startDate;
  private LocalDate endDate;
  @SortOptions(anyOf = {"printingFormatId", "printingFormatName", "printingFormatUri", "printingFormatType", "modifiedAt"})
  private String sort;

  /**
   * Get sort as Json.
   *
   * @return String
   */
  @JsonIgnore
  public String getSortAsJson() {
    JSONObject jsonObject = new JSONObject();
    jsonObject.put("limit", super.getSize());

    var offset = (super.getPage() - 1) * super.getSize();
    jsonObject.put("offset", offset);

    if (sort == null || sort.isBlank()) {
      jsonObject.put("sort_column", "printing_format_name");
      jsonObject.put("sort_direction", ASC.name());
    } else {
      String[] options = sort.split(",");
      jsonObject.put("sort_column", toSnakeCase(options[0]));
      jsonObject.put("sort_direction", options[1].toUpperCase());
    }
    return jsonObject.toJSONString();
  }

  public LocalDate getEndDate() {
    if (endDate == null)
      return null;
    if (startDate == null)
      return endDate;

    if(endDate.isBefore(startDate)) {
      return endDate.minusDays(1);
    } else {
      return endDate;
    }
  }
}
