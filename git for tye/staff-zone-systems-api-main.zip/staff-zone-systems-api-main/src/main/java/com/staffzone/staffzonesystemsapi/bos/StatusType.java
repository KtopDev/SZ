package com.staffzone.staffzonesystemsapi.bos;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * StatusType: <br/>
 * {@link #SUCCESS},<br/>
 * {@link #ERROR}.
 */
@Getter
@AllArgsConstructor
public enum StatusType {
  SUCCESS,
  ERROR;
}
