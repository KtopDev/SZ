package com.staffzone.staffzonesystemsapi.entities;

import com.staffzone.staffzonesystemsapi.entities.ids.AppUsersBranchId;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;

/**
 * The persistent class for the app_users_branches database table.
 */
@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@EqualsAndHashCode(callSuper = true)
@Table(name = "app_users_branches")
public class AppUsersBranch extends Audit {
  @EmbeddedId
  private AppUsersBranchId id;

  @Column(name = "is_primary")
  private Boolean isPrimary;

  @ManyToOne
  @JoinColumn(name = "role")
  private AppRole appRole;

  @ManyToOne
  @JoinColumn(name = "app_user_id")
  private AppUser appUser;

  @ManyToOne
  @JoinColumn(name = "branch_id")
  private Branch branch;

  @Builder.Default
  @Column(updatable = false, insertable = false)
  private Boolean isRowActive = false;
}
