package com.staffzone.staffzonesystemsapi.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.staffzone.staffzonesystemsapi.entities.ids.BranchWorkerAppTermId;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;

/**
 * Entity mapped against "<strong>branch worker app terms</strong>" Table.
 * {@link BranchWorkerAppTermId}
 */
@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "branch_worker_app_terms")
public class BranchWorkerAppTerm extends Audit {
  @EmbeddedId
  private BranchWorkerAppTermId id;

  @MapsId("branchId")
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "branch_id", nullable = false)
  @JsonBackReference
  private Branch branch;

  @MapsId("workerAppTermId")
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "worker_app_term_id", nullable = false)
  private WorkerAppTerm workerAppTerm;

  @Builder.Default
  @NotNull
  @Column(name = "is_row_active", nullable = false)
  private Boolean isRowActive = false;
}