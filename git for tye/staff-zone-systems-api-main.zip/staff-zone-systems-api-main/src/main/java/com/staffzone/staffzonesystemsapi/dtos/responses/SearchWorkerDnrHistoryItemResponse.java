package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Worker Dnr History Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchWorkerDnrHistoryItemResponse {
  @JsonSetter(value = "dnr_date")
  private String dnrDate;
  @JsonSetter(value = "branch_id")
  private String branchId;
  @JsonSetter(value = "client_id")
  private String clientId;
  @JsonSetter(value = "dnr_reason")
  private String dnrReason;
  @JsonSetter(value = "dnr_status")
  private String dnrStatus;
  @JsonSetter(value = "project_id")
  private String projectId;
  @JsonSetter(value = "total_rows")
  private String totalRows;
  @JsonSetter(value = "branch_name")
  private String branchName;
  @JsonSetter(value = "client_name")
  private String clientName;
  @JsonSetter(value = "project_name")
  private String projectName;
  @JsonSetter(value = "dnr_remove_date")
  private String dnrRemoveDate;
  @JsonSetter(value = "dnr_remove_reason")
  private String dnrRemoveReason;
}
