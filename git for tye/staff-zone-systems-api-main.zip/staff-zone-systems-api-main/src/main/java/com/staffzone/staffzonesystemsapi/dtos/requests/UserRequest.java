package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * User Request Dto.
 */
@Data
@NoArgsConstructor
@SuperBuilder
public class UserRequest {
  //Basic Information
  @NotBlank(message = "First name cannot be blank")
  private String firstName;

  @NotBlank(message = "Last name cannot be blank")
  private String lastName;


  @NotBlank(message = "Job title cannot be blank")
  private String jobTitle;

  //Contact Information
  @NotBlank(message = "Cell phone cannot be blank")
  @Pattern(regexp = "^\\d{10}", message = "Cell phone must have 10 characters")
  private String phone;

  @Email(message = "Email must be valid")
  @NotBlank(message = "Email cannot be blank")
  private String email;

  @Builder.Default
  private Boolean isSalesCloser = false;

  //TODO branches and roles
  //@NotEmpty(message = "Branches cannot be blank")
  //private List<String> branches;
  //Branches and Security Roles

  //2FA
  @Pattern(regexp = "SMS|EMAIL|AUTH_APP|NONE", message = "MultiFactor must be either SMS, EMAIL or NONE")
  private String multiFactorAuthenticationPreference;
  @Digits(integer = 2, fraction = 0)
  private Integer multiFactorAuthenticationTtlDays;
}
