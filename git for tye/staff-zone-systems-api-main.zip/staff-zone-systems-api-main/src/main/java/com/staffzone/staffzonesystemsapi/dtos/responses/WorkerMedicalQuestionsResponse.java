package com.staffzone.staffzonesystemsapi.dtos.responses;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.UUID;

/**
 * WorkerMedicalQuestions response.
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class WorkerMedicalQuestionsResponse {
  private UUID questionId;
  private String questionIndex;
  private String questionCategory;
  private String question;
  private String questionHelpText;
  private String questionType;
  private Boolean isRequired;
  private String answer;
  private String createdAt;
}
