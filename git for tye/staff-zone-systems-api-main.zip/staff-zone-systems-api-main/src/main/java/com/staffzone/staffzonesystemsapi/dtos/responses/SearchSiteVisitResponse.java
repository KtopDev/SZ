package com.staffzone.staffzonesystemsapi.dtos.responses;

import static java.lang.Integer.parseInt;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Search SiteVisit Response DTO.
 */
@Getter
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class SearchSiteVisitResponse extends PaginatedAbstractResponse {
  private List<SearchSiteVisitItemResponse> content;

  /**
   * Set Tools.
   *
   * @param json String
   */
  public void setContent(String json) {
    if (json == null) {
      content = new ArrayList<>();
    } else {
      var objectMapper = new ObjectMapper();
      try {
        content = objectMapper.readValue(json, new TypeReference<>() {
        });
      } catch (JsonProcessingException e) {
        throw new RuntimeException(e);
      }
    }

    setTotalSize(content.isEmpty() ? 0 : parseInt(content.get(0).getTotalRows()));
  }
}
