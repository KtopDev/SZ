package com.staffzone.staffzonesystemsapi.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Lk SetUp Table.
 */
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "lk_setup")
public class LkSetup {
  @Id
  @Column(name = "setup_key", nullable = false)
  private String setupKey;
  @Column(name = "setup_value", nullable = false)
  private String setupValue;
  @Column(name = "is_row_active", nullable = false)
  private Boolean isRowActive;
}
