package com.staffzone.staffzonesystemsapi.dtos;

import lombok.Getter;

/**
 * Dropdown Item Project Document Type Dto.
 */
@Getter
public class DropdownItemProjectDocTypeDto extends DropdownItemDto {
  private final Boolean visibleToClient;

  public DropdownItemProjectDocTypeDto(String id, String displayName, Boolean visibleToClient) {
    super(id, displayName);
    this.visibleToClient = visibleToClient;
  }
}
