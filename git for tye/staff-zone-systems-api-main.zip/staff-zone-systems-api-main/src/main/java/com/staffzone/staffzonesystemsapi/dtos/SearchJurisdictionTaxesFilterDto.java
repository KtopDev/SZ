package com.staffzone.staffzonesystemsapi.dtos;

import com.staffzone.staffzonesystemsapi.entities.Branch;
import com.staffzone.staffzonesystemsapi.entities.UnemploymentJurisdictions;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class SearchJurisdictionTaxesFilterDto {
  private String status;
  private String jurisdiction;
  private LocalDate startDate;
  private LocalDate endDate;

  public static UnemploymentJurisdictions build(UnemploymentJurisdictions tax) {
    return UnemploymentJurisdictions.builder()
            .id(tax.getId())
            .lkStates(tax.getLkStates())
            .minWage(tax.getMinWage())
            .maxWage(tax.getMaxWage())
            .rate(tax.getRate())
            .federalCreditRate(tax.getFederalCreditRate())
            .employeeRate(tax.getEmployeeRate())
            .companyRate(tax.getCompanyRate())
            .status(tax.getStatus())
            .modifiedAt(tax.getModifiedAt())
            .isRowActive(tax.getIsRowActive())
            .build();
  }
}
