package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.staffzone.staffzonesystemsapi.entities.WorkerWithholding;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Worker WithHoldings Response DTO.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WorkerWithHoldingsSummaryResponse {
  private UUID workerId;
  private Integer withHoldingId;
  private Boolean isFederalIncomeTaxExempt;
  private String fillingStatus;
  private Boolean hasMoreThanOneJob;
  private BigDecimal deductionsAmount;
  private BigDecimal otherIncomeAmount;
  private BigDecimal dependentsAmount;
  private BigDecimal additionalWithholdingAmount;
  private BigDecimal stateAdditionalWithholdingAmount;
  private Boolean isNonexistentAlien;
  private Boolean isStateIncomeTaxExempt;
  private String stateFillingStatus;
  private Integer regularAllowances;
  private Integer additionalAllowances;

  public static WorkerWithHoldingsSummaryResponse fromEntity(WorkerWithholding entity) {
    return WorkerWithHoldingsSummaryResponse.builder()
            .workerId(entity.getId().getWorkerId())
            .withHoldingId(entity.getId().getWithholdingId())
            .isFederalIncomeTaxExempt(entity.getIsFederalIncomeTaxExempt())
            .fillingStatus(entity.getFillingStatus())
            .hasMoreThanOneJob(entity.getHasMoreThanOneJob())
            .deductionsAmount(entity.getDeductionsAmount())
            .otherIncomeAmount(entity.getOtherIncomeAmount())
            .dependentsAmount(entity.getDependentsAmount())
            .additionalWithholdingAmount(entity.getAdditionalWithholdingAmount())
            .stateAdditionalWithholdingAmount(entity.getStateAdditionalWithholdingAmount())
            .isNonexistentAlien(entity.getIsNontesitentAlien())
            .isStateIncomeTaxExempt(entity.getIsStateIncomeTaxExempt())
            .stateFillingStatus(entity.getStateFillingStatus())
            .regularAllowances(entity.getRegularAllowances())
            .additionalAllowances(entity.getAdicionalAllowances())
            .build();
  }
}
