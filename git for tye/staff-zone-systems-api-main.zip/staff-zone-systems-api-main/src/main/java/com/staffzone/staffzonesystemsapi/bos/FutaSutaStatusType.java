package com.staffzone.staffzonesystemsapi.bos;

/**
 * FutaSutaStatusType: <br/>
 * {@link #ACTIVE},<br/>
 * {@link #INACTIVE}.
 *
 */
public enum FutaSutaStatusType {
  ACTIVE, INACTIVE
}
