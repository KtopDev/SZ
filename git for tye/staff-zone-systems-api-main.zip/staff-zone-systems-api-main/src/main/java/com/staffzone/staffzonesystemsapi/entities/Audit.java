package com.staffzone.staffzonesystemsapi.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreType;
import jakarta.persistence.Column;
import jakarta.persistence.MappedSuperclass;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;

/**
 * Audit Fields for All Tables.
 */
@MappedSuperclass
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@JsonIgnoreType
public class Audit {
  @JsonIgnore
  @Column(name = "created_at", insertable = false, updatable = false)
  private LocalDateTime createdAt;

  @JsonIgnore
  @Column(name = "created_by", insertable = false, updatable = false)
  private String createdBy;

  @JsonIgnore
  @Column(name = "modified_at", insertable = false, updatable = false)
  private LocalDateTime modifiedAt;

  @JsonIgnore
  @Column(name = "modified_by", insertable = false, updatable = false)
  private String modifiedBy;
}
