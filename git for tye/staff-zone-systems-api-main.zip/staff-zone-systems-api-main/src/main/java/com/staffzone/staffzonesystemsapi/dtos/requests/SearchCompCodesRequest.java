package com.staffzone.staffzonesystemsapi.dtos.requests;

import static com.staffzone.staffzonesystemsapi.entities.CompCodes.Fields.compCode;
import static com.staffzone.staffzonesystemsapi.entities.CompCodes.Fields.compCodeDescription;
import static com.staffzone.staffzonesystemsapi.utils.StringUtils.toSnakeCase;
import static org.springframework.data.domain.Sort.Direction.ASC;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.staffzone.staffzonesystemsapi.validators.SortOptions;
import jakarta.validation.constraints.Pattern;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.JSONObject;

/**
 * Search Comp Code Request DTO.
 */
@Slf4j
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class SearchCompCodesRequest extends SearchAbstractRequest {
  private String searchBy;
  private String state;
  @Pattern(regexp = "^$|Active|Archived|ACTIVE|ARCHIVED",
          message = "Status must be either 'Active', 'Inactive'")
  private String status;
  private LocalDate startDate;
  private LocalDate endDate;
  @SortOptions(anyOf = {compCode, compCodeDescription, "stateName", "efectiveDate"})
  private String sort;

  /**
   * Get sort as Json.
   *
   * @return String
   */
  @JsonIgnore
  public String getSortAsJson() {
    JSONObject jsonObject = new JSONObject();
    jsonObject.put("limit", super.getSize());

    var offset = (super.getPage() - 1) * super.getSize();
    jsonObject.put("offset", offset);

    if (sort == null || sort.isBlank()) {
      jsonObject.put("sort_column", toSnakeCase(compCode));
      jsonObject.put("sort_direction", ASC.name());
    } else {
      String[] options = sort.split(",");
      jsonObject.put("sort_column", toSnakeCase(options[0]));
      jsonObject.put("sort_direction", options[1].toUpperCase());
    }
    return jsonObject.toJSONString();
  }

  @JsonIgnore
  public String[] getStates() {
    return (state == null || state.isBlank()) ? null : new String[]{state};
  }

  public String getStatus() {
    return status == null || status.isBlank() ? null : status.toUpperCase();
  }
}
