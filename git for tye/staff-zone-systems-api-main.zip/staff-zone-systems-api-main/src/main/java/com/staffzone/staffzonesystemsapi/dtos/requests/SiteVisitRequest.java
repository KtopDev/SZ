package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SiteVisitRequest {
  @NotNull(message = "Contact cannot be blank")
  private UUID contactId;
  @NotNull(message = "Project cannot be blank")
  private UUID projectId;
  @NotBlank(message = "Notes cannot be blank")
  private String visitNotes;
  @NotNull(message = "Date cannot be blank")
  private LocalDate visitDate;
}
