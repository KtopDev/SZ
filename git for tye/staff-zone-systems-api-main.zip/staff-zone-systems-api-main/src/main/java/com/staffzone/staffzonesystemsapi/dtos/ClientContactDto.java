package com.staffzone.staffzonesystemsapi.dtos;

import com.staffzone.staffzonesystemsapi.bos.MultiFactorType;
import com.staffzone.staffzonesystemsapi.entities.ClientContact;
import java.util.List;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Client Contact DTO.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class ClientContactDto {
  private UUID contactId;
  private String status;
  private String name;
  private String lastName;
  private String phone;
  private String email;
  private Boolean isPrimary;
  private Boolean isAppAccessEnabled;
  private Boolean canReceiveInvoices;
  private Boolean canApproveHours;
  private Boolean canRateWorkers;
  private MultiFactorType multifactorPreference;
  private int multifactorTtlDays;
  private List<String> activeProjects;

  /**
   * build.
   *
   * @param clientContact {@link ClientContact}
   * @return {@link ClientContactDto}
   */
  public static ClientContactDto build(ClientContact clientContact) {
    return ClientContactDto.builder()
            .contactId(clientContact.getId())
            .name(clientContact.getName())
            .lastName(clientContact.getLastName())
            .phone(clientContact.getPhone())
            .email(clientContact.getEmail())
            .isPrimary(clientContact.getIsPrimary())
            .isAppAccessEnabled(clientContact.getIsAppAccessEnabled())
            .canReceiveInvoices(clientContact.getCanReceiveInvoices())
            .canApproveHours(clientContact.getCanApproveHours())
            .canRateWorkers(clientContact.getCanRateWorkers())
            .multifactorPreference(clientContact.getMultiFactorAuthenticationPreference())
            .multifactorTtlDays(clientContact.getMultiFactorAuthenticationTtlDays())
            .activeProjects(clientContact.getActiveProjects())
            .status(clientContact.getClient().getStatus())
            .build();
  }
}
