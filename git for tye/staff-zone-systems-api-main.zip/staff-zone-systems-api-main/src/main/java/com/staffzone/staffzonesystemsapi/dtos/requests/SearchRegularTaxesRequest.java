package com.staffzone.staffzonesystemsapi.dtos.requests;

import static com.staffzone.staffzonesystemsapi.utils.StringUtils.toSnakeCase;
import static java.util.UUID.fromString;
import static org.springframework.data.domain.Sort.Direction.ASC;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.staffzone.staffzonesystemsapi.bos.CalculationType;
import com.staffzone.staffzonesystemsapi.bos.ConcubinageStatusType;
import com.staffzone.staffzonesystemsapi.validators.SortOptions;
import com.staffzone.staffzonesystemsapi.validators.Uuid;
import com.staffzone.staffzonesystemsapi.validators.ValueOfEnum;
import java.time.LocalDate;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import net.minidev.json.JSONObject;

/**
 * Search Regular Tax Request DTO.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class SearchRegularTaxesRequest extends SearchAbstractRequest {
  @Uuid(enableNullValues = true)
  private String jurisdictionId;
  @ValueOfEnum(enumClass = ConcubinageStatusType.class, enableNullValues = true)
  private String fillingStatus;
  @ValueOfEnum(enumClass = CalculationType.class, enableNullValues = true)
  private String calculationType;
  private LocalDate startDate;
  private LocalDate endDate;
  @SortOptions(anyOf = {"tax_id", "tax_jurisdiction_id", "effective_date","filling_status", "bracket_start",
          "bracket_end","base_amount","calculation_type","tax_rate","modified_at","tax_jurisdiction_name"})
  private String sort;

  /**
   * Get sort as Json.
   *
   * @return String
   */
  @JsonIgnore
  public String getSortAsJson() {
    JSONObject jsonObject = new JSONObject();
    jsonObject.put("limit", super.getSize());

    var offset = (super.getPage() - 1) * super.getSize();
    jsonObject.put("offset", offset);

    if (sort == null || sort.isBlank()) {
      jsonObject.put("sort_column", "tax_jurisdiction_name");
      jsonObject.put("sort_direction", ASC.name());
    } else {
      String[] options = sort.split(",");
      jsonObject.put("sort_column", toSnakeCase(options[0]));
      jsonObject.put("sort_direction", options[1].toUpperCase());
    }
    return jsonObject.toJSONString();
  }

  public UUID getJurisdictionId() {
    return (jurisdictionId == null || jurisdictionId.isBlank()) ? null : fromString(jurisdictionId);
  }
  public String getFillingStatus() {
    return (fillingStatus == null || fillingStatus.isBlank()) ? null : fillingStatus;
  }
  public String getCalculationType() {
    return (calculationType == null || calculationType.isBlank()) ? null : calculationType;
  }
}
