package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Comp Codes Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchCompCodesItemResponse {
  private String state;
  @JsonSetter(value = "comp_code")
  private String compCode;
  @JsonSetter(value = "state_name")
  private String stateName;
  @JsonSetter(value = "total_rows")
  private String totalRows;
  @JsonSetter(value = "comp_code_id")
  private String compCodeId;
  @JsonSetter(value = "efective_date")
  private String efectiveDate;
  @JsonSetter(value = "burden_per_hour")
  private String burdenPerHour;
  @JsonSetter(value = "cost_per_hundred")
  private String costPerHundred;
  @JsonSetter(value = "bill_rate_per_hundred")
  private String billRatePerHundred;
  @JsonSetter(value = "comp_code_description")
  private String compCodeDescription;
  @JsonSetter(value = "comp_code_billing_description")
  private String compCodeBillingDescription;
}
