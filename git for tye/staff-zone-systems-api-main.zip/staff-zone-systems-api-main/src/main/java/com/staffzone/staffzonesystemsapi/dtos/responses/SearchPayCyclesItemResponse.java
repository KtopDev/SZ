package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Pay Cycles Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchPayCyclesItemResponse {
  @JsonSetter(value = "pay_cycle_id")
  private String id;
  @JsonSetter(value = "pay_cycle_name")
  private String name;
  @JsonSetter(value = "start_iso_day_of_week")
  private String startDayOfWeek;
  @JsonSetter(value = "end_iso_day_of_week")
  private String endDayOfWeek;
  @JsonSetter(value = "total_rows")
  private String totalRows;
}
