package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.staffzone.staffzonesystemsapi.dtos.MFATokenDto;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.UUID;

/**
 * Login Response DTO.
 */
@Getter
@Setter
@Builder
@ToString
public class LoginResponse {
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String status;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private UUID authProcessId;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String token;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private long expiresIn;
  @JsonInclude()
  private String mfaPreference;
  @JsonInclude()
  private MFATokenDto mfaTokenDto;
}