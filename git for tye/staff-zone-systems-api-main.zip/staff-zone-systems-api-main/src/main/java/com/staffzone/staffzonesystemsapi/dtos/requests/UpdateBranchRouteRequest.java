package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@SuperBuilder
public class UpdateBranchRouteRequest {
    @NotBlank(message = "Route name cannot be blank")
    private String routeName;

    @NotNull(message = "Seats cannot be null")
    @PositiveOrZero(message = "Seats must be positive number or zero")
    private Integer seats;
}
