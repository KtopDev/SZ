package com.staffzone.staffzonesystemsapi.entities;

import com.staffzone.staffzonesystemsapi.entities.ids.BranchSickPayJurisdictionsId;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import java.util.Set;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;

@Entity
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "branch_sick_pay_jurisdictions")
public class BranchSickPayJurisdictions {
  @EmbeddedId
  private BranchSickPayJurisdictionsId id;
  @Column(name = "is_row_active")
  private Boolean isRowActive;
  @Transient
  private UUID sickPayGuid;

}
