package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.staffzone.staffzonesystemsapi.validators.Uuid;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * MFA Code Request Dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VerifyMfaCodeRequest {
  @Uuid
  private String authProcessId;
  @NotEmpty
  private String code;
  @NotEmpty
  private String userType;
}
