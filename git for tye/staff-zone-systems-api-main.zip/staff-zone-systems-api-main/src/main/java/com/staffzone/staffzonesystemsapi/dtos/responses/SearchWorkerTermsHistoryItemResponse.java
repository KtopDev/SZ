package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Worker Terms and Conditions Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchWorkerTermsHistoryItemResponse {
  @JsonSetter(value = "total_rows")
  private String totalRows;
  @JsonSetter(value = "sort_order")
  private String sortOrder;
  @JsonSetter(value = "worker_app_term_id")
  private String workerAppTermId;
  @JsonSetter(value = "approval_request_ts")
  private String approvalRequestTs;
  @JsonSetter(value = "worker_app_term_label")
  private String workerAppTermLabel;
  @JsonSetter(value = "worker_app_term_file_uri")
  private String workerAppTermFileUri;
  @JsonSetter(value = "worker_app_term_es_file_uri")
  private String workerAppTermEsFileUri;
  @JsonSetter(value = "created_at")
  private String createdAt;
  @JsonSetter(value = "accepted_at")
  private String acceptedAt;
}
