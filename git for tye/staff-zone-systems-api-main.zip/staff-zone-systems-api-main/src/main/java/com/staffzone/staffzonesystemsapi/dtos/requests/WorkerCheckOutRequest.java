package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.staffzone.staffzonesystemsapi.validators.Uuid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Worker Check-Out Request.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WorkerCheckOutRequest {
  @Uuid
  private String branchId;
}
