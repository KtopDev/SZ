package com.staffzone.staffzonesystemsapi.dtos.requests;

import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.staffzone.staffzonesystemsapi.dtos.ProjectBonusDto;
import com.staffzone.staffzonesystemsapi.validators.Uuid;
import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;

/**
 * Project Request Dto.
 */
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProjectRequest extends ProjectBasicInformationRequest {
  @NotNull(message = "Local Taxes cannot be null")
  @Digits(fraction = 4, integer = 10,
          message = "Local Taxes can't be bigger than 999999999.9999")
  @DecimalMin(value = "0.0", message = "Local Taxes can't be lower than zero.")
  private BigDecimal localTaxes;
  @NotNull(message = "Sale Taxes cannot be null")
  @Digits(fraction = 4, integer = 10,
          message = "Sale Taxes can't be bigger than 999999999.9999")
  @DecimalMin(value = "0.0", message = "Local Taxes can't be lower than zero.")
  private BigDecimal saleTaxes;
  @Uuid(enableNullValues = true, message = "Comp Code Id Invalid UUID Format")
  private String compCodeId;
  @Uuid(enableNullValues = true, message = "Pay Cycle Id Invalid UUID Format")
  private String payCycleId;
  private Boolean isCertifiedPayroll;
  private Boolean isDefaultWageSetupOverriden;

  @PositiveOrZero(message = "Minimum Wage Amount must be a positive value")
  private BigDecimal minimumWageAmount;
  @PositiveOrZero(message = "Weekly Regular Hours must be a positive value")
  private BigDecimal weeklyRegularHours;
  @PositiveOrZero(message = "Daily Regular Hours must be a positive value")
  private BigDecimal dailyRegularHours;
  @PositiveOrZero(message = "Overtime Modifier must be a positive value")
  private BigDecimal overtimeModifier;
  private String siteNotes;
  private Boolean isSelfDispatch;
  @NotNull(message = "Billing Contact is required")
  @Uuid(message = "Billing Contact Invalid UUID Format")
  private String billingContactId;
  @NotBlank(message = "Invoice Method is required")
  //FIXME Confirm values for the pattern
  //@Pattern(regexp = "^(paper|PAPER|email|EMAIL)$",
  //        message = "Please enter a valid invoice method; PAPER or EMAIL")
  private String invoiceMethod;
  @NotNull(message = "Printing Format is required")
  @Uuid(message = "Printing Format Invalid UUID Format")
  private String printingFormatId;
  @NotBlank(message = "indicate the frequency of the invoice")
  //FIXME Confirm values for the pattern
  @Pattern(regexp = "^(DAILY|WEEKLY)$",
          message = "Please enter a valid invoice method: DAILY, or WEEKLY")
  private String invoicePeriodicity;
  @NotNull(message = "Transportation PayCode is required")
  @Uuid(message = "Transportation PayCode Invalid UUID Format")
  private String transportationPayCodeId;
  @NotNull
  @PositiveOrZero(message = "Transportation Amount must be a positive value")
  private BigDecimal transportationAmount;
  private Boolean isHouseSale;
  @Valid
  private List<ProjectBonusDto> projectBonuses;
  @NotNull
  private List<@Uuid String> projectSalesUsers;
  @NotNull
  private List<@Uuid String> projectTaxes;
  @NotNull
  private List<@Uuid String> projectUnemploymentJurisdictions;
  @NotNull
  private List<@Uuid String> projectSickPayJurisdictions;
  @NotNull
  private List<@Uuid String> projectSiteRequirements;
  private List<@Uuid String> projectCertifications;
  @NotNull
  private List<@Uuid String> projectPpes;
  private List<@Uuid String> projectTools;
  private List<@Uuid String> projectSkills;

  private ArrayNode convertUuidsToArrayNode(List<String> uuids, ObjectMapper mapper) {
    ArrayNode arrayNode = mapper.createArrayNode();
    for (String uuid : uuids) {
      arrayNode.add(uuid);
    }
    return arrayNode;
  }

  @SneakyThrows
  @JsonIgnore
  public String asJson() {
    ObjectMapper mapper = new ObjectMapper();
    ObjectNode jsonObject = mapper.createObjectNode();
    jsonObject.put("branch_id", getBranchId());
    jsonObject.put("project_name", getProjectName());
    jsonObject.put("client_id", getClientId());
    jsonObject.put("phone", getPhone());
    jsonObject.put("fax", getFax());
    jsonObject.put("address", getAddress());
    jsonObject.put("address_line_2", getAddressLine2());
    jsonObject.put("state", getState());
    jsonObject.put("city", getCity());
    jsonObject.put("postal_code", getPostalCode());
    jsonObject.put("local_taxes", localTaxes);
    jsonObject.put("sale_taxes", saleTaxes);
    jsonObject.put("comp_code_id", compCodeId);
    jsonObject.put("pay_cycle_id", payCycleId);
    jsonObject.put("is_certified_payroll", isCertifiedPayroll);
    jsonObject.put("is_default_wage_setup_overriden", isDefaultWageSetupOverriden);
    jsonObject.put("minimum_wage_amount", minimumWageAmount);
    jsonObject.put("weekly_regular_hours", weeklyRegularHours);
    jsonObject.put("daily_regular_hours", dailyRegularHours);
    jsonObject.put("overtime_modifier", overtimeModifier);
    jsonObject.put("site_notes", siteNotes);
    jsonObject.put("is_self_dispatch", isSelfDispatch);
    jsonObject.put("billing_contact_id", billingContactId);
    jsonObject.put("invoice_method", invoiceMethod);
    jsonObject.put("printing_format_id", printingFormatId);
    jsonObject.put("invoice_periodicity", invoicePeriodicity);
    jsonObject.put("transportation_pay_code_id", transportationPayCodeId);
    jsonObject.put("transportation_amount", transportationAmount);
    jsonObject.put("is_house_sale", isHouseSale);

    ArrayNode projectBonusArray = mapper.createArrayNode();
    if (projectBonuses != null) {
      for (ProjectBonusDto bonus : projectBonuses) {
        projectBonusArray.add(bonus.asJsonNode(mapper));
      }
      jsonObject.set("project_bonus", projectBonusArray);
    }

    jsonObject.set("project_sale_codes", convertUuidsToArrayNode(projectSalesUsers, mapper));
    jsonObject.set("project_taxes", convertUuidsToArrayNode(projectTaxes, mapper));
    jsonObject.set("project_unemployment_jurisdictions",
            convertUuidsToArrayNode(projectUnemploymentJurisdictions, mapper));
    jsonObject.set("project_sick_pay_jurisdictions",
            convertUuidsToArrayNode(projectSickPayJurisdictions, mapper));
    jsonObject.set("project_site_requirements",
            convertUuidsToArrayNode(projectSiteRequirements, mapper));
    jsonObject.set("project_ppe", convertUuidsToArrayNode(projectPpes, mapper));
    if (projectCertifications != null) {
      jsonObject.set("project_certifications",
              convertUuidsToArrayNode(projectCertifications, mapper));
    }
    if (projectTools != null) {
      jsonObject.set("project_tools",
              convertUuidsToArrayNode(projectTools, mapper));
    }
    if (projectSkills != null) {
      jsonObject.set("project_skills",
              convertUuidsToArrayNode(projectSkills, mapper));
    }

    return mapper.writeValueAsString(jsonObject);
  }

}
