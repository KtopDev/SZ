package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.staffzone.staffzonesystemsapi.validators.Uuid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateProjectOrderDetailsRequest {
    @Uuid
    @NotBlank(message = "Project Id cannot be blank")
    private String projectId;
    @Uuid
    @NotBlank(message = "Order Id cannot be blank")
    private String orderId;
    @Uuid
    @NotBlank(message = "Worker Based Billing Id cannot be blank")
    private String projectWorkerBasedBillingId;
    @NotNull(message = "Number Of Workers cannot be blank")
    @Positive
    private Integer numberOfWorkers;
    @NotNull(message = "Hours Needed cannot be blank")
    @Positive
    private Double hoursNeeded;

    @SneakyThrows
    @JsonIgnore
    public ObjectNode asJsonNode(ObjectMapper mapper) {
        ObjectNode jsonObject = mapper.createObjectNode();
        jsonObject.put("project_id", projectId);
        jsonObject.put("order_id", orderId);
        jsonObject.put("project_worker_based_billing_id", projectWorkerBasedBillingId);
        jsonObject.put("number_of_workers", numberOfWorkers);
        jsonObject.put("hours_needed", hoursNeeded);
        return jsonObject;
    }
}
