package com.staffzone.staffzonesystemsapi.dtos.requests;

import static com.staffzone.staffzonesystemsapi.utils.StringUtils.toSnakeCase;
import static org.springframework.data.domain.Sort.Direction.ASC;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.staffzone.staffzonesystemsapi.bos.LastPayType;
import com.staffzone.staffzonesystemsapi.bos.WarningType;
import com.staffzone.staffzonesystemsapi.validators.SortOptions;
import com.staffzone.staffzonesystemsapi.validators.Uuid;
import com.staffzone.staffzonesystemsapi.validators.ValueOfEnum;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Positive;
import java.math.BigDecimal;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import net.minidev.json.JSONObject;

/**
 * Search Worker Disciplinary Forms Request DTO.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class SearchDispatchWorkerRequest extends SearchAbstractRequest {
  private String searchBy;
  @Uuid(message = "branchId cannot be null")
  private String branchId;
  @Uuid(enableNullValues = true)
  private String clientId;
  private Boolean isCheckedIn;
  @ValueOfEnum(enumClass = WarningType.class, enableNullValues = true)
  private String warningType;
  //Vehicles Filters
  private Boolean hasVehicle;
  @Positive(message = "Min Passengers must be a positive number.")
  @Min(value = 1, message = "Min Passengers must be 1 or more.")
  private Integer minPassengers;
  @Positive(message = "Max Passengers must be a positive number.")
  private Integer maxPassengers;
  //Vehicles Filters END
  private List<@Uuid String> skills;
  private List<@Uuid String> certifications;
  @Positive(message = "rating must be greater than 0")
  private BigDecimal rating;
  @ValueOfEnum(enumClass = LastPayType.class, enableNullValues = true)
  private String lastPay;
  @SortOptions(anyOf = {"workerCode", "firstName", "lastName", "middleInitial",
          "otherNames", "ssnNumber", "checkinAt", "canDrive", "fullName", "skillsCount",
          "warnings", "rating", "paymentAvg", "lastPayDate", "passengersCount", "status"})
  private String sort;

  /**
   * Get sort as Json.
   *
   * @return String
   */
  @JsonIgnore
  public String getSortAsJson() {
    JSONObject jsonObject = new JSONObject();
    jsonObject.put("limit", super.getSize());

    var offset = (super.getPage() - 1) * super.getSize();
    jsonObject.put("offset", offset);

    if (sort == null || sort.isBlank()) {
      jsonObject.put("sort_column", "first_name");
      jsonObject.put("sort_direction", ASC.name());
    } else {
      String[] options = sort.split(",");
      jsonObject.put("sort_column", toSnakeCase(options[0]));
      jsonObject.put("sort_direction", options[1].toUpperCase());
    }
    return jsonObject.toJSONString();
  }

  /**
   * Get vehiclesFilters as JSON.
   * Ex: {
   * "has_vehicle": BOOLEAN,
   * "min_passengers": INTEGER,
   * "max_passengers": INTEGER
   * }
   *
   * @return String
   */
  @JsonIgnore
  public String getVehiclesFilterAsJson() {
    if (hasVehicle == null || !hasVehicle) {
      return null;
    }

    JSONObject json = new JSONObject();
    json.put("has_vehicle", hasVehicle);
    json.put("min_passengers", minPassengers);
    json.put("max_passengers", maxPassengers);

    return json.toJSONString();
  }

  /**
   * Get skills as Json.
   *
   * @return String
   */
  @JsonIgnore
  public String getSkillsAsJson() {
    if (skills == null || skills.isEmpty()) return null;

    StringBuilder sb = new StringBuilder("[");
    for (int i = 0; i < skills.size(); i++) {
      JSONObject node = new JSONObject();
      node.put("skill_id", skills.get(i));
      sb.append(node.toString());
      if (i < skills.size() - 1) {
        sb.append(",");
      }
    }
    sb.append("]");

    return sb.toString();
  }

  /**
   * Get certifications as Json.
   *
   * @return String
   */
  @JsonIgnore
  public String getCertificationsAsJson() {
    if (certifications == null || certifications.isEmpty()) return null;

    StringBuilder sb = new StringBuilder("[");
    for (int i = 0; i < certifications.size(); i++) {
      JSONObject node = new JSONObject();
      node.put("certification_id", certifications.get(i));
      sb.append(node.toString());
      if (i < certifications.size() - 1) {
        sb.append(",");
      }
    }
    sb.append("]");

    return sb.toString();
  }
}
