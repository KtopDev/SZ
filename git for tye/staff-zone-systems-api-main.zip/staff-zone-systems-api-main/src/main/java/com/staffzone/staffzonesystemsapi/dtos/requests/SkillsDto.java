package com.staffzone.staffzonesystemsapi.dtos.requests;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SkillsDto {
  private String skillGroup;
  private String skillName;

}
