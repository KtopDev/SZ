package com.staffzone.staffzonesystemsapi.dtos.responses;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

/**
 * DTO mapped against "<strong>certification</strong>" Table.
 */
@SuperBuilder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CertificationResponse {
  private UUID certificationId;
  private String certificationName;
  private String certificationDescription;
  private String certificationAbreviation;
  private Boolean isOverridable;
  private Integer daysFromFirstPlacement;
  private Integer daysFromHire;
  private UUID branchId;
}
