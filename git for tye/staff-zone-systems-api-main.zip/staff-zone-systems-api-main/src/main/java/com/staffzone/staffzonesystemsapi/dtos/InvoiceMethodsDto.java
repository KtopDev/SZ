package com.staffzone.staffzonesystemsapi.dtos;

import com.staffzone.staffzonesystemsapi.entities.LkInvoiceMethods;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Invoice Methods DTO.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class InvoiceMethodsDto {
  private String invoiceMethod;
  private String label;
  private Integer sortOrder;

  /**
   * Invoice Methods build from LkInvoiceMethods.
   *
   * @param invoiceMethods {@link LkInvoiceMethods}
   * @return InvoiceMethodsDto
   */
  public static InvoiceMethodsDto build(LkInvoiceMethods invoiceMethods) {
    return InvoiceMethodsDto.builder()
            .invoiceMethod(invoiceMethods.getInvoiceMethod())
            .label(invoiceMethods.getLabel())
            .sortOrder(invoiceMethods.getSortOrder())
            .build();
  }
}
