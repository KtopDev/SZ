package com.staffzone.staffzonesystemsapi.dtos;

import lombok.Getter;

/**
 * Dropdown Item With Description Dto.
 */
@Getter
public class DropDownItemWithDescDto extends DropdownItemDto {
  private final String description;

  public DropDownItemWithDescDto(String id, String displayName, String description) {
    super(id, displayName);
    this.description = description;
  }
}
