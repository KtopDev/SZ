package com.staffzone.staffzonesystemsapi.bos;

/**
 * Check Format Options: <br/>
 * {@link #SMS},<br/>
 * {@link #EMAIL},<br/>
 * {@link #PUSH},<br/>
 */
public enum MessageTemplateType {
  SMS, EMAIL, PUSH
}
