package com.staffzone.staffzonesystemsapi.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;

/**
 * Entity mapped against "<strong>LkPaymentTerm</strong>" Table.
 */
@Entity
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "lk_payment_terms")
public class LkPaymentTerm {
  @Id
  @Size(max = 50)
  @Column(name = "payment_term", nullable = false, length = 50)
  private String paymentTerm;

  @Builder.Default
  @NotNull
  @Column(name = "is_row_active", nullable = false)
  private Boolean isRowActive = false;

  @NotNull
  @Column(name = "label", nullable = false, length = Integer.MAX_VALUE)
  private String label;

  @NotNull
  @Column(name = "sort_order", nullable = false)
  private Integer sortOrder;

}
