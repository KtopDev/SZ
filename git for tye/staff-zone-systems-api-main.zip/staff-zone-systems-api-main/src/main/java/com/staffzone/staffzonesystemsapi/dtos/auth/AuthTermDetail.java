package com.staffzone.staffzonesystemsapi.dtos.auth;

import com.fasterxml.jackson.annotation.JsonSetter;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class AuthTermDetail {
  private UUID clientAppTermId;
  private UUID workerAppTermId;
  private String clientAppTermLabel;
  private String workerAppTermLabel;
  private String clientAppTermFileUri;
  private String workerAppTermFileUri;
  private String workerAppTermEsFileUri;
  private String approvalRequestTs;
  private Integer sortOrder;

  @JsonSetter("client_app_term_id")
  public void setClientAppTermId(UUID clientAppTermId) {
    this.clientAppTermId = clientAppTermId;
  }

  @JsonSetter("worker_app_term_id")
  public void setWorkerAppTermId(UUID workerAppTermId) {
    this.workerAppTermId = workerAppTermId;
  }

  @JsonSetter("client_app_term_label")
  public void setClientAppTermLabel(String clientAppTermLabel) {
    this.clientAppTermLabel = clientAppTermLabel;
  }

  @JsonSetter("worker_app_term_label")
  public void setWorkerAppTermLabel(String workerAppTermLabel) {
    this.workerAppTermLabel = workerAppTermLabel;
  }

  @JsonSetter("client_app_term_file_uri")
  public void setClientAppTermFileUri(String clientAppTermFileUri) {
    this.clientAppTermFileUri = clientAppTermFileUri;
  }

  @JsonSetter("worker_app_term_file_uri")
  public void setWorkerAppTermFileUri(String workerAppTermFileUri) {
    this.workerAppTermFileUri = workerAppTermFileUri;
  }

  @JsonSetter("worker_app_term_es_file_uri")
  public void setWorkerAppTermEsFileUri(String workerAppTermEsFileUri) {
    this.workerAppTermEsFileUri = workerAppTermEsFileUri;
  }

  @JsonSetter("approval_request_ts")
  public void setApprovalRequestTs(String approvalRequestTs) {
    this.approvalRequestTs = approvalRequestTs;
  }

  @JsonSetter("sort_order")
  public void setSortOrder(Integer sortOrder) {
    this.sortOrder = sortOrder;
  }
}
