package com.staffzone.staffzonesystemsapi.bos;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * AuthStatusType: <br/>
 * {@link #ACTIVE},<br/>
 * {@link #INACTIVE},<br/>
 * {@link #DNR},<br/>
 * {@link #TERMINATED},<br/>
 * {@link #INCOMPLETE},<br/>
 */
@Getter
@AllArgsConstructor
public enum WorkerStatusType {
  ACTIVE,
  INACTIVE,
  DNR,
  TERMINATED,
  INCOMPLETE;
}
