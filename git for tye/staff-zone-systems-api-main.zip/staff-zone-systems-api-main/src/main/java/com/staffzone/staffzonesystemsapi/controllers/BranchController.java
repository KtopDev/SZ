package com.staffzone.staffzonesystemsapi.controllers;

import java.util.List;
import java.util.UUID;

import com.staffzone.staffzonesystemsapi.dtos.BranchInformationForWorkerDto;
import com.staffzone.staffzonesystemsapi.dtos.requests.BranchRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchBranchRequest;
import com.staffzone.staffzonesystemsapi.dtos.responses.PaginatedBranchResponse;
import com.staffzone.staffzonesystemsapi.entities.Branch;
import com.staffzone.staffzonesystemsapi.entities.WorkerAppTerm;
import com.staffzone.staffzonesystemsapi.services.BranchService;
import com.staffzone.staffzonesystemsapi.services.WorkerService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller for Branches Endpoints.
 */
@RequestMapping("/api/v1/branches")
@CrossOrigin("*")
@RestController
@AllArgsConstructor
public class BranchController {
    private BranchService branchService;
    private WorkerService workerService;

    @PostMapping
    @Operation(summary = "Creates a Branch and returns newly created branch guid")
    public ResponseEntity<Branch> save(@RequestBody @Valid BranchRequest branchRequest) {
        Branch branch = branchService.createBranch(branchRequest);
        return new ResponseEntity<>(branchService.findById(branch.getBranchId()), HttpStatus.CREATED);
    }

    @PutMapping("/{uuid}")
    @Operation(summary = "Updates a Branch and returns the updated branch")
    public ResponseEntity<Branch> update(@PathVariable String uuid,
                                         @RequestBody @Valid BranchRequest updateBranchRequest) {
        Branch branch = branchService.updateBranch(uuid, updateBranchRequest);
        return new ResponseEntity<>(branchService.findById(branch.getBranchId()), HttpStatus.OK);
    }

    @PostMapping("/{uuid}/activate")
    @Operation(summary = "Reactivates the Branch")
    public ResponseEntity<Branch> activate(@PathVariable String uuid) {
        Branch branch = branchService.activate(uuid);
        return new ResponseEntity<>(branchService.findById(branch.getBranchId()), HttpStatus.OK);
    }

    @PostMapping("/{uuid}/deactivate")
    @Operation(summary = "Deactivates the Branch")
    public ResponseEntity<Branch> deactivate(@PathVariable String uuid) {
        Branch branch = branchService.deactivate(uuid);
        return new ResponseEntity<>(branchService.findById(branch.getBranchId()), HttpStatus.OK);
    }

    @GetMapping("/{uuid}")
    @Operation(summary = "Returns Branch information by guid")
    public ResponseEntity<Branch> findById(@PathVariable UUID uuid) {
        Branch branch = branchService.findById(uuid);
        return ResponseEntity.ok(branch);
    }

    /**
     * Get all Legal Terms by Branch Id for Workers.
     *
     * @param uuid String
     * @return List of {@link WorkerAppTerm}
     */
    @GetMapping("/{uuid}/worker-app-terms")
    @Operation(summary = "Load Terms & Conditions from Legal Department for Workers")
    public ResponseEntity<List<WorkerAppTerm>> getTermsConditions(@PathVariable String uuid) {
        List<WorkerAppTerm> list = workerService.getLegalAgreementsByBranchId(uuid);
        return ResponseEntity.ok(list);
    }

    @GetMapping
    @Operation(summary = "Returns paginated Branch information")
    public ResponseEntity<PaginatedBranchResponse> search(@Valid SearchBranchRequest request) {
        PaginatedBranchResponse paginatedBranchResponse = branchService.searchBranches(request);
        return ResponseEntity.ok(paginatedBranchResponse);
    }

    @GetMapping("/work-history")
    @Operation(summary = "Returns a list of Branch information")
    public ResponseEntity<List<BranchInformationForWorkerDto>> listBranchesInformationForWorker(@RequestParam String workerId,
                                                                                                @RequestParam String workedOnly) {
        List<BranchInformationForWorkerDto> list = branchService.listBranchesInformationForWorker(workerId, workedOnly);
        return ResponseEntity.ok(list);
    }

}
