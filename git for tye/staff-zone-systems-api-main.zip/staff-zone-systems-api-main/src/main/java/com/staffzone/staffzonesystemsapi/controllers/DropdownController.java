package com.staffzone.staffzonesystemsapi.controllers;

import static com.staffzone.staffzonesystemsapi.bos.CheckFormatType.DEFAULT_CHECK;
import static com.staffzone.staffzonesystemsapi.bos.CheckFormatType.DEPOSIT;
import static com.staffzone.staffzonesystemsapi.bos.CheckFormatType.INVOICE;
import static com.staffzone.staffzonesystemsapi.bos.CheckFormatType.SICK_CHECK;
import static com.staffzone.staffzonesystemsapi.bos.DropdownType.of;
import static com.staffzone.staffzonesystemsapi.bos.MessageTemplateType.SMS;
import static org.springframework.http.MediaType.APPLICATION_JSON;

import com.staffzone.staffzonesystemsapi.bos.DropdownType;
import com.staffzone.staffzonesystemsapi.bos.SkillTierType;
import com.staffzone.staffzonesystemsapi.dtos.DropdownDto;
import com.staffzone.staffzonesystemsapi.dtos.responses.BranchLocationsResponse;
import com.staffzone.staffzonesystemsapi.services.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller for Dropdowns.
 */
@Slf4j
@AllArgsConstructor
@RequestMapping("/api/v1")
@CrossOrigin("*")
@RestController
public class DropdownController {
  private final PayCodesService payCodesService;
  private final ProjectContactService projectContactService;
  private AppUserService appUserService;
  private CheckFormatsService checkFormatsService;
  private CompCodesService compCodesService;
  private FutaSutaSdiService futaSutaSdiService;
  private PayCyclesService payCyclesService;
  private LkStatesService lkStatesService;
  private PayRulesService payRulesService;
  private TaxesService taxesService;
  private BranchService branchService;
  private LkInvoiceMethodsService invoiceMethodsService;
  private LkPaymentTermService lkPaymentTermService;
  private AppClaimService appClaimService;
  private LkJobTitleService lkJobTitleService;
  private AppRoleService appRoleService;
  private SkillGroupsService skillGroupService;
  private ClientService clientService;
  private ClientContactService clientContactService;
  private SiteRequirementsService siteRequirementsService;
  private CertificationService certificationService;
  private SkillsService skillsService;
  private PpeService ppeService;
  private ToolsService toolsService;
  private final BillCodesService billCodesService;
  private final ProjectService projectService;
  private final ProjectOrderService projectOrderService;
  private final MessageTemplateService messageTemplateService;
  private final WorkerService workerService;
  private final CountriesService countriesService;


  /**
   * Recover Dropdowns.
   *
   * @param dropdownType Options available:
   *                     <br/><pre>{@link com.staffzone.staffzonesystemsapi.bos.DropdownType }</pre>
   * @return Dropdown values, <pre>i.e.:</pre> <pre>{@code
   *   {
   *     'dropdown':[
   *       {
   *         'id': '1',
   *         'display-name': 'Option 1'
   *       }
   *     ]
   *   }
   * } </pre>
   */
  @Operation(summary = "Retrieves Dropdown values based on the dropdown type.")
  @GetMapping("/{dropdown}/dropdown")
  //@PreAuthorize("isAuthenticated()")
  @ResponseBody
  public Object getDropdownBasedOnType(
      @Parameter(
        in = ParameterIn.PATH,
        description = "Type of dropdown values to retrieve. Available options: "
                + "check-formats, comp-codes(accepts 'state' filter), deposit-advice-format, "
                + "futa-suta-sdi, pay-check-formats, invoice-formats, pay-cycles, pay-rules, "
                + "states, tax-jurisdictions(accepts 'type' filter), branches, invoice-methods, "
                + "claims, roles, skill-groups, project-contacts(accepts 'projectId' filter), "
                + "pay-codes, site-requirements, certifications, skills, ppes, tools, "
                + "client-contacts(accepts 'clientId' filter), skill-tiers, bill-codes, "
                + "project-document-types, sms-message-templates, rate-agreement-types, "
                + "disciplinary-warning-types, payment-terms, job-titles",
        schema = @Schema(type = "string")
      )
      @PathVariable("dropdown") String dropdownType,
      @RequestParam(value = "state", required = false) String state,
      @RequestParam(value = "projectId", required = false) UUID projectId,
      @RequestParam(value = "clientId", required = false) UUID clientId,
      @RequestParam(value = "type", required = false) String type) {
    DropdownDto dropdownDto;
    try {
      DropdownType enumVal = of(dropdownType);
      if (enumVal == null) {
        throw new IllegalStateException("Unexpected value: " + of(dropdownType));
      }

      switch (enumVal) {
        case COMP_CODES -> dropdownDto = compCodesService.findActivesCompCodes(state);
        case CHECK_FORMATS -> dropdownDto = checkFormatsService.findActives(DEFAULT_CHECK);
        case DEPOSIT_ADVICE_FORMAT -> dropdownDto = checkFormatsService.findActives(DEPOSIT);
        case FUTA_SUTA_SDI -> dropdownDto = futaSutaSdiService.findActives();
        case PAY_CHECK_FORMATS -> dropdownDto = checkFormatsService.findActives(SICK_CHECK);
        case INVOICE_FORMATS -> dropdownDto = checkFormatsService.findActives(INVOICE);
        case PAY_CYCLES -> dropdownDto = payCyclesService.findActives();
        case PAY_RULES -> dropdownDto = payRulesService.findActives();
        case STATES -> dropdownDto = lkStatesService.findActives();
        case TAX_JURISDICTIONS -> dropdownDto = taxesService.findActivesJurisdictions(type);
        case INVOICE_METHODS -> dropdownDto = invoiceMethodsService.findActives();
        case PAYMENT_TERMS -> dropdownDto = lkPaymentTermService.findActives();
        case APP_CLAIMS -> dropdownDto = appClaimService.findActives();
        case APP_ROLES -> dropdownDto = appRoleService.findActives();
        case JOB_TITLES -> dropdownDto = lkJobTitleService.findActives();
        case SKILL_GROUPS -> dropdownDto = skillGroupService.findActives();
        case PROJECT_CONTACTS -> dropdownDto = projectContactService
                .listProjectsContactsDropDown(projectId);
        case CLIENT_CONTACTS -> dropdownDto = clientContactService.findActivesContacts(clientId);
        case SALES_CLOSERS -> dropdownDto = appUserService.findActivesSalesClosers();
        case PAY_CODES -> dropdownDto = payCodesService.findActives();
        case SITE_REQUIREMENTS -> dropdownDto = siteRequirementsService.findActives();
        case CERTIFICATIONS -> dropdownDto = certificationService.findActives();
        case SKILLS -> dropdownDto = skillsService.findActives();
        case PPES -> dropdownDto = ppeService.findActives();
        case TOOLS -> dropdownDto = toolsService.findActives();
        case SKILL_TIERS -> dropdownDto = SkillTierType.toDropdownDto();
        case BILL_CODES -> dropdownDto = billCodesService.findActives();
        case PROJECT_DOCUMENT_TYPES -> dropdownDto = projectService
                .findActivesProjectDocumentTypes();
        case SMS_MESSAGE_TEMPLATES -> dropdownDto = messageTemplateService.findActivesByType(SMS);
        case RATE_AGREEMENT_TYPES -> dropdownDto = projectService.findActiveAgreementTypes();
        case DISCIPLINARY_WARNING_TYPES -> dropdownDto = workerService
                .findActiveDisciplinaryWarningTypes();
        case WORKER_DOCUMENT_TYPES -> dropdownDto = workerService.findActiveWorkerDocumentTypes();
        case COUNTRIES -> dropdownDto = countriesService.findActiveCountries();
        default -> throw new IllegalStateException("Unexpected value: " + enumVal);
      }
    } catch (Exception e) {
      log.error("Invalid Request Mapping", e.getCause());
      return ResponseEntity.status(400).contentType(APPLICATION_JSON)
              .body("{'message': 'Invalid Path'}");
    }
    return ResponseEntity.ok(dropdownDto);
  }

  @GetMapping("/branches-dropdown")
  //@PreAuthorize("isAuthenticated()")
  @ResponseBody
  public Object getBranchesDropDown() {
    return ResponseEntity.ok(branchService.findActives());
  }

  @GetMapping("/clients-dropdown")
  @ResponseBody
  public Object getClientsDropDown() {
    return ResponseEntity.ok(clientService.findActives());
  }

  @GetMapping("/projects-dropdown")
  @ResponseBody
  public Object getProjectsDropDown(
          @RequestParam(value = "clientId", required = false) UUID clientId) {
    return ResponseEntity.ok(projectService.findActiveByClient(clientId));
  }

  @GetMapping("/orders-dropdown")
  @ResponseBody
  public Object getOrdersDropDown(
          @RequestParam(value = "projectId") UUID projectId) {
    return ResponseEntity.ok(projectOrderService.findActiveByProject(projectId));
  }

  @GetMapping("/active-branches-locations")
  @Operation(summary = "Returns Json with Active Branches Locations information.")
  public ResponseEntity<BranchLocationsResponse> search() {
    BranchLocationsResponse response = branchService.searchCurrentBranches();
    return ResponseEntity.ok(response);
  }

}
