package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.staffzone.staffzonesystemsapi.validators.Uuid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Auth User Request DTO.
 * <pre>{@code
 *    {
 *      "phone: "String"
 *    }
 * }</pre>
 */
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class AuthUserRequest {
  @Uuid
  private String workerId;
  @NotEmpty
  @Pattern(regexp = "^\\d{10}", message = "Phone must have 10 digits")
  private String phone;
}
