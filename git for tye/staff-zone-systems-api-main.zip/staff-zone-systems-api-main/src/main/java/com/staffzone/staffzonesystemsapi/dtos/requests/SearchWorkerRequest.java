package com.staffzone.staffzonesystemsapi.dtos.requests;

import static com.staffzone.staffzonesystemsapi.utils.StringUtils.toSnakeCase;
import static java.util.UUID.fromString;
import static org.springframework.data.domain.Sort.Direction.ASC;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.staffzone.staffzonesystemsapi.bos.WorkerStatusType;
import com.staffzone.staffzonesystemsapi.utils.DateUtils;
import com.staffzone.staffzonesystemsapi.utils.JsonUtils;
import com.staffzone.staffzonesystemsapi.validators.SortOptions;
import com.staffzone.staffzonesystemsapi.validators.Uuid;
import com.staffzone.staffzonesystemsapi.validators.ValueOfEnum;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.JSONObject;

/**
 * Search Worker Request DTO.
 */
@Slf4j
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class SearchWorkerRequest extends SearchAbstractRequest {
  private String searchBy;
  @Uuid(enableNullValues = true, enableEmptyValues = true)
  private String branchId;
  private List<@Uuid String> skills;
  private List<@Uuid String> certifications;
  private LocalDate startDate;
  private LocalDate endDate;
  private LocalDate lastDayWorkedStartDate;
  private LocalDate lastDayWorkedEndDate;
  private List<@ValueOfEnum(enumClass = WorkerStatusType.class) String> status;
  @SortOptions(anyOf = {"workerCode", "branchName", "firstName", "lastName", "lastDayWorked",
      "warnings", "raiting", "status"})
  private String sort;
  private Boolean previouslyWorked;
  @Uuid(enableNullValues = true)
  private String projectId;
  @Uuid(enableNullValues = true, enableEmptyValues = true)
  private String clientId;

  /**
   * Get sort as Json.
   *
   * @return String
   */
  @JsonIgnore
  public String getSortAsJson() {
    JSONObject jsonObject = new JSONObject();
    jsonObject.put("limit", super.getSize());

    var offset = (super.getPage() - 1) * super.getSize();
    jsonObject.put("offset", offset);

    if (sort == null || sort.isBlank()) {
      jsonObject.put("sort_column", toSnakeCase("firstName"));
      jsonObject.put("sort_direction", ASC.name());
    } else {
      String[] options = sort.split(",");
      jsonObject.put("sort_column", toSnakeCase(options[0]));
      jsonObject.put("sort_direction", options[1].toUpperCase());
    }

    return jsonObject.toJSONString();
  }

  public UUID getBranchId(){
    return (branchId == null || branchId.isEmpty()) ? null : fromString(branchId);
  }

  public UUID getClientId(){
    return (clientId == null || clientId.isEmpty()) ? null : fromString(clientId);
  }

  public String[] getSkills() {
    if(skills == null)
      return null;

    String[] skillsArr = new String[skills.size()];
    return skills.toArray(skillsArr);
  }

  public String[] getCertifications() {
    if(certifications == null)
      return null;

    String[] certificationsArr = new String[certifications.size()];
    return certifications.toArray(certificationsArr);
  }

  @JsonIgnore
  public String[] getStatusArray() {
    if (status == null) {
      return null;
    }

    String[] statusArr = new String[status.size()];
    return status.toArray(statusArr);
  }

  @JsonIgnore
  public String getProjectFilterAsJson() {
    if (previouslyWorked == null && projectId == null) {
      return null;
    }
    ProjectFilter projectFilter = ProjectFilter.builder()
        .projectId(fromString(projectId))
        .previouslyWorked(previouslyWorked)
        .build();
    return JsonUtils.toDatabaseJson(projectFilter);
  }

  @JsonIgnore
  public String getCreatedDateFilterAsJson() {
    if (startDate==null && endDate==null) return null;
    JSONObject jsonObject = new JSONObject();
    jsonObject.put("start_date", DateUtils.toString(startDate));
    jsonObject.put("end_date", DateUtils.toString(endDate));
    return jsonObject.toJSONString();
  }

  @JsonIgnore
  public String getLastDateWorkedFilterAsJson() {
    if (lastDayWorkedStartDate==null && lastDayWorkedEndDate==null) return null;
    JSONObject jsonObject = new JSONObject();
    jsonObject.put("start_date", DateUtils.toString(lastDayWorkedStartDate));
    jsonObject.put("end_date", DateUtils.toString(lastDayWorkedEndDate));
    return jsonObject.toJSONString();
  }

  @JsonIgnore
  public String getSkillsFilterAsJson() {
    return JsonUtils.toJsonArray("skill_id", skills);
  }

  @JsonIgnore
  public String getCertificationsFilterAsJson() {
    return JsonUtils.toJsonArray("certification_id", certifications);
  }
}
