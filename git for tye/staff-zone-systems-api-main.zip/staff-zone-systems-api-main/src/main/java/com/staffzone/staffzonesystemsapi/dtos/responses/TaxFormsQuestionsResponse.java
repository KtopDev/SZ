package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * TaxFormsQuestions Response from create and edit tax forms stored procedure.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TaxFormsQuestionsResponse {
  @JsonSetter(value = "question_id")
  private String questionId;
  @JsonSetter(value = "sort_order")
  private String sortOrder;
  @JsonSetter(value = "question_text")
  private String questionText;
  @JsonSetter(value = "question_type")
  private String questionType;
  private List<TaxFormsQuestionOptionsResponse> options = new ArrayList<>();
}
