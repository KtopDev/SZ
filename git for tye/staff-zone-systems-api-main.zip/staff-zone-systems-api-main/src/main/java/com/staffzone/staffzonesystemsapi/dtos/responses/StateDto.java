package com.staffzone.staffzonesystemsapi.dtos.responses;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * States DTO.
 * <pre>{@code
 *    {
 *      "state": "string",
 *      "state_name": "string",
 *      "cities": ...
 *    }
 * }</pre>
 * {@link CityDto}
 */
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class StateDto {
  private String state;
  @SuppressWarnings("checkstyle:MemberName")
  private String state_name;
  private List<CityDto> cities;
}
