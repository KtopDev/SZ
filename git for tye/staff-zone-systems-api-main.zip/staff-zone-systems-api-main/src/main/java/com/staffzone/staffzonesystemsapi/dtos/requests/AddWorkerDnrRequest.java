package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotBlank;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * WorkerDnr Request DTO.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class AddWorkerDnrRequest {
  private UUID branchId;
  private UUID clientId;
  private UUID projectId;
  @NotBlank(message = "Reason cannot be blank")
  private String reason;
}
