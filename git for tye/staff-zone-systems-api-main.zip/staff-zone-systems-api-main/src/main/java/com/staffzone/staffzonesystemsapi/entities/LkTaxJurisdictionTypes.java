package com.staffzone.staffzonesystemsapi.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;

/**
 * Entity mapped against "<strong>LkTaxJurisdictionTypes</strong>" Table.
 */
@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "lk_tax_jurisdiction_types")
public class LkTaxJurisdictionTypes extends Audit {
  @Id
  @Column(name = "jurisdiction_type", length = 20)
  private String jurisdictionType;
  private String label;
  @Builder.Default
  @Column(name = "is_row_active")
  private Boolean isRowActive = true;
}
