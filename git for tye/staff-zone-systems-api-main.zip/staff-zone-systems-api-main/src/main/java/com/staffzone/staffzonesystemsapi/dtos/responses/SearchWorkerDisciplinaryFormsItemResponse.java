package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Worker Disciplinary Forms Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchWorkerDisciplinaryFormsItemResponse {
  @JsonSetter(value = "total_rows")
  private String totalRows;
  @JsonSetter(value = "status")
  private String status;
  @JsonSetter(value = "form_date")
  private String formDate;
  @JsonSetter(value = "created_at")
  private String createdAt;
  @JsonSetter(value = "project_name")
  private String projectName;
  @JsonSetter(value = "warning_type_name")
  private String warningTypeName;
  @JsonSetter(value = "disciplinary_form_id")
  private String disciplinaryFormId;
  @JsonSetter(value = "disciplinary_form_number")
  private String disciplinaryFormNumber;
}
