package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.staffzone.staffzonesystemsapi.validators.AgreementUploadType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;
import org.springframework.web.multipart.MultipartFile;

/**
 * Project Signed Agreement Request Dto.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@FieldNameConstants
public class ProjectSignedAgreementsRequest {
  @NotBlank(message = "agreementType cannot be blank")
  private String agreementType;
  @AgreementUploadType
  @NotNull(message = "Need to upload a agreement")
  private MultipartFile agreement;
}
