package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import java.util.UUID;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Certification Id Response.
 */
@Data
@NoArgsConstructor
public class CertificationDto {
  @JsonSetter(value = "certification_id")
  private UUID certificationId;
  @JsonSetter(value = "certification_name")
  private String certificationName;
  @JsonSetter(value = "certification_abreviation")
  private String certificationAbbreviation;
}
