package com.staffzone.staffzonesystemsapi.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;

/**
 * Entity mapped against "<strong>client_notes</strong>" Table.
 */
@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "client_notes")
public class ClientNotes extends Audit {

  @Id
  private UUID clientNoteId;

  @ToString.Exclude
  @JsonIgnore
  @ManyToOne
  @JoinColumn(name = "client_id", nullable = false)
  private Client client;

  @Size(max = 100)
  @NotNull
  @Column(name = "title", nullable = false)
  private String title;

  @Size(max = 50)
  @NotNull
  @Column(name = "note_type", nullable = false)
  private String noteType;

  @Size(max = 300)
  @NotNull
  @Column(name = "note", nullable = false)
  private String note;

  @Builder.Default
  @Column(updatable = false, insertable = false)
  private Boolean isRowActive = false;

}