package com.staffzone.staffzonesystemsapi.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;

/**
 * Entity mapped against "<strong>clients</strong>" Table.
 */
@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "clients")
public class Client extends Audit {
  @Id
  @Column(name = "client_id", nullable = false)
  private UUID id;

  @Builder.Default
  @NotNull
  @Column(name = "is_row_active", nullable = false)
  private Boolean isRowActive = false;

  @Size(max = 7)
  @NotNull
  @Column(name = "client_code", nullable = false, length = 7)
  private String clientCode;

  @NotNull
  @Column(name = "client_name", nullable = false, length = Integer.MAX_VALUE)
  private String clientName;

  @Size(max = 20)
  @NotNull
  @Column(name = "status", nullable = false, length = 20)
  private String status;

  @NotNull
  @Column(name = "status_ts", nullable = false)
  private LocalDateTime statusTs;

  @NotNull
  @Column(name = "credit_limit", nullable = false, precision = 14, scale = 4)
  private BigDecimal creditLimit;

  @NotNull
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "payment_term", nullable = false)
  private LkPaymentTerm paymentTerm;

  @NotNull
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "invoice_method", nullable = false)
  private LkInvoiceMethods invoiceMethod;

  @NotNull
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "invoice_printing_format_id", nullable = false)
  private PrintingFormats invoicePrintingFormat;

  @Size(max = 10)
  @NotNull
  @Column(name = "phone", nullable = false, length = 10)
  private String phone;

  @Size(max = 10)
  @Column(name = "fax", length = 10)
  private String fax;

  @NotNull
  @Column(name = "address", nullable = false, length = Integer.MAX_VALUE)
  private String address;

  @Column(name = "address_line_2", length = Integer.MAX_VALUE)
  private String addressLine2;

  @NotNull
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "state", nullable = false)
  private LkStates state;

  @Size(max = 50)
  @NotNull
  @Column(name = "city", nullable = false, length = 50)
  private String city;

  @Size(max = 10)
  @NotNull
  @Column(name = "postal_code", nullable = false, length = 10)
  private String postalCode;

  @NotNull
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "comp_code_id", nullable = false)
  private CompCodes compCode;

  @Transient
  private LocalDateTime lastOrderDate;

  @Builder.Default
  @JsonIgnore
  @ToString.Exclude
  @OneToMany(mappedBy = "client", fetch = FetchType.LAZY)
  private Set<ClientBranch> branches = new LinkedHashSet<>();

  @JsonIgnore
  @ToString.Exclude
  @OneToMany(mappedBy = "client", fetch = FetchType.LAZY)
  private Set<ClientContact> clientContacts;
}