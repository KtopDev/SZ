package com.staffzone.staffzonesystemsapi.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;

/**
 * Entity mapped against "<strong>LkStates</strong>" Table.
 */
@Entity
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "lk_states")
public class LkStates {
  @Id
  @Column(length = 2, nullable = false)
  private String state;
  @Column(name = "state_name", nullable = false)
  private String stateName;
  @Column(name = "is_row_active", nullable = false)
  private Boolean isRowActive;

  public LkStates(String state) {
    this.state = state;
  }
}
