package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search SiteVisit Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchSiteVisitItemResponse {
  @JsonSetter(value = "site_visit_id")
  private String siteVisitId;
  @JsonSetter(value = "contact_id")
  private String contactId;
  @JsonSetter(value = "visit_date")
  private String visitDate;
  @JsonSetter(value = "visit_notes")
  private String visitNotes;
  @JsonSetter(value = "total_rows")
  private String totalRows;
}
