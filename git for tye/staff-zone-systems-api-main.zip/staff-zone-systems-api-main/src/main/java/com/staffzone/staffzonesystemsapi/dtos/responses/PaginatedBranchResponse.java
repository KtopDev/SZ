package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.staffzone.staffzonesystemsapi.dtos.BranchSearchDto;
import com.staffzone.staffzonesystemsapi.dtos.SearchBranchFilterDto;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class PaginatedBranchResponse extends PaginatedAbstractResponse {
  private List<BranchSearchDto> content;
  private SearchBranchFilterDto filters;
}
