package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Worker Documents Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchWorkerDocumentsItemResponse {
  @JsonSetter(value = "projects")
  private List<Project> projects;
  @JsonSetter(value = "file_name")
  private String fileName;
  @JsonSetter(value = "file_path")
  private String filePath;
  @JsonSetter(value = "is_general")
  private Boolean isGeneral;
  @JsonSetter(value = "total_rows")
  private String totalRows;
  @JsonSetter(value = "document_type")
  private String documentType;
  @JsonSetter(value = "document_type_name")
  private String documentsTypeName;

  public static class Project {
    @JsonProperty("project_id")
    private String projectId;
    @JsonProperty("project_name")
    private String projectName;
  }

}
