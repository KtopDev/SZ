package com.staffzone.staffzonesystemsapi.dtos.requests;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class VehicleFilter {
  private Boolean hasVehicle;
  private Integer minPassengers;
  private Integer maxPassengers;
}
