package com.staffzone.staffzonesystemsapi.dtos;

import com.staffzone.staffzonesystemsapi.entities.LkPaymentTerm;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Payment Term DTO.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class PaymentTermDto {
  private String paymentTerm;
  private String label;
  private Integer sortOrder;

  /**
   * Payment Term build from LkPaymentTerm.
   *
   * @param paymentTerm {@link LkPaymentTerm}
   * @return PaymentTermDto
   */
  public static PaymentTermDto build(LkPaymentTerm paymentTerm) {
    return PaymentTermDto.builder()
            .paymentTerm(paymentTerm.getPaymentTerm())
            .label(paymentTerm.getLabel())
            .sortOrder(paymentTerm.getSortOrder())
            .build();
  }
}
