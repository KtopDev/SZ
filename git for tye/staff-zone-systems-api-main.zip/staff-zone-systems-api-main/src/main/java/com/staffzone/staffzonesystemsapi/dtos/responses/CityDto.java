package com.staffzone.staffzonesystemsapi.dtos.responses;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * City DTO.
 * <pre>{@code
 *    {
 *      "city": "string",
 *      "branches": [...]
 *    }
 * }</pre>
 * {@link BranchLocationDto}
 */
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class CityDto {
  private String city;
  private List<BranchLocationDto> branches;
}
