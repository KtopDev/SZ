package com.staffzone.staffzonesystemsapi.dtos.responses;

import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * Project Order Response DTO.
 */
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CreateProjectOrderDetailsResponse {
  private UUID orderId;
  private UUID projectId;
  private String skillTier;
  private String description;
  private String hoursNeeded;
  private String numberOfWorkers;
  private String projectWorkerBasedBillingId;
}
