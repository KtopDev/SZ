package com.staffzone.staffzonesystemsapi.dtos.requests;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.staffzone.staffzonesystemsapi.bos.CalculationType;
import com.staffzone.staffzonesystemsapi.bos.ConcubinageStatusType;
import com.staffzone.staffzonesystemsapi.validators.Uuid;
import com.staffzone.staffzonesystemsapi.validators.ValueOfEnum;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.minidev.json.JSONObject;

/**
 * Regular Tax Request DTO.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RegularTaxRequest {
  @Uuid
  private String jurisdictionId;
  @NotNull(message = "effectiveDate cannot be null")
  private LocalDate effectiveDate;
  @ValueOfEnum(enumClass = ConcubinageStatusType.class)
  private String fillingStatus;
  @NotNull(message = "Please, indicate Bracket Start")
  @PositiveOrZero
  private BigDecimal bracketStart;
  @NotNull(message = "Please,indicate Bracket End")
  @PositiveOrZero
  private BigDecimal bracketEnd;
  @PositiveOrZero
  private BigDecimal baseAmount;
  @ValueOfEnum(enumClass = CalculationType.class)
  private String calculationType;
  @NotNull(message = "Please,indicate Tax Rate")
  @Positive
  @Max(1)
  private BigDecimal taxRate;

  public BigDecimal getBaseAmount() {
    return (baseAmount == null || baseAmount.compareTo(BigDecimal.ZERO) == 0 ) ? null : baseAmount;
  }
}
