package com.staffzone.staffzonesystemsapi.controllers;

import java.util.List;
import java.util.UUID;

import com.staffzone.staffzonesystemsapi.dtos.requests.AssignWorkerToOrderRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.CreateDispatchBucketRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.MoveWorkerToBucketDetailsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.RemoveWorkerRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchProjectOrderRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchRouteRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SplitProjectOrderRequest;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchBranchOrderResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchRouteResponse;
import com.staffzone.staffzonesystemsapi.entities.DispatchBucketDetails;
import com.staffzone.staffzonesystemsapi.services.BranchRouteService;
import com.staffzone.staffzonesystemsapi.services.DispatchBucketService;
import com.staffzone.staffzonesystemsapi.services.ProjectOrderService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller for Dispatcher Endpoints.
 */
@RequestMapping("/api/v1/dispatcher")
@CrossOrigin("*")
@RestController
@AllArgsConstructor
@Validated
public class DispatcherController {
    private BranchRouteService branchRouteService;
    private ProjectOrderService projectOrderService;
    private DispatchBucketService dispatchBucketService;


    @GetMapping("/{branchId}/orders")
    @Operation(summary = "Project Orders list and search by branch")
    public ResponseEntity<SearchBranchOrderResponse> searchOrders(
            @PathVariable UUID branchId,
            @Valid SearchProjectOrderRequest request) {
        return ResponseEntity.ok(projectOrderService.searchBranchOrders(branchId, request));
    }

    @GetMapping("/routes")
    @Operation(summary = "Branch Routes list and search")
    public ResponseEntity<SearchRouteResponse> searchBranchRoutes(
            @Valid SearchRouteRequest request) {
        return ResponseEntity.ok(branchRouteService.searchBranchRoutes(request));
    }

    @PostMapping("/assign-order-to-route")
    @Operation(summary = "Assign Project Order to a Branch Route")
    public ResponseEntity<String> assignOrderToRoute(@RequestBody @Valid CreateDispatchBucketRequest request) {
        return ResponseEntity.ok(dispatchBucketService.assignOrderToRoute(request));
    }

    @PutMapping("/{workerId}/{sourceBucketDetailId}/move-worker")
    @Operation(summary = "Move Worker (change worker transport)")
    public ResponseEntity<String> moveWorkerToBucketDetails(@PathVariable UUID workerId, @PathVariable UUID sourceBucketDetailId,
                                                            @RequestBody @Valid MoveWorkerToBucketDetailsRequest request) {
        return ResponseEntity.ok(dispatchBucketService.moveWorkerToBucketDetails(workerId, sourceBucketDetailId, request));
    }

    @PostMapping("/split-order/{routeId}")
    @Operation(summary = "Split Project Order and assign to a Branch Route")
    public ResponseEntity<String> splitOrderAndAssignToRoute(@PathVariable UUID routeId,
                                                             @RequestBody @Valid SplitProjectOrderRequest splitRequest) {
        return ResponseEntity.ok(dispatchBucketService.splitOrderAndAssignToRoute(routeId, splitRequest));
    }

    @Operation(summary = "Increments the additional worker slots for a specific bucket detail")
    @PutMapping(value = "/bucket/details/{bucketDetailId}/increment-slots")
    public ResponseEntity<String> incrementBucketDetailAdditionalSlots(@PathVariable UUID bucketDetailId) {
        return ResponseEntity.ok().body(dispatchBucketService.incrementAdditionalSlots(bucketDetailId));
    }

    @Operation(summary = "Reduces the additional worker slots for a specific bucket detail")
    @PutMapping(value = "/bucket/details/{bucketDetailId}/reduce-slots")
    public ResponseEntity<String> reduceBucketDetailAdditionalSlots(@PathVariable UUID bucketDetailId) {
        return ResponseEntity.ok().body(dispatchBucketService.reduceAdditionalSlots(bucketDetailId));
    }

    @DeleteMapping("/{bucketDetailId}/remove-worker")
    @Operation(summary = "Removing worker from bucket")
    public ResponseEntity<String> removeWorkerFromBucket(@PathVariable UUID bucketDetailId,
                                                         @RequestBody @Valid RemoveWorkerRequest request) {
        return ResponseEntity.ok(dispatchBucketService.removeWorkerFromBucket(bucketDetailId, request));
    }

    @Operation(summary = "Assigns a worker to an order")
    @PutMapping(value = "/orders/{orderId}/wbb/{projectWorkerBasedBillingId}")
    public ResponseEntity<String> assignWorkerToOrder(@PathVariable UUID orderId,
                                                      @PathVariable UUID projectWorkerBasedBillingId,
                                                      @RequestBody @Valid AssignWorkerToOrderRequest request) {
        return ResponseEntity.ok().body(dispatchBucketService.assignWorkerToOrder(orderId, projectWorkerBasedBillingId,
                UUID.fromString(request.getWorkerId()), null));
    }

    @Operation(summary = "Assigns a worker to bucket")
    @PutMapping(value = "/bucket/details/{bucketDetailId}/{slotIndex}")
    public ResponseEntity<String> assignWorkerToBucket(@PathVariable UUID bucketDetailId,
                                                       @PathVariable Integer slotIndex,
                                                       @RequestBody @Valid AssignWorkerToOrderRequest request) {
        return ResponseEntity.ok().body(dispatchBucketService.assignWorkerToBucket(bucketDetailId,
                UUID.fromString(request.getWorkerId()), slotIndex));
    }

    @PutMapping("/{bucketId}/move-order-to-route/{routeId}")
    @Operation(summary = "Move order to a route (change bucket)")
    public ResponseEntity<String> moveOrderToRoute(@PathVariable UUID bucketId,
                                                   @PathVariable UUID routeId) {
        return ResponseEntity.ok(dispatchBucketService.moveOrderToRoute(bucketId, routeId));
    }

    @GetMapping("/{bucketId}/dispatch-details/temp")
    @Operation(summary = "Temporary endpoint to bring Dispatch details")
    public ResponseEntity<DispatchBucketDetails> temporaryDispatchBucketDetails(@PathVariable UUID bucketId) {
        return ResponseEntity.ok(dispatchBucketService.findById(bucketId));
    }

    @GetMapping("/all-dispatch-details/temp")
    @Operation(summary = "Temporary endpoint to bring Dispatch details")
    public ResponseEntity<List<DispatchBucketDetails>> allTemporaryDispatchBucketDetails() {
        return ResponseEntity.ok((List<DispatchBucketDetails>) dispatchBucketService.findAll());
    }

}
