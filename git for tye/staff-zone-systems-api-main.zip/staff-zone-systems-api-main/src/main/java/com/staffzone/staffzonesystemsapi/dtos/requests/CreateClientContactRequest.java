package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateClientContactRequest {
  private String clientId;
  @NotBlank(message = "Name cannot be blank")
  private String name;
  @NotBlank(message = "Last Name cannot be blank")
  private String lastName;
  @NotBlank(message = "Email cannot be blank")
  @Pattern(regexp = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$", message = "Invalid email address")
  private String email;
  @NotBlank(message = "Phone cannot be blank")
  @Pattern(regexp = "^\\d{10}", message = "Phone must have 10 digits")
  private String cellPhone;
  @NotNull(message = "Contact access field cannot be null")
  private Boolean isClientAppEnable;
  @NotNull(message = "Receive and pay invoice field cannot be null")
  private Boolean isBillAndInvoiceEnable;
  @NotNull(message = "Approve and create orders field cannot be null")
  private Boolean isApprovalAndCreationEnable;
  @NotNull(message = "Rate Worker field cannot be null")
  private Boolean isRateWorkersEnable;
  @NotBlank(message = "Please indicate an MFA")
  private String preferredMultiFactor;
  @NotNull(message = "Insert a number between 1 and 365")
  @Min(value = 1)
  @Max(value = 365)
  private Integer multiFactorAuthenticationTtlDays;
}
