package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Garnishment Type Request.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GarnishmentTypeRequest {
  @NotBlank(message = "Type Name cannot be blank")
  private String garnishmentTypeName;
  @NotNull(message = "Percentage cannot be null")
  @Positive(message = "Max Percentage must be bigger than 0")
  @DecimalMax(value = "100.0", inclusive = false)
  private BigDecimal maxPercentage;
}
