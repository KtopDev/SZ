package com.staffzone.staffzonesystemsapi.dtos;

import com.staffzone.staffzonesystemsapi.entities.AppUser;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * App User Dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class AppUserDto {
  private UUID appUserId;
  private String userCode;
  private String firstName;
  private String lastName;
  private String status;
  private String jobTitle;

  /**
   * Custom build.
   *
   * @param appUser {@link AppUser}
   * @return AppUserDto
   */
  public static AppUserDto build(AppUser appUser) {
    return AppUserDto.builder()
            .appUserId(appUser.getAppUserId())
            .userCode(appUser.getAppUserCode())
            .firstName(appUser.getFirstName())
            .lastName(appUser.getLastName())
            .status(appUser.getStatus())
            .jobTitle(appUser.getLkJobTitle().getLabel())
            .build();
  }
}
