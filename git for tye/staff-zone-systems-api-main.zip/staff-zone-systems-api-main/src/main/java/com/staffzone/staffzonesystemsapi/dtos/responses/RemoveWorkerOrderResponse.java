package com.staffzone.staffzonesystemsapi.dtos.responses;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Remove Worker From Order stored procedure.
 */
@Data
@NoArgsConstructor
public class RemoveWorkerOrderResponse {
  private String workerId;
}
