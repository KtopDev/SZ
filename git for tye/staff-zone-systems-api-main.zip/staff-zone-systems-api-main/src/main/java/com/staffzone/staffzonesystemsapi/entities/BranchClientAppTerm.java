package com.staffzone.staffzonesystemsapi.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.staffzone.staffzonesystemsapi.entities.ids.BranchClientAppTermId;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldNameConstants;

/**
 * Entity mapped against "<strong>branch_client_app_terms</strong>" Table.
 */
@Entity
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@FieldNameConstants
@Table(name = "branch_client_app_terms")
public class BranchClientAppTerm {
  @EmbeddedId
  private BranchClientAppTermId id;

  @MapsId("branchId")
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "branch_id", nullable = false)
  @JsonBackReference
  private Branch branch;

  @MapsId("clientAppTermId")
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "client_app_term_id", nullable = false)
  private ClientAppTerms clientAppTerm;

  @Builder.Default
  @NotNull
  @Column(name = "is_row_active", nullable = false)
  private Boolean isRowActive = false;

}