package com.staffzone.staffzonesystemsapi.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;

/**
 * Entity mapped against "<strong>LkProjectSignedAgreementType</strong>" Table.
 */
@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "lk_project_signed_agreement_types")
public class LkProjectSignedAgreementType extends Audit {
  @Column(name = "is_row_active")
  private Boolean isRowActive;
  @Id
  @Column(name = "agreement_type")
  private String agreementType;
  @Column(name = "agreement_type_name")
  private String agreementTypeName;
}
