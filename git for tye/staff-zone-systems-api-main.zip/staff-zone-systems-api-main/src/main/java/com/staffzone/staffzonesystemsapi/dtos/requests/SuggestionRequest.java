package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Suggestion Request Dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SuggestionRequest {
  @NotBlank(message = "suggestion cannot be blank")
  private String suggestion;
}
