package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.staffzone.staffzonesystemsapi.bos.TaxJurisdictionType;
import com.staffzone.staffzonesystemsapi.validators.ValueOfEnum;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;
import org.hibernate.validator.constraints.Length;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxJurisdictionsRequest {
  private String name;
  @NotBlank(message = "type cannot be blank")
  @ValueOfEnum(enumClass = TaxJurisdictionType.class,
               message = "Type must be either 'STATE','CITY','REGIONAL','SCHOOL_DISTRICT'")
  private String type;
  @Length(min = 2, max = 2, message = "Length should be 2")
  private String state;

  @SneakyThrows
  @JsonIgnore
  public String toDBJson() {
    ObjectMapper mapper = new ObjectMapper();
    ObjectNode jsonObject = mapper.createObjectNode();
    jsonObject.put("tax_jurisdiction_name", name);
    jsonObject.put("jurisdiction_type", type);
    jsonObject.put("state", state);
    return mapper.writeValueAsString(jsonObject);
  }
}
