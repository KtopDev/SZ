package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.staffzone.staffzonesystemsapi.entities.LkStates;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * States DTO.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StatesDto {
  private String state;
  private String stateName;

  /**
   * States builder from LkStates.
   *
   * @param lkStates {@link LkStates}
   * @return StatesDto
   */
  public static StatesDto build(LkStates lkStates) {
    return StatesDto.builder()
            .state(lkStates.getState())
            .stateName(lkStates.getStateName())
            .build();
  }
}
