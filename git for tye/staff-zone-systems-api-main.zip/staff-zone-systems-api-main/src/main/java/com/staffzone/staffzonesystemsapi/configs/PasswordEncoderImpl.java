package com.staffzone.staffzonesystemsapi.configs;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import lombok.SneakyThrows;
import org.springframework.security.crypto.password.PasswordEncoder;

public class PasswordEncoderImpl implements PasswordEncoder {
  @Override
  public String encode(CharSequence rawPassword) {
    return createSHAHash(rawPassword.toString());
  }

  @Override
  public boolean matches(CharSequence rawPassword, String encodedPassword) {
    String encodedRaw = encode(rawPassword);
    return encodedRaw.equals(encodedPassword);
  }

  @SneakyThrows
  public String createSHAHash(String input) {
    String hashtext = null;
    MessageDigest md = MessageDigest.getInstance("SHA-256");
    byte[] messageDigest =
        md.digest(input.getBytes(StandardCharsets.UTF_8));

    hashtext = convertToHex(messageDigest);
    return hashtext;
  }

  private String convertToHex(final byte[] messageDigest) {
    BigInteger bigint = new BigInteger(1, messageDigest);
    String hexText = bigint.toString(16);
    while (hexText.length() < 32) {
      hexText = "0".concat(hexText);
    }
    return hexText;
  }
}
