package com.staffzone.staffzonesystemsapi.dtos.responses;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Client App term Item Response Dto.
 * <pre>{@code
 *    {
 *      "sort_order":                  number,
 *      "modified_at":                 "dd/mm/yyyy",
 *      "in_use_branches":             [... ],
 *      "worker_app_term_id":          "string"
 *      "worker_app_term_file_uri":    "string",
 *      "worker_app_term_label":   "string",
 *      "worker_app_term_es_file_uri": "string"
 *    }
 * }</pre>
 * {@link InUseBranchResponse}
 */
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class WorkerAppTermItemResponse {
  private Integer sort_order;
  private String modified_at;
  private List<InUseBranchResponse> in_use_branches;
  private String worker_app_term_id;
  private String worker_app_term_file_uri;
  private String worker_app_term_label;
  private String worker_app_term_es_file_uri;
}
