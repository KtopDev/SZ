package com.staffzone.staffzonesystemsapi.bos;

public enum MfaPreferenceType {
  SMS, EMAIL, AUTH_APP, NONE;
  public static MfaPreferenceType of(String str) {
    for (MfaPreferenceType type : values()) {
      if (str.toUpperCase().equals(type.name())) {
        return type;
      }
    }
    return null;
  }
}
