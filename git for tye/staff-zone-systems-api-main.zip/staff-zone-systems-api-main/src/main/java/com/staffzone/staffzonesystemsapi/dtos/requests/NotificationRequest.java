package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

/**
 * Notification Request Dto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class NotificationRequest {

  @NotBlank(message = "You must add a message")
  @Length(max = 160, message = "The text should not exceed 160 characters")
  private String text;
}
