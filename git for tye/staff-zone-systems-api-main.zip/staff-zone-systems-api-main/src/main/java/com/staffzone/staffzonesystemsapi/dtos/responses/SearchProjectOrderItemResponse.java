package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Project Order Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchProjectOrderItemResponse {
  @JsonSetter(value = "order_id")
  private String orderId;
  @JsonSetter(value = "ocurrences")
  private String occurrences;
  @JsonSetter(value = "total_rows")
  private String totalRows;
  @JsonSetter(value = "last_dispatch_ts")
  private String lastDispatch;
  @JsonSetter(value = "order_number")
  private String orderNumber;
  @JsonSetter(value = "status")
  private String status;
  @JsonSetter(value = "order_start_ts")
  private String orderStartTs;
  @JsonSetter(value = "status_ts")
  private String statusTs;
}
