package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Search Abstract Request DTO.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class SearchAbstractRequest {
  @Builder.Default
  @Min(1)
  private int size = 10;
  @Builder.Default
  @Min(1)
  private int page = 1;
}
