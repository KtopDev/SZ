package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.util.UUID;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Order DTO Response.
 */
@Data
@NoArgsConstructor
public class OrderDto {
  @JsonAlias(value = "seats")
  private Integer seats;
  @JsonAlias(value = "order_id")
  private UUID orderId;
  @JsonAlias(value = "client_name")
  private String clientName;
  @JsonAlias(value = "order_number")
  private String orderNumber;
  @JsonAlias(value = "project_name")
  private String projectName;
  @JsonAlias(value = "dispatch_bucket_id")
  private UUID dispatchBucketId;
}
