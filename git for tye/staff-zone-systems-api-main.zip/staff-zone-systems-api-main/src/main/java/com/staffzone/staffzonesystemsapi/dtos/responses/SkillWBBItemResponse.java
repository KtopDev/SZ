package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import java.util.UUID;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Skill Response from create and edit skill stored procedure.
 */
@Data
@NoArgsConstructor
public class SkillWBBItemResponse {
  @JsonSetter(value = "skill_id")
  private String skillId;
  @JsonSetter(value = "skill_name")
  private String skillName;
}
