package com.staffzone.staffzonesystemsapi.bos;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * StatusType: <br/>
 * {@link #MONTHLY},<br/>
 * {@link #YEARLY}.
 */
@Getter
@AllArgsConstructor
public enum RecurrencyType {
  MONTHLY,
  YEARLY;
}
