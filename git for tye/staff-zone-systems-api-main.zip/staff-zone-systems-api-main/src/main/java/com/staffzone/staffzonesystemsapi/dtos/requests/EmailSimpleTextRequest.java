package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Email Base Request Dto.
 * <br/> Also see {@link EmailBaseRequest}
 */
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@SuperBuilder
public class EmailSimpleTextRequest extends EmailBaseRequest {
  @NotNull(message = "The content cannot be null")
  private String message;
}
