package com.staffzone.staffzonesystemsapi.dtos;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

/**
 * WorkerDnr Remove Request DTO.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class RemoveWorkerDnrRequest {
  @NotBlank(message = "Reason cannot be blank")
  private String reason;
}
