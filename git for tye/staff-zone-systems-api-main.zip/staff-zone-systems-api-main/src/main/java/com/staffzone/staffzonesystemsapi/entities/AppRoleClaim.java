package com.staffzone.staffzonesystemsapi.entities;

import com.staffzone.staffzonesystemsapi.entities.ids.AppRoleClaimId;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;


/**
 * The persistent class for the app_role_claims database table.
 */
@Entity
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "app_role_claims")
public class AppRoleClaim {
  @EmbeddedId
  private AppRoleClaimId id;

  @ManyToOne
  @JoinColumn(name = "claim")
  private AppClaim appClaim;

  @ManyToOne
  @JoinColumn(name = "role")
  private AppRole appRole;

  @Builder.Default
  @Column(updatable = false, insertable = false)
  private Boolean isRowActive = false;
  @Column(updatable = false, insertable = false)
  private LocalDate createdAt;
  @Column(updatable = false, insertable = false)
  private String createdBy;
  @Column(updatable = false, insertable = false)
  private String modifiedBy;
  @Column(updatable = false, insertable = false)
  private LocalDate modifiedAt;
}
