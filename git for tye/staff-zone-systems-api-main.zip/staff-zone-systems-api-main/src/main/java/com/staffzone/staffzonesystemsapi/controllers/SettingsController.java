package com.staffzone.staffzonesystemsapi.controllers;

import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.ResponseEntity.ok;

import com.staffzone.staffzonesystemsapi.dtos.requests.BillCodeRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.CertificationRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.CompCodeRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.CreatePayCyclesRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.CreateUnemploymentJurisdictionsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.LedgerAccountRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.GarnishmentTypeRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.GarnishmentVendorRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.HeadTaxRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.PayCodeRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.PpeRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.RegularTaxRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchBillCodeRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchCertificationsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchCompCodesRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchGarnishmentsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchGarnishmentsTypesRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchHeadTaxesRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchJurisdictionTaxesRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchJurisdictionsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchLedgerAccountRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchPayCodeRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchPayCyclesRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchPpeRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchPrintingFormatsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchPrintingFormatsWithoutFormatRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchRegularTaxesRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchSickPayRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchSiteRequirementsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchSkillsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchTaxFormsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchToolsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SickPayJurisdictionsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SiteRequirementRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SkillsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.TaxFormsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.TaxJurisdictionsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.ToolsRequest;
import com.staffzone.staffzonesystemsapi.dtos.responses.BillCodeDatabaseResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.CertificationResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.CompCodeResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.DatabaseResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.GarnishmentsVendorResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.HeadTaxResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.PaginatedJurisdictionTaxesResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.PayCodeDatabaseResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.PayCyclesResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.PpeResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.RegularTaxResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchBillCodeResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchCertificationsResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchCompCodesResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchGarnishmentsResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchGarnishmentsTypesResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchHeadTaxResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchJurisdictionsResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchLedgerAccountResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchPayCodeResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchPayCyclesResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchPpeResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchPrintingFormatsResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchRegularTaxResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchSickPayResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchSiteRequirementsResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchSkillsResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchTaxFormsResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchToolsResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SickPayJurisdictionsResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SiteRequirementsResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SkillResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.TaxFormsResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.TaxJurisdictionsResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.ToolResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.UnJurisdictionResponse;
import com.staffzone.staffzonesystemsapi.entities.BillCodes;
import com.staffzone.staffzonesystemsapi.entities.CompCodes;
import com.staffzone.staffzonesystemsapi.entities.GarnishmentType;
import com.staffzone.staffzonesystemsapi.entities.GarnishmentVendor;
import com.staffzone.staffzonesystemsapi.entities.HeadTax;
import com.staffzone.staffzonesystemsapi.entities.LedgerAccounts;
import com.staffzone.staffzonesystemsapi.entities.PayCodes;
import com.staffzone.staffzonesystemsapi.entities.PayCycles;
import com.staffzone.staffzonesystemsapi.entities.PersonalProtectiveEquipment;
import com.staffzone.staffzonesystemsapi.entities.PrintingFormats;
import com.staffzone.staffzonesystemsapi.entities.RegularTax;
import com.staffzone.staffzonesystemsapi.entities.SickPayJurisdictions;
import com.staffzone.staffzonesystemsapi.entities.Skills;
import com.staffzone.staffzonesystemsapi.entities.UnemploymentJurisdictions;
import com.staffzone.staffzonesystemsapi.services.BillCodesService;
import com.staffzone.staffzonesystemsapi.services.CertificationService;
import com.staffzone.staffzonesystemsapi.services.CompCodesService;
import com.staffzone.staffzonesystemsapi.services.FutaSutaSdiService;
import com.staffzone.staffzonesystemsapi.services.LedgerAccountService;
import com.staffzone.staffzonesystemsapi.services.GarnishmentService;
import com.staffzone.staffzonesystemsapi.services.PayCodesService;
import com.staffzone.staffzonesystemsapi.services.PayCyclesService;
import com.staffzone.staffzonesystemsapi.services.PayRulesService;
import com.staffzone.staffzonesystemsapi.services.PpeService;
import com.staffzone.staffzonesystemsapi.services.PrintingFormatService;
import com.staffzone.staffzonesystemsapi.services.SiteRequirementsService;
import com.staffzone.staffzonesystemsapi.services.SkillsService;
import com.staffzone.staffzonesystemsapi.services.TaxFormsService;
import com.staffzone.staffzonesystemsapi.services.TaxesService;
import com.staffzone.staffzonesystemsapi.services.ToolsService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import java.util.UUID;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller for Settings Endpoints.
 */
@RequestMapping("/api/v1/settings")
@CrossOrigin("*")
@RestController
@AllArgsConstructor
public class SettingsController {
  private final SkillsService skillsService;
  private final GarnishmentService garnishmentsService;
  private final TaxesService taxesService;
  private PayRulesService payRulesService;
  private PpeService ppeService;
  private CompCodesService compCodeService;
  private FutaSutaSdiService futaSutaSdiService;
  private PayCyclesService payCyclesService;
  private PayCodesService payCodeService;
  private BillCodesService billCodeService;
  private ToolsService toolsService;
  private SiteRequirementsService siteRequirementsService;
  private CertificationService certificationService;
  private TaxFormsService taxFormsService;
  private PrintingFormatService printingFormatService;
  private LedgerAccountService ledgerAccountService;

  @GetMapping("/comp-codes/{compCode}")
  @Operation(summary = "Retrieves CompCode info by compCode")
  public ResponseEntity<CompCodes> findById(@PathVariable UUID compCode) {
    return ResponseEntity.ok(compCodeService.findById(compCode));
  }

  @PostMapping("/comp-codes")
  @Operation(summary = "Creates a CompCode")
  public ResponseEntity<CompCodes> save(@RequestBody @Valid CompCodeRequest request) {
    CompCodeResponse response = compCodeService.createCompCode(request);
    return new ResponseEntity<>(compCodeService.findById(response.getCompCodeId()), CREATED);
  }

  @GetMapping("/comp-codes")
  @Operation(summary = "Filter CompCode search")
  public ResponseEntity<SearchCompCodesResponse> searchBy(
          @Valid SearchCompCodesRequest request) {
    return ResponseEntity.ok(compCodeService.searchCompCodes(request));
  }

  @GetMapping("/pay-cycles")
  @Operation(summary = "Pay Cycles search")
  public ResponseEntity<SearchPayCyclesResponse> searchPayCycles(
          @RequestParam(name = "pay_cycle_name", required = false) String payCycleName,
          @Valid SearchPayCyclesRequest paginationOptions) {
    return ResponseEntity.ok(payCyclesService.search(payCycleName, paginationOptions));
  }

  @GetMapping("/taxes")
  @Operation(summary = "Search FUTA SUTA SDI taxes")
  public ResponseEntity<PaginatedJurisdictionTaxesResponse> searchBy(
          @Valid SearchJurisdictionTaxesRequest search) {
    return ResponseEntity.ok(futaSutaSdiService.searchJurisdictionTaxes(search));
  }

  @PostMapping("/taxes")
  @Operation(summary = "Create FUTA SUTA SDI")
  public ResponseEntity<UnemploymentJurisdictions> createTaxes(
          @RequestBody @Valid CreateUnemploymentJurisdictionsRequest request) {
    UnJurisdictionResponse taxes = futaSutaSdiService.createTaxes(request);
    return new ResponseEntity<>(futaSutaSdiService
            .findById(taxes.getUnemploymentJurisdictionId()), CREATED);
  }

  @PutMapping("/comp-codes/{compCodeId}")
  @Operation(summary = "Edits a CompCode")
  public ResponseEntity<CompCodes> edit(@PathVariable UUID compCodeId,
                                        @RequestBody @Valid CompCodeRequest request) {
    CompCodeResponse response = compCodeService.editCompCode(compCodeId, request);
    return ResponseEntity.ok(compCodeService.findById(response.getCompCodeId()));
  }

  @DeleteMapping("/comp-codes/{compCodeId}")
  @Operation(summary = "Deletes a CompCode")
  public ResponseEntity<DatabaseResponse<CompCodeResponse>> delete(
          @PathVariable UUID compCodeId) {
    return ResponseEntity.ok(compCodeService.deleteCompCode(compCodeId));
  }

  @PutMapping("/taxes/{taxId}")
  @Operation(summary = "Edits a FUTA SUTA SDI")
  public ResponseEntity<UnemploymentJurisdictions> editTaxes(
          @PathVariable UUID taxId,
          @RequestBody @Valid CreateUnemploymentJurisdictionsRequest request) {
    UnJurisdictionResponse tax = futaSutaSdiService.ediTaxes(taxId, request);
    return ResponseEntity.ok(futaSutaSdiService.findById(tax.getUnemploymentJurisdictionId()));
  }

  @DeleteMapping("/taxes/{taxId}")
  @Operation(summary = "Deletes a FUTA SUTA SDI")
  public ResponseEntity<DatabaseResponse<UnJurisdictionResponse>> deleteTaxes(
          @PathVariable UUID taxId) {
    return ResponseEntity.ok(futaSutaSdiService.deleteTaxes(taxId));
  }

  @PostMapping("/pay-cycles")
  @Operation(summary = "Create a Pay cycles")
  public ResponseEntity<PayCycles> createPayCycles(
          @RequestBody @Valid CreatePayCyclesRequest request) {
    PayCycles cycles = payCyclesService.createPayCycles(request);
    return new ResponseEntity<>(payCyclesService
            .findById(cycles.getPayCycleId()), CREATED);
  }

  @PutMapping("/pay-cycles/{payCycleId}")
  @Operation(summary = "Create a Pay cycles")
  public ResponseEntity<PayCycles> editPayCycles(
          @PathVariable UUID payCycleId,
          @RequestBody @Valid CreatePayCyclesRequest request) {
    PayCycles payCycle = payCyclesService.editPayCycles(payCycleId, request);
    return ResponseEntity.ok(payCyclesService.findById(payCycle.getPayCycleId()));
  }

  @DeleteMapping("/pay-cycles/{payCycleId}")
  @Operation(summary = "Deletes a Pay Cycle")
  public ResponseEntity<DatabaseResponse<PayCyclesResponse>> deletePayCycles(
          @PathVariable UUID payCycleId) {
    return ResponseEntity.ok(payCyclesService.deletePayCycle(payCycleId));
  }

  @GetMapping("/sick-pay")
  @Operation(summary = "Sick pay list and search")
  public ResponseEntity<SearchSickPayResponse> searchSickPay(
          @Valid SearchSickPayRequest sickPayRequest) {
    return ResponseEntity.ok(payRulesService.searchSickPay(sickPayRequest));
  }

  @GetMapping("/sick-pay/{sickPayId}")
  @Operation(summary = "Retrieves Sick Pay info by id")
  public ResponseEntity<SickPayJurisdictions> findSickPayById(@PathVariable UUID sickPayId) {
    return ResponseEntity.ok(payRulesService.findById(sickPayId));
  }

  @PostMapping("/sick-pay")
  @Operation(summary = "Creates a Sick Pay")
  public ResponseEntity<SickPayJurisdictions> saveSickPay(
          @RequestBody @Valid SickPayJurisdictionsRequest request) {
    SickPayJurisdictions response = payRulesService.createSickPay(request);
    return new ResponseEntity<>(payRulesService.findById(response.getId()), CREATED);
  }

  @PutMapping("/sick-pay/{sickPayId}")
  @Operation(summary = "Edits a Sick Pay")
  public ResponseEntity<SickPayJurisdictions> editSickPay(
          @PathVariable UUID sickPayId,
          @RequestBody @Valid SickPayJurisdictionsRequest request) {
    SickPayJurisdictions sickPay = payRulesService.editSickPay(sickPayId, request);
    return ResponseEntity.ok(payRulesService.findById(sickPay.getId()));
  }

  @DeleteMapping("/sick-pay/{sickPayId}")
  @Operation(summary = "Deletes a Sick Pay")
  public ResponseEntity<DatabaseResponse<SickPayJurisdictionsResponse>> deleteSickPay(
          @PathVariable UUID sickPayId) {
    return ResponseEntity.ok(payRulesService.deleteSickPay(sickPayId));
  }

  @GetMapping("/ppe")
  @Operation(summary = "PPE list and search")
  public ResponseEntity<SearchPpeResponse> searchPpe(
          @Valid SearchPpeRequest ppeRequest) {
    return ResponseEntity.ok(ppeService.searchPpe(ppeRequest));
  }

  @PostMapping("/ppe")
  @Operation(summary = "Creates a PPE")
  public ResponseEntity<PpeResponse> savePpe(@RequestBody @Valid PpeRequest request) {
    PpeResponse response = ppeService.createPpe(request);
    return new ResponseEntity<>(response, CREATED);
  }

  @PutMapping("/ppe/{ppeId}")
  @Operation(summary = "Edits a PPE")
  public ResponseEntity<PpeResponse> editPpe(@PathVariable UUID ppeId,
                                             @RequestBody @Valid PpeRequest request) {
    PpeResponse response = ppeService.editPpe(ppeId, request);
    return ResponseEntity.ok(response);
  }

  @GetMapping("/ppe/{ppeId}")
  @Operation(summary = "Get info for a PPE")
  public ResponseEntity<PersonalProtectiveEquipment> getPpe(@PathVariable UUID ppeId) {
    return ResponseEntity.ok(ppeService.findById(ppeId));
  }

  @DeleteMapping("/ppe/{ppeId}")
  @Operation(summary = "Deletes a PPE")
  public ResponseEntity<DatabaseResponse> deletePpe(@PathVariable UUID ppeId) {
    return ResponseEntity.ok(ppeService.deletePpe(ppeId));
  }

  @GetMapping("/pay-codes")
  @Operation(summary = "Pay codes list and search")
  public ResponseEntity<SearchPayCodeResponse> searchPayCodes(
          @Valid SearchPayCodeRequest payCodeRequest) {
    return ResponseEntity.ok(payCodeService.searchPayCodes(payCodeRequest));
  }

  @GetMapping("/bill-codes")
  @Operation(summary = "Bill codes list and search")
  public ResponseEntity<SearchBillCodeResponse> searchBillCodes(
          @Valid SearchBillCodeRequest billCodeRequest) {
    return ResponseEntity.ok(billCodeService.searchBillCodes(billCodeRequest));
  }

  @PutMapping("/pay-codes/{payCodeId}")
  @Operation(summary = "Edits a Pay code")
  public ResponseEntity<PayCodes> editPayCodes(@PathVariable UUID payCodeId,
                                               @RequestBody @Valid PayCodeRequest request) {
    PayCodes payCodes = payCodeService.editPayCode(payCodeId, request);
    return ResponseEntity.ok(payCodeService.findById(payCodes.getPayCodeId()));
  }

  @PostMapping("/pay-codes")
  @Operation(summary = "Creates a Pay code")
  public ResponseEntity<PayCodes> createPayCodes(@RequestBody @Valid PayCodeRequest request) {
    PayCodes payCodes = payCodeService.createPayCode(request);
    return ResponseEntity.ok(payCodeService.findById(payCodes.getPayCodeId()));
  }

  @DeleteMapping("/pay-codes/{payCodeId}")
  @Operation(summary = "Deletes a Pay Code")
  public ResponseEntity<DatabaseResponse<PayCodeDatabaseResponse>> deletePayCodes(
          @PathVariable UUID payCodeId) {
    return ResponseEntity.ok(payCodeService.deletePayCode(payCodeId));
  }

  @PostMapping("/bill-codes")
  @Operation(summary = "Creates a Bill code")
  public ResponseEntity<BillCodes> createBillCodes(@RequestBody @Valid BillCodeRequest request) {
    BillCodes billCodes = billCodeService.createBillCode(request);
    return ResponseEntity.ok(billCodeService.findById(billCodes.getBillCodeId()));
  }

  @PutMapping("/bill-codes/{billCodeId}")
  @Operation(summary = "Edits a Bill code")
  public ResponseEntity<BillCodes> editBillCodes(@PathVariable UUID billCodeId,
                                                 @RequestBody @Valid BillCodeRequest request) {
    BillCodes billCodes = billCodeService.editBillCode(billCodeId, request);
    return ResponseEntity.ok(billCodeService.findById(billCodes.getBillCodeId()));
  }

  @DeleteMapping("/bill-codes/{billCodeId}")
  @Operation(summary = "Deletes a Bill Code")
  public ResponseEntity<DatabaseResponse<BillCodeDatabaseResponse>> deleteBillCodes(
          @PathVariable UUID billCodeId) {
    return ResponseEntity.ok(billCodeService.deleteBillCode(billCodeId));
  }

  @GetMapping("/site-requirements")
  @Operation(summary = "Site Requirements list and search")
  public ResponseEntity<SearchSiteRequirementsResponse> searchSiteRequirements(
          @Valid SearchSiteRequirementsRequest request) {
    return ResponseEntity.ok(siteRequirementsService.searchSiteRequirements(request));
  }

  @GetMapping("/tools")
  @Operation(summary = "Tools list and search")
  public ResponseEntity<SearchToolsResponse> searchTools(
          @Valid SearchToolsRequest toolsRequest) {
    return ResponseEntity.ok(toolsService.searchTools(toolsRequest));
  }

  @PostMapping("/tools")
  @Operation(summary = "Creates a Tool")
  public ResponseEntity<ToolResponse> createTools(@RequestBody @Valid ToolsRequest request) {
    ToolResponse response = toolsService.createTools(request);
    return new ResponseEntity<>(response, CREATED);
  }

  @PutMapping("/tools/{toolsId}")
  @Operation(summary = "Edits a Tool")
  public ResponseEntity<ToolResponse> editTools(@PathVariable UUID toolsId,
                                                @RequestBody @Valid ToolsRequest request) {
    ToolResponse response = toolsService.editTools(toolsId, request);
    return ResponseEntity.ok(response);
  }

  @DeleteMapping("/tools/{toolsId}")
  @Operation(summary = "Deletes a Tool")
  public ResponseEntity<DatabaseResponse> deleteTools(@PathVariable UUID toolsId) {
    DatabaseResponse deleteResponse = toolsService.deleteTools(toolsId);
    return ResponseEntity.ok(deleteResponse);
  }

  @GetMapping("/certifications")
  @Operation(summary = "Certifications list and search")
  public ResponseEntity<SearchCertificationsResponse> searchCertifications(
          @Valid SearchCertificationsRequest certificationsRequest) {
    return ResponseEntity.ok(certificationService.searchCertifications(certificationsRequest));
  }

  @PostMapping("/certifications")
  @Operation(summary = "Creates a Certification")
  public ResponseEntity<CertificationResponse> saveCertification(
          @RequestBody @Valid CertificationRequest request) {
    CertificationResponse response = certificationService.createCertification(request);
    return new ResponseEntity<>(response, CREATED);
  }

  @PutMapping("/certifications/{certificationId}")
  @Operation(summary = "Edits a Certification")
  public ResponseEntity<CertificationResponse> editCertification(
          @PathVariable UUID certificationId,
          @RequestBody @Valid CertificationRequest request) {
    return ResponseEntity.ok(certificationService.editCertification(certificationId, request));
  }

  @DeleteMapping("/certifications/{certificationId}")
  @Operation(summary = "Deletes a Bill Code")
  public ResponseEntity<DatabaseResponse<BillCodeDatabaseResponse>> deleteCertification(
          @PathVariable UUID certificationId) {
    return ResponseEntity.ok(certificationService.deleteCertification(certificationId));
  }

  @PostMapping("/site-requirements")
  @Operation(summary = "Creates a Site Requirement")
  public ResponseEntity<SiteRequirementsResponse> createSiteRequirement(
          @RequestBody @Valid SiteRequirementRequest request) {
    SiteRequirementsResponse response = siteRequirementsService.createSiteRequirement(request);
    return new ResponseEntity<>(response, CREATED);
  }

  @PutMapping("/site-requirements/{siteRequirementId}")
  @Operation(summary = "Edit Site Requirements")
  public ResponseEntity<SiteRequirementsResponse> editSiteRequirements(
          @PathVariable UUID siteRequirementId,
          @RequestBody @Valid SiteRequirementRequest request) {
    SiteRequirementsResponse response = siteRequirementsService
            .editSiteRequirements(siteRequirementId, request);
    return ResponseEntity.ok(response);
  }

  @PostMapping("/skills")
  @Operation(summary = "Creates a Skills")
  public ResponseEntity<Skills> createSkills(@RequestBody @Valid SkillsRequest request) {
    SkillResponse skills = skillsService.createSkills(request);
    return new ResponseEntity<>(skillsService.findById(skills.getSkillId()), CREATED);
  }

  @PutMapping("/skills/{skillId}")
  @Operation(summary = "Edits a Skill")
  public ResponseEntity<Skills> editSkill(@PathVariable UUID skillId,
                                          @RequestBody @Valid SkillsRequest request) {
    Skills response = skillsService.editSkills(skillId, request);
    return ResponseEntity.ok(skillsService.findById(response.getId()));
  }

  @GetMapping("/skills")
  @Operation(summary = "Skills list and search")
  public ResponseEntity<SearchSkillsResponse> searchSkills(
          @Valid SearchSkillsRequest searchSkillsRequest) {
    return ResponseEntity.ok(skillsService.searchSkills(searchSkillsRequest));
  }

  @DeleteMapping("/skills/{skillId}")
  @Operation(summary = "Deletes a Skill")
  public ResponseEntity<DatabaseResponse> deleteSkill(@PathVariable UUID skillId) {
    DatabaseResponse deleteResponse = skillsService.deleteSkills(skillId);
    return ResponseEntity.ok(deleteResponse);
  }

  @GetMapping("/garnishment-types")
  @Operation(summary = "Garnishment Types list and search")
  public ResponseEntity<SearchGarnishmentsTypesResponse> searchGarnishments(
          @Valid SearchGarnishmentsTypesRequest searchGarnishmentsRequest) {
    return ResponseEntity.ok(garnishmentsService
            .searchGarnishmentsTypes(searchGarnishmentsRequest));
  }

  @PostMapping("/garnishment-types")
  @Operation(summary = "Creates a Garnishment Type")
  public ResponseEntity<GarnishmentType> saveGarnishmentType(
          @RequestBody @Valid GarnishmentTypeRequest request) {
    GarnishmentType response = garnishmentsService.createGarnishmentType(request);
    return new ResponseEntity<>(garnishmentsService.typeFindById(response.getId()), CREATED);
  }

  @PutMapping("/garnishment-types/{typeId}")
  @Operation(summary = "Edits a Garnishment Type")
  public ResponseEntity<GarnishmentType> editGarnishmentType(
          @PathVariable UUID typeId,
          @RequestBody @Valid GarnishmentTypeRequest request) {
    GarnishmentType response = garnishmentsService.editGarnishmentType(typeId, request);
    return ResponseEntity.ok(garnishmentsService.typeFindById(response.getId()));
  }

  @DeleteMapping("/garnishment-types/{typeId}")
  @Operation(summary = "Deletes a Garnishment Type")
  public ResponseEntity<DatabaseResponse> deleteGarnishmentType(@PathVariable UUID typeId) {
    DatabaseResponse deleteResponse = garnishmentsService.deleteGarnishmentType(typeId);
    return ResponseEntity.ok(deleteResponse);
  }

  @GetMapping("/garnishment-vendor")
  @Operation(summary = "Garnishments list and search")
  public ResponseEntity<SearchGarnishmentsResponse> searchGarnishments(
          @Valid SearchGarnishmentsRequest searchGarnishmentsRequest) {
    return ResponseEntity.ok(garnishmentsService
            .searchGarnishmentsVendor(searchGarnishmentsRequest));
  }


  @PutMapping("/garnishment-vendor/{vendorUuId}")
  @Operation(summary = "Edits a Garnishment Vendor")
  public ResponseEntity<GarnishmentVendor> editGarnishmentVendor(
          @PathVariable String vendorUuId,
          @RequestBody @Valid GarnishmentVendorRequest request) {
    GarnishmentVendor response = garnishmentsService.editGarnishmentVendor(UUID.fromString(vendorUuId), request);
    return ResponseEntity.ok(garnishmentsService.vendorFindById(response.getId()));
  }

  @DeleteMapping("/garnishment-vendor/{vendorUuId}")
  @Operation(summary = "Deletes a Garnishment Vendor")
  public ResponseEntity<DatabaseResponse> deleteGarnishmentVendor(@PathVariable UUID vendorUuId) {
    DatabaseResponse deleteResponse = garnishmentsService.deleteGarnishmentVendor(vendorUuId);
    return ResponseEntity.ok(deleteResponse);
  }

  @PostMapping("/garnishment-vendor")
  @Operation(summary = "Creates a Garnishment Vendor")
  public ResponseEntity<GarnishmentsVendorResponse> createGarnishmentVendor(
          @RequestBody @Valid GarnishmentVendorRequest request) {
    GarnishmentsVendorResponse response = garnishmentsService.createGarnishmentVendor(request);
    return new ResponseEntity<>(response, CREATED);
  }

  @PostMapping("/taxes/jurisdiction")
  @Operation(summary = "Create Tax Jurisdiction")
  public ResponseEntity<TaxJurisdictionsResponse> createTaxesJurisdiction(
          @RequestBody @Valid TaxJurisdictionsRequest request) {
    TaxJurisdictionsResponse taxes = taxesService.createTaxJurisdiction(request);
    return new ResponseEntity<>(taxes, CREATED);
  }

  @PutMapping("/jurisdiction/{jurisdictionId}")
  @Operation(summary = "Edits a Tax Jurisdiction")
  public ResponseEntity<TaxJurisdictionsResponse> editTaxJurisdiction(
          @PathVariable UUID jurisdictionId,
          @RequestBody @Valid TaxJurisdictionsRequest request) {
    TaxJurisdictionsResponse response = taxesService.editTaxJurisdiction(jurisdictionId, request);
    return ResponseEntity.ok(response);
  }

  @DeleteMapping("/jurisdiction/{jurisdictionId}")
  @Operation(summary = "Delete a Tax Jurisdiction")
  public ResponseEntity<DatabaseResponse<TaxJurisdictionsResponse>> deleteTaxJurisdiction(
          @PathVariable UUID jurisdictionId) {
    return ok(taxesService.deleteTaxJurisdiction(jurisdictionId));
  }

  @GetMapping("/taxes/jurisdiction")
  @Operation(summary = "Search and list Tax Jurisdiction")
  public ResponseEntity<SearchJurisdictionsResponse> searchTaxesJurisdiction(
          @Valid SearchJurisdictionsRequest request) {
    SearchJurisdictionsResponse response = taxesService.searchTaxJurisdiction(request);
    return ResponseEntity.ok(response);
  }

  @PostMapping("/taxes/forms")
  @Operation(summary = "Create Tax Forms")
  public ResponseEntity<TaxFormsResponse> createTaxesForm(
          @RequestBody @Valid TaxFormsRequest request) {
    TaxFormsResponse taxes = taxFormsService.createTaxForm(request);
    return new ResponseEntity<>(taxes, CREATED);
  }

  @GetMapping("/taxes/forms")
  @Operation(summary = "Search and list Tax Forms")
  public ResponseEntity<SearchTaxFormsResponse> searchTaxForms(
          @Valid SearchTaxFormsRequest request) {
    SearchTaxFormsResponse response = taxFormsService.searchTaxForms(request);
    return ResponseEntity.ok(response);
  }

  @GetMapping("/taxes/forms/{taxFormId}")
  @Operation(summary = "Retrieves a Tax Forms' details")
  public ResponseEntity<TaxFormsResponse> getDetails(
          @PathVariable UUID taxFormId) {
    TaxFormsResponse response = taxFormsService.getDetails(taxFormId);
    return ResponseEntity.ok(response);
  }

  @PutMapping("/taxes/forms/{taxFormId}")
  @Operation(summary = "Edits a Tax Forms")
  public ResponseEntity<TaxFormsResponse> editTaxForms(
          @PathVariable UUID taxFormId,
          @RequestBody @Valid TaxFormsRequest request) {
    TaxFormsResponse response = taxFormsService.editTaxForms(taxFormId, request);
    return ResponseEntity.ok(response);
  }

  @DeleteMapping("/taxes/forms/{taxFormsId}")
  @Operation(summary = "Delete a Tax Form")
  public ResponseEntity<DatabaseResponse<TaxFormsResponse>> deleteTaxForm(
          @PathVariable UUID taxFormsId) {
    return ok(taxFormsService.deleteTaxForm(taxFormsId));
  }

  @GetMapping("/ticket-formats")
  @Operation(summary = "Search and list Ticket formats")
  public ResponseEntity<SearchPrintingFormatsResponse> searchPrintingFormats(
          @Valid SearchPrintingFormatsRequest request) {
    SearchPrintingFormatsResponse response = printingFormatService.searchPrintingFormats(request);
    return ResponseEntity.ok(response);
  }

  @GetMapping("/certified-payroll")
  @Operation(summary = "Search and list Certified Payroll")
  public ResponseEntity<SearchPrintingFormatsResponse> searchCertifiedPayroll(
          @Valid SearchPrintingFormatsWithoutFormatRequest request) {
    SearchPrintingFormatsResponse response = printingFormatService.searchCertifiedPayroll(request);
    return ResponseEntity.ok(response);
  }

  @GetMapping("/certified-payroll/{formatId}")
  @Operation(summary = "Retrieves a Certified Payroll' details")
  public ResponseEntity<PrintingFormats> getCertifiedPayroll(@PathVariable UUID formatId) {
    PrintingFormats response = printingFormatService.findById(formatId);
    return ResponseEntity.ok(response);
  }

  @PostMapping("/taxes/tables/headTax")
  @Operation(summary = "Creates a Head Tax")
  public ResponseEntity<HeadTaxResponse> createHeadTax(@RequestBody @Valid HeadTaxRequest request) {
    return new ResponseEntity<>(taxesService.createHeadTax(request), CREATED);
  }

  @PostMapping("/taxes/tables/regularTax")
  @Operation(summary = "Creates a Regular Tax")
  public ResponseEntity<RegularTaxResponse> createRegularTax(@RequestBody @Valid RegularTaxRequest request) {
    return new ResponseEntity<>(taxesService.createRegularTax(request), CREATED);
  }

  @PutMapping("/taxes/tables/headTax/{taxId}")
  @Operation(summary = "Edit Head Tax")
  public ResponseEntity<HeadTax> editHeadTax(@PathVariable UUID taxId,
                                             @RequestBody @Valid HeadTaxRequest request) {
    return ResponseEntity.ok(taxesService.updateHeadTax(taxId, request));
  }

  @PutMapping("/taxes/tables/regularTax/{taxId}")
  @Operation(summary = "Edit Regular Tax")
  public ResponseEntity<RegularTax> editRegularTax(@PathVariable UUID taxId,
                                                   @RequestBody @Valid RegularTaxRequest request) {
    return ResponseEntity.ok(taxesService.updateRegularTax(taxId, request));
  }

  @DeleteMapping("/taxes/tables/headTax/{taxId}")
  @Operation(summary = "Delete a Head Tax")
  public ResponseEntity<String> deleteHeadTax(@PathVariable UUID taxId) {
    return ok(taxesService.deleteHeadTax(taxId));
  }

  @DeleteMapping("/taxes/tables/regularTax/{taxId}")
  @Operation(summary = "Delete a Regular Tax")
  public ResponseEntity<String> deleteRegularTax(@PathVariable UUID taxId) {
    return ok(taxesService.deleteRegularTax(taxId));
  }

  @GetMapping("/taxes/tables/headTax")
  @Operation(summary = "Search and list Head Tax")
  public ResponseEntity<SearchHeadTaxResponse> searchCertifiedPayroll(
          @Valid SearchHeadTaxesRequest request) {
    SearchHeadTaxResponse response = taxesService.searchHeadTaxes(request);
    return ResponseEntity.ok(response);
  }

  @GetMapping("/taxes/tables/regularTax")
  @Operation(summary = "Search and list Regular Tax")
  public ResponseEntity<SearchRegularTaxResponse> searchCertifiedPayroll(
          @Valid SearchRegularTaxesRequest request) {
    SearchRegularTaxResponse response = taxesService.searchRegularTaxes(request);
    return ResponseEntity.ok(response);
  }

  @PostMapping("/ledger/accounts")
  @Operation(summary = "Creates a General Ledger Account")
  public ResponseEntity<LedgerAccounts> createLedgerAccount(@RequestBody @Valid LedgerAccountRequest request) {
    return new ResponseEntity<>(ledgerAccountService.createLedgerAccount(request), CREATED);
  }

  @PutMapping("/ledger/accounts/{account}")
  @Operation(summary = "Edit a General Ledger Account")
  public ResponseEntity<LedgerAccounts> editLedgerAccount(@PathVariable String account,
                                                         @RequestBody @Valid LedgerAccountRequest request) {
    return ResponseEntity.ok(ledgerAccountService.editLedgerAccount(account, request));
  }

  @DeleteMapping("/ledger/accounts/{account}")
  @Operation(summary = "Delete a General Ledger Account")
  public ResponseEntity<DatabaseResponse> deleteLedgerAccount(@PathVariable String account) {
    return ok(ledgerAccountService.deleteLedgerAccount(account));
  }

  @GetMapping("/ledger/accounts/{account}")
  @Operation(summary = "Return info of a General Ledger Account")
  public ResponseEntity<LedgerAccounts> getLedgerAccount(@PathVariable String account) {
    return ok(ledgerAccountService.findById(account));
  }

  @GetMapping("/ledger/accounts")
  @Operation(summary = "Search and list Ledger Accounts")
  public ResponseEntity<SearchLedgerAccountResponse> searchLedgerAccounts(
      @Valid SearchLedgerAccountRequest request) {
    SearchLedgerAccountResponse response = ledgerAccountService.searchLedgerAccounts(request);
    return ResponseEntity.ok(response);
  }
}
