package com.staffzone.staffzonesystemsapi.dtos.responses;

import java.util.UUID;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Bill code for delete stored procedure.
 */
@Data
@NoArgsConstructor
public class BillCodeDatabaseResponse {
  private UUID id;
}
