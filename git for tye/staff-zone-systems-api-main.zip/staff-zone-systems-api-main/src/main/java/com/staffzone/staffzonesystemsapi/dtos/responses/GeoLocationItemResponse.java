package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Geo Location Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class GeoLocationItemResponse {
  private String city;
  private String phone;
  private String address;
  private Double distance;
  private Double latitude;
  @JsonSetter("branch_id")
  private String branchId;
  private Double longitude;
  @JsonSetter("state_name")
  private String stateName;
  @JsonSetter("branch_name")
  private String branchName;
  @JsonSetter("postal_code")
  private String postalCode;
  @JsonSetter("geo_location")
  private String geoLocation;
  @JsonSetter("address_line_2")
  private String addressLine2;
}
