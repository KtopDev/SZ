package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * Worker Sick Pay Request.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WorkerSickPayRequest {
  @NotNull(message = "date is required.")
  private LocalDate date;
  @Positive
  private Integer hours;
  @NotBlank
  private String reason;
}
