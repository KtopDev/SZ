package com.staffzone.staffzonesystemsapi.entities;

import static jakarta.persistence.EnumType.STRING;

import com.staffzone.staffzonesystemsapi.bos.MultiFactorType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * Entity mapped against "<strong>client_contacts</strong>" Table.
 */
@Entity
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "client_contacts")
public class ClientContact implements StaffZoneUser, UserDetails {
  @Id
  @Column(name = "contact_id", nullable = false)
  private UUID id;

  @ToString.Exclude
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "client_id", nullable = false)
  private Client client;

  @Builder.Default
  @NotNull
  @Column(name = "is_row_active", nullable = false)
  private Boolean isRowActive = false;

  @Size(max = 100)
  @NotNull
  @Column(name = "name", nullable = false, length = 100)
  private String name;

  @Size(max = 100)
  @NotNull
  @Column(name = "last_name", nullable = false, length = 100)
  private String lastName;

  @Size(max = 10)
  @NotNull
  @Column(name = "phone", nullable = false, length = 10)
  private String phone;

  @Size(max = 255)
  @NotNull
  @Column(name = "email", nullable = false)
  private String email;

  @Builder.Default
  @NotNull
  @Column(name = "is_primary", nullable = false)
  private Boolean isPrimary = false;

  @Builder.Default
  @NotNull
  @Column(name = "is_app_access_enabled", nullable = false)
  private Boolean isAppAccessEnabled = false;

  @Builder.Default
  @NotNull
  @Column(name = "can_receibe_invoices", nullable = false)
  private Boolean canReceiveInvoices = false;

  @Builder.Default
  @NotNull
  @Column(name = "can_approve_hours", nullable = false)
  private Boolean canApproveHours = false;

  @Builder.Default
  @NotNull
  @Column(name = "can_rate_workers", nullable = false)
  private Boolean canRateWorkers = false;

  @NotNull
  @Column(name = "multi_factor_authentication_preference", nullable = false, length = 20)
  @Enumerated(STRING)
  private MultiFactorType multiFactorAuthenticationPreference;

  @NotNull
  @Column(name = "multi_factor_authentication_ttl_days", nullable = false)
  private Integer multiFactorAuthenticationTtlDays;

  @Column(name = "password_hash", length = Integer.MAX_VALUE)
  private String password;

  @Column(name = "password_expire_ts")
  private LocalDateTime passwordExpireTs;

  @Column(name = "last_multi_factor_authentication_ts")
  private LocalDateTime lastMultiFactorAuthenticationTs;

  @Transient
  private List<String> activeProjects;

  @Override
  public Collection<? extends GrantedAuthority> getAuthorities() {
    return List.of();
  }

  @Override
  public String getUsername() {
    return email;
  }

  @Override
  public boolean isAccountNonExpired() {
    return true;
  }

  @Override
  public boolean isAccountNonLocked() {
    return true;
  }

  @Override
  public boolean isCredentialsNonExpired() {
    return passwordExpireTs == null || LocalDateTime.now().isBefore(passwordExpireTs);
  }

  @Override
  public boolean isEnabled() {
    return getIsRowActive();
  }
}