package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;
import org.hibernate.validator.constraints.Length;

/**
 * Garnishment Vendor Request.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GarnishmentVendorRequest {
  @NotBlank(message = "Id cannot be blank")
  private String garnishmentVendorTpId;
  @NotBlank(message = "Name cannot be blank")
  private String name1;
  @NotBlank(message = "Name cannot be blank")
  private String name2;
  @NotBlank(message = "Contact name cannot be blank")
  private String contactName;
  @NotBlank(message = "Phone cannot be blank")
  @Length(min = 10, max = 10, message = "Please enter a valid Phone.")
  private String contactPhone;
  @Email(regexp = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$", message = "Text entered is not an email")
  @Length(min = 6, message = "Please enter a valid email")
  @NotBlank(message = "Email cannot be blank")
  private String contactEmail;
  @NotBlank(message = "Street cannot be blank")
  private String streetAddress;
  private String street2Address;
  @NotBlank(message = "Please enter a City State")
  private String city;
  @NotBlank(message = "Please enter a valid State")
  private String state;
  @NotBlank(message = "Zip Code cannot be blank")
  @Length(min = 5, max = 10, message = "Please enter a valid Zip Code.")
  private String zipCode;

  @SneakyThrows
  @JsonIgnore
  public String asJson() {
    ObjectMapper mapper = new ObjectMapper();
    ObjectNode jsonObject = mapper.createObjectNode();
    jsonObject.put("vendor_tp_id", garnishmentVendorTpId);
    jsonObject.put("vendor_name_1", name1);
    jsonObject.put("vendor_name_2", name2);
    jsonObject.put("contact_name", contactName);
    jsonObject.put("contact_phone", contactPhone);
    jsonObject.put("contact_email", contactEmail);
    jsonObject.put("address_1", streetAddress);
    jsonObject.put("address_2", street2Address);
    jsonObject.put("state", state);
    jsonObject.put("city", city);
    jsonObject.put("postal_code", zipCode);
    return mapper.writeValueAsString(jsonObject);
  }
}
