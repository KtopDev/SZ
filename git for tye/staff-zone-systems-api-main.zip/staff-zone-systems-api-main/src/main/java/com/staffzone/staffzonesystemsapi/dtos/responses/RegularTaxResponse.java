package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Head Tax Response from Create and edit tax stored procedure.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RegularTaxResponse {
  @JsonAlias("tax_id")
  private String taxId;
  @JsonAlias("tax_jurisdiction_id")
  private String taxJurisdictionId;
  @JsonAlias("effective_date")
  private String effectiveDate;
  @JsonAlias("filling_status")
  private String fillingStatus;
  @JsonAlias("bracket_start")
  private String bracketStart;
  @JsonAlias("bracket_end")
  private String bracketEnd;
  @JsonAlias("base_amount")
  private String baseAmount;
  @JsonAlias("calculation_type")
  private String calculationType;
  @JsonAlias("tax_rate")
  private String taxRate;
}
