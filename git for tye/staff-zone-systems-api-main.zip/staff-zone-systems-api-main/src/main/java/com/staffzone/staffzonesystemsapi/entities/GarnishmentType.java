package com.staffzone.staffzonesystemsapi.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.ColumnDefault;

@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "garnishment_types")
public class GarnishmentType extends Audit {
  @Id
  @Column(name = "garnishment_type_id", nullable = false)
  private UUID id;

  @NotNull
  @ColumnDefault("true")
  @Column(name = "is_row_active", nullable = false)
  private Boolean isRowActive = false;

  @NotNull
  @Column(name = "garnishment_type_name", nullable = false, length = Integer.MAX_VALUE)
  private String garnishmentTypeName;

  @NotNull
  @Column(name = "max_percentage", nullable = false, precision = 5, scale = 2)
  private BigDecimal maxPercentage;

}