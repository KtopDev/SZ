package com.staffzone.staffzonesystemsapi.entities;

import com.staffzone.staffzonesystemsapi.entities.ids.AppUserMfaKeyId;
import com.staffzone.staffzonesystemsapi.entities.ids.AppUsersBranchId;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;

/**
 * App User MFA Key Entity.
 */
@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "app_user_mfa_keys")
public class AppUserMfaKey extends Audit {
  @EmbeddedId
  private AppUserMfaKeyId id;

  @Column(name = "app_user_mfa_key", insertable = false, updatable = false)
  private String appUserMfaKey;

  @MapsId("appUserId")
  @ManyToOne
  @JoinColumn(name = "app_user_id", nullable = false)
  private AppUser appUser;

  @Column(updatable = false, insertable = false)
  private final Boolean isRowActive = false;
}
