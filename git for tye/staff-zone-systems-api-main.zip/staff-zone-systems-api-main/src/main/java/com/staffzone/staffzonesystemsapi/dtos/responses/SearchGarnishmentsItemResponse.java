package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Certifications Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchGarnishmentsItemResponse {
  @JsonSetter(value = "total_rows")
  private String totalRows;
  @JsonSetter("vendor_id")
  private String vendorId;
  @JsonSetter("created_at")
  private String createdAt;
  @JsonSetter("vendor_name_1")
  private String vendorName1;
  @JsonSetter("vendor_name_2")
  private String vendorName2;
  @JsonSetter("contact_name")
  private String contactName;
  @JsonSetter("contact_phone")
  private String contactPhone;
  @JsonSetter("contact_email")
  private String contactEmail;
  @JsonSetter("address_1")
  private String address1;
  @JsonSetter("address_2")
  private String address2;
  @JsonSetter("state")
  private String state;
  @JsonSetter("state_name")
  private String stateName;
  @JsonSetter("city")
  private String city;
  @JsonSetter("postal_code")
  private String postalCode;
  @JsonSetter("vendor_tp_id")
  private String vendorTpId;
}
