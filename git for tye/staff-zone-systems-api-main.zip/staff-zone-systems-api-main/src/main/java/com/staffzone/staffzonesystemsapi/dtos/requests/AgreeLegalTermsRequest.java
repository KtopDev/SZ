package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;

/**
 * App Terms Request Dto.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@FieldNameConstants
public class AgreeLegalTermsRequest {
  @NotNull(message = "Contact Id cannot be null.")
  private UUID contactId;
  @NotNull(message = "Client App Terms cannot be null")
  @NotEmpty(message = "Client App Terms need at least one Id.")
  private List<UUID> clientAppTerms;
}
