package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.staffzone.staffzonesystemsapi.bos.RecurrencyType;
import com.staffzone.staffzonesystemsapi.validators.Uuid;
import com.staffzone.staffzonesystemsapi.validators.ValueOfEnum;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import java.math.BigDecimal;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Head Tax Request DTO.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HeadTaxRequest {
  @Uuid
  private String jurisdictionId;
  @NotNull(message = "effectiveDate cannot be null")
  private LocalDate effectiveDate;
  @ValueOfEnum(enumClass = RecurrencyType.class)
  private String recurrency;
  @NotNull(message = "Please, indicate Tax Amount")
  @Positive(message = "taxAmount must be greater than 0")
  private BigDecimal taxAmount;
  @NotNull(message = "Please,indicate Employee Percentage")
  @PositiveOrZero
  private BigDecimal employeePercentage;
  @NotNull(message = "Please,indicate Employer Percentage")
  @PositiveOrZero
  private BigDecimal employerPercentage;

}
