package com.staffzone.staffzonesystemsapi.bos;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * OrderStatusType: <br/>
 * {@link #ACTIVE},<br/>
 * {@link #REQUESTED},<br/>
 * {@link #FINISHED}.
 */
@Getter
@AllArgsConstructor
public enum OrderStatusType {
  ACTIVE,
  REQUESTED,
  FINISHED
}
