package com.staffzone.staffzonesystemsapi.dtos.responses;

import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Auth User Response DTO.
 * <pre>{@code
 *    {
 *      "authProcessId": "UUID"
 *    }
 * }</pre>
 */
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class AuthUserResponse {
  private UUID authProcessId;
}
