package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.staffzone.staffzonesystemsapi.bos.TaxFormQuestionType;
import com.staffzone.staffzonesystemsapi.validators.Uuid;
import com.staffzone.staffzonesystemsapi.validators.ValueOfEnum;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Tax Form Question Request DTO.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxFormQuestionsRequest {
  @Uuid(enableNullValues = true)
  private String questionId;
  @NotBlank(message = "questionText cannot be blank")
  private String questionText;
  @NotNull(message = "sortOrder cannot be blank")
  @PositiveOrZero
  private Integer sortOrder;
  @NotBlank(message = "questionType cannot be blank")
  @ValueOfEnum(enumClass = TaxFormQuestionType.class)
  private String questionType;
  @Valid
  private Set<TaxFormQuestionOptionRequest> options;

  /**
   * Build JSON.
   *
   * @param mapper {@link ObjectMapper}
   * @return {@link ObjectNode}
   */
  public ObjectNode asJsonNode(ObjectMapper mapper) {
    ObjectNode jsonObject = mapper.createObjectNode();
    jsonObject.put("question_text", questionText);
    jsonObject.put("sort_order", sortOrder);
    jsonObject.put("question_type", questionType);
    jsonObject.put("question_id", questionId);

    ArrayNode optionsArray = mapper.createArrayNode();
    if (options!=null) {
      for (TaxFormQuestionOptionRequest option : options) {
        optionsArray.add(option.asJsonNode(mapper));
      }
    }
    jsonObject.set("options", optionsArray);
    return jsonObject;
  }
}
