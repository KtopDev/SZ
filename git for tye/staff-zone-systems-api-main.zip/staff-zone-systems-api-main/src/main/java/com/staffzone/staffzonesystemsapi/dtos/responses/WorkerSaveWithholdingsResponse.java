package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Workers Verification response.
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class WorkerSaveWithholdingsResponse {
  private Boolean isProcessed;
  private String message;

  @JsonGetter("isProcessed")
  public Boolean getIsProcessed() {
    return isProcessed;
  }

  @JsonSetter("is_processed")
  public void setIsProcessed(Boolean isProcessed) {
    this.isProcessed = isProcessed;
  }

  @JsonGetter("message")
  public String getMessage() {
    return message;
  }

  @JsonSetter("message")
  public void setMessage(String message) {
    this.message = message;
  }
}
