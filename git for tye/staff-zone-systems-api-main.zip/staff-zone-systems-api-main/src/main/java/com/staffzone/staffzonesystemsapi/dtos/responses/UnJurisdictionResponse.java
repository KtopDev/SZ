package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Un jurisdiction Response from create and edit Un jurisdiction stored procedure.
 */
@Data
@NoArgsConstructor
public class UnJurisdictionResponse {
  private UUID unemploymentJurisdictionId;
  private String state;
  private BigDecimal minWage;
  private BigDecimal  maxWage;
  private BigDecimal  rate;
  private BigDecimal federalCreditRate;
  private BigDecimal employeeRate;
  private BigDecimal companyRate;
  private String status;
  private String statusTs;

}
