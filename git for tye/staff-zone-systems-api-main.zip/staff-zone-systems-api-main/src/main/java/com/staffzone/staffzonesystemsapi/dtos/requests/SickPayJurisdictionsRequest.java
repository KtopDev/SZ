package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * SickPayJurisdictions Request Dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SickPayJurisdictionsRequest {

  @NotBlank(message = "State cannot be blank")
  private String state;

  @NotBlank(message = "Effective cannot be blank")
  private String effectiveDate;

  @NotBlank(message = "Anniversary Method cannot be blank")
  private String anniversaryMethod;

  @NotNull(message = "Vesting Days cannot be blank")
  @PositiveOrZero(message = "Vesting Days must be positive or zero")
  private Integer vestingDays;

  @NotNull(message = "Suspended Days cannot be blank")
  @PositiveOrZero(message = "Suspended Days must be positive or zero")
  private Integer suspendedDays;

  @NotNull(message = "Lose After Days cannot be blank")
  @PositiveOrZero(message = "Lose After Days Days must be positive or zero")
  private Integer loseAfterDays;

  @NotNull(message = "Accrual Hours cannot be blank")
  @PositiveOrZero(message = "Accrual Hours must be positive or zero")
  private Double accrualHours;

  @NotNull(message = "Worked Hours cannot be blank")
  @Positive(message = "Worked Hours must be greater than zero")
  private Double workedHours;

  @NotNull(message = "Max Carry Forward Hours cannot be blank")
  @PositiveOrZero(message = "Max Carry Forward Hours must be positive or zero")
  private Double maxCarryForwardHours;

  @NotNull(message = "Max PerYear Hours cannot be blank")
  @PositiveOrZero(message = "Max PerYear Hours must be positive or zero")
  private Double maxPerYearHours;

  @NotNull(message = "Max Unused Hours cannot be blank")
  @PositiveOrZero(message = "Max Unused Hours must be positive or zero")
  private Double maxUnusedHours;

  @NotNull(message = "Min Consumable Hours cannot be blank")
  @PositiveOrZero(message = "Min Consumable Hours must be positive or zero")
  private Double minConsumableHours;

}
