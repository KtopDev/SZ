package com.staffzone.staffzonesystemsapi.dtos.responses;

import java.util.UUID;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Sick pay jurisdiction for delete stored procedure.
 */
@Data
@NoArgsConstructor
public class SickPayJurisdictionsResponse {
  private UUID id;
}
