package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.util.UUID;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * CompCode Response from create and edit tax jurisdiction stored procedure.
 */
@Data
@NoArgsConstructor
public class TaxJurisdictionsResponse {
  private String state;
  @JsonAlias(value = "state_name")
  private String stateName;
  @JsonAlias(value = "jurisdiction_type")
  private String jurisdictionType;
  @JsonAlias(value = "tax_jurisdiction_id")
  private UUID taxJurisdictionId;
  @JsonAlias(value = "tax_jurisdiction_name")
  private String taxJurisdictionName;
  @JsonAlias(value = "jurisdiction_type_label")
  private String jurisdictionTypeLabel;
}
