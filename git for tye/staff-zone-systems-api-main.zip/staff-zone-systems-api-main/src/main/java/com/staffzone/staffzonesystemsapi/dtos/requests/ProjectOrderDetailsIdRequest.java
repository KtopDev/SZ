package com.staffzone.staffzonesystemsapi.dtos.requests;

import java.util.UUID;

import com.staffzone.staffzonesystemsapi.validators.Uuid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProjectOrderDetailsIdRequest {
  @Uuid(message = "Invalid format of Project Id")
  private UUID projectId;
  @Uuid(message = "Invalid format of Order Id")
  private UUID orderId;
  @Uuid(message = "Invalid format of Worker Based Billing Id")
  private UUID projectWorkerBasedBillingId;
}
