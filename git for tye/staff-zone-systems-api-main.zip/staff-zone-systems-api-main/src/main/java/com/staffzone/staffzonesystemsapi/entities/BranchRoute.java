package com.staffzone.staffzonesystemsapi.entities;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;

/**
 * Entity mapped against "<strong>branch_routes</strong>" Table
 */
@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "branch_routes")
public class BranchRoute extends Audit {
  @Id
  @Column(name = "route_id", nullable = false)
  private UUID id;

  @NotNull
  @Column(name = "branch_id", nullable = false)
  private UUID branchId;

  @Column(name = "driver_id")
  private UUID driverId;

  @Builder.Default
  @NotNull
  @Column(name = "is_row_active", nullable = false)
  private Boolean isRowActive = true;

  @NotNull
  @Column(name = "route_name", nullable = false, length = 255)
  private String routeName;

  @NotNull
  @Column(name = "route_type", nullable = false, length = 20)
  private String routeType;

  @NotNull
  @Column(name = "seats", nullable = false)
  private Integer seats;

  @Column(name = "route_date")
  private LocalDate routeDate;

  @OneToMany
  @JoinColumn(name = "branch_route_id")
  private List<ProjectOrderDetails> assignedOrders;
}