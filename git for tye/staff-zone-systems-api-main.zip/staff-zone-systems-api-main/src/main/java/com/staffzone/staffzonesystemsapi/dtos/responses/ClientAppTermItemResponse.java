package com.staffzone.staffzonesystemsapi.dtos.responses;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Client App term Item Response Dto.
 * <pre>{@code
 *    {
 *      "sort_order":               number,
 *      "modified_at":              "dd/mm/yyyy",
 *      "in_use_branches":          [... ],
 *      "client_app_term_id":       "string"
 *      "client_app_term_file_uri": "string",
 *      "client_app_term_label": "string"
 *    }
 * }</pre>
 * {@link InUseBranchResponse}
 */
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@SuppressWarnings("checkstyle:MemberName")
public class ClientAppTermItemResponse {
  private Integer sort_order;
  private String modified_at;
  private List<InUseBranchResponse> in_use_branches;
  private String client_app_term_id;
  private String client_app_term_file_uri;
  private String client_app_term_label;
}
