package com.staffzone.staffzonesystemsapi.dtos.requests;


import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Ledger Account Request DTO.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class LedgerAccountRequest {
  @NotEmpty(message = "Please, indicate account number")
  @Pattern(regexp = "^\\d{5}", message = "Account number must have 5 digits")
  private String account;
  @NotEmpty(message = "Please, indicate account description")
  @Size(max=50)
  private String accountName;
}
