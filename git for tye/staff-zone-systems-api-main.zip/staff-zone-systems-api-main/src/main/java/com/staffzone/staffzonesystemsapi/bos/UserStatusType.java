package com.staffzone.staffzonesystemsapi.bos;

public enum UserStatusType {
  ACTIVE, INACTIVE;
  public static UserStatusType of(String str) {
    for (UserStatusType type : values()) {
      if (str.toUpperCase().equals(type.name())) {
        return type;
      }
    }
    return null;
  }
}
