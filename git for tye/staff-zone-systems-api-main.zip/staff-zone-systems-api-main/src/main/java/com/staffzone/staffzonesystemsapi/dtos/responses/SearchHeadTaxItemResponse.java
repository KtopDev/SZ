package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Head Taxes Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchHeadTaxItemResponse {
  private String state;
  @JsonAlias("tax_id")
  private String taxId;
  @JsonAlias("row_order")
  private Integer rowOrder;
  @JsonAlias("recurrency")
  private String recurrency;
  @JsonAlias("tax_amount")
  private Double taxAmount;
  @JsonAlias("total_rows")
  private String totalRows;
  @JsonAlias("modified_at")
  private String modifiedAt;
  @JsonAlias("effective_date")
  private String effectiveDate;
  @JsonAlias("employee_percentage")
  private Double employeePercentage;
  @JsonAlias("employer_percentage")
  private Double employerPercentage;
  @JsonAlias("tax_jurisdiction_id")
  private String taxJurisdictionId;
  @JsonAlias("tax_jurisdiction_name")
  private String taxJurisdictionName;
}
