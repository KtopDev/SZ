package com.staffzone.staffzonesystemsapi.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;

/**
 * Entity mapped against "<strong>ledger_accounts</strong>" Table.
 */
@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "ledger_accounts")
public class LedgerAccounts extends Audit {
  @Id
  @Column(name = "ledger_account")
  private String account;
  @Column(name = "ledger_account_name")
  private String accountName;
  @Column(name = "is_row_active")
  private boolean isRowActive;
}
