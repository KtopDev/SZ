package com.staffzone.staffzonesystemsapi.dtos;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.staffzone.staffzonesystemsapi.bos.SMSSourceApplication;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class SMSMessage {
    @JsonProperty("From")
    private String from;
    @JsonProperty("To")
    private String to;
    @JsonProperty("MessageText")
    private String messageText;
    @JsonProperty("SourceApplication")
    private SMSSourceApplication sourceApplication;
}
