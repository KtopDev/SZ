package com.staffzone.staffzonesystemsapi.bos;

/**
 * Check Format Options: <br/>
 * {@link #DEFAULT_CHECK},<br/>
 * {@link #SICK_CHECK},<br/>
 * {@link #DEPOSIT},<br/>
 * {@link #INVOICE}.
 */
public enum CheckFormatType {
  DEFAULT_CHECK, SICK_CHECK, DEPOSIT, INVOICE
}
