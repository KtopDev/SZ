package com.staffzone.staffzonesystemsapi.controllers;

import com.staffzone.staffzonesystemsapi.dtos.LoginUserDto;
import com.staffzone.staffzonesystemsapi.dtos.PhoneLoginUserDto;
import com.staffzone.staffzonesystemsapi.dtos.VerifyCodeDto;
import com.staffzone.staffzonesystemsapi.dtos.requests.UserLogOutRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.VerifyMfaCodeRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.VerifyMfaOTPRequest;
import com.staffzone.staffzonesystemsapi.dtos.responses.LoginResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SendCodeResponse;
import com.staffzone.staffzonesystemsapi.services.AuthenticationService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Authentication Controller.
 */
@RequestMapping("/api/v1")
@RestController
@AllArgsConstructor
public class AuthenticationController {
  private AuthenticationService authenticationService;

  @PostMapping("/login")
  public ResponseEntity<LoginResponse> login(
          @RequestBody @Valid LoginUserDto loginUserDto) throws Exception {
    LoginResponse loginResponse = authenticationService.login(loginUserDto);
    return ResponseEntity.ok(loginResponse);
  }

  @PostMapping("/login/phone/send-code")
  public ResponseEntity<SendCodeResponse> sendCode(
          @RequestBody @Valid PhoneLoginUserDto phoneLoginUserDto) {
    SendCodeResponse sendCodeResponse = authenticationService.sendCode(phoneLoginUserDto);
    return ResponseEntity.ok(sendCodeResponse);
  }

  @PostMapping("/login/phone/verify-code")
  public ResponseEntity<LoginResponse> verifyPhoneCode(
          @RequestBody @Valid VerifyCodeDto verifyCodeDto) {
    LoginResponse loginResponse = authenticationService.verifyCode(verifyCodeDto);
    return ResponseEntity.ok(loginResponse);
  }

  @PostMapping("/login/mfa/verify-code")
  public ResponseEntity<LoginResponse> verifyMfaCode(
          @RequestBody @Valid VerifyMfaCodeRequest request) {
    LoginResponse loginResponse = authenticationService.verifyMfaCode(request);
    return ResponseEntity.ok(loginResponse);
  }

  @PostMapping("/login/mfa/verify-otp")
  public ResponseEntity<LoginResponse> verifyOtpCode(
          @RequestBody @Valid VerifyMfaOTPRequest request) {
    LoginResponse loginResponse = authenticationService.verifyOtpCode(request);
    return ResponseEntity.ok(loginResponse);
  }

  @PostMapping("/logout")
  public ResponseEntity<String> logout(@RequestBody @Valid UserLogOutRequest logOutUser) {
    return ResponseEntity.ok(authenticationService.logout(logOutUser));
  }
}
