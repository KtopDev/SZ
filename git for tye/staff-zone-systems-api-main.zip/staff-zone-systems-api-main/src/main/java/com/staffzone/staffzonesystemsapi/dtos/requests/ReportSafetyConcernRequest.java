package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.multipart.MultipartFile;

/**
 * Report a Safety Concern Request Dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReportSafetyConcernRequest {
  @NotBlank(message = "Description cannot be blank")
  private String description;
  private List<MultipartFile> photos;
}
