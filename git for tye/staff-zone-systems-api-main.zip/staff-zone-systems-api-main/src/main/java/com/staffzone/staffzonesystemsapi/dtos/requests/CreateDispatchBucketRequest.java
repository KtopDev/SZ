package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.staffzone.staffzonesystemsapi.validators.Uuid;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Create DispatchBucket Request DTO.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CreateDispatchBucketRequest {
  @NotEmpty(message = "Route Id cannot be empty.")
  @Uuid(message = "Route Id Invalid UUID Format")
  private String routeId;

  @NotEmpty(message = "Order Id cannot be empty.")
  @Uuid(message = "Order Id Invalid UUID Format")
  private String orderId;

  @NotEmpty(message = "Project Id cannot be empty.")
  @Uuid(message = "Project Id Invalid UUID Format")
  private String projectId;

  @NotEmpty(message = "Branch Id cannot be empty.")
  @Uuid(message = "Branch Id Invalid UUID Format")
  private String branchId;

}
