package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Bill Codes Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchBillCodeItemResponse {
  @JsonSetter(value = "bill_code_id")
  private String billCodeId;
  @JsonSetter(value = "bill_code_name")
  private String billCodeName;
  @JsonSetter(value = "bill_code_description")
  private String billCodeDescription;
  @JsonSetter(value = "total_rows")
  private String totalRows;
  @JsonSetter(value = "created_at")
  private String createdAt;
}
