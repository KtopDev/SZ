package com.staffzone.staffzonesystemsapi.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;
import org.apache.commons.lang3.builder.ToStringExclude;

/**
 * Entity mapped against "<strong>Certifications</strong>" Table.
 */
@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "certifications")
public class Certification extends Audit {
  @Id
  @Column(name = "certification_id")
  private UUID certificationId;
  @Column(name = "certification_name", nullable = false)
  private String certificationName;
  @Column(name = "certification_abreviation", nullable = false)
  private String certificationAbbreviation;
  @Column(name = "certification_description")
  private String certificationDescription;
  @Column(name = "is_overridable", nullable = false)
  private boolean cantBeOverridden;
  @Column(name = "days_from_hire")
  private Integer daysFromHire;
  @Column(name = "days_from_first_placement")
  private Integer daysFromFirstPlacement;
  @ManyToOne
  @JsonIgnore
  @ToStringExclude
  @JoinColumn(name = "branch_id")
  private Branch branch;
  @Column(name = "is_row_active")
  private boolean isRowActive;

  public UUID getBranchId() {
    return branch != null ? branch.getBranchId() : null;
  }
}
