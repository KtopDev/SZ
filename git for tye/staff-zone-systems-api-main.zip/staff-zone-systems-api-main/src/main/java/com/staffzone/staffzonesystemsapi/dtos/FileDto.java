package com.staffzone.staffzonesystemsapi.dtos;

import java.net.URI;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * File Dto.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FileDto {
  private String fileName;
  private URI uri;
}
