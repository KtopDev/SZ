package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.staffzone.staffzonesystemsapi.utils.StringUtils;
import com.staffzone.staffzonesystemsapi.validators.SortOptions;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.JSONObject;

import java.time.LocalDate;

import static com.staffzone.staffzonesystemsapi.utils.StringUtils.toSnakeCase;
import static org.apache.commons.lang3.StringUtils.isNotBlank;
import static org.apache.commons.lang3.StringUtils.remove;
import static org.springframework.data.domain.Sort.Direction.ASC;

/**
 * Search document history Request DTO.
 */
@Slf4j
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class SearchWorkerDocumentHistoryRequest extends SearchAbstractRequest {
  private String documentType;
  private LocalDate startDate;
  private LocalDate endDate;
  @SortOptions(anyOf = {"documentNumber"})
  private String sort;

  /**
   * Get sort as Json.
   *
   * @return String
   */
  @JsonIgnore
  public String getSortAsJson() {
    JSONObject jsonObject = new JSONObject();
    jsonObject.put("limit", super.getSize());

    var offset = (super.getPage() - 1) * super.getSize();
    jsonObject.put("offset", offset);

    if (sort == null || sort.isBlank()) {
      jsonObject.put("sort_column", toSnakeCase("documentNumber"));
      jsonObject.put("sort_direction", ASC.name());
    } else {
      String[] options = sort.split(",");
      jsonObject.put("sort_column", toSnakeCase(options[0]));
      jsonObject.put("sort_direction", options[1].toUpperCase());
    }
    return jsonObject.toJSONString();
  }

  public String getDocumentType() {
    return isNotBlank(documentType) ? documentType : "DRIVERS_LICENSE";
  }

}
