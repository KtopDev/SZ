package com.staffzone.staffzonesystemsapi.dtos;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Dropdown Item Dto.
 */
@Getter
@AllArgsConstructor
public class DropdownItemDto {
  private String id;
  private String displayName;
}
