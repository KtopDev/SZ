package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.staffzone.staffzonesystemsapi.bos.Folder;
import com.staffzone.staffzonesystemsapi.validators.ValueOfEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * Folder Path Request DTO.
 */
@Data
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FolderPathRequest {
  @ValueOfEnum(enumClass = Folder.class)
  private String folder;

  /**
   * Get Enum value.
   *
   * @return {@link Folder}
   */
  public Folder getFolder() {
    if (folder == null) {
      return null;
    }

    return Folder.valueOf(folder);
  }
}
