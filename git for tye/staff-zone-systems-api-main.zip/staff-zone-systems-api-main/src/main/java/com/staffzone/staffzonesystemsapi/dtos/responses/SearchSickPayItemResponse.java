package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Sick Pay Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchSickPayItemResponse {
  @JsonSetter(value = "state")
  private String state;
  @JsonSetter(value = "state_name")
  private String stateName;
  @JsonSetter(value = "total_rows")
  private String totalRows;
  @JsonSetter(value = "vesting_days")
  private Integer vestingPeriod;
  @JsonSetter(value = "worked_hours")
  private Integer workedWorked;
  @JsonSetter(value = "accrual_hours")
  private Integer accrualHours;
  @JsonSetter(value = "efective_date")
  private String effectiveDate;
  @JsonSetter(value = "suspended_days")
  private Integer suspendedPeriod;
  @JsonSetter(value = "lose_after_days")
  private Integer lostAfter;
  @JsonSetter(value = "max_unused_hours")
  private Integer maxUnusedHours;
  @JsonSetter(value = "anniversary_method")
  private String anniversaryMethod;
  @JsonSetter(value = "max_per_year_hours")
  private Integer maxPerYearUsable;
  @JsonSetter(value = "min_consumable_hours")
  private Integer minConsumableHours;
  @JsonSetter(value = "max_carry_forward_hours")
  private Integer maxCarryForward;
  @JsonSetter(value = "anniversary_method_label")
  private String anniversaryMethodLabel;
  @JsonSetter(value = "sick_pay_jurisdiction_id")
  private String sickPayJurisdictionId;
}
