package com.staffzone.staffzonesystemsapi.dtos.responses;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Sort;

/**
 * Pagination Abstract Response DTO.
 */
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class PaginatedAbstractResponse {
  private int size;
  private long totalSize;
  private int page;
  private int totalPages;
  private boolean hasNext;
  private String sort;

  /**
   * Setter sort.
   *
   * @param sort String
   */
  public void setSort(String sort) {
    if (StringUtils.isBlank(sort)) {
      this.sort = Sort.unsorted().toString();
    } else {
      this.sort = sort;
    }
  }

  /**
   * Set Total Size.
   *
   * @param total long
   */
  public void setTotalSize(long total) {
    totalSize = total;

    totalPages = totalSize == 0 ? 0 :
            (totalSize % size == 0) ? (int) (totalSize / size) :
                    (int) (totalSize / size + 1);

    hasNext = totalPages > page;
  }
}
