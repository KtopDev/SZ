package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.staffzone.staffzonesystemsapi.validators.SamePassword;
import com.staffzone.staffzonesystemsapi.validators.ValidPassword;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;

/**
 * Password Request Data DTO.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@SamePassword
@FieldNameConstants
public class PasswordRequest {
  @ValidPassword
  @NotBlank(message = "ValidPassword cannot be blank")
  private String password;

  @ValidPassword
  @NotBlank(message = "ValidPassword cannot be blank")
  private String confirmPassword;
}
