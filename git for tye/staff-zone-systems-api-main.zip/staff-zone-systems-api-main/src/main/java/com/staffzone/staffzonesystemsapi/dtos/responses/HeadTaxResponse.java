package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Head Tax Response from Create and edit tax stored procedure.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class HeadTaxResponse {
  @JsonAlias("tax_id")
  private String taxId;
  private String recurrency;
  @JsonAlias("tax_amount")
  private Double taxAmount;
  @JsonAlias("effective_date")
  private String effectiveDate;
  @JsonAlias("employee_percentage")
  private Double employeePercentage;
  @JsonAlias("employer_percentage")
  private Double employerPercentage;
  @JsonAlias("tax_jurisdiction_id")
  private String taxJurisdictionId;
}
