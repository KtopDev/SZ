package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

/**
 * Worker WithHoldings Form Request DTO.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class WorkerWithholdingsFormRequest {

  @NotNull(message = "isFederalIncomeTaxExempt cannot be null")
  private Boolean isFederalIncomeTaxExempt;
  @NotNull(message = "fillingStatus cannot be null")
  @Pattern(regexp = "SINGLE|MARRIED_JOINTLY|MARRIED_SEPARATELY|HEAD_OF_HOUSEHOLD|QUALIFYING_WIDOW",
      message = "fillingStatus must be one of the following: SINGLE, MARRIED_JOINTLY, " +
          "MARRIED_SEPARATELY, HEAD_OF_HOUSEHOLD, QUALIFYING_WIDOW")
  private String fillingStatus;
  @NotNull(message = "hasMoreThanOneJob cannot be null")
  private Boolean hasMoreThanOneJob;
  @NotNull(message = "deductionsAmount cannot be null")
  private BigDecimal deductionsAmount;
  @NotNull(message = "otherIncomeAmount cannot be null")
  private BigDecimal otherIncomeAmount;
  @NotNull(message = "dependentsAmount cannot be null")
  private BigDecimal dependentsAmount;
  @NotNull(message = "additionalWithholdingAmount cannot be null")
  private BigDecimal additionalWithholdingAmount;
  @NotNull(message = "stateAdditionalWithholdingAmount cannot be null")
  private BigDecimal stateAdditionalWithholdingAmount;
  @NotNull(message = "isNontesitentAlien cannot be null")
  private Boolean isNontesitentAlien;
  @NotNull(message = "isStateIncomeTaxExempt cannot be null")
  private Boolean isStateIncomeTaxExempt;
  @NotNull(message = "stateFillingStatus cannot be null")
  @Pattern(regexp = "SINGLE|MARRIED_JOINTLY|MARRIED_SEPARATELY|HEAD_OF_HOUSEHOLD|QUALIFYING_WIDOW",
      message = "State Filling status must be one of the following: SINGLE, MARRIED_JOINTLY, " +
          "MARRIED_SEPARATELY, HEAD_OF_HOUSEHOLD, QUALIFYING_WIDOW")
  private String stateFillingStatus;
  @NotNull(message = "regularAllowances cannot be null")
  private Integer regularAllowances;
  @NotNull(message = "adicionalAllowances cannot be null")
  private Integer adicionalAllowances;
}
