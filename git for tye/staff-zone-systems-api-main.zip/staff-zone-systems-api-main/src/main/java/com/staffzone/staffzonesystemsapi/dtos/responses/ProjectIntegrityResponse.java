package com.staffzone.staffzonesystemsapi.dtos.responses;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

/**
 * Search Projects Create Response DTO.
 */
@Data
@NoArgsConstructor
public class ProjectIntegrityResponse {
  private String type;
  private String table;
  private String column;
  private String constraint;
}