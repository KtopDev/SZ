package com.staffzone.staffzonesystemsapi.bos;

/**
 * MultiFactorType: <br/>
 * {@link #SMS},<br/>
 * {@link #EMAIL},<br/>
 * {@link #NONE}.
 */
public enum MultiFactorType {
  SMS, EMAIL, NONE, AUTH_APP;

  /**
   * Method to search value from any String.
   *
   * @param str
   *            <br/> Accept null and is case-insensitive.
   * @return <br/>If null will return {@link #NONE}, otherwise search between options
   */
  public static MultiFactorType of(String str) {
    MultiFactorType result = NONE;
    if (str == null) {
      return result;
    }

    for (MultiFactorType type : values()) {
      if (str.toUpperCase().equals(type.name())) {
        result = type;
      }
    }

    return result;
  }
}
