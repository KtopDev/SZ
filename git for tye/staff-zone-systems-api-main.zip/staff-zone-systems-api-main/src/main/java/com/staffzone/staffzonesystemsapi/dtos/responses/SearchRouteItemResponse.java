package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Search Route Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchRouteItemResponse {
  @JsonAlias(value = "total_rows")
  private String totalRows;
  @JsonAlias(value = "route_id")
  private String routeId;
  @JsonAlias(value = "route_name")
  private String routeName;
  @JsonAlias(value = "route_type")
  private String routeType;
  @JsonAlias(value = "available_seats")
  private String availableSeats;
  @JsonAlias(value = "row_order")
  private Integer rowOrder;
  @JsonAlias(value = "orders")
  private List<OrderDto> orders;
}
