package com.staffzone.staffzonesystemsapi.dtos.requests;

import static com.staffzone.staffzonesystemsapi.utils.StringUtils.toSnakeCase;
import static org.springframework.data.domain.Sort.Direction.ASC;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.staffzone.staffzonesystemsapi.validators.SortOptions;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import net.minidev.json.JSONObject;

/**
 * Search Garnishment Types Request DTO.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class SearchGarnishmentsRequest extends SearchAbstractRequest {
  private String searchBy;
  private LocalDate startDate;
  private LocalDate endDate;
  @SortOptions(anyOf = {"vendor_name_1", "vendor_name_2", "contact_name", "vendor_tp_id"})
  private String sort;

  /**
   * Get sort as Json.
   *
   * @return String
   */
  @JsonIgnore
  public String getSortAsJson() {
    JSONObject jsonObject = new JSONObject();
    jsonObject.put("limit", super.getSize());

    var offset = (super.getPage() - 1) * super.getSize();
    jsonObject.put("offset", offset);

    if (sort == null || sort.isBlank()) {
      jsonObject.put("sort_column", "vendor_name_1");
      jsonObject.put("sort_direction", ASC.name());
    } else {
      String[] options = sort.split(",");
      jsonObject.put("sort_column", toSnakeCase(options[0]));
      jsonObject.put("sort_direction", options[1].toUpperCase());
    }
    return jsonObject.toJSONString();
  }

  public LocalDate getEndDate() {
    if (endDate == null)
      return null;
    if (startDate == null)
      return endDate;

    if(endDate.isBefore(startDate)) {
      return endDate.minusDays(1);
    } else {
      return endDate;
    }
  }
}
