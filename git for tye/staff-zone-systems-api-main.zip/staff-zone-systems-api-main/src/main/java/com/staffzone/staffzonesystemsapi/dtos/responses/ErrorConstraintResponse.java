package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.staffzone.staffzonesystemsapi.dtos.ErrorConstraintDetail;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Error Constraint Response.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ErrorConstraintResponse {
  private String message;
  private boolean isProcessed;
  private ErrorConstraintDetail entity;

  public ErrorConstraintResponse(String message, boolean isProcessed) {
    this.message = message;
    this.isProcessed = isProcessed;
  }
}