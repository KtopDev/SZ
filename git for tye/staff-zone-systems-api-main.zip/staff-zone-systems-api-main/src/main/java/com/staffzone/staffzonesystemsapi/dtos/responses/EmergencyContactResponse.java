package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Emergency Contact Dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class EmergencyContactResponse {
  private String name;
  private String phone;
  @JsonAlias("contact_id")
  private String contactId;
  private String relationship;
}
