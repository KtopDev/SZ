package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.staffzone.staffzonesystemsapi.validators.Uuid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;
import lombok.experimental.SuperBuilder;
import org.hibernate.validator.constraints.Length;

/**
 * Project Base Request Dto.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ProjectBasicInformationRequest {
  @Uuid
  private String branchId;
  @NotBlank(message = "projectName cannot be blank")
  private String projectName;
  @Uuid
  private String clientId;
  @NotBlank(message = "address cannot be blank")
  private String address;
  private String addressLine2;
  @Length(min = 2, max = 2)
  @NotBlank(message = "state cannot be blank")
  private String state;
  @NotBlank(message = "city cannot be blank")
  private String city;
  @NotNull(message = "phone cannot be null")
  @Pattern(regexp = "^\\d{10}$",
          message = "phone must have at maximum 10 digits.")
  @Size(max = 10, message = "phone cannot exceed 10 chars")
  private String phone;
  @Pattern(regexp = "^\\d{10}$",
          message = "fax must have at maximum 10 digits.")
  @Size(max = 10, message = "Fax cannot exceed 10 chars")
  private String fax;
  @NotBlank(message = "postal Code cannot be blank")
  @Pattern(regexp = "^\\d{5}$", message = "postal Code must have 5 digits")
  @Size(max = 5, message = "postal Code must have 5 digits")
  private String postalCode;

  @SneakyThrows
  @JsonIgnore
  public String asJson() {
    ObjectMapper mapper = new ObjectMapper();
    ObjectNode jsonObject = mapper.createObjectNode();
    jsonObject.put("branch_id", branchId);
    jsonObject.put("project_name", projectName);
    jsonObject.put("client_id", clientId);
    jsonObject.put("address", address);
    jsonObject.put("address_line_2", addressLine2);
    jsonObject.put("state", state);
    jsonObject.put("city", city);
    jsonObject.put("phone", phone);
    jsonObject.put("fax", fax);
    jsonObject.put("postal_code", postalCode);
    return mapper.writeValueAsString(jsonObject);
  }

}
