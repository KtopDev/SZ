package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.staffzone.staffzonesystemsapi.bos.MedicalQuestionnaireUpdateRequestType;
import com.staffzone.staffzonesystemsapi.bos.UserType;
import com.staffzone.staffzonesystemsapi.validators.Uuid;
import com.staffzone.staffzonesystemsapi.validators.ValueOfEnum;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Send Medical Questionnaire Request Dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MedicalQuestionnaireSendRequest {
  @NotBlank(message = "requestType cannot be blank")
  @ValueOfEnum(enumClass = MedicalQuestionnaireUpdateRequestType.class)
  private String requestType;
}
