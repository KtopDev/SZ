package com.staffzone.staffzonesystemsapi.dtos.responses;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.staffzone.staffzonesystemsapi.dtos.responses.ProjectCertifiedPayrollSettings;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Project Details DTO.
 */
@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProjectDetails {
  private UUID projectId;
  private String projectName;
  private Integer projectCode;
  private UUID branchId;
  private String branchName;
  private Integer branchCode;
  private UUID clientId;
  private String clientName;
  private UUID compCodeId;
  private String compCodeCode;
  private UUID payCycleId;
  private String payCycleName;
  private String phone;
  private String fax;
  private String address;
  private String addressLine2;
  private String state;
  private String city;
  private String postalCode;
  private BigDecimal localTaxes;
  private BigDecimal saleTaxes;
  private Boolean isCertifiedPayroll;
  private Boolean isDefaultWageSetupOverriden;
  private BigDecimal minimumWageAmount;
  private BigDecimal weeklyRegularHours;
  private BigDecimal dailyRegularHours;
  private BigDecimal overtimeModifier;
  private BigDecimal effectiveOvertimeModifier;
  private String siteNotes;
  private Boolean isSelfDispatch;
  private UUID billingContactId;
  private ClientContactDetails billingContact;
  private String invoiceMethod;
  private UUID printingFormatId;
  private String printingFormatName;
  private String invoicePeriodicity;
  private UUID transportationPayCodeId;
  private BigDecimal transportationAmount;
  private Boolean isHouseSale;
  private String status;
  private String statusTs;
  private Boolean rowActive;
  private ProjectCertifiedPayrollSettings projectCertifiedPayrollSettings;
  private List<ProjectBonusDetails> projectBonuses;
  private List<ProjectSalesUserDetails> projectSalesUsers;
  private List<CommonDetails> projectTaxes;
  private List<CommonDetails> projectUnemploymentJurisdictions;
  private List<CommonDetails> projectSickPayJurisdictions;
  private List<CommonDetails> projectSiteRequirements;
  private List<CommonDetails> projectCertifications;
  private List<CommonDetails> projectSkills;
  private List<CommonDetails> projectPpes;
  private List<CommonDetails> projectTools;

  public void setIsRowActive(Boolean rowActive) {
    this.rowActive = rowActive;
  }

  public void setCompCode(String compCodeCode) {
    this.compCodeCode = compCodeCode;
  }
}
