package com.staffzone.staffzonesystemsapi.dtos.responses;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

/**
 * DTO mapped against "<strong>tolls</strong>" Table.
 */
@SuperBuilder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ToolResponse {
  private UUID toolId;
  private String toolName;
  private String toolDescription;
  private String toolAbreviation;
  private UUID branchId;
}
