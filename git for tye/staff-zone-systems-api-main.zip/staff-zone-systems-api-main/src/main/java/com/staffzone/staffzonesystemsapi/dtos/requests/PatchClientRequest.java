package com.staffzone.staffzonesystemsapi.dtos.requests;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Patch Client Request Dto.
 */
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PatchClientRequest {
  private String status;
}
