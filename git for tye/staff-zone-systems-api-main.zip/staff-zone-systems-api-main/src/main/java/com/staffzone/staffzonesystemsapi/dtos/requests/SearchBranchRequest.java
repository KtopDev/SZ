package com.staffzone.staffzonesystemsapi.dtos.requests;

import static com.staffzone.staffzonesystemsapi.entities.Branch.Fields.address;
import static com.staffzone.staffzonesystemsapi.entities.Branch.Fields.branchCode;
import static com.staffzone.staffzonesystemsapi.entities.Branch.Fields.branchName;
import static com.staffzone.staffzonesystemsapi.entities.Branch.Fields.modifiedAt;

import com.staffzone.staffzonesystemsapi.entities.Branch.Fields;
import com.staffzone.staffzonesystemsapi.validators.SortOptions;
import jakarta.validation.constraints.Pattern;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class SearchBranchRequest extends SearchAbstractRequest {
  @SortOptions(anyOf = {branchName, branchCode, Fields.status, Fields.state, modifiedAt, address})
  private String sort;
  private String nameCode;
  private String state;
  @Pattern(regexp = "^$|Active|Inactive|ACTIVE|INACTIVE",
          message = "Status must be either 'Active', 'Inactive'")
  private String status;
  private LocalDate startDate;
  private LocalDate endDate;
}
