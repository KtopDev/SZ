package com.staffzone.staffzonesystemsapi.controllers;

import static org.springframework.http.MediaType.MULTIPART_FORM_DATA_VALUE;
import static org.springframework.http.ResponseEntity.ok;

import com.staffzone.staffzonesystemsapi.dtos.requests.AgreeLegalTermsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.AppTermsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.UpdateClientAppTermRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.UpdateClientTermsOrderRequest;
import com.staffzone.staffzonesystemsapi.dtos.responses.ClientAppTermItemResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.ClientAppTermsResponse;
import com.staffzone.staffzonesystemsapi.entities.ClientAppTerms;
import com.staffzone.staffzonesystemsapi.services.ClientAppTermsService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import java.util.UUID;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Client App Terms Controller.
 */
@RequestMapping("/api/v1/client-app-terms")
@CrossOrigin("*")
@RestController
@AllArgsConstructor
public class ClientAppTermsController {
  private ClientAppTermsService clientTermsService;

  @GetMapping
  @Operation(description = "Get Client App Terms")
  public ResponseEntity<ClientAppTermsResponse> getAllLegalTerms(@RequestParam(required = false) UUID clientId) {
    return ResponseEntity.ok(clientTermsService.findActivesByClientId(clientId));
  }

  @GetMapping("/{termId}")
  @Operation(description = "Get a Client App Term")
  public ResponseEntity<ClientAppTermItemResponse> getLegalTerm(@PathVariable UUID termId) {
    return ResponseEntity.ok(clientTermsService.findActiveTermById(termId));
  }

  @PostMapping(consumes = {MULTIPART_FORM_DATA_VALUE})
  @Operation(description = "Add new Client App Terms")
  public ResponseEntity<ClientAppTermsResponse> addClientAppTerms(
          @ModelAttribute @Valid AppTermsRequest request) {
    return ResponseEntity.ok(clientTermsService.save(request));
  }

  @PostMapping("/agree")
  @Operation(summary = "Saves that the client is agree with the Legal Terms for the  Client App")
  public ResponseEntity<String> agreeLegalTerms(
          @RequestBody AgreeLegalTermsRequest request) {
    return ResponseEntity.ok(clientTermsService.agreeLegalTerms(request));
  }

  /**
   * Get all Legal Terms by BranchId for Clients.
   *
   * @param clientAppTermId UUID
   * @param request         {@link AppTermsRequest}
   * @return List of {@link ClientAppTermsResponse}
   */
  @PatchMapping(consumes = {MULTIPART_FORM_DATA_VALUE}, value = "/{clientAppTermId}")
  @Operation(description = "Update Client App Terms")
  public ResponseEntity<ClientAppTerms> updateClientAppTerm(
          @PathVariable("clientAppTermId") UUID clientAppTermId,
          @ModelAttribute @Valid UpdateClientAppTermRequest request) {
    return ok(clientTermsService.update(clientAppTermId, request));
  }

  @DeleteMapping("/{clientAppTermId}")
  @Operation(summary = "Delete a Client app Term")
  public ResponseEntity<ClientAppTerms> deleteWorkerAppTerm(
          @PathVariable("clientAppTermId") UUID clientAppTermId) {
    return ok(clientTermsService.delete(clientAppTermId));
  }

  @PutMapping("/update-order")
  @Operation(summary = "Update Client App Terms order")
  public void updateClientTermsOrder(@RequestBody UpdateClientTermsOrderRequest request) {
    clientTermsService.updateClientTermsOrder(request);
  }
}
