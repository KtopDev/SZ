package com.staffzone.staffzonesystemsapi.dtos.responses;

import java.util.UUID;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Projects Create Response DTO.
 */
@Data
@NoArgsConstructor
public class ProjectResponse {
  private UUID branchId;
  private UUID clientId;
  private UUID projectId;
  private Integer branchCode;
  private String branchName;
  private String clientName;
  private Integer projectCode;
  private String projectName;
  private String status;
}