package com.staffzone.staffzonesystemsapi.dtos.requests;

import lombok.*;

/**
 * Workers Verification request.
 */
@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WorkerLoginRequest {
  private String phone;
  private String email;
}
