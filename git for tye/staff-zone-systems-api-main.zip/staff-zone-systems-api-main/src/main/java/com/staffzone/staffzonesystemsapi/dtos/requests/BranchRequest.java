package com.staffzone.staffzonesystemsapi.dtos.requests;

import static com.staffzone.staffzonesystemsapi.utils.Constants.IPV4_PATTERN;

import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Branch Request.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BranchRequest {
  //Basic Information
  @NotBlank(message = "Branch name cannot be blank")
  @Size(min = 3, max = 20, message = "Branch name cannot exceed 20 chars")
  private String branchName;

  @NotBlank(message = "Branch code cannot be blank")
  @Size(max = 3, message = "Branch code cannot exceed 3 chars")
  private String branchCode;

  @NotBlank(message = "Phone cannot be blank")
  @Size(max = 10, message = "Phone cannot exceed 10 chars")
  private String phone;

  @Size(max = 10, message = "Fax cannot exceed 10 chars")
  private String fax;

  @NotNull(message = "Pay limit daily cannot be blank")
  @Digits(fraction = 4, integer = 10,
          message = "Daily pay limit can't be bigger than 999999999.9999")
  private BigDecimal payLimitDaily;

  @NotNull(message = "Pay limit weekly cannot be blank")
  @Digits(fraction = 4, integer = 10,
          message = "Weekly pay limit can't be bigger than 999999999.9999")
  private BigDecimal payLimitWeekly;

  @NotBlank(message = "Pay cycle weekly cannot be blank")
  private String payCycle;

  //Location
  @NotBlank(message = "Address cannot be blank")
  private String address;

  private String addressLine2;

  @NotBlank(message = "State cannot be blank")
  private String state;

  @NotBlank(message = "City cannot be blank")
  @Size(max = 50, message = "City cannot exceed 50 chars")
  private String city;

  @NotBlank(message = "Postal Code cannot be blank")
  @Size(max = 5, message = "Postal Code must have 5 digits")
  private String postalCode;

  @NotBlank(message = "Geolocation cannot be blank")
  @Size(max = 50, message = "Geolocation cannot exceed 50 chars")
  private String geoLocation;

  //Taxes
  @NotEmpty(message = "Tax Jurisdictions cannot be blank")
  private List<String> taxJurisdictions;

  @NotEmpty(message = "Futa Suta Sdi cannot be blank")
  private List<String> futaSutaSdi;

  //Sick Pay Rules
  @NotEmpty(message = "Sick Pay Jurisdictions cannot be blank")
  private List<String> sickPayJurisdictions;

  //Print Ip Configuration
  @NotBlank(message = "Scanner Ip cannot be blank")
  @Pattern(regexp = IPV4_PATTERN,
          message = "Scanner IP need to follow IPV4 format")
  private String scannerIp;

  @NotBlank(message = "Check printer IP cannot be blank")
  @Pattern(regexp = IPV4_PATTERN,
          message = "Check printer IP need to follow IPV4 format")
  private String checkPrinterIp;

  @NotBlank(message = "Report printer IP cannot be blank")
  @Pattern(regexp = IPV4_PATTERN,
          message = "Report IP need to follow IPV4 format")
  private String reportPrinterIp;

  //Other Settings
  @NotBlank(message = "Default Check Printing Format Id cannot be blank")
  private String defaultCheckPrintingFormatId;

  @NotBlank(message = "Sick Check Printing Format Id cannot be blank")
  private String sickCheckPrintingFormatId;

  @NotBlank(message = "Deposit Printing Format Id cannot be blank")
  private String depositPrintingFormatId;

  @NotBlank(message = "Comp code cannot be blank")
  private String compCodeId;

  @NotNull
  private BigDecimal minimumWageAmount;
  @NotNull
  private BigDecimal weeklyRegularHours;
  @NotNull
  private BigDecimal dailyRegularHours;
  @NotNull
  private BigDecimal overtimeModifier;

  @NotNull
  private Boolean isVoluntaryDeductionApproveRequired;

  //Terms and Conditions
  private List<String> clientTerms;

  private List<String> workerTerms;
}
