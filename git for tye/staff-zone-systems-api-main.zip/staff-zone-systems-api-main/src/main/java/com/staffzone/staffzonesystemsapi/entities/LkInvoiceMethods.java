package com.staffzone.staffzonesystemsapi.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;

/**
 * Entity mapped against "<strong>LkInvoiceMethods</strong>" Table.
 */
@Entity
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "lk_invoice_methods")
public class LkInvoiceMethods {
  @Id
  @Column(name = "invoice_method", nullable = false)
  private String invoiceMethod;
  @Column(name = "label", nullable = false)
  private String label;
  @Column(name = "sort_order", nullable = false)
  private Integer sortOrder;
  @Column(name = "is_row_active", nullable = false)
  private Boolean isRowActive;
}
