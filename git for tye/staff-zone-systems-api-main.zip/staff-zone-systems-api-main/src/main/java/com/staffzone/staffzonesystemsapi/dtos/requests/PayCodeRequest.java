package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PayCodeRequest {
  @NotBlank(message = "Pay Code Name cannot be blank")
  private String payCodeName;
  @NotBlank(message = "Pay Code Description cannot be blank")
  private String payCodeDescription;
}
