package com.staffzone.staffzonesystemsapi.dtos;

import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class BranchInformationForWorkerDto {
    private UUID branchId;
    private String branchName;
    private String phone;
    private String fax;
    private String address;
    private String state;
    private String stateName;
    private String modifiedAt;
    private String status;
    private Boolean workedIn;

}
