package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.staffzone.staffzonesystemsapi.dtos.SearchClientNotesFilterDto;
import com.staffzone.staffzonesystemsapi.entities.ClientNotes;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Paginated Client Notes Response DTO.
 */
@EqualsAndHashCode(callSuper = false)
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class PaginatedClientNotesResponse extends PaginatedAbstractResponse {
  private List<ClientNotes> content;
  private SearchClientNotesFilterDto filters;
}
