package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Projects Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchProjectsItemResponse {
  @JsonSetter(value = "total_rows")
  private String totalRows;
  @JsonSetter(value = "project_id")
  private String projectId;
  @JsonSetter(value = "project_code")
  private String projectCode;
  @JsonSetter(value = "project_name")
  private String projectName;
  @JsonSetter(value = "client_name")
  private String client;
  @JsonSetter(value = "client_id")
  private String clientId;
  @JsonSetter(value = "branch_name")
  private String branch;
  @JsonSetter(value = "branch_id")
  private String branchId;
  @JsonSetter(value = "branch_code")
  private String branchCode;
  @JsonSetter(value = "visit_date")
  private String lastVisitDate;
  @JsonSetter(value = "status")
  private String status;
}
