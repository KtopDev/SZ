package com.staffzone.staffzonesystemsapi.dtos.responses;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

/**
 * Client Contact Details DTO.
 */
@Data
@NoArgsConstructor
public class CommonDetails {
  private UUID id;
  private String name;

  public void setTaxJurisdictionId(UUID id) {
    this.id = id;
  }
  public void setTaxJurisdictionName(String name) {
    this.name = name;
  }
  public void setUnemploymentJurisdictionId(UUID id) {
    this.id = id;
  }
  public void setSickPayJurisdictionId(UUID id) {
    this.id = id;
  }
  public void setStateName(String name) {
    this.name = name;
  }
  public void setSiteRequirementId(UUID id) {
    this.id = id;
  }
  public void setSiteRequirementName(String name) {
    this.name = name;
  }
  public void setCertificationId(UUID id) {
    this.id = id;
  }
  public void setCertificationName(String name) {
    this.name = name;
  }
  public void setSkillId(UUID id) {
    this.id = id;
  }
  public void setSkillName(String name) {
    this.name = name;
  }
  public void setPpeId(UUID id) {
    this.id = id;
  }
  public void setPpeName(String name) {
    this.name = name;
  }
  public void setToolId(UUID id) {
    this.id = id;
  }
  public void setToolName(String name) {
    this.name = name;
  }
}
