package com.staffzone.staffzonesystemsapi.dtos;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.staffzone.staffzonesystemsapi.entities.AppRole;
import com.staffzone.staffzonesystemsapi.entities.AppUsersBranch;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * User Role detail Dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class UserRoleDetail implements UserDetails {
  private UUID appUserId;
  private String appUserCode;
  private String firstName;
  private String lastName;
  private String status;
  private String jobTitle;
  private String email;
  private String phone;
  private List<RoleDetail> roles;

  @JsonSetter("job_title")
  public void setJobTitle(String jobTitle) {
    this.jobTitle = jobTitle;
  }

  @JsonSetter("first_name")
  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  @JsonSetter("last_name")
  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  @JsonSetter("app_user_id")
  public void setAppUserId(UUID appUserId) {
    this.appUserId = appUserId;
  }

  @JsonSetter("app_user_code")
  public void setUserCode(String appUserCode) {
    this.appUserCode = appUserCode;
  }

  @Override
  public String getUsername() {
    return email;
  }

  @Override
  @JsonIgnore
  public Collection<? extends GrantedAuthority> getAuthorities() {
    return getRoles().stream()
        .map(role -> new SimpleGrantedAuthority("ROLE_" + role.getRole()))
        .collect(Collectors.toSet());
  }

  @Override
  @JsonIgnore
  public String getPassword() {
    return null;
  }

  @Override
  @JsonIgnore
  public boolean isAccountNonExpired() {
    return true;
  }

  @Override
  @JsonIgnore
  public boolean isAccountNonLocked() {
    return true;
  }

  @Override
  @JsonIgnore
  public boolean isCredentialsNonExpired() {
    return true;
  }

  @Override
  @JsonIgnore
  public boolean isEnabled() {
    return true;
  }
}
