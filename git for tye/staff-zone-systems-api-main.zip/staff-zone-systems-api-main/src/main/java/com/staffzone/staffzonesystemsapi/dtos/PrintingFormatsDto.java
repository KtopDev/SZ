package com.staffzone.staffzonesystemsapi.dtos;

import com.staffzone.staffzonesystemsapi.entities.PrintingFormats;
import java.time.LocalDateTime;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Printing Formats DTO.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class PrintingFormatsDto {
  private UUID printingFormatId;
  private PrintingFormatTypeDto printingFormatType;
  private String printingFormatName;
  private String printingFormatUri;
  private LocalDateTime modifiedAt;

  /**
   * Printing Formats build from LkPrintingFormatTypes.
   *
   * @param printingFormats {@link PrintingFormats}
   * @return PrintingFormatsDto
   */
  public static PrintingFormatsDto build(PrintingFormats printingFormats) {
    return PrintingFormatsDto.builder()
            .printingFormatId(printingFormats.getPrintingFormatId())
            .printingFormatType(PrintingFormatTypeDto
                    .build(printingFormats.getLkPrintingFormatType()))
            .printingFormatName(printingFormats.getPrintingFormatName())
            .printingFormatUri(printingFormats.getPrintingFormatUri())
            .modifiedAt(printingFormats.getModifiedAt())
            .build();
  }
}
