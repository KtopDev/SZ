package com.staffzone.staffzonesystemsapi.entities;

import java.time.LocalDateTime;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;

/**
 * Entity mapped against "<strong>dispatch_buckets</strong>" Table.
 */
@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "dispatch_buckets")
public class DispatchBucket extends Audit {
  @Id
  @Column(name = "dispatch_bucket_id", nullable = false)
  private UUID dispatchBucketId;

  @NotNull
  @Column(name = "branch_id", nullable = false)
  private UUID branchId;

  @NotNull
  @Column(name = "order_id", nullable = false)
  private UUID orderId;

  @NotNull
  @Column(name = "project_id", nullable = false)
  private UUID projectId;

  @NotNull
  @Column(name = "route_id", nullable = false)
  private UUID routeId;

  @Builder.Default
  @NotNull
  @Column(name = "is_row_active", nullable = false)
  private Boolean isRowActive = true;

  @Column(name = "seats", nullable = false)
  private Integer seats;

  @Column(name = "status", nullable = false)
  private String status;

  @Column(name = "status_ts", nullable = false)
  private LocalDateTime statusTs;
}