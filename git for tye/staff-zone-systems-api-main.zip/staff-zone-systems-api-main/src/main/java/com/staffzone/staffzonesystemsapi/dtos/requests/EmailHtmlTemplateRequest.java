package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotNull;
import java.util.Map;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Email Base Request Dto.
 * <br/> Also see {@link EmailBaseRequest}
 */
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@SuperBuilder
public class EmailHtmlTemplateRequest extends EmailBaseRequest {
  @NotNull(message = "The template cannot be null")
  private String htmlTemplate;
  private Map<String, Object> map;
}
