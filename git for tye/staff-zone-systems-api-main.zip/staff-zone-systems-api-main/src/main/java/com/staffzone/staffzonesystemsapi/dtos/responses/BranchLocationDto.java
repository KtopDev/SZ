package com.staffzone.staffzonesystemsapi.dtos.responses;

import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Branch Locations DTO.
 * <pre>{@code
 *    {
 *      "phone": "string",
 *      "address": "string",
 *      "branch_id": "UUID",
 *      "branch_name": "string",
 *      "postal_code": "string",
 *      "address_line_2": "string"
 *    }
 * }</pre>
 */
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@SuppressWarnings("checkstyle:MemberName")
public class BranchLocationDto {
  private String phone;
  private String address;
  private UUID branch_id;
  private String branch_name;
  private String postal_code;
  private String address_line_2;
  private String geo_location;
}
