package com.staffzone.staffzonesystemsapi.dtos.requests;

import java.time.LocalDate;
import java.util.UUID;

import com.staffzone.staffzonesystemsapi.validators.Uuid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@SuperBuilder
public class BranchRouteRequest {
    @NotNull(message = "Branch Id is required")
    @Uuid(message = "Branch Id Invalid UUID Format")
    private UUID branchId;

    @NotBlank(message = "Route name cannot be blank")
    @NotNull(message = "Route name cannot be null")
    private String routeName;

    @NotBlank(message = "Route type cannot be blank")
    @NotNull(message = "Route type cannot be null")
    private String routeType;

    @NotNull(message = "Seats cannot be null")
    @PositiveOrZero(message = "Seats must be positive number or zero")
    private Integer seats;

    private LocalDate routeDate;

    private UUID driverId;
}
