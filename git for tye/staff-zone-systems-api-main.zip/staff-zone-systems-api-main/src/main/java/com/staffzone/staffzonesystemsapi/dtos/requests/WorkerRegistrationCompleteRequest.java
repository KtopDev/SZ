package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.util.List;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Worker Request DTO.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class WorkerRegistrationCompleteRequest {

  @NotNull(message = "Worker Id cannot be blank")
  private UUID workerId;

  private String address;

  private String addressLine2;

  private String city;

  private String state;

  @Size(max = 5, message = "Postal Code must have 5 digits")
  private String postalCode;

  private String legalStatus;

  private String alienRegistrationNumber;

  private String i94Number;

  private String passportNumber;

  private String passportCountryCode;

  private String signaturePath;

  private List<TermsAcceptanceDto> termsAcceptance;

  private List<SkillsDto> skills;

}
