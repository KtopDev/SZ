package com.staffzone.staffzonesystemsapi.dtos.responses;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Create ProjectWorkerBasedBilling Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProjectOrderBasedBillingResponse {
  private String name;
  private String status;
  private String billRate;
  private String frequency;
  private String statusTs;
  private String projectId;
  private String appliedPer;
  private String description;
  private String billCodeId;
  private String billCodeName;
  private String projectOrderBasedBillingId;
}
