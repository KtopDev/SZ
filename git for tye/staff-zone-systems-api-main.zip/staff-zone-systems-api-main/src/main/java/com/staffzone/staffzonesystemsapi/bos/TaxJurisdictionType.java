package com.staffzone.staffzonesystemsapi.bos;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * MultiFactorType: <br/>
 * {@link #STATE},<br/>
 * {@link #CITY},<br/>
 * {@link #REGIONAL},<br/>
 * {@link #SCHOOL_DISTRICT}.
 *
 */
@Getter
@AllArgsConstructor
public enum TaxJurisdictionType {
  FEDERAL("FEDERAL"),
  STATE("STATE"),
  CITY("CITY"),
  REGIONAL("REGIONAL"),
  SCHOOL_DISTRICT("SCHOOL_DISTRICT");

  private final String value;

  /**
   * Method to search value from any String.
   *
   * @param str
   *            <br/> Accept null and is case-sensitive.
   * @return <br/> Search between options
   */
  public static TaxJurisdictionType of(String str) {
    for (TaxJurisdictionType type : values()) {
      if (str.equalsIgnoreCase(type.value)) {
        return type;
      }
    }
    return null;
  }
}
