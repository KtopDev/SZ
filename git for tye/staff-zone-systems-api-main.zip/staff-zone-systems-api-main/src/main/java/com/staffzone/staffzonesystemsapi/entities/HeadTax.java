package com.staffzone.staffzonesystemsapi.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.ColumnDefault;

/**
 * Entity mapped against "<strong>HeadTax</strong>" Table.
 */
@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "head_taxes")
public class HeadTax extends Audit {
  @Id
  @Column(name = "tax_id", nullable = false)
  private UUID id;

  @Builder.Default
  @NotNull
  @ColumnDefault("true")
  @Column(name = "is_row_active", nullable = false)
  private Boolean isRowActive = true;

  @NotNull
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "tax_jurisdiction_id", nullable = false)
  private TaxJurisdictions taxJurisdiction;

  @NotNull
  @Column(name = "effective_date", nullable = false)
  private LocalDate effectiveDate;

  @Size(max = 50)
  @NotNull
  @Column(name = "recurrency", nullable = false, length = 50)
  private String recurrency;

  @NotNull
  @Column(name = "tax_amount", nullable = false, precision = 10, scale = 2)
  private BigDecimal taxAmount;

  @NotNull
  @Column(name = "employee_percentage", nullable = false, precision = 3, scale = 2)
  private BigDecimal employeePercentage;

  @NotNull
  @Column(name = "employer_percentage", nullable = false, precision = 3, scale = 2)
  private BigDecimal employerPercentage;

}