package com.staffzone.staffzonesystemsapi.dtos.responses;

import java.math.BigDecimal;
import java.util.UUID;

import com.staffzone.staffzonesystemsapi.entities.PayCodes;
import com.staffzone.staffzonesystemsapi.entities.Project;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Project Details DTO.
 */
@Data
@NoArgsConstructor
public class ProjectBonusDetails {
  @Setter
  private UUID projectBonusId;
  private UUID bonusPayCodeId;
  private BigDecimal bonusRequiredHours;
  private BigDecimal bonusAmount;
  private String bonusFrequency;

}
