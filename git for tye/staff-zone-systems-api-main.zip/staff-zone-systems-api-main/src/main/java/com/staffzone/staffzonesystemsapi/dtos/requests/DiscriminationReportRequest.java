package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Discrimination Report Request Dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DiscriminationReportRequest {
  @NotBlank(message = "You must add details")
  private String eventDetails;
  @NotNull(message = "You must add a date")
  private LocalDate eventDate;
  @NotBlank(message = "You must add a location")
  private String eventLocation;
  @NotBlank(message = "You must add a reason")
  private String eventReason;
  @NotEmpty(message = "You must add a subject involved")
  @Valid
  private List<SubjectRequest> subjectsInvolved;
  @Valid
  private List<SubjectRequest> witnesses;
}
