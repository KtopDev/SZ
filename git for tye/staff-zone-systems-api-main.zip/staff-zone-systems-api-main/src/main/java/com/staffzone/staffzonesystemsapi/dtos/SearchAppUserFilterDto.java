package com.staffzone.staffzonesystemsapi.dtos;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class SearchAppUserFilterDto {
    private String nameOrCode;
    private String status;
    private String jobTitle;
}
