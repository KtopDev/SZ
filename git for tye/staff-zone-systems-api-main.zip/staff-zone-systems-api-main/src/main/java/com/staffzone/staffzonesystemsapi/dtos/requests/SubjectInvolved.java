package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

/**
 * Subject Involved Request Dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SubjectInvolved {
  @NotBlank(message = "fullName cannot be blank")
  @Length(min = 3,message = "Minimum 3 characters")
  private String fullName;
  @NotBlank(message = "employee cannot be blank")
  @Length(min = 3,message = "Minimum 3 characters")
  private String employee;
  @NotBlank(message = "position cannot be blank")
  @Length(min = 3,message = "Minimum 3 characters")
  private String position;

}
