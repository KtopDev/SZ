package com.staffzone.staffzonesystemsapi.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;

/**
 * The persistent class for the app_claims database table.
 */
@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@EqualsAndHashCode(callSuper = true)
@Table(name = "app_claims")
public class AppClaim extends Audit {

  @Id
  @Column(name = "claim")
  private String claim;
  @Column(name = "label")
  private String label;

  @Builder.Default
  @Column(updatable = false, insertable = false)
  private Boolean isRowActive = false;
}
