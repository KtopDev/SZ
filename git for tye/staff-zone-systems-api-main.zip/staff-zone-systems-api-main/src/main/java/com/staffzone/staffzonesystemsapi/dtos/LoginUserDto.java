package com.staffzone.staffzonesystemsapi.dtos;

import jakarta.validation.constraints.NotEmpty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LoginUserDto {
  @NotEmpty
  private String username;
  @NotEmpty
  private String password;
  @NotEmpty
  private String userType;

}