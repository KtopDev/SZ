package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Reset Password Request Data DTO.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ResetWorkerPasswordLinkRequest {
  @NotBlank(message = "Email cannot be blank")
  @Email(message = "Email must be valid")
  private String email;
}
