package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.UUID;

/**
 * Workers complete registration response.
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class WorkerRegistrationCompleteResponse {
  private UUID workerId;
  private String email;
  private String phone;
  private String status;
  private String statusTs;
  private String firstName;
  private String lastName;
  private String otherNames;
  private String workerCode;
  private String signatureTs;
  private String dateOfBirth;
  private String middleInitial;
  private String signaturePath;
  private String address;
  @JsonProperty("address_line_2")
  private String addressLine2;
  private String city;
  private String state;
  private String postalCode;
  private String legalStatus;
  private String alienRegistrationNumber;
  @JsonProperty("i_94_number")
  private String i94Number;
  private String passportNumber;
  private String passportCountryCode;
  private String termsAcceptance;
  private String skills;
}
