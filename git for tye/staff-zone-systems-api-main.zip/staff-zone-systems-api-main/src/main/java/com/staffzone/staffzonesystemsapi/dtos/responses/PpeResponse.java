package com.staffzone.staffzonesystemsapi.dtos.responses;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

/**
 * DTO mapped against "<strong>ppe</strong>" Table.
 */
@SuperBuilder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PpeResponse {
  private UUID ppeId;
  private String ppeName;
  private String ppeDescription;
  private String ppeAbreviation;
  private UUID branchId;
}
