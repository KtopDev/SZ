package com.staffzone.staffzonesystemsapi.bos;

import com.staffzone.staffzonesystemsapi.dtos.DropdownDto;
import com.staffzone.staffzonesystemsapi.dtos.DropdownItemDto;

import java.util.EnumSet;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * SkillTierType: <br/>
 * {@link #GENERAL_LABOR},<br/>
 * {@link #ADVANCED},<br/>
 * {@link #SEMI_SKILLED},<br/>
 * {@link #SKILLED}.
 */
public enum SkillTierType {
  GENERAL_LABOR,
  ADVANCED,
  SEMI_SKILLED,
  SKILLED;

  public static DropdownDto toDropdownDto() {
    Set<DropdownItemDto> items = EnumSet.allOf(SkillTierType.class).stream()
        .map(skill -> new DropdownItemDto(
            skill.name(),
            capitalize(skill.name().toLowerCase().replace('_', ' '))
        ))
        .collect(Collectors.toSet());

    return DropdownDto.builder()
        .dropdown(items)
        .build();
  }

  private static String capitalize(String str) {
    return Character.toUpperCase(str.charAt(0)) + str.substring(1);
  }
}
