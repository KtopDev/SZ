package com.staffzone.staffzonesystemsapi.controllers;

import static org.springframework.http.HttpHeaders.CONTENT_DISPOSITION;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.MediaType.APPLICATION_PDF_VALUE;

import com.staffzone.staffzonesystemsapi.dtos.requests.ClientNotesRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.CreateClientContactRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.CreateClientRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.PatchClientRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchClientNotesRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchClientRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SelectedClientNotesRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.UpdateClientRequest;
import com.staffzone.staffzonesystemsapi.dtos.responses.ClientResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.PaginatedClientNotesResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchClientsResponse;
import com.staffzone.staffzonesystemsapi.entities.Client;
import com.staffzone.staffzonesystemsapi.entities.ClientContact;
import com.staffzone.staffzonesystemsapi.entities.ClientNotes;
import com.staffzone.staffzonesystemsapi.services.ClientNotesService;
import com.staffzone.staffzonesystemsapi.services.ClientService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import java.util.UUID;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller for Clients Endpoints.
 */
@RequestMapping("/api/v1/clients")
@CrossOrigin("*")
@RestController
@AllArgsConstructor
public class ClientController {
  private ClientService clientService;
  private ClientNotesService clientNotesService;

  @GetMapping
  @Operation(summary = "Search a Client and returns list base on filters")
  public ResponseEntity<SearchClientsResponse> findAll(
          @Valid SearchClientRequest searchClientRequest) {
    return ResponseEntity.ok(clientService.searchClient(searchClientRequest));
  }

  @PostMapping
  @Operation(summary = "Creates a Client and returns newly created client guid")
  public ResponseEntity<ClientResponse> save(
          @RequestBody @Valid CreateClientRequest createClientRequest) {
    Client client = clientService.creatClient(createClientRequest);
    return new ResponseEntity<>(clientService.findById(client.getId().toString()), CREATED);
  }

  /**
   * Returns paginated Client Notes information for a client.
   *
   * @param clientId UUID
   * @param request  {@link SearchClientNotesRequest}
   * @return RequestEntity {@link PaginatedClientNotesResponse}
   */
  @GetMapping("/{clientId}/notes")
  @Operation(summary = "Returns paginated Client Notes information for a client")
  public ResponseEntity<PaginatedClientNotesResponse> notes(
          @PathVariable UUID clientId,
          @Valid SearchClientNotesRequest request) {
    request.setClientId(clientId);
    PaginatedClientNotesResponse paginatedClientNotesResponse = clientNotesService
            .searchClientNotes(request);
    return ResponseEntity.ok(paginatedClientNotesResponse);
  }

  /**
   * "Creates a Client Note and returns newly created note guid".
   *
   * @param clientId           UUID
   * @param clientNotesRequest {@link ClientNotesRequest}
   * @return RequestEntity {@link ClientNotes}
   */
  @PostMapping("/{clientId}/notes")
  @Operation(summary = "Creates a Client Note and returns newly created note guid")
  public ResponseEntity<ClientNotes> saveNote(
          @PathVariable UUID clientId, @RequestBody @Valid ClientNotesRequest clientNotesRequest) {
    clientNotesRequest.setClientId(clientId);
    ClientNotes clientNotes = clientNotesService.createClientNotes(clientNotesRequest);
    return new ResponseEntity<>(clientNotesService.findById(
            clientNotes.getClientNoteId()), HttpStatus.CREATED);
  }

  /**
   * Updates a Client Note and returns the updated note.
   *
   * @param clientId                 UUID
   * @param noteId                   UUID
   * @param updateClientNotesRequest ClientNotesRequest
   * @return RequestEntity {@link ClientNotes}
   */
  @PutMapping("/{clientId}/notes/{noteId}")
  @Operation(summary = "Updates a Client Note and returns the updated note")
  public ResponseEntity<ClientNotes> updateNote(
          @PathVariable UUID clientId,
          @PathVariable UUID noteId,
          @RequestBody @Valid ClientNotesRequest updateClientNotesRequest) {
    updateClientNotesRequest.setClientNoteId(noteId);
    updateClientNotesRequest.setClientId(clientId);
    ClientNotes clientNotes = clientNotesService.updateClientNotes(updateClientNotesRequest);
    return new ResponseEntity<>(clientNotesService.findById(
            clientNotes.getClientNoteId()), HttpStatus.OK);
  }

  @DeleteMapping("/{clientId}/notes/{noteId}")
  @Operation(summary = "Deletes a Client Note")
  //TODO Is needed clientId??
  public ResponseEntity<ClientNotes> deleteNote(
          @PathVariable UUID clientId,
          @PathVariable UUID noteId) {
    ClientNotes clientNotes = clientNotesService.deleteClientNotes(noteId);
    return new ResponseEntity<>(clientNotes, HttpStatus.OK);
  }

  @GetMapping("/{clientId}/notes/{noteId}")
  @Operation(summary = "Returns Client Note information by guid")
  //TODO Is needed clientId??
  public ResponseEntity<ClientNotes> findNoteById(
          @PathVariable UUID clientId,
          @PathVariable UUID noteId) {
    ClientNotes clientNotes = clientNotesService.findById(noteId);
    return ResponseEntity.ok(clientNotes);
  }

  @PutMapping("/{uuid}")
  @Operation(summary = "Updates a Client and returns updated info")
  public ResponseEntity<ClientResponse> update(
          @PathVariable String uuid,
          @RequestBody @Valid UpdateClientRequest updateClientRequest) {
    Client client = clientService.updateClient(uuid, updateClientRequest);
    return ResponseEntity.ok(clientService.findById(client.getId().toString()));
  }

  @GetMapping("/{uuid}")
  @Operation(summary = "Retrieves Client info by uuid")
  public ResponseEntity<ClientResponse> findById(@PathVariable String uuid) {
    return ResponseEntity.ok(clientService.findById(uuid));
  }

  @PatchMapping("/{uuid}")
  @Operation(summary = "Patches a Client and returns updated info")
  public ResponseEntity<ClientResponse> patch(
          @PathVariable String uuid,
          @RequestBody @Valid PatchClientRequest patchClientRequest) {
    Client client = clientService.patchClient(uuid, patchClientRequest);
    return ResponseEntity.ok(clientService.findById(client.getId().toString()));
  }

  @PostMapping("/{clientId}/contacts")
  @Operation(summary = "Creates a Client Contact")
  public ResponseEntity<ClientContact> saveContact(
          @PathVariable UUID clientId,
          @RequestBody @Valid CreateClientContactRequest request) {
    ClientContact clientContact = clientService.createContact(clientId, request);
    return ResponseEntity.ok(clientService.findClientContactById(clientContact.getId()));
  }

  /**
   * Export Client Notes to PDF.
   *
   * @param request {@link SelectedClientNotesRequest}
   * @return byte[]
   */
  @Operation(summary = "Export Client Notes to PDF")
  @PostMapping(value = "/export-notes")
  public ResponseEntity<byte[]> downloadClientNotesPdf(
          @RequestBody @Valid SelectedClientNotesRequest request) {
    return ResponseEntity.ok()
            .header(CONTENT_TYPE, APPLICATION_PDF_VALUE)
            .header(CONTENT_DISPOSITION, "attachment; filename=client_notes.pdf")
            .body(clientNotesService.generateClientNotesPdf(request.getNotesIds()));
  }
}