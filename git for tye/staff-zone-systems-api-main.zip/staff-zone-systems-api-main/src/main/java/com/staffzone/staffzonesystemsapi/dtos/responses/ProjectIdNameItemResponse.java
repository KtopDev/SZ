package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Projects Is and name Response DTO.
 */
@Data
@NoArgsConstructor
public class ProjectIdNameItemResponse {
  @JsonSetter(value = "project_name")
  private String projectName;
  @JsonSetter(value = "project_id")
  private String projectId;
}