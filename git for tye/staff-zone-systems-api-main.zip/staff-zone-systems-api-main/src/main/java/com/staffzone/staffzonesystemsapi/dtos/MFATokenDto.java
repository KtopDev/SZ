package com.staffzone.staffzonesystemsapi.dtos;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
@AllArgsConstructor
public class MFATokenDto {
  private String qrCode;
  private String mfaCode;
  private boolean isRegistered;
}
