package com.staffzone.staffzonesystemsapi.bos;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * SMSSourceApplication: <br/>
 * {@link #TWO_FA},<br/>
 * {@link #PHONE_VERIFICATION}.
 */
public enum SMSSourceApplication {
    TWO_FA("StaffZone 2FA"),
    PHONE_VERIFICATION("StaffZone Phone Verification"),
    NOTIFICATION("StaffZone Text");

    private final String value;

    SMSSourceApplication(String value) {
        this.value = value;
    }

    @JsonValue
    public String getValue() {
        return value;
    }
}

