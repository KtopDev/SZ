package com.staffzone.staffzonesystemsapi.controllers;

import com.staffzone.staffzonesystemsapi.dtos.requests.ProjectOrderMoveRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.ProjectOrderRequest;
import com.staffzone.staffzonesystemsapi.dtos.responses.ProjectOrderResponse;
import com.staffzone.staffzonesystemsapi.services.ProjectOrderService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import java.util.UUID;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller for Project Orders Endpoints.
 */
@RequestMapping("/api/v1/project-orders")
@CrossOrigin("*")
@RestController
@AllArgsConstructor
public class ProjectOrdersController {
  private ProjectOrderService projectOrderService;

  @PutMapping("/{orderId}")
  @Operation(summary = "Updates a Project Order and returns the updated project order info")
  public ResponseEntity<ProjectOrderResponse> update(@PathVariable String orderId,
                                                     @RequestBody @Valid ProjectOrderRequest request) {
    ProjectOrderResponse project = projectOrderService.updateProjectOrder(orderId, request);
    return ResponseEntity.ok(project);
  }

  @GetMapping("/{orderId}")
  @Operation(summary = "Retrieves a Project Order details")
  public ResponseEntity<ProjectOrderResponse> get(@PathVariable UUID orderId) {
    ProjectOrderResponse project = projectOrderService.getDetails(orderId);
    return ResponseEntity.ok(project);
  }

  @PutMapping("/{orderId}/move")
  @Operation(summary = "Move a Project Order")
  public ResponseEntity<String> move(@PathVariable String orderId,
                                     @RequestBody @Valid ProjectOrderMoveRequest request) {
    return ResponseEntity.ok(projectOrderService.moveProjectOrder(orderId, request));
  }

  //TODO validate SP
  /*@DeleteMapping("/{orderId}/remove-worker")
  @Operation(summary = "Removing worker from order")
  public ResponseEntity<String> removeWorkerFromOrder(@PathVariable UUID orderId,
                                                      @RequestBody @Valid RemoveWorkerOrderRequest request) {
    return ResponseEntity.ok(projectOrderService.removeWorkerFromOrder(orderId, request));
  }*/
}
