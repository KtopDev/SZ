package com.staffzone.staffzonesystemsapi.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;

/**
 * Entity mapped against "<strong>bill_codes</strong>" Table.
 */
@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "bill_codes")
public class BillCodes extends Audit {
  @Id
  @Column(name = "bill_code_id", nullable = false)
  private UUID billCodeId;

  @NotNull
  @Column(name = "bill_code_name", nullable = false)
  private String billCodeName;

  @NotNull
  @Column(name = "bill_code_description", nullable = false)
  private String billCodeDescription;

  @Builder.Default
  @NotNull
  @Column(name = "is_row_active", nullable = false)
  private Boolean isRowActive = true;
}