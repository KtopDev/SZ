package com.staffzone.staffzonesystemsapi.bos;

/**
 * BranchStatusType: <br/>
 * {@link #ACTIVE},<br/>
 * {@link #INACTIVE}.
 *
 */
public enum ProjectObbStatusType {
  ACTIVE, INACTIVE
}
