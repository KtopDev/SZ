package com.staffzone.staffzonesystemsapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Staff Zone Application.
 *
 * @author arturo.ortiz
 */
@SpringBootApplication
public class StaffZoneApplication {

  /**
   * Staff Zone main method.
   *
   * @param args SpringApplication
   */
  public static void main(String[] args) {
    SpringApplication.run(StaffZoneApplication.class, args);
  }

}
