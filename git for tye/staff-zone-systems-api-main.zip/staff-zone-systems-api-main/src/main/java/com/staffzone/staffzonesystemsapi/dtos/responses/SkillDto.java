package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import java.util.UUID;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Skill Id Response.
 */
@Data
@NoArgsConstructor
public class SkillDto {
  @JsonSetter(value = "skill_id")
  private UUID skillId;
  @JsonSetter(value = "skill_name")
  private String skillName;
  @JsonSetter(value = "skill_group")
  private String skillGroup;
}
