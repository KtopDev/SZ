package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search PPE Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchPpeItemResponse {
  @JsonSetter(value = "ppe_id")
  private String ppeId;
  @JsonSetter(value = "ppe_name")
  private String name;
  @JsonSetter(value = "branch_id")
  private String branch;
  @JsonSetter(value = "ocurrences")
  private String occurrences;
  @JsonSetter(value = "total_rows")
  private String totalRows;
  @JsonSetter(value = "branch_name")
  private String branchName;
  @JsonSetter(value = "modified_at")
  private String lastUpdated;
  @JsonSetter(value = "ppe_abreviation")
  private String abbreviation;
  @JsonSetter(value = "ppe_description")
  private String description;
}
