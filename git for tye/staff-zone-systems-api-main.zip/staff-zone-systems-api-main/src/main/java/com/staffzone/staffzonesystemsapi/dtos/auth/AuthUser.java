package com.staffzone.staffzonesystemsapi.dtos.auth;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.staffzone.staffzonesystemsapi.bos.AuthStatusType;
import com.staffzone.staffzonesystemsapi.bos.UserType;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Authentication User Response.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class AuthUser {

  private AuthStatusType authStatus;
  private UUID authProcessId;
  private AuthMfaDetail authMfaDetails;
  private String authCodeDetails;
  private AuthUserDetail authUserDetails;
  private String authDeniedDetails;
  private String authErrorMessage;
  private UserType userType;

  @JsonSetter("auth_error_message")
  public void setAuthErrorMessage(String authErrorMessage) {
    this.authErrorMessage = authErrorMessage;
  }

  @JsonSetter("auth_status")
  public void setAuthStatus(AuthStatusType authStatus) {
    this.authStatus = authStatus;
  }

  @JsonSetter("auth_process_id")
  public void setAuthProcessId(UUID authProcessId) {
    this.authProcessId = authProcessId;
  }

  @JsonSetter("auth_mfa_details")
  public void setAuthMfaDetails(AuthMfaDetail authMfaDetails) {
    this.authMfaDetails = authMfaDetails;
  }

  @JsonSetter("auth_code_details")
  public void setAuthCodeDetails(String authCodeDetails) {
    this.authCodeDetails = authCodeDetails;
  }

  @JsonSetter("auth_user_details")
  public void setAuthUserDetails(AuthUserDetail authUserDetails) {
    this.authUserDetails = authUserDetails;
  }

  @JsonSetter("auth_denied_details")
  public void setAuthDeniedDetails(String authDeniedDetails) {
    this.authDeniedDetails = authDeniedDetails;
  }

  @JsonIgnore
  public String getEmail() {
    return getAuthUserDetails() != null ? getAuthUserDetails().getUser().getEmail() : null;
  }
}
