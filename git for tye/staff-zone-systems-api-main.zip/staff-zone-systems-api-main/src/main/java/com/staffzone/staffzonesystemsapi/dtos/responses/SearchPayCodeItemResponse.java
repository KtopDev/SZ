package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Sick Pay Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchPayCodeItemResponse {
  @JsonSetter(value = "pay_code_id")
  private String payCodeId;
  @JsonSetter(value = "pay_code_name")
  private String payCodeName;
  @JsonSetter(value = "pay_code_description")
  private String payCodeDescription;
  @JsonSetter(value = "total_rows")
  private String totalRows;
  @JsonSetter(value = "created_at")
  private String createdAt;
}
