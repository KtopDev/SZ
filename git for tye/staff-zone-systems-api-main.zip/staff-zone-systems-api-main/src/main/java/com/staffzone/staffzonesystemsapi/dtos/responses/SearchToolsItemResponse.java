package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Tools Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchToolsItemResponse {
  @JsonSetter(value = "tool_id")
  private String toolId;
  @JsonSetter(value = "branch_id")
  private String branchId;
  @JsonSetter(value = "tool_name")
  private String name;
  @JsonSetter(value = "ocurrences")
  private String occurrences;
  @JsonSetter(value = "total_rows")
  private String totalRows;
  @JsonSetter(value = "branch_name")
  private String branchName;
  @JsonSetter(value = "modified_at")
  private String lastUpdated;
  @JsonSetter(value = "tool_abreviation")
  private String abbreviation;
  @JsonSetter(value = "tool_description")
  private String description;
}
