package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.staffzone.staffzonesystemsapi.validators.Uuid;
import jakarta.validation.constraints.NotEmpty;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Selected Worker Disciplinary Forms Request DTO.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class SelectedWorkerDisciplinaryFormsRequest {
  @NotEmpty(message = "notesIds cannot be empty")
  private List<@Uuid String> disciplinaryIds;

  /**
   * Custom getter.
   *
   * @return List UUID
   */
  public List<UUID> getDisciplinaryIds() {
    return disciplinaryIds.stream()
            .map(UUID::fromString)
            .collect(Collectors.toList());
  }
}
