package com.staffzone.staffzonesystemsapi.controllers;

import static com.staffzone.staffzonesystemsapi.utils.Constants.PROJECT_DOCUMENTS;
import static com.staffzone.staffzonesystemsapi.utils.Constants.PROJECT_RATE_AGREEMENTS;
import static java.util.UUID.fromString;
import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.MediaType.MULTIPART_FORM_DATA_VALUE;

import com.staffzone.staffzonesystemsapi.bos.OrderStatusType;
import com.staffzone.staffzonesystemsapi.dtos.ClientContactDto;
import com.staffzone.staffzonesystemsapi.dtos.requests.CreateClientContactRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.CreateProjectOrderRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.DocumentTypeRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.ProjectBasicInformationRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.ProjectCertifiedPayrollSettingsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.ProjectObbRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.ProjectRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.ProjectSignedAgreementsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchClientContactRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchProjectOBBRatesRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchProjectOrderRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchProjectWBBRatesRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchProjectsAgreementsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchProjectsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchSiteVisitRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SiteVisitRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.WorkerBasedBillingRequest;
import com.staffzone.staffzonesystemsapi.dtos.responses.CreateProjectOrderResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.PaginatedClientContactResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.ProjectContactsResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.ProjectDetails;
import com.staffzone.staffzonesystemsapi.dtos.responses.ProjectOrderBasedBillingResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.ProjectRequestBasicInfoResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.ProjectResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.ProjectWorkerBasedBillingResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchProjectOBBRatesResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchProjectOrderResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchProjectWBBRatesResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchProjectsAgreementsResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchProjectsResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchSiteVisitResponse;
import com.staffzone.staffzonesystemsapi.entities.ClientContact;
import com.staffzone.staffzonesystemsapi.entities.Project;
import com.staffzone.staffzonesystemsapi.entities.ProjectCertifiedPayrollSettings;
import com.staffzone.staffzonesystemsapi.entities.ProjectSiteVisits;
import com.staffzone.staffzonesystemsapi.entities.ProjectWorkerBasedBilling;
import com.staffzone.staffzonesystemsapi.services.ClientContactService;
import com.staffzone.staffzonesystemsapi.services.ClientService;
import com.staffzone.staffzonesystemsapi.services.ProjectContactService;
import com.staffzone.staffzonesystemsapi.services.ProjectOrderService;
import com.staffzone.staffzonesystemsapi.services.ProjectRequestBasicInfoService;
import com.staffzone.staffzonesystemsapi.services.ProjectService;
import com.staffzone.staffzonesystemsapi.services.SiteVisitService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.UUID;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller for Projects Endpoints.
 */
@RequestMapping("/api/v1/projects")
@CrossOrigin("*")
@RestController
@AllArgsConstructor
@Validated
public class ProjectsController {
  private final ProjectContactService projectContactService;
  private final ClientContactService clientContactService;
  private final ClientService clientService;
  private final SiteVisitService siteVisitService;
  private final ProjectService projectService;
  private final ProjectOrderService projectOrderService;
  private final ProjectRequestBasicInfoService projectRequestService;

  @PutMapping("/{uuid}")
  @Operation(summary = "Updates a Project and returns the updated project info")
  public ResponseEntity<ProjectResponse> updateProject(@PathVariable String uuid,
                                                       @RequestBody @Valid ProjectRequest request) {
    ProjectResponse project = projectService.updateProject(uuid, request);
    return ResponseEntity.ok(project);
  }

  /**
   * Create Site Visit.
   *
   * @param request SiteVisitRequest
   * @return ProjectSiteVisits
   */
  @PostMapping("/site-visits")
  public ResponseEntity<ProjectSiteVisits> createSiteVisit(
          @RequestBody @Valid SiteVisitRequest request) {
    ProjectSiteVisits projectSiteVisits = siteVisitService.createSiteVisit(request);
    return new ResponseEntity<>(siteVisitService
            .findById(projectSiteVisits.getSiteVisitId()), CREATED);
  }

  @GetMapping("/site-visits")
  @Operation(summary = "SiteVisits list and search")
  public ResponseEntity<SearchSiteVisitResponse> searchSiteVisit(
          @Valid SearchSiteVisitRequest request) {
    return ResponseEntity.ok(siteVisitService.searchSiteVisit(request));
  }

  @GetMapping
  @Operation(summary = "Projects list and search")
  public ResponseEntity<SearchProjectsResponse> searchProjects(
          @Valid SearchProjectsRequest searchProjectsRequest) {
    return ResponseEntity.ok(projectService.searchProjects(searchProjectsRequest));
  }

  @PostMapping
  @Operation(summary = "Create full information for new project ")
  public ResponseEntity<Project> createProject(@RequestBody @Valid ProjectRequest request) {
    ProjectResponse response = projectService.createProject(request);
    return new ResponseEntity<>(projectService.findById(response.getProjectId()), CREATED);
  }

  @PostMapping("/{projectId}/contacts")
  @Operation(summary = "Creates a Project Contact")
  public ResponseEntity<ClientContact> saveContact(
          @PathVariable UUID projectId,
          @RequestBody @Valid CreateClientContactRequest request) {
    ClientContact clientContact = clientService
            .createContact(fromString(request.getClientId()), request);
    projectContactService.saveContact(
            projectId,
            fromString(request.getClientId()),
            clientContact.getId());
    return ResponseEntity.ok(clientService.findClientContactById(clientContact.getId()));
  }

  @GetMapping("{projectId}/contacts")
  @Operation(summary = "Projects Contacts list and search")
  public ResponseEntity<PaginatedClientContactResponse> searchProjectsContacts(
          @PathVariable String projectId, @Valid SearchClientContactRequest request) {
    Project project = projectService.findById(fromString(projectId));
    request.setClientId(project.getClientId().toString());
    PaginatedClientContactResponse clientContactsPaginated =
            clientContactService.searchClientContacts(request);

    ProjectContactsResponse projectContacts = projectContactService
            .listProjectsContacts(fromString(projectId));

    ClientContactDto billingContact = ClientContactDto.build(project.getBillingContact());

    List<ClientContactDto> clientContactsFilteredByProject =
            projectContactService.filterProjectContactsFromClientContacts(
                    clientContactsPaginated, projectContacts, billingContact.getContactId()
            );

    clientContactsPaginated.setContent(clientContactsFilteredByProject);
    clientContactsPaginated.setTotalSize(clientContactsFilteredByProject.size());
    return ResponseEntity.ok(clientContactsPaginated);
  }

  @GetMapping("/{uuid}")
  @Operation(summary = "Retrieves Project details by guid")
  public ResponseEntity<ProjectDetails> getProjectDetails(@PathVariable UUID uuid) {
    ProjectDetails projectDetails = projectService.getProjectDetails(uuid);
    return ResponseEntity.ok(projectDetails);
  }

  @PostMapping("/{uuid}/obb")
  @Operation(summary = "Creates order based billing for the project")
  public ResponseEntity<ProjectOrderBasedBillingResponse> createProjectBasedBilling(
          @PathVariable UUID uuid,
          @RequestBody @Valid ProjectObbRequest request) {
    return new ResponseEntity<>(projectService
            .createProjectOrderBasedBilling(uuid, request), CREATED);
  }

  @PostMapping("/{projectId}/rates-wbb")
  @Operation(summary = "Create worker based billing")
  public ResponseEntity<ProjectWorkerBasedBilling> createWorkerBasedBilling(
          @PathVariable UUID projectId,
          @RequestBody @Valid WorkerBasedBillingRequest request) {
    ProjectWorkerBasedBillingResponse response =
            projectService.createWorkerBasedBilling(projectId, request);
    return new ResponseEntity<>(projectService.projectWbbFindById(response.getId()), CREATED);
  }

  @GetMapping("/{projectId}/rates-wbb")
  @Operation(summary = "Project WBB Rates list and search")
  public ResponseEntity<SearchProjectWBBRatesResponse> searchProjectWbbRates(
          @PathVariable UUID projectId,
          @Valid SearchProjectWBBRatesRequest request) {
    return ResponseEntity.ok(projectService.searchProjectWbbRates(projectId, request));
  }

  @GetMapping("/{projectId}/rates-obb")
  @Operation(summary = "Project OBB Rates list and search")
  public ResponseEntity<SearchProjectOBBRatesResponse> searchProjectWbbRates(
          @PathVariable UUID projectId,
          @Valid SearchProjectOBBRatesRequest request) {
    return ResponseEntity.ok(projectService.searchProjectObbRates(projectId, request));
  }

  @GetMapping("/{projectId}/agreements")
  @Operation(summary = "Agreements list and search")
  public ResponseEntity<SearchProjectsAgreementsResponse> searchAgreements(
          @PathVariable UUID projectId,
          @Valid SearchProjectsAgreementsRequest request) {
    return ResponseEntity.ok(projectService.searchProjectsAgreements(projectId, request));
  }

  /**
   * Upload Project Documents.
   *
   * @param projectId Uuid
   * @param request   String
   * @return File Name
   */
  @PostMapping(path = "/{projectId}/upload-document", consumes = {MULTIPART_FORM_DATA_VALUE})
  @Operation(summary = "Upload document")
  public ResponseEntity<String> uploadDocument(@PathVariable("projectId") UUID projectId,
                                               @ModelAttribute @Valid DocumentTypeRequest request) {
    URI uri = projectService.loadDocument(
            PROJECT_DOCUMENTS,
            request.getDocument().getName(),
            request.getDocument());
    return ResponseEntity.ok(projectService.saveDocument(
            uri,
            request,
            projectId));
  }

  /**
   * Upload Project Agreements.
   *
   * @param projectId Uuid
   * @param request   String
   * @return File Name
   */
  @PostMapping(path = "/{projectId}/agreements", consumes = {MULTIPART_FORM_DATA_VALUE})
  @Operation(summary = "Upload agreement")
  public ResponseEntity<String> uploadAgreement(
          @PathVariable("projectId") UUID projectId,
          @ModelAttribute @Valid ProjectSignedAgreementsRequest request) {
    URI uri = projectService.loadDocument(
            PROJECT_RATE_AGREEMENTS,
            request.getAgreement().getName(),
            request.getAgreement());
    return ResponseEntity.ok(projectService.saveAgreement(
            uri,
            request,
            projectId));
  }

  @PostMapping("/{projectId}/order")
  @Operation(summary = "Creates a Project Order and returns the updated project order info")
  public ResponseEntity<CreateProjectOrderResponse> createOrder(
          @PathVariable String projectId,
          @RequestBody @Valid CreateProjectOrderRequest request) {
    request.setOrderStatusType(OrderStatusType.ACTIVE);
    CreateProjectOrderResponse project = projectOrderService.createProjectOrder(projectId, request);
    return new ResponseEntity<>(project, CREATED);
  }

  @PostMapping("/{projectId}/client-order")
  @Operation(summary = "Client Requests a Project Order and returns the updated project order info")
  public ResponseEntity<CreateProjectOrderResponse> clientCreateOrder(
      @PathVariable String projectId,
      @RequestBody @Valid CreateProjectOrderRequest request) {
    request.setOrderStatusType(OrderStatusType.REQUESTED);
    CreateProjectOrderResponse project = projectOrderService.createProjectOrder(projectId, request);
    return new ResponseEntity<>(project, CREATED);
  }

  @PutMapping("/{projectId}/payroll-settings")
  @Operation(summary = "Updates a Certified payroll setting and returns the updated entity info")
  public ResponseEntity<ProjectCertifiedPayrollSettings> updateCertifiedPayroll(
          @PathVariable UUID projectId,
          @RequestBody @Valid ProjectCertifiedPayrollSettingsRequest request) {
    return ResponseEntity.ok(projectService.updateCertifiedPayrollSettings(projectId, request));
  }

  @PostMapping("/request-project")
  @Operation(summary = "Create basic information for new project ")
  public ResponseEntity<ProjectRequestBasicInfoResponse> createProjectBasicInfo(
          @RequestBody @Valid ProjectBasicInformationRequest request) {
    return new ResponseEntity<>(projectRequestService.createProjectBasicInfo(request), CREATED);
  }

  @GetMapping("/{projectId}/orders")
  @Operation(summary = "Search Project's Orders and returns list base on filters")
  public ResponseEntity<SearchProjectOrderResponse> searchOrders(
      @PathVariable UUID projectId,
      @Valid SearchProjectOrderRequest searchProjectOrderRequest) {
    return ResponseEntity.ok(projectOrderService.searchProjectOrders(projectId, searchProjectOrderRequest));
  }
}
