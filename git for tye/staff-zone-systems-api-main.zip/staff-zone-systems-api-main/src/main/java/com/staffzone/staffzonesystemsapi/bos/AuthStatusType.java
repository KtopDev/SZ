package com.staffzone.staffzonesystemsapi.bos;

/**
 * AuthStatusType: <br/>
 * {@link #GRANTED},<br/>
 * {@link #CODE},<br/>
 * {@link #DENIED},<br/>
 * {@link #MFA},<br/>
 * {@link #ERROR}.
 *
 */
public enum AuthStatusType {
  GRANTED, CODE, DENIED, MFA, ERROR;

  /**
   * Look up.
   *
   * @param str String
   * @return {@link AuthStatusType}
   */
  public static AuthStatusType of(String str) {
    for (AuthStatusType type : values()) {
      if (str.toUpperCase().equals(type.name())) {
        return type;
      }
    }
    return null;
  }
}
