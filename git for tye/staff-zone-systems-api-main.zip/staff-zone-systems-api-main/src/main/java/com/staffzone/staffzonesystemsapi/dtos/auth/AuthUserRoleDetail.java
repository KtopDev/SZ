package com.staffzone.staffzonesystemsapi.dtos.auth;

import com.fasterxml.jackson.annotation.JsonSetter;
import java.util.List;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * User Role detail Dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class AuthUserRoleDetail {
  private String firstName;
  private String lastName;
  private String status;
  private String email;
  private String phone;
  private UUID sessionId;
  private String sessionExpireTs;
  private String passwordExpireTs;
  private Integer daysSinceLastPasswordChange;
  private List<AuthRoleDetail> roles;
  //user fields
  private UUID appUserId;
  private String appUserCode;
  private String jobTitle;
  //client fields
  private UUID clientId;
  private UUID contactId;
  private Boolean isPrimary;
  private Boolean canRateWorkers;
  private Boolean canApproveHours;
  //worker fields
  private UUID workerId;
  private String workerCode;


  @JsonSetter("client_id")
  public void setClientId(UUID clientId) {
    this.clientId = clientId;
  }

  @JsonSetter("contact_id")
  public void setContactId(UUID contactId) {
    this.contactId = contactId;
  }

  @JsonSetter("is_primary")
  public void setPrimary(Boolean primary) {
    isPrimary = primary;
  }

  @JsonSetter("can_rate_workers")
  public void setCanRateWorkers(Boolean canRateWorkers) {
    this.canRateWorkers = canRateWorkers;
  }

  @JsonSetter("can_approve_hours")
  public void setCanApproveHours(Boolean canApproveHours) {
    this.canApproveHours = canApproveHours;
  }

  @JsonSetter("worker_id")
  public void setWorkerId(UUID workerId) {
    this.workerId = workerId;
  }

  @JsonSetter("worker_code")
  public void setWorkerCode(String workerCode) {
    this.workerCode = workerCode;
  }

  @JsonSetter("session_expire_ts")
  public void setSessionExpireTs(String sessionExpireTs) {
    this.sessionExpireTs = sessionExpireTs;
  }

  @JsonSetter("password_expire_ts")
  public void setPasswordExpireTs(String passwordExpireTs) {
    this.passwordExpireTs = passwordExpireTs;
  }

  @JsonSetter("days_since_last_password_change")
  public void setDaysSinceLastPasswordChange(Integer daysSinceLastPasswordChange) {
    this.daysSinceLastPasswordChange = daysSinceLastPasswordChange;
  }

  @JsonSetter("session_id")
  public void setSessionId(UUID sessionId) {
    this.sessionId = sessionId;
  }

  @JsonSetter("job_title")
  public void setJobTitle(String jobTitle) {
    this.jobTitle = jobTitle;
  }

  @JsonSetter("first_name")
  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  @JsonSetter("last_name")
  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  @JsonSetter("app_user_id")
  public void setAppUserId(UUID appUserId) {
    this.appUserId = appUserId;
  }

  @JsonSetter("app_user_code")
  public void setAppUserCode(String appUserCode) {
    this.appUserCode = appUserCode;
  }

}
