package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonSetter;
import jakarta.validation.constraints.NotBlank;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PpeRequest {
  @NotBlank(message = "PPE Name cannot be blank")
  private String ppeName;
  @NotBlank(message = "PPE Abbreviation cannot be blank")
  private String ppeAbbreviation;
  @NotBlank(message = "PPE Description cannot be blank")
  private String ppeDescription;
  private UUID branchId;

  @JsonGetter("ppe_abreviation")
  public String getPpeAbbreviation() {
    return ppeAbbreviation;
  }

  @JsonSetter("ppeAbbreviation")
  public void setPpeAbbreviation(String ppeAbbreviation) {
    this.ppeAbbreviation = ppeAbbreviation;
  }
}
