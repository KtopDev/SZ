package com.staffzone.staffzonesystemsapi.dtos.requests;

import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDate;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class SearchClientNotesRequest extends SearchAbstractRequest {
  private UUID clientId;
  private String title;
  private String noteType;
  private LocalDate startDate;
  private LocalDate endDate;
}
