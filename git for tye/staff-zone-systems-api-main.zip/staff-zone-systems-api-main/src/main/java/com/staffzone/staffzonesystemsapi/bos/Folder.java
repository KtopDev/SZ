package com.staffzone.staffzonesystemsapi.bos;

import com.staffzone.staffzonesystemsapi.exceptions.BusinessException;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * SMSSourceApplication: <br/>
 * {@link #PROJECT_DOCUMENTS},<br/>
 * {@link #PROJECT_RATE_AGREEMENTS},<br/>
 * {@link #TERMS_AND_CONDITIONS},<br/>
 * {@link #WORKER_DOCUMENTS},<br/>
 * {@link #TAX_FORMS}.
 */
@Getter
@AllArgsConstructor
public enum Folder {
  PROJECT_DOCUMENTS("project-documents"),
  PROJECT_RATE_AGREEMENTS("project-rate-agreements"),
  TERMS_AND_CONDITIONS("terms-and-conditions"),
  WORKER_DOCUMENTS("worker-documents"),
  TAX_FORMS("tax-forms"),;

  private final String value;

  /**
   * Get Enum.
   *
   * @param str String
   * @return {@link Folder}
   */
  public static Folder of(String str) {
    for (Folder type : values()) {
      if (str.equalsIgnoreCase(type.value)) {
        return type;
      }
    }
    throw new BusinessException("folder", "Available are: " + getAvailableNames());
  }

  private static String getAvailableNames() {
    StringBuilder names = new StringBuilder();
    for (Folder type : values()) {
      names.append(type.name()).append(", ");
    }
    names.setLength(names.length() - 2);
    return names.toString();
  }
}
