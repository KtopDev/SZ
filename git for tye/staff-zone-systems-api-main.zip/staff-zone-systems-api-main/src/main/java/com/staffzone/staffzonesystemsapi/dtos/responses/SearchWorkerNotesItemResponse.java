package com.staffzone.staffzonesystemsapi.dtos.responses;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Worker Notes Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchWorkerNotesItemResponse {
  private String totalRows;
  private String note;
  private String noteType;
  private String createdAt;
  private String noteTitle;
  private String workerNoteId;
}
