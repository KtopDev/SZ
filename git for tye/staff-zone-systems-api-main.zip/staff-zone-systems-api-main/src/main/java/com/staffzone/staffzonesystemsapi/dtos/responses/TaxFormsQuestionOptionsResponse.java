package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * TaxFormsQuestions Response from create and edit tax forms stored procedure.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TaxFormsQuestionOptionsResponse {
  @JsonSetter(value = "option_id")
  private String optionId;
  @JsonSetter(value = "option_text")
  private String optionText;
}
