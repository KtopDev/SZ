package com.staffzone.staffzonesystemsapi.controllers;

import static org.springframework.http.HttpStatus.CREATED;

import com.staffzone.staffzonesystemsapi.dtos.requests.BranchRouteRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.UpdateBranchRouteRequest;
import com.staffzone.staffzonesystemsapi.entities.BranchRoute;
import com.staffzone.staffzonesystemsapi.services.BranchRouteService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller for BranchRoute Endpoints.
 */
@RequestMapping("/api/v1/routes")
@CrossOrigin("*")
@RestController
@AllArgsConstructor
@Validated
public class BranchRouteController {
    public BranchRouteService branchRouteService;

    @PostMapping
    @Operation(summary = "Creates a Route and returns newly created route guid")
    public ResponseEntity<BranchRoute> createRoute(
            @RequestBody @Valid BranchRouteRequest request) {
        BranchRoute route = branchRouteService.createBranchRoute(request);
        return new ResponseEntity<>(route, CREATED);
    }

    @PutMapping("/{routeId}")
    @Operation(summary = "Updates a Route and returns the updated route")
    public ResponseEntity<BranchRoute> updateRoute(@PathVariable String routeId,
                                                   @RequestBody @Valid UpdateBranchRouteRequest request) {
        BranchRoute route = branchRouteService.updateBranchRoute(routeId, request);
        return new ResponseEntity<>(route, HttpStatus.OK);
    }

    @DeleteMapping("/{routeId}")
    @Operation(summary = "Delete a Route")
    public ResponseEntity<String> delete(@PathVariable String routeId) {
        return ResponseEntity.ok(branchRouteService.deleteBranchRoute(routeId));
    }
}
