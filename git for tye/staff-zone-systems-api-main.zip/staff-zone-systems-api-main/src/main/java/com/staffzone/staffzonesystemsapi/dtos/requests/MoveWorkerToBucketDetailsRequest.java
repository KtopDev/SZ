package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.staffzone.staffzonesystemsapi.validators.Uuid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Move Worker to Bucket Details Request DTO.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MoveWorkerToBucketDetailsRequest {
  @Uuid(message = "Bucket Details Id cannot be null")
  private String targetBucketDetailId;
  private Integer slotIndex;
}
