package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.staffzone.staffzonesystemsapi.validators.Uuid;
import jakarta.validation.constraints.NotEmpty;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Selected Client Notes Request DTO.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class SelectedClientNotesRequest {
  @NotEmpty(message = "notesIds cannot be empty")
  private List<@Uuid String> notesIds;

  /**
   * Custom getter.
   *
   * @return List UUID
   */
  public List<UUID> getNotesIds() {
    return notesIds.stream()
            .map(UUID::fromString)
            .collect(Collectors.toList());
  }
}
