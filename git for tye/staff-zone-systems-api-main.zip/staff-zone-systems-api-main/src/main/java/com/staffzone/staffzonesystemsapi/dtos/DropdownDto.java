package com.staffzone.staffzonesystemsapi.dtos;

import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

/**
 * Dropdown Dto. <br/>See: {@link DropdownItemDto}
 */
@Getter
@Builder
@AllArgsConstructor
public class DropdownDto {
  private Set<DropdownItemDto> dropdown;
}
