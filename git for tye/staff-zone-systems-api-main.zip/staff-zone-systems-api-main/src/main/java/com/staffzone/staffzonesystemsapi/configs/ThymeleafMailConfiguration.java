package com.staffzone.staffzonesystemsapi.configs;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Description;
import org.springframework.context.support.ResourceBundleMessageSource;

/**
 * Thymeleaf Mail Configuration.
 */
@Configuration
public class ThymeleafMailConfiguration {

  /**
   * Spring Message Resolver.
   *
   * @return ResourceBundleMessageSource
   */
  @Bean
  @Description("Spring Message Resolver")
  public ResourceBundleMessageSource emailMessageSource() {
    final ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
    messageSource.setBasenames(
            "html",
            "images",
            "css");
    return messageSource;
  }
}
