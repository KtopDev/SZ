package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.staffzone.staffzonesystemsapi.validators.Uuid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

/**
 * Worker Request DTO.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class WorkerEditInternalRequest {

  @NotBlank(message = "First name cannot be blank")
  private String firstName;

  @NotBlank(message = "Last name cannot be blank")
  private String lastName;

  @Size(max = 5, message = "Middle Initial cannot exceed 5 chars")
  private String middleInitial;

  @Size(max = 100, message = "Other Names cannot exceed 100 chars")
  private String otherNames;

  @NotBlank(message = "Ssn Number cannot be blank")
  @Pattern(regexp = "^\\d{9}", message = "Ssn Number must have 9 digits")
  private String ssnNumber;

  @NotNull(message = "Date Of Birth cannot be blank")
  private String dateOfBirth;

  @NotBlank(message = "Phone cannot be blank")
  @Pattern(regexp = "^\\d{10}", message = "Phone must have 10 digits")
  private String phone;

  @NotBlank(message = "Email cannot be blank")
  @Email
  private String email;

  @NotBlank(message = "Address cannot be blank")
  private String address;

  private String addressLine2;

  @NotBlank(message = "City cannot be blank")
  private String city;

  @NotBlank(message = "State cannot be blank")
  private String state;

  @NotBlank(message = "Postal Code cannot be blank")
  @Pattern(regexp = "^\\d{5}", message = "Postal Code must have 5 digits")
  private String postalCode;

  private List<@Uuid String> skills;

  private List<@Uuid String> certifications;

  private List<@Uuid String> clientRestrictions;

  @JsonGetter("address_line_2")
  public String getAddressLine2() {
    return addressLine2;
  }

  @JsonSetter("addressLine2")
  public String setAddressLine2(String addressLine2) {
    return this.addressLine2 = addressLine2;
  }
}
