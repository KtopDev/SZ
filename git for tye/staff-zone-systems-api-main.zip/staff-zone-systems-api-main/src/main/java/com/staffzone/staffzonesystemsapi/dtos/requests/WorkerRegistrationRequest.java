package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.staffzone.staffzonesystemsapi.validators.Uuid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import net.minidev.json.annotate.JsonIgnore;

/**
 * Worker Request DTO.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class WorkerRegistrationRequest {
  @NotBlank(message = "First name cannot be blank")
  private String firstName;

  @NotBlank(message = "Last name cannot be blank")
  private String lastName;

  @Size(max = 5, message = "Middle Initial cannot exceed 5 chars")
  private String middleInitial;

  @Size(max = 100, message = "Other Names cannot exceed 100 chars")
  private String otherNames;

  @NotBlank(message = "Ssn Number cannot be blank")
  @Pattern(regexp = "^\\d{9}", message = "Ssn Number must have 9 digits")
  private String ssnNumber;

  @NotNull(message = "Date Of Birth cannot be blank")
  private LocalDate dateOfBirth;

  @NotBlank(message = "Phone cannot be blank")
  @Pattern(regexp = "^\\d{10}", message = "Phone must have 10 digits")
  private String phone;

  @NotBlank(message = "Email cannot be blank")
  @Email
  private String email;

  @NotBlank(message = "Password cannot be blank")
  private String password;

  @NotNull(message = "Branch Id cannot be blank")
  @Uuid
  private String branchId;

  @JsonIgnore
  public UUID getBranchUuid() {
    return UUID.fromString(this.branchId);
  }
}
