package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.util.List;

@Data
@NoArgsConstructor
@SuperBuilder
public class UpdateClientRequest {
    @NotBlank(message = "Client name cannot be blank")
    private String clientName;

    @NotNull(message = "Credit limit cannot be blank")
    @PositiveOrZero
    @Digits(fraction = 4, integer = 10, message = "Credit limit can't be bigger than 999999999.9999")
    private BigDecimal creditLimit;

    @NotBlank(message = "Client terms cannot be blank")
    private String clientTerms;

    @NotEmpty(message = "Branch cannot be blank")
    private List<String> branches;

    @NotBlank(message = "invoice Method cannot be blank")
    private String invoiceMethod;

    @NotBlank(message = "invoice Format cannot be blank")
    private String invoiceFormat;

    @NotBlank(message = "Street Address Line 1 cannot be blank")
    private String streetAddressLine1;

    private String streetAddressLine2;

    @NotBlank(message = "City cannot be blank")
    private String city;

    @NotBlank(message = "State cannot be blank")
    private String state;

    @NotNull(message = "Postal code cannot be null")
    @Pattern(regexp = "^\\d{5}", message = "Postal code must have 5 characters")
    private String zipCode;

    @NotNull(message = "Main phone cannot be null")
    @Digits(fraction = 0, integer = 10, message = "Main phone must have 10 characters")
    private Long mainPhone;

    @NotNull(message = "Fax cannot be null")
    @Digits(fraction = 0, integer = 10, message = "Fax must have 10 characters")
    private Long faxLine;

    @NotBlank(message = "Client comp code cannot be blank")
    private String clientCompCodeId;

    @Pattern(regexp = "SMS|EMAIL|NONE", message = "MultiFactor must be either SMS, EMAIL or NONE")
    private String preferredMultiFactor;

    @NotNull(message = "MultiFactor Authentication cannot be null")
    @PositiveOrZero(message = "MultiFactor Authentication Days must be positive or zero")
    private Integer multiFactorAuthenticationTtlDays;
}
