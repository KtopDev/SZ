package com.staffzone.staffzonesystemsapi.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinColumns;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.ColumnDefault;

/**
 * Entity mapped against "<strong>client_term_acceptance</strong>" Table.
 */
@Getter
@Setter
@Entity
@Table(name = "client_term_acceptance")
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@FieldNameConstants
@EqualsAndHashCode(callSuper = true)
public class ClientTermAcceptance extends Audit {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @ColumnDefault("nextval('client_term_acceptance_client_terms_acceptance_id_seq'")
  @Column(name = "client_terms_acceptance_id", nullable = false)
  private Integer id;

  @Builder.Default
  @NotNull
  @ColumnDefault("true")
  @Column(name = "is_row_active", nullable = false)
  private Boolean isRowActive = false;

  @NotNull
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumns({
          @JoinColumn(name = "client_id", referencedColumnName = "client_id", nullable = false),
          @JoinColumn(name = "contact_id", referencedColumnName = "contact_id", nullable = false)
  })
  private ClientContact clientContacts;

  @NotNull
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "client_app_term_id", nullable = false)
  private ClientAppTerms clientAppTerm;

  @NotNull
  @Column(name = "accepted_at", nullable = false)
  private LocalDateTime acceptedAt;
}