package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;
import org.springframework.web.multipart.MultipartFile;

/**
 * App Terms Request Dto.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@FieldNameConstants
public class AppTermsRequest {
  @NotNull(message = "File name cannot be null.")
  private String fileName;
  @NotNull(message = "File cannot be null.")
  MultipartFile document;
}
