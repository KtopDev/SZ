package com.staffzone.staffzonesystemsapi.bos;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * UserType: <br/>
 * {@link #WISCONSIN},<br/>
 * {@link #UTAH},<br/>
 * {@link #MASSACHUSETTS},<br/>
 * {@link #MISSOURI},<br/>
 * {@link #MINNESOTA},<br/>
 * {@link #OKLAHOMA},<br/>
 * {@link #FLORIDA},<br/>
 * {@link #ALABAMA}.
 */
@Getter
@AllArgsConstructor
public enum Branch {
  WISCONSIN("66"),
  UTAH("85"),
  MASSACHUSETTS("32"),
  MISSOURI("58"),
  MINNESOTA("23"),
  OKLAHOMA("11"),
  FLORIDA("6"),
  ALABAMA("35");

  private final String value;

  /**
   * Look up. Is case-sensitive
   */
  public static Branch of(String str) {
    for (Branch branch : values()) {
      if (str.toUpperCase().equals(branch.name())) {
        return branch;
      }
    }

    return null;
  }

}