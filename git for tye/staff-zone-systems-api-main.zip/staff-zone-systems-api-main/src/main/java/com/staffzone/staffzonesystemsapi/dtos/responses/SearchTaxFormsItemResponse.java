package com.staffzone.staffzonesystemsapi.dtos.responses;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Tax forms Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchTaxFormsItemResponse {
  private String formId;
  private String formName;
  private String totalRows;
  private String effectiveFrom;
  private String expiresAfter;
  private String modifiedAt;
  private String taxJurisdictionId;
  private String taxJurisdictionName;
}
