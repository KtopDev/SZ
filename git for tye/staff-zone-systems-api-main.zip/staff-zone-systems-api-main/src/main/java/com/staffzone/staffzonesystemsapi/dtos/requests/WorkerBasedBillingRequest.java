package com.staffzone.staffzonesystemsapi.dtos.requests;

import static java.util.UUID.fromString;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.staffzone.staffzonesystemsapi.validators.Uuid;
import jakarta.annotation.Nullable;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.PositiveOrZero;
import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;
import lombok.experimental.SuperBuilder;

/**
 * Worker Based Billing Request Dto.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class WorkerBasedBillingRequest {
  @NotBlank(message = "skillTier is invalid or unavailable")
  private String skillTier;
  @NotBlank(message = "description cannot be blank")
  private String description;
  @Uuid
  private String compCodeId;
  @NotNull(message = "payRate cannot be null and")
  @PositiveOrZero
  private BigDecimal payRate;
  @Nullable
  @PositiveOrZero
  private BigDecimal billRate;
  @PositiveOrZero
  @Nullable
  private BigDecimal overtimeBillRate;
  @PositiveOrZero
  private BigDecimal markupPercentage;
  @Uuid(enableNullValues = true)
  private String workerId;
  @NotNull(message = "skills cannot be blank")
  private List<@Uuid String> skills;
  @NotNull(message = "certifications cannot be blank")
  private List<@Uuid String> certifications;
  @Nullable
  private String cpJobDescription;
  @Nullable
  @PositiveOrZero
  private BigDecimal cpWagesInLieu;

  private ArrayNode convertUuidsToArrayNode(List<String> uuids, ObjectMapper mapper) {
    ArrayNode arrayNode = mapper.createArrayNode();
    for (String uuid : uuids) {
      arrayNode.add(uuid);

    }
    return arrayNode;
  }

  public UUID getWorkerId() {
    return workerId == null ? null : fromString(workerId);
  }

  @SneakyThrows
  @JsonIgnore
  public String asJson() {
    ObjectMapper mapper = new ObjectMapper();
    ObjectNode jsonObject = mapper.createObjectNode();
    jsonObject.put("skill_tier", skillTier);
    jsonObject.put("description", description);
    jsonObject.put("comp_code_id", compCodeId);
    jsonObject.put("pay_rate", payRate);
    jsonObject.put("bill_rate", billRate);
    jsonObject.put("overtime_bill_rate", overtimeBillRate);
    jsonObject.put("markup_percentage", markupPercentage);
    jsonObject.put("worker_id", workerId);
    jsonObject.set("skills", convertUuidsToArrayNode(skills, mapper));
    jsonObject.set("certifications", convertUuidsToArrayNode(certifications, mapper));
    jsonObject.put("cp_job_description", cpJobDescription);
    jsonObject.put("cp_wages_in_lieu", cpWagesInLieu);
    return mapper.writeValueAsString(jsonObject);
  }

}