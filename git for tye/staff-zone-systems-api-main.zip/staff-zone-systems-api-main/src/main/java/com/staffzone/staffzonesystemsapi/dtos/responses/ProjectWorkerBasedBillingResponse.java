package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;
import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Create ProjectWorkerBasedBilling Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProjectWorkerBasedBillingResponse {
  @JsonSetter("skills")
  private List<Skill> skills;
  @JsonSetter("pay_rate")
  private BigDecimal payRate;
  @JsonSetter("bill_rate")
  private BigDecimal billRate;
  @JsonSetter("comp_code")
  private String compCode;
  @JsonSetter("project_id")
  private String projectId;
  @JsonSetter("skill_tier")
  private String skillTier;
  @JsonSetter("comp_code_id")
  private String compCodeId;
  @JsonSetter("certifications")
  private List<Certification> certifications;
  @JsonSetter("cp_wages_in_lieu")
  private BigDecimal cpWagesInLieu;
  @JsonSetter("markup_percentage")
  private BigDecimal markupPercentage;
  @JsonSetter("cp_job_description")
  private String cpJobDescription;
  @JsonSetter("overtime_bill_rate")
  private BigDecimal overtimeBillRate;
  @JsonSetter("project_worker_based_billing_id")
  private UUID id;

  public static class Skill {
    @JsonProperty("skill_id")
    private String skillId;
    @JsonProperty("skill_name")
    private String skillName;
  }

  public static class Certification {
    @JsonProperty("certification_id")
    private String certificationId;
    @JsonProperty("certification_name")
    private String certificationName;
  }
}
