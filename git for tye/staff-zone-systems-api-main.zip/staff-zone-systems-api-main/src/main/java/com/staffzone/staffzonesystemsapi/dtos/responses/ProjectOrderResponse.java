package com.staffzone.staffzonesystemsapi.dtos.responses;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;
import java.util.UUID;

/**
 * Project Order Response DTO.
 */
@Getter
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class ProjectOrderResponse {
  private UUID orderId;
  private Boolean isRowActive = true;
  private UUID projectId;
  private String orderNumber;
  private String status;
  private String orderStartTs;
  private String statusTs;
  private List<ProjectOrderDetailsResponse> projectOrderDetails;
}
