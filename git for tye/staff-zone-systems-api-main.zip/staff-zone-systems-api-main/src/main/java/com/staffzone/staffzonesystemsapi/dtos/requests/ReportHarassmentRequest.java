package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.annotation.Nullable;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

/**
 * Report Harassment Request Dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReportHarassmentRequest {
  @NotBlank(message = "User cannot bee blank")
  @Length(min = 3, message = "Minimum 3 characters")
  private String user;
  @NotBlank(message = "Email cannot bee blank")
  @Email(regexp = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$", message = "Text entered is not an email")
  private String email;
  @NotNull(message = "Please indicate when the events occurred")
  private LocalDate date;
  @NotBlank(message = "LocationOfEvent cannot be blank")
  @Length(min = 3,message = "Minimum 3 characters")
  private String locationOfEvent;
  @Valid
  @NotEmpty(message ="You need to indicate who committed the harassment.")
  private List<SubjectInvolved> subject;
  @NotBlank(message = "Explain the details of the event that occurred," +
          "Please as specific as possible. ")
  @Length(min = 3, max = 500, message = "Minimum 3 Maximum 500 characters")
  private String details;
  @Valid
  @Nullable
  private List<SubjectInvolved> witness;
  @NotBlank(message = "What do you believe that this harassment.")
  @Length(min = 3, max = 500, message = "Minimum 3 Maximum 500 characters")
  private String details2;
}
