package com.staffzone.staffzonesystemsapi.bos;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum WorkerWithHoldingStatusType {
  ACTIVE,
  ARCHIVED;
}