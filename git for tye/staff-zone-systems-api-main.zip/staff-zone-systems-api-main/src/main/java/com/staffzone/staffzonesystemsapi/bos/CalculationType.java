package com.staffzone.staffzonesystemsapi.bos;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * StatusType: <br/>
 * {@link #FLAT},<br/>
 * {@link #BASE_PLUS_RATE},<br/>
 * {@link #CAPPED}.
 */
@Getter
@AllArgsConstructor
public enum CalculationType {
  FLAT,
  BASE_PLUS_RATE,
  CAPPED;
}
