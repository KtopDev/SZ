package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonAlias;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Worker Details Dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class WorkerDetailsResponse {
  private String city;
  private String email;
  private String phone;
  private String state;
  private List<WorkerSkillsResponse> skills;
  private String status;
  private String address;
  private String warnings;
  @JsonAlias("branch_id")
  private String branchId;
  @JsonAlias("i9_status")
  private String i9Status;
  @JsonAlias("last_name")
  private String lastName;
  @JsonAlias("status_ts")
  private String statusTs;
  @JsonAlias("worker_id")
  private String workerId;
  @JsonAlias("first_name")
  private String firstName;
  @JsonAlias("ssn_number")
  private String ssnNumber;
  @JsonAlias("branch_name")
  private String branchName;
  @JsonAlias("card_number")
  private String cardNumber;
  @JsonAlias("i_94_number")
  private String i94Number;
  @JsonAlias("other_names")
  private String otherNames;
  @JsonAlias("pay_card_id")
  private String payCardId;
  @JsonAlias("postal_code")
  private String postalCode;
  @JsonAlias("worker_code")
  private String workerCode;
  @JsonAlias("legal_status")
  private String legalStatus;
  @JsonAlias("signature_ts")
  private String signatureTs;
  @JsonAlias("date_of_birth")
  private String dateOfBirth;
  @JsonAlias("password_hash")
  private String passwordHash;
  @JsonAlias("pay_frequency")
  private String payFrequency;
  @JsonAlias("profile_image")
  private String profileImage;
  @JsonAlias("account_number")
  private String accountNumber;
  @JsonAlias("address_line_2")
  private String addressLine2;
  private List<WorkerCertificationResponse> certifications;
  @JsonAlias("last_active_ts")
  private String lastActiveTs;
  @JsonAlias("last_branch_id")
  private String lastBranchId;
  @JsonAlias("middle_initial")
  private String middleInitial;
  @JsonAlias("signature_path")
  private String signaturePath;
  @JsonAlias("passport_number")
  private String passportNumber;
  @JsonAlias("card_holder_name")
  private String cardHolderName;
  @JsonAlias("last_branch_name")
  private String lastBranchName;
  @JsonAlias("emergency_contacts")
  private List<EmergencyContactResponse> emergencyContacts;
  @JsonAlias("password_expire_ts")
  private String passwordExpireTs;
  @JsonAlias("cc_masked_ssn_number")
  private String ccMaskedSsnNumber;
  @JsonAlias("passport_country_code")
  private String passportCountryCode;
  @JsonAlias("phone_verification_ts")
  private String phoneVerificationTs;
  @JsonAlias("default_payment_method")
  private String defaultPaymentMethod;
  @JsonAlias("direct_deposit_account")
  private String directDepositAccount;
  @JsonAlias("direct_deposit_routing")
  private String directDepositRouting;
  @JsonAlias("alien_registration_number")
  private String alienRegistrationNumber;
  @JsonAlias("is_withholding_irs_locked")
  private String isWithholdingIrsLocked;
  @JsonAlias("last_withholding_review_ts")
  private String lastWithholdingReviewTs;
  @JsonAlias("last_withholding_request_ts")
  private String lastWithholdingRequestTs;
  @JsonAlias("worker_client_restrictions")
  private List<String> workerEmployers;
}