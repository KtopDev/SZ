package com.staffzone.staffzonesystemsapi.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;

/**
 * Entity mapped against "<strong>comp_codes</strong>" Table.
 */
@Entity
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "comp_codes")
public class CompCodes {
  @Id
  @Column(nullable = false)
  private UUID compCodeId;
  @Column(name = "comp_code", length = 4)
  private String compCode;
  @Column(name = "comp_code_description", length = 100)
  private String compCodeDescription;
  @Column(name = "comp_code_billing_description", length = 100)
  private String compCodeBillingDescription;
  @ManyToOne
  @JoinColumn(name = "state")
  private LkStates lkState;
  @Column(name = "burden_per_hour", precision = 14, scale = 4)
  private BigDecimal burdenPerHour;
  @Column(name = "cost_per_hundred", precision = 14, scale = 4)
  private BigDecimal costPerHundred;
  @Column(name = "bill_rate_per_hundred", precision = 14, scale = 4)
  private BigDecimal billRatePreHundred;
  @Column(name = "efective_date")
  private LocalDate date;
  @Column(name = "is_row_active")
  private Boolean isRowActive;
  @Column(name = "status")
  private String status;
  @Column(name = "status_ts")
  private LocalDateTime statusTs;

  public CompCodes(String uuid) {
    this.compCodeId = UUID.fromString(uuid);
  }
}
