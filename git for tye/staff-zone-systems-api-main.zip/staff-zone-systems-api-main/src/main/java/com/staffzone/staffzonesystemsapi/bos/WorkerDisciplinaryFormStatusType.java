package com.staffzone.staffzonesystemsapi.bos;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * WorkerDisciplinaryFormStatusType: <br/>
 * {@link #PENDING},<br/>
 * {@link #SIGNED}.
 */
@Getter
@AllArgsConstructor
public enum WorkerDisciplinaryFormStatusType {
  PENDING,
  SIGNED
}
