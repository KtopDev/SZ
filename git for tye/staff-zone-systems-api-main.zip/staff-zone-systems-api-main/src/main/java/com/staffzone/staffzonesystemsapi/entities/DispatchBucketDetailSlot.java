package com.staffzone.staffzonesystemsapi.entities;

import com.staffzone.staffzonesystemsapi.entities.ids.DispatchBucketDetailSlotId;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;

@Getter
@Setter
@Entity
@Table(name = "dispatch_bucket_detail_slots")
public class DispatchBucketDetailSlot extends Audit {
  @EmbeddedId
  private DispatchBucketDetailSlotId id;

  @MapsId("dispatchBucketDetailId")
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "dispatch_bucket_detail_id", nullable = false)
  private DispatchBucketDetails dispatchBucketDetail;

  @MapsId("workerId")
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "worker_id", nullable = false)
  private Worker worker;

  @NotNull
  @ColumnDefault("true")
  @Column(name = "is_row_active", nullable = false)
  private Boolean isRowActive = false;

  @Column(name = "slot_index")
  private Integer slotIndex;

}