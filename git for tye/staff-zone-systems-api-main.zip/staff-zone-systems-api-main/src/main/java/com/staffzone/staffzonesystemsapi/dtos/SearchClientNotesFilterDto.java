package com.staffzone.staffzonesystemsapi.dtos;

import java.time.LocalDate;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class SearchClientNotesFilterDto {
  private UUID clientId;
  private String clientName;
  private String title;
  private String noteType;
  private LocalDate startDate;
  private LocalDate endDate;
}
