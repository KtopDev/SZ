package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Worker Skills response Dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class WorkerSkillsResponse {
  @JsonAlias("skill_id")
  private String skillId;
  @JsonAlias("skill_name")
  private String skillName;
  @JsonAlias("skill_description")
  private String skillDescription;
  @JsonAlias("support_document_file")
  private String supportDocumentFile;

}
