package com.staffzone.staffzonesystemsapi.bos;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * AuthStatusType: <br/>
 * {@link #ANYTIME},<br/>
 * {@link #LAST_WEEK},<br/>
 * {@link #LAST_TWO_WEEKS},<br/>
 * {@link #LAST_MONTH},<br/>
 * {@link #NEVER}.
 *
 */
@Getter
@AllArgsConstructor
public enum LastPayType {
  ANYTIME,
  LAST_WEEK,
  LAST_TWO_WEEKS,
  NEVER,
  LAST_MONTH;
}
