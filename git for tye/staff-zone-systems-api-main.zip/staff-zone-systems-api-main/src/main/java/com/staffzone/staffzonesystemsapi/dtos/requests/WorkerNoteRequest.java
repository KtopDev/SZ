package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

/**
 * Worker Note Request.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WorkerNoteRequest {
  @Length(max = 255)
  @NotBlank(message = "Worker Note Title cannot be blank")
  private String title;
  @Length(max = 50)
  @NotBlank(message = "Worker Note Type cannot be blank")
  @Pattern(regexp = "^$|GENERAL|COMMENT|COMPLAINT|WARNING",
          message = "Type must be either 'GENERAL','COMMENT','COMPLAINT' or 'WARNING'")
  private String type;
  @NotBlank(message = "Worker Note Content cannot be blank")
  private String note;

}
