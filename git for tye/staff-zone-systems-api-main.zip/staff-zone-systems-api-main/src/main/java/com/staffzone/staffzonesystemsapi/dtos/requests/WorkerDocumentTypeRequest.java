package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.staffzone.staffzonesystemsapi.validators.DocumentType;
import jakarta.annotation.Nullable;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;
import org.springframework.web.multipart.MultipartFile;

/**
 * Document Type Request Dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@FieldNameConstants
public class WorkerDocumentTypeRequest {
  @DocumentType(sizeMB = 10)
  private MultipartFile document;
  @NotBlank(message = "documentType cannot be blank")
  private String documentType;
  @NotBlank(message = "country cannot be blank")
  private String issuedBy;
  @Nullable
  @Pattern(regexp = "^[0-9]+$")
  private String documentNumber;
  private LocalDate date;
  @NotNull(message = "isGeneral cannot be null")
  private Boolean isGeneral;

  public String getIssuedBy() {
    if (issuedBy == null) {
      return null;
    }
    return issuedBy.toUpperCase();
  }

}
