package com.staffzone.staffzonesystemsapi.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;

/**
 * Entity mapped against "<strong>branches</strong>" Table.
 */
@Entity
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "branches")
public class Branch {
  @Id
  @Column(nullable = false)
  private UUID branchId;
  @Column
  private String branchName;
  @Column(length = 3, nullable = false, unique = true)
  private String branchCode;
  @Column(length = 20, nullable = false)
  private String status;
  @Column
  private LocalDateTime statusTs;
  @Column(length = 10)
  private String phone;
  @Column(length = 10)
  private String fax;
  @Column
  private String address;
  @Column(name = "address_line_2")
  private String addressLine2;
  @ManyToOne
  @JoinColumn(name = "state")
  @ToString.Exclude
  private LkStates state;
  @Column(length = 50)
  private String city;
  @Column(length = 10)
  private String postalCode;
  @Column(length = 50)
  private String geoLocation;
  @Column(precision = 14, scale = 4)
  private BigDecimal payLimitDaily;
  @Column(precision = 14, scale = 4)
  private BigDecimal payLimitWeekly;
  @ManyToOne
  @JoinColumn(name = "pay_cycle_id")
  @ToString.Exclude
  private PayCycles payCycle;
  @Column
  private Boolean isVoluntaryDeductionApproveRequired;
  @Column(length = 15)
  private String scannerIp;
  @Column(length = 15)
  private String checkPrinterIp;
  @Column(length = 15)
  private String reportPrinterIp;
  @ManyToOne
  @JoinColumn(name = "default_check_printing_format_id")
  @ToString.Exclude
  private PrintingFormats defaultCheckPrintingFormat;
  @ManyToOne
  @JoinColumn(name = "sick_check_printing_format_id")
  @ToString.Exclude
  private PrintingFormats sickCheckPrintingFormat;
  @ManyToOne
  @JoinColumn(name = "deposit_printing_format_id")
  @ToString.Exclude
  private PrintingFormats depositPrintingFormat;
  @ManyToOne
  @JoinColumn(name = "comp_code_id")
  @ToString.Exclude
  private CompCodes compCode;
  @ManyToMany
  @JoinTable(
          name = "branch_tax_jurisdictions",
          joinColumns = @JoinColumn(name = "branch_id"),
          inverseJoinColumns = @JoinColumn(name = "tax_jurisdiction_id"))
  @ToString.Exclude
  private Set<TaxJurisdictions> taxJurisdictions;
  @ManyToMany
  @JoinTable(
          name = "branch_unemployment_jurisdictions",
          joinColumns = @JoinColumn(name = "branch_id"),
          inverseJoinColumns = @JoinColumn(name = "unemployment_jurisdiction_id"))
  @ToString.Exclude
  private Set<UnemploymentJurisdictions> unemploymentJurisdictions;
  @ManyToMany
  @JoinTable(
          name = "branch_sick_pay_jurisdictions",
          joinColumns = @JoinColumn(name = "branch_id"),
          inverseJoinColumns = @JoinColumn(name = "sick_pay_jurisdiction_id"))
  @ToString.Exclude
  private Set<SickPayJurisdictions> sickPayJurisdictions;
  @Column(name = "is_row_active", updatable = false, insertable = false)
  private Boolean rowActive;
  @OneToMany(mappedBy = "branch", fetch = FetchType.LAZY)
  @JsonBackReference
  private Set<BranchClientAppTerm> clientTerms;
  @OneToMany(mappedBy = "branch", fetch = FetchType.LAZY)
  @JsonBackReference
  private Set<BranchWorkerAppTerm> workerTerms;

  @Column(name = "minimum_wage_amount", precision = 10, scale = 2)
  private BigDecimal minimumWageAmount;
  @Column(name = "weekly_regular_hours", precision = 5, scale = 2)
  private BigDecimal weeklyRegularHours;
  @Column(name = "daily_regular_hours", precision = 5, scale = 2)
  private BigDecimal dailyRegularHours;
  @Column(name = "overtime_modifier", precision = 5, scale = 2)
  private BigDecimal overtimeModifier;

  /**
   * getter clientAppTerms.
   *
   * @return Set {@link ClientAppTerms}
   */
  @Transient
  public Set<ClientAppTerms> getClientAppTerms() {
    if (this.clientTerms != null) {
      return this.clientTerms.stream()
              .map(BranchClientAppTerm::getClientAppTerm)
              .collect(Collectors.toSet());
    }
    return new HashSet<>();
  }

  /**
   * Getter workerAppTerms.
   *
   * @return Set {@link WorkerAppTerm}
   */
  @Transient
  public Set<WorkerAppTerm> getWorkerAppTerms() {
    if (this.workerTerms != null) {
      return this.workerTerms.stream()
              .map(BranchWorkerAppTerm::getWorkerAppTerm)
              .collect(Collectors.toSet());
    }
    return new HashSet<>();
  }

  @Column(updatable = false, insertable = false)
  private LocalDate createdAt;
  @Column(updatable = false, insertable = false)
  private String createdBy;
  @Column(updatable = false, insertable = false)
  private String modifiedBy;
  @Column(updatable = false, insertable = false)
  private LocalDate modifiedAt;

}
