package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.springframework.web.multipart.MultipartFile;

/**
 * Email Base Request Dto.
 */
@Data
@NoArgsConstructor
@SuperBuilder
public class EmailBaseRequest {
  @NotNull(message = "The destiny cannot be null")
  @Email(message = "Invalid email format")
  private String to;
  @NotNull(message = "The subject cannot be null")
  private String subject;
  private List<MultipartFile> attachments;
}
