package com.staffzone.staffzonesystemsapi.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDateTime;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;

/**
 * Entity mapped against "<strong>client_app_terms</strong>" Table.
 */
@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@EqualsAndHashCode(callSuper = true)
@Table(name = "client_app_terms")
public class ClientAppTerms extends Audit {
  @Id
  @Column(name = "client_app_term_id", length = 2, nullable = false)
  private UUID clientAppTermId;

  @Builder.Default
  @NotNull
  @Column(name = "is_row_active", nullable = false)
  private Boolean isRowActive = false;

  @Size(max = 100)
  @NotNull
  @Column(name = "client_app_term_label", nullable = false, length = 100)
  private String clientAppTermIdLabel;

  @NotNull
  @Column(name = "client_app_term_file_uri", nullable = false)
  private String clientAppTermFileUri;

  @NotNull
  @Column(name = "sort_order", nullable = false)
  private Integer sortOrder;

  @NotNull
  @Column(name = "approval_request_ts", nullable = false)
  private LocalDateTime approvalRequestTs;

}
