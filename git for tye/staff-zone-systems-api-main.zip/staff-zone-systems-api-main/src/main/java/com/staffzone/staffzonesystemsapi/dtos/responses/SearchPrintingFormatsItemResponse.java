package com.staffzone.staffzonesystemsapi.dtos.responses;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Printing Formats Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchPrintingFormatsItemResponse {
  private String printingFormatId;
  private String printingFormatName;
  private String printingFormatType;
  private String printingFormatUri;
  private String modifiedAt;
  private String totalRows;
}
