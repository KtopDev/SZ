package com.staffzone.staffzonesystemsapi.dtos;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;

/**
 * Client Role detail Dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class ClientDetail {
  private UUID clientId;
  private String clientCode;
  private String firstName;
  private String clientName;
  private String lastName;
  private String name;
  private String email;
  private String phone;
  private Boolean primary;
  private List<RoleDetail> roles;

  @JsonSetter("first_name")
  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  @JsonSetter("last_name")
  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  @JsonSetter("client_name")
  public void setClientName(String clientName) {
    this.clientName = clientName;
  }

  @JsonSetter("client_id")
  public void setClientId(UUID clientId) {
    this.clientId = clientId;
  }

  @JsonSetter("client_code")
  public void setClientCode(String clientCode) {
    this.clientCode = clientCode;
  }

  @JsonSetter("is_primary")
  public void setPrimary(Boolean isPrimary) {
    this.primary = isPrimary;
  }

}
