package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.staffzone.staffzonesystemsapi.dtos.ClientContactDto;
import com.staffzone.staffzonesystemsapi.dtos.SearchClientContactFilterDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@EqualsAndHashCode(callSuper = false)
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class PaginatedClientContactResponse extends PaginatedAbstractResponse {
  private List<ClientContactDto> content;
  private SearchClientContactFilterDto filters;
}
