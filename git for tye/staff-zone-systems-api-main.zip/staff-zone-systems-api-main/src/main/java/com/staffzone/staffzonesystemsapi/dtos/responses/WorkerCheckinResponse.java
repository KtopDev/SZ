package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Worker Checkin Response Dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class WorkerCheckinResponse {
  @JsonSetter("branch_id")
  private String branchId;
  @JsonSetter("can_drive")
  private Boolean canDrive;
  @JsonSetter("worker_id")
  private String workerId;
  private String checkinAt;

}
