package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.staffzone.staffzonesystemsapi.validators.Uuid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import java.math.BigDecimal;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProjectObbRequest {
  @Uuid
  private String billCode;
  @NotBlank(message = "Name cannot be blank")
  private String name;
  @NotBlank(message = "Description cannot be blank")
  private String description;
  @NotNull(message = "Bill Rate cannot be blank")
  @Positive(message = "Bill Rate must be bigger than zero")
  private BigDecimal billRate;
  @NotBlank(message = "Frequency cannot be blank")
  @Pattern(regexp = "(?i)^$|DAILY|WEEKLY|FIRST_TIME",
      message = "Frequency must be either 'DAILY', 'WEEKLY' or 'FIRST_TIME'")
  private String frequency;
  @NotBlank(message = "Applied Per cannot be blank")
  @Pattern(regexp = "(?i)^$|WORKER|ORDER",
      message = "Applied Per must be either 'WORKER', 'ORDER'")
  private String appliedPer;

  @SneakyThrows
  @JsonIgnore
  public String asJson() {
    ObjectMapper mapper = new ObjectMapper();
    ObjectNode jsonObject = mapper.createObjectNode();
    jsonObject.put("bill_code_id", billCode);
    jsonObject.put("name", name);
    jsonObject.put("description", description);
    jsonObject.put("bill_rate", billRate);
    jsonObject.put("frequency", frequency);
    jsonObject.put("applied_per", appliedPer);
    return mapper.writeValueAsString(jsonObject);
  }
}
