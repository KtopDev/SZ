package com.staffzone.staffzonesystemsapi.dtos.auth;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Auth User Detail DTO.
 * <pre>{@code
 *    {
 *      "user": "AuthUserRoleDetail",
 *      "terms":   [...]
 *    }
 * }</pre>
 * {@link AuthUserRoleDetail}
 * {@link AuthTermDetail}
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class AuthUserDetail {
  private AuthUserRoleDetail user;
  private List<AuthTermDetail> terms;
}
