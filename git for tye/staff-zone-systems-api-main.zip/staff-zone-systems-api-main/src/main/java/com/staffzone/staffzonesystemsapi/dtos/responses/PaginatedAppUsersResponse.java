package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.staffzone.staffzonesystemsapi.dtos.AppUserDto;
import com.staffzone.staffzonesystemsapi.dtos.SearchAppUserFilterDto;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class PaginatedAppUsersResponse extends PaginatedAbstractResponse {
  private List<AppUserDto> content;
  private SearchAppUserFilterDto filters;
}
