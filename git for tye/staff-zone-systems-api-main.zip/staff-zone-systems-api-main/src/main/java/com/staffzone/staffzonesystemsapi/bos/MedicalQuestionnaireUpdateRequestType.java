package com.staffzone.staffzonesystemsapi.bos;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * MedicalQuestionnaireUpdateRequestType: <br/>
 * {@link #SMS_PIN_AND_UPDATE_KIOSK_APP},<br/>
 * {@link #PUSH_NOTIFICATION_AND_UPDATE_KIOSK_APP},<br/>
 * {@link #BOTH}.
 */
@Getter
@AllArgsConstructor
public enum MedicalQuestionnaireUpdateRequestType {
  SMS_PIN_AND_UPDATE_KIOSK_APP,
  PUSH_NOTIFICATION_AND_UPDATE_KIOSK_APP,
  BOTH;
}
