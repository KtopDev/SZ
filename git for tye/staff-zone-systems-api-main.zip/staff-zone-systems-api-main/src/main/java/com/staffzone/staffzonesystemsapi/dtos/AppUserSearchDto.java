package com.staffzone.staffzonesystemsapi.dtos;

import com.staffzone.staffzonesystemsapi.entities.AppUser;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class AppUserSearchDto {
  private UUID appUserId;
  private String firstName;
  private String lastName;
  private String status;
  private String branchName;
  private String jobTitle;
  private String roleName;
  // private String branchName; como vai pegar? via tabela n-n? app_users_branches
  // private LkJobTitle jobTitle;
  // securityRole


  public static AppUserSearchDto build(AppUser appUser) {
    return AppUserSearchDto.builder()
            .appUserId(appUser.getAppUserId())
            .firstName(appUser.getFirstName())
            .lastName(appUser.getLastName())
            .status(appUser.getStatus())
            .jobTitle(appUser.getLkJobTitle().getLabel())
            .build();
  }
}
