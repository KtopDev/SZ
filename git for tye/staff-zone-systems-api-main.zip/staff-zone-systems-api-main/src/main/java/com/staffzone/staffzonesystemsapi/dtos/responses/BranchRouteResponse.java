package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * BranchRoute DTO.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BranchRouteResponse {
    private String routeId;
    private String routeName;
    private String routeType;
    private Integer seats;
    private String routeDate;
    private String driverId;
    private String createdAt;
    private String modifiedAt;
}
