package com.staffzone.staffzonesystemsapi.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;

/**
 * The persistent class for the lk_job_titles database table.
 */
@Entity
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "lk_job_titles")
public class LkJobTitle {
  @Id
  @Column(name = "job_title")
  private String jobTitle;

  @Column(name = "label")
  private String label;

  @Column(name = "sort_order")
  private Integer sortOrder;

  @Builder.Default
  @Column(updatable = false, insertable = false)
  private Boolean isRowActive = false;
}
