package com.staffzone.staffzonesystemsapi.dtos.auth;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class AuthMfaDetail {
  private String mfaCode;
  private String[] mfaAppKeys;
  private String mfaPreference;

  @JsonSetter("mfa_code")
  public void setMfaCode(String mfaCode) {
    this.mfaCode = mfaCode;
  }

  @JsonSetter("mfa_app_keys")
  public void setMfaAppKeys(String[] mfaAppKeys) {
    this.mfaAppKeys = mfaAppKeys;
  }

  @JsonSetter("mfa_preference")
  public void setMfaPreference(String mfaPreference) {
    this.mfaPreference = mfaPreference;
  }
}
