package com.staffzone.staffzonesystemsapi.configs;

import com.staffzone.staffzonesystemsapi.bos.UserType;
import com.staffzone.staffzonesystemsapi.repositories.AppUserRepository;
import com.staffzone.staffzonesystemsapi.repositories.ClientContactRepository;
import com.staffzone.staffzonesystemsapi.repositories.WorkerRepository;
import lombok.AllArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class CustomUserDetailsService {

  private final AppUserRepository appUserRepository;
  private final WorkerRepository workerRepository;
  private final ClientContactRepository clientContactRepository;

  public UserDetails loadUserByUsernameAndUserType(
          String username,
          UserType userType) throws UsernameNotFoundException {
    return switch (userType) {
      case EMPLOYEE -> appUserRepository.findByEmailAndIsRowActiveIsTrue(username)
          .orElseThrow(() -> new UsernameNotFoundException("User not found"));
      case WORKER -> workerRepository.findByEmail(username)
          .orElseThrow(() -> new UsernameNotFoundException("User not found"));
      case CLIENT -> clientContactRepository.findByEmail(username)
          .orElseThrow(() -> new UsernameNotFoundException("User not found"));
    };
  }
}
