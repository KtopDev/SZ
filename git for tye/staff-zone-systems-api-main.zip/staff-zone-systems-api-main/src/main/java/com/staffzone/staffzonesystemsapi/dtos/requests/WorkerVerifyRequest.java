package com.staffzone.staffzonesystemsapi.dtos.requests;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.staffzone.staffzonesystemsapi.validators.Uuid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Workers Verification request.
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class WorkerVerifyRequest {
  @NotBlank(message = "Phone cannot be blank")
  @Pattern(regexp = "^\\d{10}", message = "Phone must have 10 digits")
  private String phone;
  @NotNull(message = "Worker Id name cannot be blank")
  @Uuid
  private String workerId;
  @NotBlank(message = "Phone Verification Code name cannot be blank")
  private String phoneVerificationCode;

  @JsonIgnore
  public UUID getWorkerUUID() {
    return UUID.fromString(this.workerId);
  }
}
