package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * TaxForms Response from Create and edit tax forms stored procedure.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TaxFormsResponse {
  @JsonSetter(value = "form_id")
  private String formId;
  @JsonSetter(value = "form_name")
  private String formName;
  @JsonSetter(value = "expires_after")
  private String expiresAfter;
  @JsonSetter(value = "effective_from")
  private String effectiveFrom;
  @JsonSetter(value = "tax_jurisdiction_id")
  private UUID taxJurisdictionId;
  @JsonSetter(value = "prompt_after_inactivity_days")
  private String promptAfterInactivityDays;
  @JsonSetter(value = "tax_form_questions")
  private List<TaxFormsQuestionsResponse> questions = new ArrayList<>();
}
