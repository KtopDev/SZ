package com.staffzone.staffzonesystemsapi.dtos.responses;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Jurisdiction Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchJurisdictionItemResponse {
  private String state;
  private String stateName;
  private String totalRows;
  private String modifiedAt;
  private String jurisdictionType;
  private String taxJurisdictionId;
  private String taxJurisdictionName;
  private String jurisdictionTypeLabel;
}
