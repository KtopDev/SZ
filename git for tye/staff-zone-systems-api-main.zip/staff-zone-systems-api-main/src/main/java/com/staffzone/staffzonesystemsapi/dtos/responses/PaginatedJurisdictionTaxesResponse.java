package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.staffzone.staffzonesystemsapi.dtos.SearchJurisdictionTaxesFilterDto;
import com.staffzone.staffzonesystemsapi.entities.UnemploymentJurisdictions;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class PaginatedJurisdictionTaxesResponse extends PaginatedAbstractResponse {
  private List<UnemploymentJurisdictions> content;
  private SearchJurisdictionTaxesFilterDto filters;
}
