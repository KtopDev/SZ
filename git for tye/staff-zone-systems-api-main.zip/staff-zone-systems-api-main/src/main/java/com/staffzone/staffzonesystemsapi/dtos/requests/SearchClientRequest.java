package com.staffzone.staffzonesystemsapi.dtos.requests;

import static com.staffzone.staffzonesystemsapi.entities.Client.Fields.clientCode;
import static com.staffzone.staffzonesystemsapi.entities.Client.Fields.clientName;
import static com.staffzone.staffzonesystemsapi.entities.Client.Fields.lastOrderDate;
import static com.staffzone.staffzonesystemsapi.utils.StringUtils.toSnakeCase;
import static org.springframework.data.domain.Sort.Direction.ASC;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.staffzone.staffzonesystemsapi.validators.SortOptions;
import jakarta.validation.constraints.Pattern;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.JSONObject;
import org.apache.commons.lang3.StringUtils;

/**
 * Search Client Request DTO.
 */
@Slf4j
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class SearchClientRequest extends SearchAbstractRequest {
  private String name;
  private String branch;
  private LocalDate startDate;
  private LocalDate endDate;
  @Pattern(regexp = "^$|Active|Inactive|DNS|In Legal",
          message = "Status must be either 'Active', 'Inactive', 'DNS' or 'In Legal'")
  private String status;
  @SortOptions(
          anyOf = {clientCode, clientName, lastOrderDate, "status"})
  private String sort;

  /**
   * Get sort as Json.
   *
   * @return String
   */
  @JsonIgnore
  public String getSortAsJson() {
    JSONObject jsonObject = new JSONObject();
    jsonObject.put("limit", super.getSize());

    var offset = (super.getPage() - 1) * super.getSize();
    jsonObject.put("offset", offset);

    if (sort == null || sort.isBlank()) {
      jsonObject.put("sort_column", toSnakeCase(clientCode));
      jsonObject.put("sort_direction", ASC.name());
    } else {
      String[] options = sort.split(",");
      jsonObject.put("sort_column", toSnakeCase(options[0]));
      jsonObject.put("sort_direction", options[1].toUpperCase());
    }

    return jsonObject.toJSONString();
  }

  public String getStatus() {
    return status == null || status.isBlank() ? null : status.toUpperCase();
  }

  @JsonIgnore
  public String[] getBranches() {
    return StringUtils.isBlank(branch) ? null : new String[]{ branch };
  }
}
