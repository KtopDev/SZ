package com.staffzone.staffzonesystemsapi.entities;

import com.staffzone.staffzonesystemsapi.entities.ids.ClientBranchId;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;

/**
 * Entity mapped against "<strong>client_branch</strong>" Table.
 */
@Entity
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "client_branches")
public class ClientBranch {
  @EmbeddedId
  private ClientBranchId id;

  @MapsId("clientId")
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "client_id", nullable = false)
  private Client client;

  @MapsId("branchId")
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "branch_id", nullable = false)
  private Branch branch;

  @Builder.Default
  @NotNull
  @Column(name = "is_row_active", nullable = false)
  private Boolean isRowActive = false;

  public ClientBranch(Client client, Branch branch) {
    id = ClientBranchId.builder()
            .branchId(branch.getBranchId())
            .clientId(client.getId())
            .build();
    isRowActive = true;
    this.client = client;
    this.branch = branch;
  }

}