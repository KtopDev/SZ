package com.staffzone.staffzonesystemsapi.dtos;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.staffzone.staffzonesystemsapi.validators.Uuid;
import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * ProjectBonus Dto.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProjectBonusDto {
  @Uuid
  private String bonusPayCodeId;
  private BigDecimal bonusRequiredHours;
  private BigDecimal bonusAmount;
  private String bonusFrequency;

  public ObjectNode asJsonNode(ObjectMapper mapper) {
    ObjectNode jsonObject = mapper.createObjectNode();
    jsonObject.put("bonus_pay_code_id", bonusPayCodeId);
    jsonObject.put("bonus_required_hours", bonusRequiredHours);
    jsonObject.put("bonus_amount", bonusAmount);
    jsonObject.put("bonus_frequency", bonusFrequency);
    return jsonObject;
  }
}
