package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@SuperBuilder
public class CreateClientRequest extends UpdateClientRequest {
  // Main contact attributes
  @NotBlank(message = "Name cannot be blank")
  private String name;

  @NotBlank(message = "Last name cannot be blank")
  private String lastName;

  @NotNull(message = "Cell phone cannot be null")
  @Digits(fraction = 0, integer = 10, message = "Cell phone must have 10 characters")
  private Long cellPhone;

  @NotBlank(message = "Email cannot be blank")
  private String email;

  @NotNull(message = "You’ll need to decide whether to enable it or not")
  private Boolean isClientAppEnable;

  @NotNull(message = "You’ll need to decide whether to enable it or not")
  private Boolean isBillAndInvoiceEnable;

  @NotNull(message = "You’ll need to decide whether to enable it or not")
  private Boolean isApprovalAndCreationEnable;

  @NotNull(message = "You’ll need to decide whether to enable it or not")
  private Boolean isRateWorkersEnable;
}
