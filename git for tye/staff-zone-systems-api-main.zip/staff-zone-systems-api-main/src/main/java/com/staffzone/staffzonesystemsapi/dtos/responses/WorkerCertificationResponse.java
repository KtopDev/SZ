package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Worker Certifications response Dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class WorkerCertificationResponse {
  @JsonAlias("certification_id")
  private String certificationId;
  @JsonAlias("certification_name")
  private String certificationName;
  @JsonAlias("support_document_file")
  private String supportDocumentFile;
  @JsonAlias("certification_description")
  private String certificationDescription;
}
