package com.staffzone.staffzonesystemsapi.bos;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * MultiFactorType: <br/>
 * {@link #ACTIVE},<br/>
 * {@link #INACTIVE},<br/>
 * {@link #DNS},<br/>
 * {@link #IN_LEGAL}.
 *
 */
@Getter
@AllArgsConstructor
public enum ClientStatusType {
  ACTIVE("ACTIVE"),
  INACTIVE("INACTIVE"),
  DNS("DNS"),
  IN_LEGAL("IN LEGAL");

  private final String value;

  /**
   * Method to search value from any String.
   *
   * @param str
   *            <br/> Accept null and is case-sensitive.
   * @return <br/> Search between options
   */
  public static ClientStatusType of(String str) {
    for (ClientStatusType type : values()) {
      if (str.equalsIgnoreCase(type.value)) {
        return type;
      }
    }

    return null;
  }
}
