package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Clients Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchClientItemResponse {
  @JsonSetter(value = "client_id")
  private String clientId;
  @JsonSetter(value = "client_name")
  private String clientName;
  @JsonSetter(value = "client_code")
  private String clientCode;
  @JsonSetter(value = "last_order_branch")
  private String lastOrderBranch;
  @JsonSetter(value = "last_order_date")
  private String lastOrderDate;
  @JsonSetter(value = "last_invoice_date")
  private String lastInvoiceDate;
  @JsonSetter(value = "status")
  private String status;
  @JsonSetter(value = "unpaid_invoices")
  private String unpaidInvoices;
  @JsonSetter(value = "total_rows")
  private String totalRows;
}
