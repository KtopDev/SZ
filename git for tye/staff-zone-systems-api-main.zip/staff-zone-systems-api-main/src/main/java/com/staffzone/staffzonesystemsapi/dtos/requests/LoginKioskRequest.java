package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Loin Kiosk Request DTO.
 */
@EqualsAndHashCode(callSuper = false)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class LoginKioskRequest extends PasswordRequest {
  @NotBlank(message = "SSN cannot be blank.")
  @Pattern(regexp = "^\\d{9}", message = "Ssn Number must have 9 digits")
  private String userSsn;
}
