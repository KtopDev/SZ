package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonSetter;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ToolsRequest {
  @NotBlank(message = "Tool Name cannot be blank")
  private String toolName;
  @NotBlank(message = "Tool Abbreviation cannot be blank")
  private String toolAbbreviation;
  @NotBlank(message = "Tool Description cannot be blank")
  private String toolDescription;
  private UUID branchId;

  @JsonGetter("tool_abreviation")
  public String getToolAbbreviation() {
    return toolAbbreviation;
  }

  @JsonSetter("toolAbbreviation")
  public void setToolAbbreviation(String toolAbbreviation) {
    this.toolAbbreviation = toolAbbreviation;
  }
}
