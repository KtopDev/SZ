package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Regular Taxes Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchRegularTaxItemResponse {
  private String state;
  @JsonAlias("tax_id")
  private String taxId;
  @JsonAlias("tax_rate")
  private Double taxRate;
  @JsonAlias("row_order")
  private Integer rowOrder;
  @JsonAlias("total_rows")
  private String totalRows;
  @JsonAlias("base_amount")
  private Double baseAmount;
  @JsonAlias("bracket_end")
  private Double bracketEnd;
  @JsonAlias("modified_at")
  private String modifiedAt;
  @JsonAlias("bracket_start")
  private Double bracketStart;
  @JsonAlias("effective_date")
  private String effectiveDate;
  @JsonAlias("filling_status")
  private String fillingStatus;
  @JsonAlias("calculation_type")
  private String calculationType;
  @JsonAlias("jurisdiction_type")
  private String jurisdictionType;
  @JsonAlias("tax_jurisdiction_id")
  private String taxJurisdictionId;
  @JsonAlias("tax_jurisdiction_name")
  private String taxJurisdictionName;
}
