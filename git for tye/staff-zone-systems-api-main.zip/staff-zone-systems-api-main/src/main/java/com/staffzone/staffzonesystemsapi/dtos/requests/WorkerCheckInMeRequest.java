package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Worker Check-In MeRequest.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WorkerCheckInMeRequest {
  @NotBlank(message = "geoLocation cannot be blank.")
  private String geoLocation;
  private Boolean canDrive;
  @PositiveOrZero
  private Integer passengersCount;
  private String phone;

  public Boolean getCanDrive() {
    return canDrive != null && canDrive;
  }

  public Integer getPassengersCount() {
    return  (canDrive == null || !canDrive) ? null : passengersCount;
  }
}
