package com.staffzone.staffzonesystemsapi.bos;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * MultiFactorType: <br/>
 * {@link #ACTIVE},<br/>
 * {@link #ON_HOLD},<br/>
 * {@link #INACTIVE},<br/>
 * {@link #STOPPED},<br/>
 * {@link #REPLACED}.
 *
 */
@Getter
@AllArgsConstructor
public enum PayCardStatusType {
  ACTIVE("ACTIVE"),
  ON_HOLD("ON-HOLD"),
  INACTIVE("INACTIVE"),
  STOPPED("STOPPED"),
  REPLACED("REPLACED");

  private final String value;

  /**
   * Method to search value from any String.
   *
   * @param str
   *            <br/> Accept null and is case-sensitive.
   * @return <br/> Search between options
   */
  public static PayCardStatusType of(String str) {
    for (PayCardStatusType type : values()) {
      if (str.equalsIgnoreCase(type.value)) {
        return type;
      }
    }
    return null;
  }
}
