package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import java.util.UUID;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Projects Basic Info Response DTO.
 */
@Data
@NoArgsConstructor
public class ProjectRequestBasicInfoResponse {
  private String fax;
  private String city;
  private String phone;
  private String state;
  private String status;
  private String address;
  @JsonSetter(value = "branch_id")
  private String branchId;
  @JsonSetter(value = "client_id")
  private String clientId;
  @JsonSetter(value = "status_ts")
  private String statusTs;
  @JsonSetter(value = "state_name")
  private String stateName;
  @JsonSetter(value = "branch_name")
  private String branchName;
  @JsonSetter(value = "client_name")
  private String clientName;
  @JsonSetter(value = "postal_code")
  private Integer postalCode;
  @JsonSetter(value = "project_code")
  private String projectCode;
  @JsonSetter(value = "project_name")
  private String projectName;
  @JsonSetter(value = "address_line_2")
  private String addressLine2;
  @JsonSetter(value = "project_request_id")
  private UUID projectRequestId;
}
