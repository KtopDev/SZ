package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.staffzone.staffzonesystemsapi.bos.OrderStatusType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateProjectOrderRequest {
  @NotNull(message = "Order Start Ts cannot be blank")
  private LocalDateTime orderStartTs;
  @NotEmpty(message = "Order details cannot be empty")
  private List<@Valid CreateProjectOrderDetailsRequest> projectOrderDetails;
  @JsonIgnore
  private OrderStatusType orderStatusType;

  @SneakyThrows
  @JsonIgnore
  public String asJson() {
    ObjectMapper mapper = new ObjectMapper();
    ObjectNode jsonObject = mapper.createObjectNode();
    jsonObject.put("order_start_ts", orderStartTs.toString());
    jsonObject.put("status", orderStatusType.name());
    ArrayNode projectOrderDetailsArray = mapper.createArrayNode();
    for (CreateProjectOrderDetailsRequest detail : projectOrderDetails) {
      projectOrderDetailsArray.add(detail.asJsonNode(mapper));
    }
    jsonObject.set("project_order_details", projectOrderDetailsArray);
    return mapper.writeValueAsString(jsonObject);
  }
}
