package com.staffzone.staffzonesystemsapi.controllers;

import static com.staffzone.staffzonesystemsapi.utils.Constants.TERMS_AND_CONDITIONS_PATH;
import static org.springframework.http.MediaType.MULTIPART_FORM_DATA_VALUE;

import com.staffzone.staffzonesystemsapi.dtos.FileDto;
import com.staffzone.staffzonesystemsapi.dtos.requests.FolderPathRequest;
import com.staffzone.staffzonesystemsapi.services.FileStorageService;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 * Controller for Files Endpoints.
 */
@RequestMapping("/api/v1/files")
@CrossOrigin("*")
@RestController
@AllArgsConstructor
public class FilesController {
  private FileStorageService fileStorageService;

  @GetMapping
  public ResponseEntity<List<FileDto>> getAllLegalTerms() {
    return ResponseEntity.ok(fileStorageService
            .getAllResources(TERMS_AND_CONDITIONS_PATH));
  }

  /**
   * Upload Legal Terms.
   *
   * @param fileName String
   * @param file     String
   * @return File Name
   */
  @PostMapping(path = "/{fileName}", consumes = {MULTIPART_FORM_DATA_VALUE})
  public ResponseEntity<String> uploadLegalTerms(@PathVariable("fileName") String fileName,
                                                 @RequestPart MultipartFile file) {
    URI uri = fileStorageService.loadLegalTerms(TERMS_AND_CONDITIONS_PATH, fileName, file);
    return ResponseEntity.ok(uri.toString());
  }

  @GetMapping("/{fileName}/uri")
  public ResponseEntity<URI> downloadLegalTermsFile(@PathVariable("fileName") String fileName,
                                                    @RequestBody @Valid FolderPathRequest folder) {
    return ResponseEntity.ok(fileStorageService.getUri(folder.getFolder().getValue(), fileName));
  }
}
