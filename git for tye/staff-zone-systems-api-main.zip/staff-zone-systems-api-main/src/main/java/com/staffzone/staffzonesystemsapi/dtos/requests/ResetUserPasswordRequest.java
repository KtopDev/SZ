package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.staffzone.staffzonesystemsapi.bos.UserType;
import com.staffzone.staffzonesystemsapi.validators.Uuid;
import com.staffzone.staffzonesystemsapi.validators.ValueOfEnum;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Reset Password Request Data DTO.
 */
@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ResetUserPasswordRequest extends PasswordRequest {
  @NotNull
  @ValueOfEnum(enumClass = UserType.class)
  private String userType;
  @NotBlank(message = "Email cannot be blank")
  @Email(message = "Email must be valid")
  private String email;
  @Uuid
  @NotBlank(message = "Request id cannot be blank")
  private String id;
}
