package com.staffzone.staffzonesystemsapi.entities;

import static jakarta.persistence.EnumType.STRING;

import com.staffzone.staffzonesystemsapi.bos.MultiFactorType;
import com.staffzone.staffzonesystemsapi.bos.UserStatusType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * The persistent class for the app_users database table.
 */
@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "app_users")
public class AppUser extends Audit implements UserDetails {
  @Id
  @Column(name = "app_user_id")
  private UUID appUserId;

  @NotNull
  @Column(name = "app_user_code", length = 7)
  private String appUserCode;

  @Column(name = "email")
  private String email;

  @Column(name = "first_name")
  private String firstName;

  @Column(name = "last_name")
  private String lastName;

  @NotNull
  @Column(name = "multi_factor_authentication_preference", nullable = false, length = 20)
  @Enumerated(STRING)
  private MultiFactorType multiFactorAuthenticationPreference;

  @Column(name = "password_expire_ts")
  private LocalDateTime passwordExpireTs;

  @Column(name = "multi_factor_authentication_ttl_days")
  private Integer multiFactorAuthenticationTtlDays;

  @Column(name = "password_hash")
  private String password;

  @Column(name = "phone")
  private String phone;

  @Column(name = "is_sales_enabled")
  private Boolean isSalesCloser;

  @Column(name = "status")
  private String status;

  @Column(name = "status_ts")
  private LocalDateTime statusTs;

  @OneToMany(mappedBy = "appUser")
  @ToString.Exclude
  private List<AppUserMfaKey> mfaKeys;

  @ManyToOne
  @JoinColumn(name = "job_title")
  private LkJobTitle lkJobTitle;

  @OneToMany(mappedBy = "appUser", fetch = FetchType.EAGER)
  private List<AppUsersBranch> appUsersBranches;

  @Builder.Default
  @Column(updatable = false, insertable = false)
  private Boolean isRowActive = false;

  @Column(name = "last_multi_factor_authentication_ts")
  private LocalDateTime lastMultiFactorAuthenticationTs;

  /**
   * get Roles.
   *
   * @return Set
   */
  public Set<AppRole> getRoles() {
    if (getAppUsersBranches() != null) {
      return getAppUsersBranches().stream()
              .map(AppUsersBranch::getAppRole)
              .collect(Collectors.toSet());
    }
    return Collections.emptySet();
  }

  @Override
  public Collection<? extends GrantedAuthority> getAuthorities() {
    return getRoles().stream()
            .map(role -> new SimpleGrantedAuthority("ROLE_" + role.getRole()))
            .collect(Collectors.toSet());
  }

  @Override
  public String getUsername() {
    return getEmail();
  }

  @Override
  public boolean isAccountNonExpired() {
    return true;
  }

  @Override
  public boolean isAccountNonLocked() {
    return true;
  }

  @Override
  public boolean isCredentialsNonExpired() {
    return passwordExpireTs == null || LocalDateTime.now().isBefore(passwordExpireTs);
  }

  @Override
  public boolean isEnabled() {
    return UserStatusType.ACTIVE.toString().equalsIgnoreCase(getStatus());
  }
}
