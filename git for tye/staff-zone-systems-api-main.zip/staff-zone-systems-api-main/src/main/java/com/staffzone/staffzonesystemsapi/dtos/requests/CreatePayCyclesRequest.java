package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Create PayCycle Request DTO.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreatePayCyclesRequest {
  @NotEmpty(message = "Pay Cycle Name cannot be empty.")
  private String payCycleName;
  @NotNull(message = "Start Iso Day Of Week cannot be empty.")
  @Min(value = 1)
  @Max(value = 7)
  private Integer startIsoDayOfWeek;
}
