package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.HashMap;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import lombok.SneakyThrows;

/**
 * CompCode Request Dto.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CompCodeRequest {
  @NotBlank(message = "Comp code cannot be blank")
  @Size(max = 4, message = "Comp code exceed 4 chars")
  private String compCode;

  @NotBlank(message = "Description name cannot be blank")
  @Size(max = 100, message = "Comp code exceed 100 chars")
  private String description;

  @NotBlank(message = "Billing Description cannot be blank")
  @Size(max = 100, message = "Comp code exceed 100 chars")
  private String billingInformation;

  private String state;

  @NotNull(message = "Burden Per Hour cannot be blank")
  @Digits(fraction = 4, integer = 10,
          message = "Daily pay limit can't be bigger than 999999999.9999")
  private BigDecimal burdenPerHour;

  @NotNull(message = "Cost Per Hundred cannot be blank")
  @Digits(fraction = 4, integer = 10,
          message = "Cost Per Hundred can't be bigger than 999999999.9999")
  private BigDecimal  costPerHundred;

  @NotNull(message = "Bill Rate Per Hundred cannot be blank")
  @Digits(fraction = 4, integer = 10,
          message = "Bill Rate Per Hundred can't be bigger than 999999999.9999")
  private BigDecimal  billRatePerHundred;

  @NotBlank(message = "Effective Date Per Hundred cannot be blank")
  private String effectiveDate;

  @SneakyThrows
  @JsonIgnore
  public String toDBJson() {
    Map map = new HashMap<>();
    map.put("comp_code", getCompCode());
    map.put("comp_code_description", getDescription());
    map.put("comp_code_billing_description", getBillingInformation());
    map.put("state", getState());
    map.put("cost_per_hundred", getCostPerHundred());
    map.put("bill_rate_per_hundred", getBillRatePerHundred());
    map.put("burden_per_hour", getBurdenPerHour());
    map.put("efective_date", getEffectiveDate());
    ObjectMapper mapper = new ObjectMapper();
    return mapper.writeValueAsString(map);
  }

}
