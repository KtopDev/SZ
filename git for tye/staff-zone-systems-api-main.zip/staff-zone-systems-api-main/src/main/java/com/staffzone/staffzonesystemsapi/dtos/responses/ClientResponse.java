package com.staffzone.staffzonesystemsapi.dtos.responses;

import static com.staffzone.staffzonesystemsapi.dtos.BranchSearchDto.build;

import com.staffzone.staffzonesystemsapi.dtos.BranchSearchDto;
import com.staffzone.staffzonesystemsapi.dtos.ClientContactDto;
import com.staffzone.staffzonesystemsapi.dtos.CompCodeDto;
import com.staffzone.staffzonesystemsapi.dtos.InvoiceMethodsDto;
import com.staffzone.staffzonesystemsapi.dtos.PaymentTermDto;
import com.staffzone.staffzonesystemsapi.dtos.PrintingFormatsDto;
import com.staffzone.staffzonesystemsapi.entities.Client;
import java.math.BigDecimal;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Client Response DTO.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ClientResponse {
  private String id;
  private String clientCode;
  private String clientName;
  private String status;
  private BigDecimal creditLimit;
  private PaymentTermDto paymentTerm;
  private InvoiceMethodsDto invoiceMethod;
  private PrintingFormatsDto invoicePrintingFormat;
  private String phone;
  private String fax;
  private String address;
  private String address2;
  private StatesDto state;
  private String city;
  private String postalCode;
  private CompCodeDto compCode;
  private List<BranchSearchDto> branches;
  private List<ClientContactDto> contacts;
  private Set<String> branchNames;
  private Set<String> branchIds;

  /**
   * Custom Constructor.
   *
   * @param client {@link Client}
   */
  public ClientResponse(Client client) {
    id = client.getId().toString();
    clientCode = client.getClientCode();
    clientName = client.getClientName();
    status = client.getStatus();
    creditLimit = client.getCreditLimit();
    paymentTerm = PaymentTermDto.build(client.getPaymentTerm());
    invoiceMethod = InvoiceMethodsDto.build(client.getInvoiceMethod());
    invoicePrintingFormat = PrintingFormatsDto.build(client.getInvoicePrintingFormat());
    phone = client.getPhone();
    fax = client.getFax();
    address = client.getAddress();
    address2 = client.getAddressLine2();
    state = StatesDto.build(client.getState());
    city = client.getCity();
    postalCode = client.getPostalCode();
    compCode = CompCodeDto.build(client.getCompCode());
    branches = client.getBranches().stream()
            .map(cb -> build(cb.getBranch()))
            .toList();

    if (client.getClientContacts() != null) {
      contacts = client.getClientContacts().stream()
              .map(ClientContactDto::build)
              .toList();
    }

    branchNames = branches.stream()
            .map(BranchSearchDto::getBranchName)
            .collect(Collectors.toSet());
    branchIds = branches.stream()
            .map(cb -> cb.getBranchId().toString())
            .collect(Collectors.toSet());
  }
}
