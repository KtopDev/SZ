package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Workers Verification response.
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class WorkerRegistrationResponse {

  private Boolean isPhoneValid;
  private Boolean isEmailValid;
  private Boolean isSSNValid;
  private String workerId;
  private String phoneVerificationCode;

  @JsonGetter("isPhoneValid")
  public Boolean getPhoneValid() {
    return isPhoneValid;
  }

  @JsonSetter("is_phone_valid")
  public void setPhoneValid(Boolean phoneValid) {
    isPhoneValid = phoneValid;
  }

  @JsonGetter("isEmailValid")
  public Boolean getEmailValid() {
    return isEmailValid;
  }

  @JsonSetter("is_email_valid")
  public void setEmailValid(Boolean emailValid) {
    isEmailValid = emailValid;
  }

  @JsonGetter("isSSNValid")
  public Boolean getSSNValid() {
    return isSSNValid;
  }

  @JsonSetter("is_ssn_number_valid")
  public void setSSNValid(Boolean SSNValid) {
    isSSNValid = SSNValid;
  }

  @JsonGetter("workerId")
  public String getWorkerId() {
    return workerId;
  }

  @JsonSetter("worker_id")
  public void setWorkerId(String workerId) {
    this.workerId = workerId;
  }

  @JsonIgnore
  public String getPhoneVerificationCode() {
    return phoneVerificationCode;
  }

  @JsonSetter("phone_verification_code")
  public void setPhoneVerificationCode(String phoneVerificationCode) {
    this.phoneVerificationCode = phoneVerificationCode;
  }
}
