package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.staffzone.staffzonesystemsapi.validators.Uuid;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Remove Worker From Order Request DTO.
 */
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RemoveWorkerOrderRequest extends RemoveWorkerRequest {
  @Uuid(message = "projectWorkerBasedBillingId cannot be null")
  private String projectWorkerBasedBillingId;
}
