package com.staffzone.staffzonesystemsapi.bos;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * AuthStatusType: <br/>
 * {@link #ALL},<br/>
 * {@link #ACTIVE},<br/>
 * {@link #INACTIVE}.
 */
@Getter
@AllArgsConstructor
public enum CompCodeStatusType {
  ALL(""), ACTIVE("ACTIVE"), INACTIVE("ARCHIVED");

  private final String value;

  /**
   * of CompCodeStatusType.
   *
   * @param str String
   * @return {@link CompCodeStatusType}
   */
  public static CompCodeStatusType of(String str) {
    for (CompCodeStatusType type : values()) {
      if (str.toUpperCase().equals(type.name())) {
        return type;
      }
    }
    return null;
  }
}
