package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Garnishment Types Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchGarnishmentTypeItemResponse {
  @JsonSetter(value = "created_at")
  private String createdAt;
  @JsonSetter(value = "total_rows")
  private String totalRows;
  @JsonSetter(value = "max_percentage")
  private String maxPercentage;
  @JsonSetter(value = "garnishment_type_id")
  private String garnishmentTypeId;
  @JsonSetter(value = "garnishment_type_name")
  private String garnishmentTypeName;
}
