package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.staffzone.staffzonesystemsapi.validators.SortOptions;
import jakarta.validation.constraints.Pattern;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import net.minidev.json.JSONObject;

import java.time.LocalDate;
import java.util.UUID;

import static com.staffzone.staffzonesystemsapi.utils.StringUtils.toSnakeCase;
import static org.springframework.data.domain.Sort.Direction.ASC;

/**
 * Search Projects Request DTO.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class SearchProjectsRequest extends SearchAbstractRequest {
  private String searchBy;
  private UUID branchId;
  private UUID clientId;
  private LocalDate lastVisitDateStart;
  private LocalDate lastVisitDateEnd;
  @Pattern(regexp = "^$|Active|Incomplete|Inactive|Closed|ACTIVE|INCOMPLETE|INACTIVE|CLOSED|DNS",
      message = "Status must be either 'Active', 'Inactive', 'Incomplete', 'Closed' or 'DNS'")
  private String status;
  @SortOptions(anyOf = {"projectCode", "projectName", "clientName", "branchName", "visitDate", "status"})
  private String sort;

  /**
   * Get sort as Json.
   *
   * @return String
   */
  @JsonIgnore
  public String getSortAsJson() {
    JSONObject jsonObject = new JSONObject();
    jsonObject.put("limit", super.getSize());

    var offset = (super.getPage() - 1) * super.getSize();
    jsonObject.put("offset", offset);

    if (sort == null || sort.isBlank()) {
      jsonObject.put("sort_column", "projectName");
      jsonObject.put("sort_direction", ASC.name());
    } else {
      String[] options = sort.split(",");
      jsonObject.put("sort_column", toSnakeCase(options[0]));
      jsonObject.put("sort_direction", options[1].toUpperCase());
    }
    return jsonObject.toJSONString();
  }

  @JsonIgnore
  public String[] getBranches() {
    return branchId == null ? null : new String[]{branchId.toString()};
  }

  @JsonIgnore
  public String[] getClients() {
    return clientId == null ? null : new String[]{clientId.toString()};
  }

  public String getStatus() {
    return status == null || status.isBlank() ? null : status.toUpperCase();
  }
}
