package com.staffzone.staffzonesystemsapi.bos;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * SickPayRequestStatusType: <br/>
 * {@link #REQUESTED},<br/>
 * {@link #APPROVED},<br/>
 * {@link #REJECTED}.
 */
@Getter
@AllArgsConstructor
public enum SickPayRequestStatusType {
  REQUESTED,
  APPROVED,
  REJECTED;
}
