package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.staffzone.staffzonesystemsapi.validators.Pdf;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;
import org.springframework.web.multipart.MultipartFile;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@FieldNameConstants
public class UpdateClientAppTermRequest {
  @NotNull(message = "File name cannot be null.")
  private String fileName;
  @Pdf(allowNull = true)
  private MultipartFile document;
}