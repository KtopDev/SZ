package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonAlias;

import java.time.LocalDate;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Dispatch Worker Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchDispatchWorkersItemResponse {
  private Double rating;
  private List<Skill> skills;
  private String status;
  private List<Warning> warnings;
  @JsonAlias("can_drive")
  private Boolean canDrive;
  @JsonAlias("last_name")
  private String lastName;
  @JsonAlias("worker_id")
  private String workerId;
  @JsonAlias("checkin_at")
  private String checkinAt;
  @JsonAlias("first_name")
  private String firstName;
  @JsonAlias("total_rows")
  private String totalRows;
  @JsonAlias("other_names")
  private String otherNames;
  @JsonAlias("payment_avg")
  private Double paymentAvg;
  @JsonAlias("worker_code")
  private String workerCode;
  @JsonAlias("last_pay_date")
  private String lastPayDate;
  private List<Certification> certifications;
  @JsonAlias("middle_initial")
  private String middleInitial;
  @JsonAlias("passengers_count")
  private Integer passengersCount;
  @JsonAlias("email")
  private String email;
  // TODO need to get this form the store procedure
  @JsonAlias("hours_worked_current_week")
  private String hoursWorkedCurrentWeek = "20";
  @JsonAlias("last_day_worked")
  private String lastDayWorked = LocalDate.now().toString();

  @Data
  public static class Warning {
    @JsonAlias("type")
    private String type;
    @JsonAlias("message")
    private String message;
  }

  @Data
  public static class Skill {
    @JsonAlias("skill_id")
    private String skillId;
    @JsonAlias("skill_name")
    private String skillName;
    @JsonAlias("skill_group")
    private String skillGroup;
  }

  @Data
  public static class Certification {
    @JsonAlias("certification_id")
    private String certificationId;
    @JsonAlias("certification_name")
    private String certificationName;
    @JsonAlias("certification_abreviation")
    private String certificationAbbreviation;
  }
}