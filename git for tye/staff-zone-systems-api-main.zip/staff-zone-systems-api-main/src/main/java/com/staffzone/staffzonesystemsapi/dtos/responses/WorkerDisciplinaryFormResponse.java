package com.staffzone.staffzonesystemsapi.dtos.responses;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * WorkerDisciplinaryFormResponse complete registration response.
 */
@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WorkerDisciplinaryFormResponse {
    private String disciplinaryFormId;
    private String workerId;
    private String workerCode;
    private String orderId;
    private String orderNumber;
    private String projectName;
    private Integer disciplinaryFormNumber;
    private String warningType;
    private LocalDate formDate;
    private String infraction;
    private String expectedBehavior;
    private String status;
    private LocalDateTime statusTs;
}
