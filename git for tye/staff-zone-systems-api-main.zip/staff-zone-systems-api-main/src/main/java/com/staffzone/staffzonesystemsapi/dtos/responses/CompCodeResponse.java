package com.staffzone.staffzonesystemsapi.dtos.responses;

import java.math.BigDecimal;
import java.util.UUID;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * CompCode Response from create and edit comp-codes stored procedure.
 */
@Data
@NoArgsConstructor
public class CompCodeResponse {
  private UUID compCodeId;
  private String compCode;
  private String compCodeDescription;
  private String compCodeBillingDescription;
  private String state;
  private String status;
  private BigDecimal burdenPerHour;
  private BigDecimal  costPerHundred;
  private BigDecimal  billRatePerHundred;
  private String efectiveDate;
  private String statusTs;
}
