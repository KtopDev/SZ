package com.staffzone.staffzonesystemsapi.dtos.requests;

import static com.staffzone.staffzonesystemsapi.entities.UnemploymentJurisdictions.Fields.lkStates;

import com.staffzone.staffzonesystemsapi.validators.SortOptions;
import jakarta.validation.constraints.Pattern;
import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class SearchJurisdictionTaxesRequest extends SearchAbstractRequest {
  @SortOptions(anyOf = {lkStates})
  private String sort;
  private String jurisdiction;
  private String state;
  @Pattern(regexp = "^$|Active|Archived|ACTIVE|ARCHIVED",
          message = "Status must be either 'Active', 'Archived'")
  private String status;
  private LocalDate startDate;
  private LocalDate endDate;
  private Boolean isRowActive;
}