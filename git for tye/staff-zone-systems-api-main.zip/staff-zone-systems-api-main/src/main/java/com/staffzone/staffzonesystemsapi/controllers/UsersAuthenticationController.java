package com.staffzone.staffzonesystemsapi.controllers;

import static com.staffzone.staffzonesystemsapi.bos.UserType.of;
import static java.util.Objects.requireNonNull;

import com.staffzone.staffzonesystemsapi.dtos.TemporaryLink;
import com.staffzone.staffzonesystemsapi.dtos.requests.ResetUserPasswordLinkRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.ResetUserPasswordRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.ResetUserPasswordSMSRequest;
import com.staffzone.staffzonesystemsapi.services.AppUserService;
import com.staffzone.staffzonesystemsapi.services.ClientService;
import com.staffzone.staffzonesystemsapi.services.TemporaryLinkService;
import com.staffzone.staffzonesystemsapi.services.WorkerService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * App User Controller.
 */
@RequestMapping("/api/v1/authentication")
@RestController
@AllArgsConstructor
public class UsersAuthenticationController {
  private ClientService clientService;
  private WorkerService workerService;
  private AppUserService appUserService;
  private TemporaryLinkService temporaryLinkService;

  /**
   * Creates a password reset link and send it by email.
   *
   * @param request {@link ResetUserPasswordLinkRequest}
   * @return String
   */
  @PostMapping("/password/reset")
  @Operation(summary = "Creates a password reset link and send it by email")
  public ResponseEntity<String> resetPasswordLink(
          @RequestBody @Valid ResetUserPasswordLinkRequest request) {
    switch (requireNonNull(of(request.getUserType()))) {
      case EMPLOYEE -> appUserService.resetPasswordLink(request);
      case WORKER -> workerService.resetPasswordLink(request);
      case CLIENT -> clientService.resetPasswordLink(request);
      default -> throw new IllegalStateException("Unexpected value: " + request.getUserType());
    }

    return ResponseEntity.ok("OK");
  }

  /**
   * Creates a password reset link and send it by SMS.
   *
   * @param request {@link ResetUserPasswordSMSRequest}
   * @return String
   */
  @PostMapping("/password/reset/phone")
  @Operation(summary = "Creates a password reset link and send it by SMS")
  public ResponseEntity<String> resetPasswordSms(
          @RequestBody @Valid ResetUserPasswordSMSRequest request) {
    switch (requireNonNull(of(request.getUserType()))) {
      case EMPLOYEE -> appUserService.resetPasswordBySMS(request);
      case WORKER -> workerService.resetPasswordBySms(request);
      case CLIENT -> clientService.resetPasswordBySms(request);
      default -> throw new IllegalStateException("Unexpected value: " + request.getUserType());
    }

    return ResponseEntity.ok("OK");
  }

  @PutMapping("/password/verify/{temporaryLinkKey}")
  @Operation(summary = "Validate link check if its active and return reset passwd info")
  public ResponseEntity<TemporaryLink> resetPasswordVerify(@PathVariable String temporaryLinkKey) {
    return ResponseEntity.ok(temporaryLinkService.getTemporaryLink(temporaryLinkKey));
  }

  /**
   * Saves the new password for the User.
   *
   * @param temporaryLinkKey String
   * @param request          {@link ResetUserPasswordRequest}
   * @return ?
   */
  @PutMapping("/password/save/{temporaryLinkKey}")
  @Operation(summary = "Saves the new password for the User")
  public ResponseEntity<?> resetPasswordSave(
          @PathVariable String temporaryLinkKey,
          @RequestBody @Valid ResetUserPasswordRequest request) {
    switch (requireNonNull(of(request.getUserType()))) {
      case EMPLOYEE -> appUserService.savePassword(temporaryLinkKey, request);
      case WORKER -> workerService.savePassword(temporaryLinkKey, request);
      case CLIENT -> clientService.savePassword(temporaryLinkKey, request);
      default -> throw new IllegalStateException("Unexpected value: " + request.getUserType());
    }

    return ResponseEntity.ok().build();
  }
}
