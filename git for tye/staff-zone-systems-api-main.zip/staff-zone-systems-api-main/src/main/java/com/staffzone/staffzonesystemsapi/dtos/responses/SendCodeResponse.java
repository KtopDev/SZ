package com.staffzone.staffzonesystemsapi.dtos.responses;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class SendCodeResponse {
  private String code;

  @Override
  public String toString() {
    return String.join("",
            "SendCodeResponse{",
                    "code='", code, "'",
                    "}");
  }
}