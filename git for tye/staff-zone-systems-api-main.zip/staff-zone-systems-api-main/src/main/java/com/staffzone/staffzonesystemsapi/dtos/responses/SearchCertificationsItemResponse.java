package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Certifications Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchCertificationsItemResponse {
  @JsonSetter(value = "total_rows")
  private String totalRows;
  @JsonSetter(value = "branch_name")
  private String branch;
  @JsonSetter(value = "days_from_hire")
  private String daysHire;
  @JsonSetter(value = "is_overridable")
  private boolean isOverridable;
  @JsonSetter(value = "certification_id")
  private String certificationId;
  @JsonSetter(value = "certification_name")
  private String name;
  @JsonSetter(value = "certification_abreviation")
  private String abbreviation;
  @JsonSetter(value = "certification_description")
  private String description;
  @JsonSetter(value = "days_from_first_placement")
  private String daysFirstPlacement;
  @JsonSetter(value = "ocurrences")
  private String occurrences;
  @JsonSetter(value = "modified_at")
  private String lastUpdated;

  @JsonGetter("cant_dispatch_without")
  public boolean isOverridable() {
    return !isOverridable;
  }
}
