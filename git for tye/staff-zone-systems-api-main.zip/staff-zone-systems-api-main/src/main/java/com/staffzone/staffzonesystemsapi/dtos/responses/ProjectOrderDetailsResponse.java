package com.staffzone.staffzonesystemsapi.dtos.responses;

import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProjectOrderDetailsResponse {
    private String projectId;
    private String orderId;
    private String projectWorkerBasedBillingId;
    private String skillTier;
    private String description;
    private Integer numberOfWorkers;
    private Double hoursNeeded;
}
