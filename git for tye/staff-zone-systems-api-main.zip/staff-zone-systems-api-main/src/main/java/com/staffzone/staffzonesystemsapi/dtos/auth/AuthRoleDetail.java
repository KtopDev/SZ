package com.staffzone.staffzonesystemsapi.dtos.auth;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonSetter;
import java.util.List;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Role detail Dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class AuthRoleDetail {
  private List<UUID> branches;
  private List<String> roleClaims;
  private String role;

  @JsonSetter("role_claims")
  public void setRole_Claims(List<String> roleClaims) {
    this.roleClaims = roleClaims;
  }

  @JsonSetter("roleClaims")
  public void setRoleClaims(List<String> roleClaims) {
    this.roleClaims = roleClaims;
  }

  @JsonGetter("roleClaims")
  public List<String> getRoleClaims() {
    return roleClaims;
  }

}
