package com.staffzone.staffzonesystemsapi.bos;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * UserType: <br/>
 * {@link #EMPLOYEE},<br/>
 * {@link #CLIENT},<br/>
 * {@link #WORKER}.
 */
@Getter
@AllArgsConstructor
public enum UserType {
  EMPLOYEE("APP_USER"), CLIENT("CLIENT_CONTACT"), WORKER("WORKER");

  private final String actor;

  /**
   * Look up. Is case-sensitive
   *
   * @param str <strong>i.e:</strong> EMPLOYEE
   * @return <strong>i.e:</strong> EMPLOYEE <br><strong>It can return NULL</strong>
   */
  public static UserType of(String str) {
    for (UserType type : values()) {
      if (str.toUpperCase().equals(type.name())) {
        return type;
      }
    }

    return null;
  }
}
