package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Skills Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchSkillsItemResponse {
  @JsonSetter(value = "total_rows")
  private String totalRows;
  @JsonSetter(value = "skill_id")
  private String skillId;
  @JsonSetter(value = "skill_name")
  private String skillName;
  @JsonSetter(value = "branch_id")
  private String branchId;
  @JsonSetter(value = "branch_name")
  private String branchName;
  @JsonSetter(value = "skill_group")
  private String skillGroup;
  @JsonSetter(value = "skill_description")
  private String skillDescription;
  @JsonSetter(value = "modified_at")
  private String modifiedAt;
}
