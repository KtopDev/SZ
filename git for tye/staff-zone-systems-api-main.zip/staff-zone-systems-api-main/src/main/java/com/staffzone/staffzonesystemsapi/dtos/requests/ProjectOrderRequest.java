package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProjectOrderRequest {
  private LocalDateTime orderStartTs;
  private List<@Valid ProjectOrderDetailsRequest> projectOrderDetails;

  @SneakyThrows
  @JsonIgnore
  public String asJson() {
    ObjectMapper mapper = new ObjectMapper();
    ObjectNode jsonObject = mapper.createObjectNode();
    if (orderStartTs != null) {
      jsonObject.put("order_start_ts", orderStartTs.toString());
    }
    ArrayNode projectOrderDetailsArray = mapper.createArrayNode();
    for (ProjectOrderDetailsRequest detail : projectOrderDetails) {
      projectOrderDetailsArray.add(detail.asJsonNode(mapper));
    }
    jsonObject.set("project_order_details", projectOrderDetailsArray);

    return mapper.writeValueAsString(jsonObject);
  }
}
