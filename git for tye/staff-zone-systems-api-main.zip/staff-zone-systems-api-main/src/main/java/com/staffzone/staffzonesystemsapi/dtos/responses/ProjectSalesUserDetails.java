package com.staffzone.staffzonesystemsapi.dtos.responses;

import java.util.UUID;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Project Sales User DTO.
 */
@Data
@NoArgsConstructor
public class ProjectSalesUserDetails {
  private String name;
  private UUID userId;

  public void setAppUserId(UUID userId) {
    this.userId = userId;
  }
}
