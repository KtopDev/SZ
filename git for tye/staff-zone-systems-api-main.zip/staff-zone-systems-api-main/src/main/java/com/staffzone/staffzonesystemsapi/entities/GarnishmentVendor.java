package com.staffzone.staffzonesystemsapi.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.ColumnDefault;

@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "garnishment_vendors")
public class GarnishmentVendor extends Audit {
  @Id
  @Column(name = "vendor_id", nullable = false)
  private UUID id;

  @NotNull
  @ColumnDefault("true")
  @Column(name = "is_row_active", nullable = false)
  private Boolean isRowActive = false;

  @NotNull
  @Column(name = "vendor_tp_id", nullable = false, length = Integer.MAX_VALUE)
  private String vendorTpId;

  @NotNull
  @Column(name = "vendor_name_1", nullable = false, length = Integer.MAX_VALUE)
  private String vendorName1;

  @Column(name = "vendor_name_2", length = Integer.MAX_VALUE)
  private String vendorName2;

  @NotNull
  @Column(name = "contact_name", nullable = false, length = Integer.MAX_VALUE)
  private String contactName;

  @Size(max = 10)
  @NotNull
  @Column(name = "contact_phone", nullable = false, length = 10)
  private String contactPhone;

  @Size(max = 255)
  @NotNull
  @Column(name = "contact_email", nullable = false)
  private String contactEmail;

  @NotNull
  @Column(name = "address_1", nullable = false, length = Integer.MAX_VALUE)
  private String address1;

  @Column(name = "address_2", length = Integer.MAX_VALUE)
  private String address2;

  @NotNull
  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "state", nullable = false)
  private LkStates state;

  @Size(max = 50)
  @NotNull
  @Column(name = "city", nullable = false, length = 50)
  private String city;

  @Size(max = 10)
  @NotNull
  @Column(name = "postal_code", nullable = false, length = 10)
  private String postalCode;

}