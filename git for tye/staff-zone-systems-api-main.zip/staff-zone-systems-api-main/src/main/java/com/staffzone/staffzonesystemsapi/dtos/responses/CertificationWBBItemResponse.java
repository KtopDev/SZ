package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Skill Response from create and edit skill stored procedure.
 */
@Data
@NoArgsConstructor
public class CertificationWBBItemResponse {
  @JsonSetter(value = "certification_id")
  private String certificationId;
  @JsonSetter(value = "certification_name")
  private String certificationName;
}
