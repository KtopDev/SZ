package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.staffzone.staffzonesystemsapi.validators.Uuid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Remove Worker Request DTO.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RemoveWorkerRequest {
  @Uuid(message = "workerId cannot be null")
  private String workerId;
}
