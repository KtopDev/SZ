package com.staffzone.staffzonesystemsapi.controllers;

import com.staffzone.staffzonesystemsapi.services.PushNotificationService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/notifications")
public class NotificationController {

  private final PushNotificationService pushNotificationService;

  public NotificationController(PushNotificationService pushNotificationService) {
    this.pushNotificationService = pushNotificationService;
  }

  @PostMapping("/send")
  public String sendNotification(@RequestParam String title, @RequestParam String message, @RequestParam String tag) {
    try {
      pushNotificationService.sendNotification(title, message, tag);
      return "Notification sent successfully!";
    } catch (Exception e) {
      return "Failed to send notification: " + e.getMessage();
    }
  }
}
