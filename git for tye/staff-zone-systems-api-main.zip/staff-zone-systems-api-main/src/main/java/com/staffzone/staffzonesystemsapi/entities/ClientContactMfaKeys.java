package com.staffzone.staffzonesystemsapi.entities;

import com.staffzone.staffzonesystemsapi.entities.ids.ClientContactMfaKeysId;
import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;

/**
 * Client Contact MFA Key Entity.
 */
@Entity
@SuperBuilder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "client_contact_mfa_keys")
public class ClientContactMfaKeys extends Audit {
  @EmbeddedId
  private ClientContactMfaKeysId id;

  @Column(updatable = false, insertable = false)
  private final Boolean isRowActive = false;
}
