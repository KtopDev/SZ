package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.staffzone.staffzonesystemsapi.validators.Uuid;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * Tax Form Question Option Request DTO.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class TaxFormQuestionOptionRequest {
  @Uuid(enableNullValues = true)
  private String optionId;
  @NotBlank(message = "optionText cannot be null")
  private String optionText;

  public TaxFormQuestionOptionRequest(String optionText) {
    this.optionText = optionText;
  }

  /**
   * Build JSON.
   *
   * @param mapper {@link ObjectMapper}
   * @return {@link ObjectNode}
   */
  public ObjectNode asJsonNode(ObjectMapper mapper) {
    ObjectNode jsonObject = mapper.createObjectNode();
    jsonObject.put("option_id", optionId);
    jsonObject.put("option_text", optionText);
    return jsonObject;
  }
}
