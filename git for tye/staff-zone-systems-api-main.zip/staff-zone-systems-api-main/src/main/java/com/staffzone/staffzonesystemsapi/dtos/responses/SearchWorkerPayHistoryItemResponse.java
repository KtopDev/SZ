package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Worker Pay History Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchWorkerPayHistoryItemResponse {
  @JsonSetter(value = "status")
  private String status;
  @JsonSetter(value = "created_at")
  private String createdAt;
  @JsonSetter(value = "total_rows")
  private String totalRows;
  @JsonSetter(value = "status_by_name")
  private String statusByName;
}
