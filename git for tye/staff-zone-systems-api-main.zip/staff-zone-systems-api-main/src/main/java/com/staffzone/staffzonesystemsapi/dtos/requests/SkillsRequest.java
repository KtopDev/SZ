package com.staffzone.staffzonesystemsapi.dtos.requests;

import static java.util.UUID.fromString;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.staffzone.staffzonesystemsapi.validators.Uuid;
import jakarta.validation.constraints.NotBlank;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.minidev.json.JSONObject;
import org.hibernate.validator.constraints.Length;

/**
 * Skills Request.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SkillsRequest {
  @NotBlank(message = "Skill Name cannot be blank")
  private String skillsName;
  @Length(max = 300)
  @NotBlank(message = "Skill Description cannot be blank")
  private String skillsDescription;
  @NotBlank(message = "Skill Group cannot be blank")
  private String skillGroup;
  @Uuid(enableNullValues = true)
  private String branchId;

  @JsonIgnore
  public String getDataAsJson() {
    JSONObject jsonObject = new JSONObject();
    jsonObject.put("skill_name", this.skillsName);
    jsonObject.put("skill_description", this.skillsDescription);
    jsonObject.put("skill_group", this.skillGroup);
    jsonObject.put("branch_id", branchId);
    return jsonObject.toJSONString();
  }

  public UUID getBranchId() {
    if (branchId == null) {
      return null;
    }

    return fromString(branchId);
  }

}
