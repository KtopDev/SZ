package com.staffzone.staffzonesystemsapi.controllers;

import static com.staffzone.staffzonesystemsapi.bos.UserType.WORKER;
import static com.staffzone.staffzonesystemsapi.utils.Constants.WORKER_DOCUMENTS;
import static java.util.UUID.fromString;
import static java.util.UUID.randomUUID;
import static org.springframework.http.HttpHeaders.CONTENT_DISPOSITION;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.OK;
import static org.springframework.http.MediaType.APPLICATION_PDF_VALUE;
import static org.springframework.http.MediaType.MULTIPART_FORM_DATA_VALUE;

import com.staffzone.staffzonesystemsapi.dtos.RemoveWorkerDnrRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.AddWorkerDnrRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.AuthUserByCodeRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.AuthUserRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.CreateWorkerDisciplinaryFormRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.LoginKioskRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.MedicalQuestionnaireSendRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.NotificationRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.ResetUserPasswordLinkRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.ResetWorkerPasswordLinkRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchDispatchWorkerRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchWorkerDisciplinaryFormsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchWorkerDnrHistoryRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchWorkerDocumentHistoryRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchWorkerDocumentsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchWorkerNotesRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchWorkerPayHistoryRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchWorkerRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SearchWorkerTermsHistoryRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SelectedClientNotesRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.SelectedWorkerDisciplinaryFormsRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.WorkerCheckInMeRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.WorkerCheckInRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.WorkerCheckOutRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.WorkerCreateInternalRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.WorkerDocumentTypeRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.WorkerEditInternalRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.WorkerLoginRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.WorkerNoteRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.WorkerRegistrationCompleteRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.WorkerRegistrationRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.WorkerRegistrationUpdatePhoneRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.WorkerSickPayRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.WorkerVerifyRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.WorkerWithholdingsFormRequest;
import com.staffzone.staffzonesystemsapi.dtos.responses.AuthUserResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.LoginResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchDispatchWorkersResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchWorkerDisciplinaryFormsResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchWorkerDnrHistoryResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchWorkerDocumentHistoryResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchWorkerDocumentsResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchWorkerNotesResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchWorkerPayHistoryResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchWorkerTermsHistoryResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.SearchWorkersResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.WorkerAvailableSickHoursResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.WorkerDetailsResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.WorkerDisciplinaryFormResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.WorkerInternalResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.WorkerMedicalQuestionsResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.WorkerRegistrationCompleteResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.WorkerRegistrationResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.WorkerVerifyResponse;
import com.staffzone.staffzonesystemsapi.dtos.responses.WorkerWithHoldingsSummaryResponse;
import com.staffzone.staffzonesystemsapi.entities.ClientContact;
import com.staffzone.staffzonesystemsapi.entities.Worker;
import com.staffzone.staffzonesystemsapi.exceptions.BusinessException;
import com.staffzone.staffzonesystemsapi.services.WorkerDisciplinaryFormsService;
import com.staffzone.staffzonesystemsapi.services.WorkerDnrService;
import com.staffzone.staffzonesystemsapi.services.WorkerNotesService;
import com.staffzone.staffzonesystemsapi.services.WorkerService;
import com.staffzone.staffzonesystemsapi.validators.Uuid;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller for Workers Endpoints.
 */
@RequestMapping("/api/v1/workers")
@CrossOrigin("*")
@RestController
@AllArgsConstructor
public class WorkerController {
  private WorkerDnrService workerDnrService;
  private WorkerService workerService;
  private WorkerNotesService workerNotesService;
  private WorkerDisciplinaryFormsService workerDisciplinaryFormsService;

  @PostMapping("/registration/start")
  @Operation(summary = "Creates a Worker and returns verification code with worker guid")
  public ResponseEntity<WorkerRegistrationResponse> registrationStart(
          @RequestBody @Valid WorkerRegistrationRequest workerRequest) {
    WorkerRegistrationResponse worker = workerService.registrationStart(workerRequest);
    return new ResponseEntity<>(worker, OK);
  }

  @PostMapping("/registration/complete")
  @Operation(summary = "Completes the worker registration")
  public ResponseEntity<WorkerRegistrationCompleteResponse> registrationComplete(
          @RequestBody @Valid WorkerRegistrationCompleteRequest workerRequest) {
    WorkerRegistrationCompleteResponse worker = workerService.registrationComplete(workerRequest);
    return new ResponseEntity<>(worker, OK);
  }

  @PatchMapping("/{workerId}/registration")
  @Operation(summary = "Updates the phone number of an existing worker")
  public ResponseEntity<Void> updatePhone(
          @PathVariable UUID workerId,
          @RequestBody @Valid WorkerRegistrationUpdatePhoneRequest phoneUpdateRequest) {
    workerService.registrationUpdatePhone(workerId, phoneUpdateRequest);
    return ResponseEntity.ok().build();
  }

  //TODO refactoring to merge methods updatePhone and updatePhoneToDispatch
  @PatchMapping("/{workerId}/updatephone")
  @Operation(summary = "Updates the phone number as parte of Check for Dispatch - Step One")
  public ResponseEntity<Void> updatePhoneToDispatch(
          @PathVariable UUID workerId,
          @RequestBody @Valid WorkerRegistrationUpdatePhoneRequest phoneUpdateRequest) {
    workerService.registrationUpdatePhone(workerId, phoneUpdateRequest);
    return ResponseEntity.ok().build();
  }

  @PostMapping("/registration/verify")
  @Operation(summary = "Verify code with worker guid")
  public ResponseEntity<WorkerVerifyResponse> registrationVerify(
          @RequestBody @Valid WorkerVerifyRequest workerRequest) {
    WorkerVerifyResponse worker = workerService.registrationVerify(workerRequest);
    return new ResponseEntity<>(worker, OK);
  }

  @PostMapping("/login/send-code")
  @Operation(summary = "Send Login code")
  public ResponseEntity<AuthUserResponse> sendCode(
          @RequestBody @Valid WorkerLoginRequest workerLoginRequest) {
    AuthUserResponse response = workerService.loginCode(workerLoginRequest);
    return ResponseEntity.ok(response);
  }

  @PostMapping("/login/verify-code")
  @Operation(summary = "Enter Login code")
  public ResponseEntity<LoginResponse> verifyCode(
          @RequestBody @Valid AuthUserByCodeRequest verifyCodeDto) {
    LoginResponse response = workerService.verifyLoginCode(verifyCodeDto);
    return ResponseEntity.ok(response);
  }

  @PostMapping("/login-ka")
  public ResponseEntity<LoginResponse> loginKa(
          @RequestBody @Valid LoginKioskRequest request) {
    LoginResponse loginResponse = workerService.loginKa(request);
    return ResponseEntity.ok(loginResponse);
  }

  @PostMapping("/registration/resend-code")
  @Operation(summary = "Verify code with worker guid")
  public ResponseEntity<String> resendVerificationCode(
          @RequestBody @Valid AuthUserRequest workerRequest) {
    String worker = workerService.resendCodeVerification(workerRequest);
    return new ResponseEntity<>(worker, OK);
  }

  @PostMapping("/withholdings-settings")
  @Operation(summary = "Save worker's with-holdings settings")
  public ResponseEntity<String> saveWithholdingsForm(
          @AuthenticationPrincipal Worker worker,
          @RequestBody @Valid WorkerWithholdingsFormRequest request) {
    workerService.saveWithholdings(worker.getWorkerId(), request);
    return ResponseEntity.ok("With Holdings settings saved successfully");
  }

  @PutMapping("/{workerId}/withholdings-settings/lock")
  @Operation(summary = "Locks worker's with-holdings settings")
  public ResponseEntity<String> lockWithholdingsForm(@PathVariable UUID workerId) {
    workerService.setWithholdingsLock(workerId, true);
    return ResponseEntity.ok("With Holdings settings locked successfully");
  }

  @PutMapping("/{workerId}/withholdings-settings/unlock")
  @Operation(summary = "Unlocks worker's with-holdings settings")
  public ResponseEntity<String> unlockWithholdingsForm(@PathVariable UUID workerId) {
    workerService.setWithholdingsLock(workerId, false);
    return ResponseEntity.ok("With Holdings settings unlocked successfully");
  }

  @GetMapping("/{workerId}/withholdings-settings")
  @Operation(summary = "Return worker's with-holdings settings summary info")
  public ResponseEntity<WorkerWithHoldingsSummaryResponse> getWithHolding(
          @PathVariable UUID workerId) {
    WorkerWithHoldingsSummaryResponse summary = workerService.getApprovedWithHolding(workerId);
    return ResponseEntity.ok(summary);
  }

  @PostMapping
  @Operation(summary = "Creates a worker and returns worker info")
  public ResponseEntity<WorkerInternalResponse> createInternalWorker(
          @RequestBody @Valid WorkerCreateInternalRequest request,
          @AuthenticationPrincipal UserDetails user) {
    WorkerInternalResponse worker = null;
    if (user instanceof ClientContact clientContact) {
      request.setClientRestrictions(Collections.singletonList(clientContact.getClient().getId().toString()));
      worker = workerService.createInternalWorker(request, true);
    } else {
      worker = workerService.createInternalWorker(request, false);
    }
    return new ResponseEntity<>(worker, CREATED);
  }

  @PutMapping("/{workerId}")
  @Operation(summary = "Updates a worker and returns worker info")
  public ResponseEntity<WorkerInternalResponse> editInternalWorker(
          @PathVariable UUID workerId,
          @RequestBody @Valid WorkerEditInternalRequest request) {
    WorkerInternalResponse worker = workerService.editInternalWorker(workerId, request);
    return ResponseEntity.ok(worker);
  }

  @GetMapping
  @Operation(summary = "Search a Worker and returns list base on filters")
  public ResponseEntity<SearchWorkersResponse> findAll(@Valid SearchWorkerRequest request) {
    return ResponseEntity.ok(workerService.searchWorker(request));
  }

  @PostMapping("/reset-link")
  @Operation(summary = "Sends a link to reset password to workers email")
  public ResponseEntity<?> resetLink(
          @RequestBody @Valid ResetWorkerPasswordLinkRequest request) {
    ResetUserPasswordLinkRequest resetUserRequest = ResetUserPasswordLinkRequest.builder()
            .userType(WORKER.getActor())
            .email(request.getEmail())
            .build();
    workerService.sendResetPasswordLinkEmail(resetUserRequest);
    return new ResponseEntity<>(OK);
  }

  @GetMapping("/{workerId}")
  @Operation(summary = "Search for a worker and return details of this")
  public ResponseEntity<WorkerDetailsResponse> findWorker(@PathVariable UUID workerId) {
    return ResponseEntity.ok(workerService.workerDetails(workerId));
  }

  @PostMapping("/{workerId}/text")
  @Operation(summary = "Send Text Notification")
  public ResponseEntity<String> sendNotification(@PathVariable UUID workerId,
                                                 @RequestBody @Valid NotificationRequest request) {
    return ResponseEntity.ok(workerService.sendNotification(workerId, request));
  }

  @PutMapping("/{workerId}/terminate")
  @Operation(summary = "Terminate a worker")
  public ResponseEntity<String> terminate(@PathVariable UUID workerId) {
    return ResponseEntity.ok(workerService.terminate(workerId));
  }

  @DeleteMapping("/{workerId}/documents/{documentId}")
  @Operation(summary = "Deletes a document history")
  public ResponseEntity<String> deleteDocumentHistory(@PathVariable UUID workerId,
                                                      @PathVariable UUID documentId) {
    return ResponseEntity.ok(workerService.deleteWorkerDocumentHistory(workerId, documentId));
  }

  @GetMapping("/{workerId}/document-history")
  @Operation(summary = "Search a document history")
  public ResponseEntity<SearchWorkerDocumentHistoryResponse> searchDocumentHistory(
          @PathVariable UUID workerId,
          @Valid SearchWorkerDocumentHistoryRequest request) {
    return ResponseEntity.ok(workerService.searchWorkerDocumentHistory(workerId, request));
  }

  @GetMapping("/{workerId}/documents")
  @Operation(summary = "Search for worker documents and return a list based on filters")
  public ResponseEntity<SearchWorkerDocumentsResponse> searchWorkerDocument(
          @PathVariable UUID workerId,
          @Valid SearchWorkerDocumentsRequest request) {
    return ResponseEntity.ok(workerService.searchWorkerDocuments(workerId, request));
  }

  @GetMapping("/{workerId}/terms")
  @Operation(summary = "Get Worker Terms and Conditions History")
  public ResponseEntity<SearchWorkerTermsHistoryResponse> getTermsHistory(
          @PathVariable UUID workerId,
          @Valid SearchWorkerTermsHistoryRequest workerTermsRequest) {
    return ResponseEntity.ok(workerService.getTermsHistory(workerId, workerTermsRequest));
  }

  @PostMapping("/{workerId}/dnr")
  @Operation(summary = "Add Worker Do Not Repeat Record")
  public ResponseEntity<String> addDnr(@PathVariable UUID workerId,
                                       @RequestBody @Valid AddWorkerDnrRequest request) {
    return ResponseEntity.ok(workerDnrService.addDnr(workerId, request));
  }

  @DeleteMapping("/dnr/{dnrId}")
  @Operation(summary = "Remove Worker Do Not Repeat")
  public ResponseEntity<String> removeDnr(@PathVariable @Uuid String dnrId,
                                          @RequestBody @Valid RemoveWorkerDnrRequest request) {
    return ResponseEntity.ok(workerDnrService.removeDnr(fromString(dnrId), request));
  }

  @GetMapping("/{workerId}/pay")
  @Operation(summary = "Get Worker Pay History")
  public ResponseEntity<SearchWorkerPayHistoryResponse> getPayHistory(
          @PathVariable String workerId,
          @Valid SearchWorkerPayHistoryRequest request) {
    return ResponseEntity.ok(workerService.getPayHistory(fromString(workerId), request));
  }

  @GetMapping("/{workerId}/dnr")
  @Operation(summary = "Get Worker Do Not Repeat History")
  public ResponseEntity<SearchWorkerDnrHistoryResponse> getDnrHistory(
          @PathVariable UUID workerId,
          @Valid SearchWorkerDnrHistoryRequest request) {
    return ResponseEntity.ok(workerService.getDnrHistory(workerId, request));
  }

  @PostMapping("/{workerId}/disciplinary-forms")
  @Operation(summary = "Save worker's disciplinary form")
  public ResponseEntity<String> saveDisciplinaryForm(
          @PathVariable UUID workerId,
          @RequestBody @Valid CreateWorkerDisciplinaryFormRequest request) {
    String result = workerDisciplinaryFormsService.createDisciplinaryForm(workerId, request);
    return new ResponseEntity<>(result, CREATED);
  }

  @GetMapping("/{workerId}/disciplinary-forms")
  @Operation(summary = "Get Worker Disciplinary Forms")
  public ResponseEntity<SearchWorkerDisciplinaryFormsResponse> getDisciplinaryForms(
          @PathVariable UUID workerId,
          @Valid SearchWorkerDisciplinaryFormsRequest request) {
    return ResponseEntity.ok(workerDisciplinaryFormsService
            .getDisciplinaryForms(workerId, request));
  }


  @GetMapping("/{workerId}/disciplinary-forms/{disciplinaryFormId}")
  @Operation(summary = "Get a single Worker Disciplinary Form")
  public ResponseEntity<WorkerDisciplinaryFormResponse> findDisciplinaryForm(
          @PathVariable UUID workerId,
          @PathVariable UUID disciplinaryFormId) {
    return ResponseEntity.ok(workerDisciplinaryFormsService
            .findDisciplinaryForm(disciplinaryFormId, workerId));
  }

  @DeleteMapping("/{workerId}/disciplinary-forms/{disciplinaryFormId}")
  @Operation(summary = "Deletes a worker disciplinary form")
  public ResponseEntity<String> deleteDisciplinaryForm(@PathVariable UUID workerId,
                                                       @PathVariable UUID disciplinaryFormId) {
    return ResponseEntity.ok(workerDisciplinaryFormsService
            .deleteDisciplinaryForm(workerId, disciplinaryFormId));
  }

  @GetMapping("/{workerId}/medical-questions")
  @Operation(summary = "List the medical questions for a worker")
  public ResponseEntity<List<WorkerMedicalQuestionsResponse>> medicalQuestionsList(
          @PathVariable UUID workerId) {
    return ResponseEntity.ok(workerService.medicalQuestionsList(workerId));
  }

  @PostMapping(path = "/{workerId}/upload-document", consumes = {MULTIPART_FORM_DATA_VALUE})
  @Operation(summary = "Upload document")
  public ResponseEntity<String> uploadDocument(@PathVariable UUID workerId,
                                               @ModelAttribute
                                               @Valid WorkerDocumentTypeRequest request) {
    UUID id = randomUUID();
    URI uri = workerService.loadDocument(
            WORKER_DOCUMENTS,
            id.toString() + "-" + request.getDocument().getName(),
            request.getDocument());
    return ResponseEntity.ok(workerService.saveDocument(
            uri,
            request,
            workerId));
  }

  @PostMapping("/{workerId}/notes")
  @Operation(summary = "Add Worker Note Record")
  public ResponseEntity<String> addWorkerNote(@PathVariable UUID workerId,
                                              @RequestBody @Valid WorkerNoteRequest request) {
    return ResponseEntity.ok(workerNotesService.addWorkerNote(workerId, request));
  }

  @PutMapping("/{workerId}/notes/{noteId}")
  @Operation(summary = "Edit Worker Note Record")
  public ResponseEntity<String> editWorkerNote(@PathVariable UUID workerId,
                                               @PathVariable UUID noteId,
                                               @RequestBody @Valid WorkerNoteRequest request) {
    return ResponseEntity.ok(workerNotesService.editWorkerNote(workerId, noteId, request));
  }

  @DeleteMapping("/{workerId}/notes/{noteId}")
  @Operation(summary = "Deletes a worker note")
  public ResponseEntity<String> deleteWorkerNote(@PathVariable UUID workerId,
                                                 @PathVariable UUID noteId) {
    return ResponseEntity.ok(workerNotesService.deleteWorkerNote(workerId, noteId));
  }

  @GetMapping("/{workerId}/note")
  @Operation(summary = "Search Worker Notes")
  public ResponseEntity<SearchWorkerNotesResponse> searchWorkerNotes(
          @PathVariable UUID workerId,
          @Valid SearchWorkerNotesRequest request) {
    return ResponseEntity.ok(workerNotesService.searchWorkerNotes(workerId, request));
  }

  @PostMapping("/{workerId}/medical-questionnaire/request")
  @Operation(summary = "Send request to worker to complete medical questionnaire")
  public ResponseEntity<String> medicalQuestionnaireRequest(
          @PathVariable UUID workerId,
          @RequestBody @Valid MedicalQuestionnaireSendRequest request) {
    return ResponseEntity.ok(workerService.medicalQuestionnaireRequest(workerId, request));
  }

  @GetMapping("/dispatch/search")
  @Operation(summary = "Search Worker Dispatch")
  public ResponseEntity<SearchDispatchWorkersResponse> searchDispatchWorker(
          @Valid SearchDispatchWorkerRequest request) {
    return ResponseEntity.ok(workerService.searchDispatchWorker(request));
  }

  @PostMapping("/{workerId}/check-in")
  @Operation(summary = "Check-In Worker")
  public ResponseEntity<String> workerCheckIn(@PathVariable @Uuid String workerId,
                                              @RequestBody @Valid WorkerCheckInRequest request) {
    return ResponseEntity.ok(workerService.checkin(workerId, request));
  }

  @PutMapping("/{workerId}/check-out")
  @Operation(summary = "Check-Out Worker")
  public ResponseEntity<String> workerCheckOut(@PathVariable @Uuid String workerId,
                                               @RequestBody @Valid WorkerCheckOutRequest branchId) {
    return ResponseEntity.ok(workerService.checkout(workerId, branchId));
  }

  @PostMapping("/me/check-in")
  @Operation(summary = "Check-In Me")
  public ResponseEntity<String> workerMeCheckIn(@AuthenticationPrincipal Worker worker,
                                                @RequestBody @Valid WorkerCheckInMeRequest request) {
    return ResponseEntity.ok(workerService.meCheckin(worker.getWorkerId(), request));
  }

  @PostMapping("/me/sick-pay")
  @Operation(summary = "Request sick pay")
  public ResponseEntity<String> requestSickPay(@AuthenticationPrincipal Worker worker,
                                               @RequestBody @Valid WorkerSickPayRequest request) {
    if (worker == null) {
      throw new BusinessException("workerId", "Wrong userType, user is not a worker");
    }
    return ResponseEntity.ok(workerService.requestSickPay(worker.getWorkerId(), request));
  }

  @GetMapping("/me/available-sick-hours")
  @Operation(summary = "Get worker available sick hours")
  public ResponseEntity<WorkerAvailableSickHoursResponse> requestSickPay(@AuthenticationPrincipal Worker worker) {
    if (worker == null) {
      throw new BusinessException("workerId", "Wrong userType, user is not a worker");
    }
    return ResponseEntity.ok(workerService.getAvailableHoursForSickPayRequest(worker.getWorkerId()));
  }

  /**
   * Export Worker Disciplinary forms to PDF.
   *
   * @param request {@link SelectedClientNotesRequest}
   * @return byte[]
   */
  @Operation(summary = "Export Worker Disciplinary forms to PDF")
  @PostMapping(value = "/disciplinary-forms/export")
  public ResponseEntity<byte[]> downloadWorkerDisciplinaryFormsPdf(
          @RequestBody @Valid SelectedWorkerDisciplinaryFormsRequest request) {
    return ResponseEntity.ok()
            .header(CONTENT_TYPE, APPLICATION_PDF_VALUE)
            .header(CONTENT_DISPOSITION,
                    "attachment; filename=worker_disciplinary_forms.pdf")
            .body(workerDisciplinaryFormsService.createDisciplinaryFormPdf(request.getDisciplinaryIds()));
  }
}