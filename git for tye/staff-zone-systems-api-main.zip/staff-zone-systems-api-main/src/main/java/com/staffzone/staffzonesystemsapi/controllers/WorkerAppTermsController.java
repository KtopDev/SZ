package com.staffzone.staffzonesystemsapi.controllers;

import static org.springframework.http.MediaType.MULTIPART_FORM_DATA_VALUE;
import static org.springframework.http.ResponseEntity.ok;

import com.staffzone.staffzonesystemsapi.dtos.requests.UpdateWorkerAppTermRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.UpdateWorkerTermsOrderRequest;
import com.staffzone.staffzonesystemsapi.dtos.requests.WorkerAppTermsRequest;
import com.staffzone.staffzonesystemsapi.dtos.responses.WorkerAppTermsResponse;
import com.staffzone.staffzonesystemsapi.entities.WorkerAppTerm;
import com.staffzone.staffzonesystemsapi.services.WorkerAppTermsService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import java.util.UUID;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Worker App Terms Controller.
 */
@RequestMapping("/api/v1/worker-app-terms")
@CrossOrigin("*")
@RestController
@AllArgsConstructor
public class WorkerAppTermsController {
  private WorkerAppTermsService workerTermsService;

  @GetMapping
  @Operation(description = "Get Worker App Terms")
  public ResponseEntity<WorkerAppTermsResponse> getLegalTerms() {
    return ok(workerTermsService.findActives());
  }

  @PostMapping(consumes = {MULTIPART_FORM_DATA_VALUE})
  @Operation(description = "Add new Worker App Terms")
  public ResponseEntity<WorkerAppTermsResponse> addWorkerAppTerms(
          @ModelAttribute @Valid WorkerAppTermsRequest request) {
    return ok(workerTermsService.save(request));
  }

  /**
   * Updates Worker App Terms.
   *
   * @param workerAppTermId UUID
   * @param request         {@link WorkerAppTermsRequest}
   * @return List of {@link WorkerAppTermsResponse}
   */
  @PatchMapping(consumes = {MULTIPART_FORM_DATA_VALUE}, value = "/{workerAppTermId}")
  @Operation(description = "Update Worker App Terms")
  public ResponseEntity<WorkerAppTerm> updateWorkerAppTerms(
          @PathVariable("workerAppTermId") UUID workerAppTermId,
          @ModelAttribute @Valid UpdateWorkerAppTermRequest request) {
    return ok(workerTermsService.update(workerAppTermId, request));
  }

  @DeleteMapping("/{workerAppTermId}")
  @Operation(summary = "Delete a Worker app Term ")
  public ResponseEntity<WorkerAppTerm> deleteWorkerAppTerms(
          @PathVariable("workerAppTermId") UUID workerAppTermId) {
    return ok(workerTermsService.delete(workerAppTermId));
  }

  @PutMapping("/update-order")
  @Operation(summary = "Update Worker App Terms order")
  public void updateWorkerTermsOrder(@RequestBody UpdateWorkerTermsOrderRequest request) {
    workerTermsService.updateWorkerTermsOrder(request);
  }
}
