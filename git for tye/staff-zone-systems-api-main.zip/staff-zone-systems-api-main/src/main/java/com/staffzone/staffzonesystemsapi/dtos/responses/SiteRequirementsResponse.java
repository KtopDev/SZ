package com.staffzone.staffzonesystemsapi.dtos.responses;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

/**
 * DTO mapped against "<strong>site_requirements</strong>" Table.
 */
@SuperBuilder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SiteRequirementsResponse {
  private UUID siteRequirementId;
  private String siteRequirementName;
  private String siteRequirementDescription;
  private UUID branchId;
}
