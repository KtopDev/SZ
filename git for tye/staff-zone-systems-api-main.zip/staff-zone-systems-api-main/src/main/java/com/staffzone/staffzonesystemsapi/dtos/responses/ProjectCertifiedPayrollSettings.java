package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.UUID;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
@Setter
public class ProjectCertifiedPayrollSettings {
    private UUID projectId;
    private String jobName;
    private UUID printingFormatId;
    private String contactPhone;
    private String payrollReport;
    private String payrollNumber;
    private String wageDecisionNumber;
    private String address;
    private String addressLine2;
    private String city;
    private String state;
    private String postalCode;
    private String phone;
    private String fax;

}