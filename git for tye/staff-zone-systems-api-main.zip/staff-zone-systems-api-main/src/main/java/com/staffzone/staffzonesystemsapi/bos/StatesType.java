package com.staffzone.staffzonesystemsapi.bos;

import lombok.Getter;

/**
 * StatusType: <br/>
 * {@link #ALABAMA},<br/>
 * {@link #ALASKA},<br/>
 * {@link #ARIZONA},<br/>
 * {@link #ARKANSAS},<br/>
 * {@link #CALIFORNIA},<br/>
 * {@link #COLORADO},<br/>
 * {@link #CONNECTICUT},<br/>
 * {@link #DELAWARE},<br/>
 * {@link #FLORIDA},<br/>
 * {@link #GEORGIA},<br/>
 * {@link #HAWAII},<br/>
 * {@link #IDAHO},<br/>
 * {@link #ILLINOIS},<br/>
 * {@link #INDIANA},<br/>
 * {@link #IOWA},<br/>
 * {@link #KANSAS},<br/>
 * {@link #KENTUCKY},<br/>
 * {@link #LOUISIANA},<br/>
 * {@link #MAINE},<br/>
 * {@link #MARYLAND},<br/>
 * {@link #MASSACHUSETTS},<br/>
 * {@link #MICHIGAN},<br/>
 * {@link #MINNESOTA},<br/>
 * {@link #MISSISSIPPI},<br/>
 * {@link #MISSOURI},<br/>
 * {@link #MONTANA},<br/>
 * {@link #NEBRASKA},<br/>
 * {@link #NEVADA},<br/>
 * {@link #NEW_HAMPSHIRE},<br/>
 * {@link #NEW_JERSEY},<br/>
 * {@link #NEW_MEXICO},<br/>
 * {@link #NEW_YORK},<br/>
 * {@link #NORTH_CAROLINA},<br/>
 * {@link #NORTH_DAKOTA},<br/>
 * {@link #OHIO},<br/>
 * {@link #OKLAHOMA},<br/>
 * {@link #OREGON},<br/>
 * {@link #PENNSYLVANIA},<br/>
 * {@link #RHODE_ISLAND},<br/>
 * {@link #SOUTH_CAROLINA},<br/>
 * {@link #SOUTH_DAKOTA},<br/>
 * {@link #TENNESSEE},<br/>
 * {@link #TEXAS},<br/>
 * {@link #UTAH},<br/>
 * {@link #VERMONT},<br/>
 * {@link #VIRGINIA},<br/>
 * {@link #WASHINGTON},<br/>
 * {@link #WEST_VIRGINIA},<br/>
 * {@link #WISCONSIN},<br/>
 * {@link #WYOMING}.
 */
@Getter
public enum StatesType {
  ALABAMA("AL"),
  ALASKA("AK"),
  ARIZONA("AZ"),
  ARKANSAS("AR"),
  CALIFORNIA("CA"),
  COLORADO("CO"),
  CONNECTICUT("CT"),
  DELAWARE("DE"),
  FLORIDA("FL"),
  GEORGIA("GA"),
  HAWAII("HI"),
  IDAHO("ID"),
  ILLINOIS("IL"),
  INDIANA("IN"),
  IOWA("IA"),
  KANSAS("KS"),
  KENTUCKY("KY"),
  LOUISIANA("LA"),
  MAINE("ME"),
  MARYLAND("MD"),
  MASSACHUSETTS("MA"),
  MICHIGAN("MI"),
  MINNESOTA("MN"),
  MISSISSIPPI("MS"),
  MISSOURI("MO"),
  MONTANA("MT"),
  NEBRASKA("NE"),
  NEVADA("NV"),
  NEW_HAMPSHIRE("NH"),
  NEW_JERSEY("NJ"),
  NEW_MEXICO("NM"),
  NEW_YORK("NY"),
  NORTH_CAROLINA("NC"),
  NORTH_DAKOTA("ND"),
  OHIO("OH"),
  OKLAHOMA("OK"),
  OREGON("OR"),
  PENNSYLVANIA("PA"),
  RHODE_ISLAND("RI"),
  SOUTH_CAROLINA("SC"),
  SOUTH_DAKOTA("SD"),
  TENNESSEE("TN"),
  TEXAS("TX"),
  UTAH("UT"),
  VERMONT("VT"),
  VIRGINIA("VA"),
  WASHINGTON("WA"),
  WEST_VIRGINIA("WV"),
  WISCONSIN("WI"),
  WYOMING("WY");

  private final String abbreviation;

  StatesType(String abbreviation) {
    this.abbreviation = abbreviation;
  }
}
