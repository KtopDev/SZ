package com.staffzone.staffzonesystemsapi.dtos.requests;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonSetter;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CertificationRequest {
  @NotBlank(message = "Certification Name cannot be blank")
  private String certificationName;
  @NotBlank(message = "Certification Abbreviation cannot be blank")
  private String certificationAbbreviation;
  @NotBlank(message = "Certification Description cannot be blank")
  private String certificationDescription;
  @NotNull(message = "Can't dispatch without this requirement cannot be null")
  private Boolean cantDispatchWithout;
  @Positive(message = "Days from hire must be positive")
  private Integer daysFromHire;
  @Positive(message = "Days from first placement must be positive")
  private Integer daysFromFirstPlacement;
  private UUID branchId;

  @JsonGetter("certification_abreviation")
  public String getCertificationAbbreviation() {
    return certificationAbbreviation;
  }

  @JsonSetter("certificationAbbreviation")
  public void setCertificationAbbreviation(String certificationAbbreviation) {
    this.certificationAbbreviation = certificationAbbreviation;
  }

  @JsonGetter("is_overridable")
  public Boolean getCantDispatchWithout() {
    return cantDispatchWithout;
  }

  @JsonSetter("cantDispatchWithout")
  public void setCantDispatchWithout(Boolean cantDispatchWithout) {
    this.cantDispatchWithout = cantDispatchWithout;
  }
}
