package com.staffzone.staffzonesystemsapi.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;

/**
 * Entity mapped against "<strong>LkProjectDocumentType</strong>" Table.
 */
@Entity
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@FieldNameConstants
@Table(name = "lk_project_document_types")
public class LkProjectDocumentType {
  @Id
  @Column(name = "document_type")
  private String documentType;
  @Column(name = "document_type_name")
  private String documentTypeName;
  @Column(name = "is_client_visible")
  private Boolean isClientVisible;
  @Column(name = "is_row_active")
  private Boolean isRowActive;

}
