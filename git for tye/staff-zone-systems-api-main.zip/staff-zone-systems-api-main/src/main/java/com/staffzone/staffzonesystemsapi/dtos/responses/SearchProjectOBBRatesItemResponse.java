package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonSetter;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Search Projects WBB Rates Item Response DTO.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SearchProjectOBBRatesItemResponse {
  @JsonSetter(value = "total_rows")
  private String totalRows;
  @JsonSetter(value = "project_order_based_billing_id")
  private String projectOrderBasedBillingId;
  @JsonSetter(value = "name")
  private String name;
  @JsonSetter(value = "status")
  private String status;
  @JsonSetter(value = "bill_rate")
  private String billRate;
  @JsonSetter(value = "frequency")
  private String frequency;
  @JsonSetter(value = "applied_per")
  private String appliedPer;
  @JsonSetter(value = "description")
  private String description;
  @JsonSetter(value = "bill_code_id")
  private String billCodeId;
  @JsonSetter(value = "bill_code_name")
  private String billCodeName;
}