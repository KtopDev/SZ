package com.staffzone.staffzonesystemsapi.dtos.responses;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * In Use Branch Response Dto.
 * <pre>{@code
 *    {
 *      "branch_id":   "string",
 *      "branch_code": "string",
 *      "branch_name": "string"
 *    }
 * }</pre>
 */
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@SuppressWarnings("checkstyle:MemberName")
public class InUseBranchResponse {
  private String branch_id;
  private String branch_code;
  private String branch_name;
}
