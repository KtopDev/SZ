package com.staffzone.staffzonesystemsapi.bos;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * StatusType: <br/>
 * {@link #SINGLE},<br/>
 * {@link #MARRIED_JOINTLY},<br/>
 * {@link #MARRIED_SEPARATELY},<br/>
 * {@link #HEAD_OF_HOUSEHOLD},<br/>
 * {@link #QUALIFYING_WIDOW}.
 */
@Getter
@AllArgsConstructor
public enum ConcubinageStatusType {
  SINGLE,
  MARRIED_JOINTLY,
  MARRIED_SEPARATELY,
  HEAD_OF_HOUSEHOLD,
  QUALIFYING_WIDOW;

}
