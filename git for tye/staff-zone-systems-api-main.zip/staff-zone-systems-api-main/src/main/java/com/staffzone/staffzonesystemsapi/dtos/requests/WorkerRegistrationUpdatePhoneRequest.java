package com.staffzone.staffzonesystemsapi.dtos.requests;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * Worker Update Phone Request DTO.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class WorkerRegistrationUpdatePhoneRequest {
    @NotBlank(message = "Phone cannot be blank")
    @Pattern(regexp = "^\\d{10}", message = "Phone must have 10 digits")
    private String phone;
}
