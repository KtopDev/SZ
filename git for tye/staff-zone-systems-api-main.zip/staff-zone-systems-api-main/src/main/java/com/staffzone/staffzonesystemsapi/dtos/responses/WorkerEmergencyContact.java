package com.staffzone.staffzonesystemsapi.dtos.responses;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Worker Emergency Contact response Dto.
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class WorkerEmergencyContact {
  @JsonAlias("contact_id")
  private String contactId;
  @JsonAlias("name")
  private String name;
  @JsonAlias("phone")
  private String phone;
  @JsonAlias("relationship")
  private String relationship;

}
